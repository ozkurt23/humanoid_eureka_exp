
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AdvApprox_Cutting.hxx>
#include <AdvApp2Var_Criterion.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AdvApp2Var_Patch.hxx>
#include <AdvApp2Var_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AdvApp2Var_Context.hxx>
#include <AdvApp2Var_Node.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AdvApp2Var_Context.hxx>
#include <AdvApp2Var_Framework.hxx>
#include <AdvApp2Var_Criterion.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <AdvApp2Var_ApproxAFunc2Var.hxx>
#include <AdvApp2Var_ApproxF2var.hxx>
#include <AdvApp2Var_Context.hxx>
#include <AdvApp2Var_Criterion.hxx>
#include <AdvApp2Var_CriterionRepartition.hxx>
#include <AdvApp2Var_CriterionType.hxx>
#include <AdvApp2Var_EvaluatorFunc2Var.hxx>
#include <AdvApp2Var_Framework.hxx>
#include <AdvApp2Var_Iso.hxx>
#include <AdvApp2Var_MathBase.hxx>
#include <AdvApp2Var_Network.hxx>
#include <AdvApp2Var_Node.hxx>
#include <AdvApp2Var_Patch.hxx>
#include <AdvApp2Var_SysBase.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AdvApp2Var(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("AdvApp2Var"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_AdvApp2Var_Criterion : public AdvApp2Var_Criterion{
    public:
        using AdvApp2Var_Criterion::AdvApp2Var_Criterion;


        // public pure virtual
        void Value(AdvApp2Var_Patch & P, const AdvApp2Var_Context & C) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AdvApp2Var_Criterion,Value,P,C) };
        bool IsSatisfied( const AdvApp2Var_Patch & P) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AdvApp2Var_Criterion,IsSatisfied,P) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_AdvApp2Var_EvaluatorFunc2Var : public AdvApp2Var_EvaluatorFunc2Var{
    public:
        using AdvApp2Var_EvaluatorFunc2Var::AdvApp2Var_EvaluatorFunc2Var;


        // public pure virtual
        void Evaluate(int * theDimension,double * theUStartEnd,double * theVStartEnd,int * theFavorIso,double * theConstParam,int * theNbParams,double * theParameters,int * theUOrder,int * theVOrder,double * theResult,int * theErrorCode) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AdvApp2Var_EvaluatorFunc2Var,Evaluate,theDimension,theUStartEnd,theVStartEnd,theFavorIso,theConstParam,theNbParams,theParameters,theUOrder,theVOrder,theResult,theErrorCode) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class AdvApp2Var_ApproxAFunc2Var from ./opencascade/AdvApp2Var_ApproxAFunc2Var.hxx
    klass = m.attr("AdvApp2Var_ApproxAFunc2Var");


    // nested enums

    static_cast<py::class_<AdvApp2Var_ApproxAFunc2Var , shared_ptr<AdvApp2Var_ApproxAFunc2Var>  >>(klass)
    // constructors
        .def(py::init<  const int, const int, const int, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> &, const double, const double, const double, const double, const GeomAbs_IsoType, const GeomAbs_Shape, const GeomAbs_Shape, const int, const int, const int, const int, const AdvApp2Var_EvaluatorFunc2Var &,AdvApprox_Cutting &,AdvApprox_Cutting & >()  , py::arg("Num1DSS"),  py::arg("Num2DSS"),  py::arg("Num3DSS"),  py::arg("OneDTol"),  py::arg("TwoDTol"),  py::arg("ThreeDTol"),  py::arg("OneDTolFr"),  py::arg("TwoDTolFr"),  py::arg("ThreeDTolFr"),  py::arg("FirstInU"),  py::arg("LastInU"),  py::arg("FirstInV"),  py::arg("LastInV"),  py::arg("FavorIso"),  py::arg("ContInU"),  py::arg("ContInV"),  py::arg("PrecisCode"),  py::arg("MaxDegInU"),  py::arg("MaxDegInV"),  py::arg("MaxPatch"),  py::arg("Func"),  py::arg("UChoice"),  py::arg("VChoice") )
        .def(py::init<  const int, const int, const int, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> &, const double, const double, const double, const double, const GeomAbs_IsoType, const GeomAbs_Shape, const GeomAbs_Shape, const int, const int, const int, const int, const AdvApp2Var_EvaluatorFunc2Var &, const AdvApp2Var_Criterion &,AdvApprox_Cutting &,AdvApprox_Cutting & >()  , py::arg("Num1DSS"),  py::arg("Num2DSS"),  py::arg("Num3DSS"),  py::arg("OneDTol"),  py::arg("TwoDTol"),  py::arg("ThreeDTol"),  py::arg("OneDTolFr"),  py::arg("TwoDTolFr"),  py::arg("ThreeDTolFr"),  py::arg("FirstInU"),  py::arg("LastInU"),  py::arg("FirstInV"),  py::arg("LastInV"),  py::arg("FavorIso"),  py::arg("ContInU"),  py::arg("ContInV"),  py::arg("PrecisCode"),  py::arg("MaxDegInU"),  py::arg("MaxDegInV"),  py::arg("MaxPatch"),  py::arg("Func"),  py::arg("Crit"),  py::arg("UChoice"),  py::arg("VChoice") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<bool (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::IsDone),
             R"#(True if the approximation succeeded within the imposed tolerances and the wished continuities)#" 
          )
        .def("HasResult",
             (bool (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<bool (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::HasResult),
             R"#(True if the approximation did come out with a result that is not NECESSARELY within the required tolerance or a result that is not recognized with the wished continuities)#" 
          )
        .def("Surface",
             (handle<Geom_BSplineSurface> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<Geom_BSplineSurface> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::Surface),
             R"#(returns the BSplineSurface of range Index)#"  , py::arg("Index")
          )
        .def("UDegree",
             (int (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::UDegree),
             R"#()#" 
          )
        .def("VDegree",
             (int (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::VDegree),
             R"#()#" 
          )
        .def("NumSubSpaces",
             (int (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::NumSubSpaces),
             R"#()#"  , py::arg("Dimension")
          )
        .def("MaxError",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::MaxError),
             R"#(returns the errors max)#"  , py::arg("Dimension")
          )
        .def("AverageError",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::AverageError),
             R"#(returns the average errors)#"  , py::arg("Dimension")
          )
        .def("UFrontError",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::UFrontError),
             R"#(returns the errors max on UFrontiers Warning: Dimension must be equal to 3.)#"  , py::arg("Dimension")
          )
        .def("VFrontError",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::VFrontError),
             R"#(returns the errors max on VFrontiers Warning: Dimension must be equal to 3.)#"  , py::arg("Dimension")
          )
        .def("MaxError",
             (double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::MaxError),
             R"#(returns the error max of the BSplineSurface of range Index)#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("AverageError",
             (double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::AverageError),
             R"#(returns the average error of the BSplineSurface of range Index)#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("UFrontError",
             (double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::UFrontError),
             R"#(returns the error max of the BSplineSurface of range Index on a UFrontier)#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("VFrontError",
             (double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::VFrontError),
             R"#(returns the error max of the BSplineSurface of range Index on a VFrontier)#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("CritError",
             (double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_ApproxAFunc2Var::*)(  const int ,   const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::CritError),
             R"#()#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("Dump",
             (void (AdvApp2Var_ApproxAFunc2Var::*)( Standard_OStream &  ) const) static_cast<void (AdvApp2Var_ApproxAFunc2Var::*)( Standard_OStream &  ) const>(&AdvApp2Var_ApproxAFunc2Var::Dump),
             R"#(Prints on the stream 'o' information on the current state of the object.)#"  , py::arg("o")
          )
        .def("IsDone",
             (bool (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<bool (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::IsDone),
             R"#(True if the approximation succeeded within the imposed tolerances and the wished continuities)#" 
          )
        .def("HasResult",
             (bool (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<bool (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::HasResult),
             R"#(True if the approximation did come out with a result that is not NECESSARELY within the required tolerance or a result that is not recognized with the wished continuities)#" 
          )
        .def("Surface",
             (handle<Geom_BSplineSurface> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<handle<Geom_BSplineSurface> (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::Surface),
             R"#(returns the BSplineSurface of range Index)#"  , py::arg("SSPIndex")
          )
        .def("UDegree",
             (int (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::UDegree),
             R"#()#" 
          )
        .def("VDegree",
             (int (AdvApp2Var_ApproxAFunc2Var::*)() const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)() const>(&AdvApp2Var_ApproxAFunc2Var::VDegree),
             R"#()#" 
          )
        .def("NumSubSpaces",
             (int (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const) static_cast<int (AdvApp2Var_ApproxAFunc2Var::*)(  const int  ) const>(&AdvApp2Var_ApproxAFunc2Var::NumSubSpaces),
             R"#()#"  , py::arg("Dimension")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_ApproxF2var from ./opencascade/AdvApp2Var_ApproxF2var.hxx
    klass = m.attr("AdvApp2Var_ApproxF2var");

    // default constructor
    register_default_constructor<AdvApp2Var_ApproxF2var , shared_ptr<AdvApp2Var_ApproxF2var>>(m,"AdvApp2Var_ApproxF2var");

    // nested enums

    static_cast<py::class_<AdvApp2Var_ApproxF2var , shared_ptr<AdvApp2Var_ApproxF2var>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("mma2fnc__s",
                    (int (*)( int * ,  int * ,  int * ,  double * ,   const AdvApp2Var_EvaluatorFunc2Var & ,  double * ,  int * ,  int * ,  double * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  int * ,  double * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) ) static_cast<int (*)( int * ,  int * ,  int * ,  double * ,   const AdvApp2Var_EvaluatorFunc2Var & ,  double * ,  int * ,  int * ,  double * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  int * ,  double * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2fnc_),
                    R"#()#"  , py::arg("ndimen"),  py::arg("nbsesp"),  py::arg("ndimse"),  py::arg("uvfonc"),  py::arg("foncnp"),  py::arg("tconst"),  py::arg("isofav"),  py::arg("nbroot"),  py::arg("rootlg"),  py::arg("iordre"),  py::arg("ideriv"),  py::arg("ndgjac"),  py::arg("nbcrmx"),  py::arg("ncflim"),  py::arg("epsapr"),  py::arg("ncoeff"),  py::arg("courbe"),  py::arg("nbcrbe"),  py::arg("somtab"),  py::arg("diftab"),  py::arg("contr1"),  py::arg("contr2"),  py::arg("tabdec"),  py::arg("errmax"),  py::arg("errmoy"),  py::arg("iercod")
          )
        .def_static("mma2roo__s",
                    (int (*)( int * ,  int * ,  double * ,  double *  ) ) static_cast<int (*)( int * ,  int * ,  double * ,  double *  ) >(&AdvApp2Var_ApproxF2var::mma2roo_),
                    R"#()#"  , py::arg("nbpntu"),  py::arg("nbpntv"),  py::arg("urootl"),  py::arg("vrootl")
          )
        .def_static("mma2jmx__s",
                    (int (*)( int * ,  int * ,  double *  ) ) static_cast<int (*)( int * ,  int * ,  double *  ) >(&AdvApp2Var_ApproxF2var::mma2jmx_),
                    R"#()#"  , py::arg("ndgjac"),  py::arg("iordre"),  py::arg("xjacmx")
          )
        .def_static("mmapptt__s",
                    (int (*)(  const int * ,   const int * ,   const int * ,  double * ,  int *  ) ) static_cast<int (*)(  const int * ,   const int * ,   const int * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mmapptt_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2"),  py::arg("arg3"),  py::arg("arg4")
          )
        .def_static("mma2cdi__s",
                    (int (*)( int * ,  int * ,  double * ,  int * ,  double * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) ) static_cast<int (*)( int * ,  int * ,  double * ,  int * ,  double * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2cdi_),
                    R"#()#"  , py::arg("ndimen"),  py::arg("nbpntu"),  py::arg("urootl"),  py::arg("nbpntv"),  py::arg("vrootl"),  py::arg("iordru"),  py::arg("iordrv"),  py::arg("contr1"),  py::arg("contr2"),  py::arg("contr3"),  py::arg("contr4"),  py::arg("sotbu1"),  py::arg("sotbu2"),  py::arg("ditbu1"),  py::arg("ditbu2"),  py::arg("sotbv1"),  py::arg("sotbv2"),  py::arg("ditbv1"),  py::arg("ditbv2"),  py::arg("sosotb"),  py::arg("soditb"),  py::arg("disotb"),  py::arg("diditb"),  py::arg("iercod")
          )
        .def_static("mma2ds1__s",
                    (int (*)( int * ,  double * ,  double * ,   const AdvApp2Var_EvaluatorFunc2Var & ,  int * ,  int * ,  double * ,  double * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) ) static_cast<int (*)( int * ,  double * ,  double * ,   const AdvApp2Var_EvaluatorFunc2Var & ,  int * ,  int * ,  double * ,  double * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2ds1_),
                    R"#()#"  , py::arg("ndimen"),  py::arg("uintfn"),  py::arg("vintfn"),  py::arg("foncnp"),  py::arg("nbpntu"),  py::arg("nbpntv"),  py::arg("urootb"),  py::arg("vrootb"),  py::arg("isofav"),  py::arg("sosotb"),  py::arg("disotb"),  py::arg("soditb"),  py::arg("diditb"),  py::arg("fpntab"),  py::arg("ttable"),  py::arg("iercod")
          )
        .def_static("mma2ce1__s",
                    (int (*)( int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int * ,  int * ,  int * ,  int *  ) ) static_cast<int (*)( int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  double * ,  int * ,  int * ,  int * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2ce1_),
                    R"#()#"  , py::arg("numdec"),  py::arg("ndimen"),  py::arg("nbsesp"),  py::arg("ndimse"),  py::arg("ndminu"),  py::arg("ndminv"),  py::arg("ndguli"),  py::arg("ndgvli"),  py::arg("ndjacu"),  py::arg("ndjacv"),  py::arg("iordru"),  py::arg("iordrv"),  py::arg("nbpntu"),  py::arg("nbpntv"),  py::arg("epsapr"),  py::arg("sosotb"),  py::arg("disotb"),  py::arg("soditb"),  py::arg("diditb"),  py::arg("patjac"),  py::arg("errmax"),  py::arg("errmoy"),  py::arg("ndegpu"),  py::arg("ndegpv"),  py::arg("itydec"),  py::arg("iercod")
          )
        .def_static("mma2can__s",
                    (int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,  double * ,  double * ,  int *  ) ) static_cast<int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,  double * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2can_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2"),  py::arg("arg3"),  py::arg("arg4"),  py::arg("arg5"),  py::arg("arg6"),  py::arg("arg7"),  py::arg("arg8"),  py::arg("arg9"),  py::arg("arg10")
          )
        .def_static("mma1her__s",
                    (int (*)(  const int * ,  double * ,  int *  ) ) static_cast<int (*)(  const int * ,  double * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma1her_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2")
          )
        .def_static("mma2ac2__s",
                    (int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const int * ,   const double * ,   const double * ,  double *  ) ) static_cast<int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const int * ,   const double * ,   const double * ,  double *  ) >(&AdvApp2Var_ApproxF2var::mma2ac2_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2"),  py::arg("arg3"),  py::arg("arg4"),  py::arg("arg5"),  py::arg("arg6"),  py::arg("arg7"),  py::arg("arg8"),  py::arg("arg9"),  py::arg("arg10")
          )
        .def_static("mma2ac3__s",
                    (int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const int * ,   const double * ,   const double * ,  double *  ) ) static_cast<int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const int * ,   const double * ,   const double * ,  double *  ) >(&AdvApp2Var_ApproxF2var::mma2ac3_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2"),  py::arg("arg3"),  py::arg("arg4"),  py::arg("arg5"),  py::arg("arg6"),  py::arg("arg7"),  py::arg("arg8"),  py::arg("arg9"),  py::arg("arg10")
          )
        .def_static("mma2ac1__s",
                    (int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const double * ,   const double * ,   const double * ,   const double * ,   const double * ,  double *  ) ) static_cast<int (*)(  const int * ,   const int * ,   const int * ,   const int * ,   const int * ,   const double * ,   const double * ,   const double * ,   const double * ,   const double * ,   const double * ,  double *  ) >(&AdvApp2Var_ApproxF2var::mma2ac1_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1"),  py::arg("arg2"),  py::arg("arg3"),  py::arg("arg4"),  py::arg("arg5"),  py::arg("arg6"),  py::arg("arg7"),  py::arg("arg8"),  py::arg("arg9"),  py::arg("arg10"),  py::arg("arg11")
          )
        .def_static("mma2fx6__s",
                    (int (*)( int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  int * ,  int *  ) ) static_cast<int (*)( int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  int * ,  double * ,  double * ,  double * ,  double * ,  int * ,  int *  ) >(&AdvApp2Var_ApproxF2var::mma2fx6_),
                    R"#()#"  , py::arg("ncfmxu"),  py::arg("ncfmxv"),  py::arg("ndimen"),  py::arg("nbsesp"),  py::arg("ndimse"),  py::arg("nbupat"),  py::arg("nbvpat"),  py::arg("iordru"),  py::arg("iordrv"),  py::arg("epsapr"),  py::arg("epsfro"),  py::arg("patcan"),  py::arg("errmax"),  py::arg("ncoefu"),  py::arg("ncoefv")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_Context from ./opencascade/AdvApp2Var_Context.hxx
    klass = m.attr("AdvApp2Var_Context");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Context , shared_ptr<AdvApp2Var_Context>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int, const int, const int, const int, const int, const int, const int, const int, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray2<double>> & >()  , py::arg("ifav"),  py::arg("iu"),  py::arg("iv"),  py::arg("nlimu"),  py::arg("nlimv"),  py::arg("iprecis"),  py::arg("nb1Dss"),  py::arg("nb2Dss"),  py::arg("nb3Dss"),  py::arg("tol1D"),  py::arg("tol2D"),  py::arg("tol3D"),  py::arg("tof1D"),  py::arg("tof2D"),  py::arg("tof3D") )
    // custom constructors
    // methods
        .def("TotalDimension",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::TotalDimension),
             R"#()#" 
          )
        .def("TotalNumberSSP",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::TotalNumberSSP),
             R"#()#" 
          )
        .def("FavorIso",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::FavorIso),
             R"#()#" 
          )
        .def("UOrder",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::UOrder),
             R"#()#" 
          )
        .def("VOrder",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VOrder),
             R"#()#" 
          )
        .def("ULimit",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::ULimit),
             R"#()#" 
          )
        .def("VLimit",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VLimit),
             R"#()#" 
          )
        .def("UJacDeg",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::UJacDeg),
             R"#()#" 
          )
        .def("VJacDeg",
             (int (AdvApp2Var_Context::*)() const) static_cast<int (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VJacDeg),
             R"#()#" 
          )
        .def("UJacMax",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::UJacMax),
             R"#()#" 
          )
        .def("VJacMax",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VJacMax),
             R"#()#" 
          )
        .def("URoots",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::URoots),
             R"#()#" 
          )
        .def("VRoots",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VRoots),
             R"#()#" 
          )
        .def("UGauss",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::UGauss),
             R"#()#" 
          )
        .def("VGauss",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::VGauss),
             R"#()#" 
          )
        .def("IToler",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::IToler),
             R"#()#" 
          )
        .def("FToler",
             (handle<NCollection_HArray2<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::FToler),
             R"#()#" 
          )
        .def("CToler",
             (handle<NCollection_HArray2<double>> (AdvApp2Var_Context::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApp2Var_Context::*)() const>(&AdvApp2Var_Context::CToler),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_Criterion from ./opencascade/AdvApp2Var_Criterion.hxx
    klass = m.attr("AdvApp2Var_Criterion");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Criterion , shared_ptr<AdvApp2Var_Criterion> ,Py_AdvApp2Var_Criterion >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Value",
             (void (AdvApp2Var_Criterion::*)( AdvApp2Var_Patch & ,   const AdvApp2Var_Context &  ) const) static_cast<void (AdvApp2Var_Criterion::*)( AdvApp2Var_Patch & ,   const AdvApp2Var_Context &  ) const>(&AdvApp2Var_Criterion::Value),
             R"#()#"  , py::arg("P"),  py::arg("C")
          )
        .def("IsSatisfied",
             (bool (AdvApp2Var_Criterion::*)(  const AdvApp2Var_Patch &  ) const) static_cast<bool (AdvApp2Var_Criterion::*)(  const AdvApp2Var_Patch &  ) const>(&AdvApp2Var_Criterion::IsSatisfied),
             R"#()#"  , py::arg("P")
          )
        .def("MaxValue",
             (double (AdvApp2Var_Criterion::*)() const) static_cast<double (AdvApp2Var_Criterion::*)() const>(&AdvApp2Var_Criterion::MaxValue),
             R"#()#" 
          )
        .def("Type",
             (AdvApp2Var_CriterionType (AdvApp2Var_Criterion::*)() const) static_cast<AdvApp2Var_CriterionType (AdvApp2Var_Criterion::*)() const>(&AdvApp2Var_Criterion::Type),
             R"#()#" 
          )
        .def("Repartition",
             (AdvApp2Var_CriterionRepartition (AdvApp2Var_Criterion::*)() const) static_cast<AdvApp2Var_CriterionRepartition (AdvApp2Var_Criterion::*)() const>(&AdvApp2Var_Criterion::Repartition),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_EvaluatorFunc2Var from ./opencascade/AdvApp2Var_EvaluatorFunc2Var.hxx
    klass = m.attr("AdvApp2Var_EvaluatorFunc2Var");


    // nested enums

    static_cast<py::class_<AdvApp2Var_EvaluatorFunc2Var , shared_ptr<AdvApp2Var_EvaluatorFunc2Var> ,Py_AdvApp2Var_EvaluatorFunc2Var >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Evaluate",
             (void (AdvApp2Var_EvaluatorFunc2Var::*)( int * ,  double * ,  double * ,  int * ,  double * ,  int * ,  double * ,  int * ,  int * ,  double * ,  int *  ) const) static_cast<void (AdvApp2Var_EvaluatorFunc2Var::*)( int * ,  double * ,  double * ,  int * ,  double * ,  int * ,  double * ,  int * ,  int * ,  double * ,  int *  ) const>(&AdvApp2Var_EvaluatorFunc2Var::Evaluate),
             R"#(Function evaluation method to be defined by descendant)#"  , py::arg("theDimension"),  py::arg("theUStartEnd"),  py::arg("theVStartEnd"),  py::arg("theFavorIso"),  py::arg("theConstParam"),  py::arg("theNbParams"),  py::arg("theParameters"),  py::arg("theUOrder"),  py::arg("theVOrder"),  py::arg("theResult"),  py::arg("theErrorCode")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_Framework from ./opencascade/AdvApp2Var_Framework.hxx
    klass = m.attr("AdvApp2Var_Framework");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Framework , shared_ptr<AdvApp2Var_Framework>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Sequence<handle<AdvApp2Var_Node>> &, const NCollection_Sequence<NCollection_Sequence<handle<AdvApp2Var_Iso>>> &, const NCollection_Sequence<NCollection_Sequence<handle<AdvApp2Var_Iso>>> & >()  , py::arg("Frame"),  py::arg("UFrontier"),  py::arg("VFrontier") )
    // custom constructors
    // methods
        .def("FirstNotApprox",
             (handle<AdvApp2Var_Iso> (AdvApp2Var_Framework::*)( int & ,  int &  ) const) static_cast<handle<AdvApp2Var_Iso> (AdvApp2Var_Framework::*)( int & ,  int &  ) const>(&AdvApp2Var_Framework::FirstNotApprox),
             R"#(search the Index of the first Iso not approximated, if all Isos are approximated NULL is returned.)#"  , py::arg("IndexIso"),  py::arg("IndexStrip")
          )
        .def("FirstNode",
             (int (AdvApp2Var_Framework::*)(  const GeomAbs_IsoType ,   const int ,   const int  ) const) static_cast<int (AdvApp2Var_Framework::*)(  const GeomAbs_IsoType ,   const int ,   const int  ) const>(&AdvApp2Var_Framework::FirstNode),
             R"#()#"  , py::arg("Type"),  py::arg("IndexIso"),  py::arg("IndexStrip")
          )
        .def("LastNode",
             (int (AdvApp2Var_Framework::*)(  const GeomAbs_IsoType ,   const int ,   const int  ) const) static_cast<int (AdvApp2Var_Framework::*)(  const GeomAbs_IsoType ,   const int ,   const int  ) const>(&AdvApp2Var_Framework::LastNode),
             R"#()#"  , py::arg("Type"),  py::arg("IndexIso"),  py::arg("IndexStrip")
          )
        .def("ChangeIso",
             (void (AdvApp2Var_Framework::*)(  const int ,   const int ,   const handle<AdvApp2Var_Iso> &  ) ) static_cast<void (AdvApp2Var_Framework::*)(  const int ,   const int ,   const handle<AdvApp2Var_Iso> &  ) >(&AdvApp2Var_Framework::ChangeIso),
             R"#()#"  , py::arg("IndexIso"),  py::arg("IndexStrip"),  py::arg("anIso")
          )
        .def("Node",
             ( const handle<AdvApp2Var_Node> & (AdvApp2Var_Framework::*)(  const int  ) const) static_cast< const handle<AdvApp2Var_Node> & (AdvApp2Var_Framework::*)(  const int  ) const>(&AdvApp2Var_Framework::Node),
             R"#()#"  , py::arg("IndexNode")
          )
        .def("Node",
             ( const handle<AdvApp2Var_Node> & (AdvApp2Var_Framework::*)(  const double ,   const double  ) const) static_cast< const handle<AdvApp2Var_Node> & (AdvApp2Var_Framework::*)(  const double ,   const double  ) const>(&AdvApp2Var_Framework::Node),
             R"#()#"  , py::arg("U"),  py::arg("V")
          )
        .def("IsoU",
             ( const AdvApp2Var_Iso & (AdvApp2Var_Framework::*)(  const double ,   const double ,   const double  ) const) static_cast< const AdvApp2Var_Iso & (AdvApp2Var_Framework::*)(  const double ,   const double ,   const double  ) const>(&AdvApp2Var_Framework::IsoU),
             R"#()#"  , py::arg("U"),  py::arg("V0"),  py::arg("V1")
          )
        .def("IsoV",
             ( const AdvApp2Var_Iso & (AdvApp2Var_Framework::*)(  const double ,   const double ,   const double  ) const) static_cast< const AdvApp2Var_Iso & (AdvApp2Var_Framework::*)(  const double ,   const double ,   const double  ) const>(&AdvApp2Var_Framework::IsoV),
             R"#()#"  , py::arg("U0"),  py::arg("U1"),  py::arg("V")
          )
        .def("UpdateInU",
             (void (AdvApp2Var_Framework::*)(  const double  ) ) static_cast<void (AdvApp2Var_Framework::*)(  const double  ) >(&AdvApp2Var_Framework::UpdateInU),
             R"#()#"  , py::arg("CuttingValue")
          )
        .def("UpdateInV",
             (void (AdvApp2Var_Framework::*)(  const double  ) ) static_cast<void (AdvApp2Var_Framework::*)(  const double  ) >(&AdvApp2Var_Framework::UpdateInV),
             R"#()#"  , py::arg("CuttingValue")
          )
        .def("UEquation",
             ( const handle<NCollection_HArray1<double>> & (AdvApp2Var_Framework::*)(  const int ,   const int  ) const) static_cast< const handle<NCollection_HArray1<double>> & (AdvApp2Var_Framework::*)(  const int ,   const int  ) const>(&AdvApp2Var_Framework::UEquation),
             R"#()#"  , py::arg("IndexIso"),  py::arg("IndexStrip")
          )
        .def("VEquation",
             ( const handle<NCollection_HArray1<double>> & (AdvApp2Var_Framework::*)(  const int ,   const int  ) const) static_cast< const handle<NCollection_HArray1<double>> & (AdvApp2Var_Framework::*)(  const int ,   const int  ) const>(&AdvApp2Var_Framework::VEquation),
             R"#()#"  , py::arg("IndexIso"),  py::arg("IndexStrip")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_Iso from ./opencascade/AdvApp2Var_Iso.hxx
    klass = m.attr("AdvApp2Var_Iso");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Iso ,opencascade::handle<AdvApp2Var_Iso>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const GeomAbs_IsoType, const double, const double, const double, const double, const double, const int, const int, const int >()  , py::arg("type"),  py::arg("cte"),  py::arg("Ufirst"),  py::arg("Ulast"),  py::arg("Vfirst"),  py::arg("Vlast"),  py::arg("pos"),  py::arg("iu"),  py::arg("iv") )
        .def(py::init<  const GeomAbs_IsoType, const int, const int >()  , py::arg("type"),  py::arg("iu"),  py::arg("iv") )
    // custom constructors
    // methods
        .def("IsApproximated",
             (bool (AdvApp2Var_Iso::*)() const) static_cast<bool (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::IsApproximated),
             R"#()#" 
          )
        .def("HasResult",
             (bool (AdvApp2Var_Iso::*)() const) static_cast<bool (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::HasResult),
             R"#()#" 
          )
        .def("MakeApprox",
             (void (AdvApp2Var_Iso::*)(  const AdvApp2Var_Context & ,   const double ,   const double ,   const double ,   const double ,   const AdvApp2Var_EvaluatorFunc2Var & ,  AdvApp2Var_Node & ,  AdvApp2Var_Node &  ) ) static_cast<void (AdvApp2Var_Iso::*)(  const AdvApp2Var_Context & ,   const double ,   const double ,   const double ,   const double ,   const AdvApp2Var_EvaluatorFunc2Var & ,  AdvApp2Var_Node & ,  AdvApp2Var_Node &  ) >(&AdvApp2Var_Iso::MakeApprox),
             R"#()#"  , py::arg("Conditions"),  py::arg("a"),  py::arg("b"),  py::arg("c"),  py::arg("d"),  py::arg("func"),  py::arg("NodeBegin"),  py::arg("NodeEnd")
          )
        .def("ChangeDomain",
             (void (AdvApp2Var_Iso::*)(  const double ,   const double  ) ) static_cast<void (AdvApp2Var_Iso::*)(  const double ,   const double  ) >(&AdvApp2Var_Iso::ChangeDomain),
             R"#()#"  , py::arg("a"),  py::arg("b")
          )
        .def("ChangeDomain",
             (void (AdvApp2Var_Iso::*)(  const double ,   const double ,   const double ,   const double  ) ) static_cast<void (AdvApp2Var_Iso::*)(  const double ,   const double ,   const double ,   const double  ) >(&AdvApp2Var_Iso::ChangeDomain),
             R"#()#"  , py::arg("a"),  py::arg("b"),  py::arg("c"),  py::arg("d")
          )
        .def("SetConstante",
             (void (AdvApp2Var_Iso::*)(  const double  ) ) static_cast<void (AdvApp2Var_Iso::*)(  const double  ) >(&AdvApp2Var_Iso::SetConstante),
             R"#()#"  , py::arg("newcte")
          )
        .def("SetPosition",
             (void (AdvApp2Var_Iso::*)(  const int  ) ) static_cast<void (AdvApp2Var_Iso::*)(  const int  ) >(&AdvApp2Var_Iso::SetPosition),
             R"#()#"  , py::arg("newpos")
          )
        .def("ResetApprox",
             (void (AdvApp2Var_Iso::*)() ) static_cast<void (AdvApp2Var_Iso::*)() >(&AdvApp2Var_Iso::ResetApprox),
             R"#()#" 
          )
        .def("OverwriteApprox",
             (void (AdvApp2Var_Iso::*)() ) static_cast<void (AdvApp2Var_Iso::*)() >(&AdvApp2Var_Iso::OverwriteApprox),
             R"#()#" 
          )
        .def("Type",
             (GeomAbs_IsoType (AdvApp2Var_Iso::*)() const) static_cast<GeomAbs_IsoType (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::Type),
             R"#()#" 
          )
        .def("Constante",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::Constante),
             R"#()#" 
          )
        .def("T0",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::T0),
             R"#()#" 
          )
        .def("T1",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::T1),
             R"#()#" 
          )
        .def("U0",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::U0),
             R"#()#" 
          )
        .def("U1",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::U1),
             R"#()#" 
          )
        .def("V0",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::V0),
             R"#()#" 
          )
        .def("V1",
             (double (AdvApp2Var_Iso::*)() const) static_cast<double (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::V1),
             R"#()#" 
          )
        .def("UOrder",
             (int (AdvApp2Var_Iso::*)() const) static_cast<int (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::UOrder),
             R"#()#" 
          )
        .def("VOrder",
             (int (AdvApp2Var_Iso::*)() const) static_cast<int (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::VOrder),
             R"#()#" 
          )
        .def("Position",
             (int (AdvApp2Var_Iso::*)() const) static_cast<int (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::Position),
             R"#()#" 
          )
        .def("NbCoeff",
             (int (AdvApp2Var_Iso::*)() const) static_cast<int (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::NbCoeff),
             R"#()#" 
          )
        .def("SomTab",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Iso::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::SomTab),
             R"#()#" 
          )
        .def("DifTab",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Iso::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::DifTab),
             R"#()#" 
          )
        .def("MaxErrors",
             (handle<NCollection_HArray2<double>> (AdvApp2Var_Iso::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::MaxErrors),
             R"#()#" 
          )
        .def("MoyErrors",
             (handle<NCollection_HArray2<double>> (AdvApp2Var_Iso::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::MoyErrors),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AdvApp2Var_Iso::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AdvApp2Var_Iso::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AdvApp2Var_Iso::*)() const) static_cast< const handle<Standard_Type> & (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::DynamicType),
             R"#()#"
             
         )
       .def("Polynom",
             ( const handle<NCollection_HArray1<double>> & (AdvApp2Var_Iso::*)() const) static_cast< const handle<NCollection_HArray1<double>> & (AdvApp2Var_Iso::*)() const>(&AdvApp2Var_Iso::Polynom),
             R"#()#"
             
         )
;

    // Class AdvApp2Var_Network from ./opencascade/AdvApp2Var_Network.hxx
    klass = m.attr("AdvApp2Var_Network");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Network , shared_ptr<AdvApp2Var_Network>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Sequence<handle<AdvApp2Var_Patch>> &, const NCollection_Sequence<double> &, const NCollection_Sequence<double> & >()  , py::arg("Net"),  py::arg("TheU"),  py::arg("TheV") )
    // custom constructors
    // methods
        .def("FirstNotApprox",
             (bool (AdvApp2Var_Network::*)( int &  ) const) static_cast<bool (AdvApp2Var_Network::*)( int &  ) const>(&AdvApp2Var_Network::FirstNotApprox),
             R"#(search the Index of the first Patch not approximated, if all Patches are approximated false is returned)#"  , py::arg("Index")
          )
        .def("ChangePatch",
             (AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int  ) ) static_cast<AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int  ) >(&AdvApp2Var_Network::ChangePatch),
             R"#()#"  , py::arg("Index")
          )
        .def("UpdateInU",
             (void (AdvApp2Var_Network::*)(  const double  ) ) static_cast<void (AdvApp2Var_Network::*)(  const double  ) >(&AdvApp2Var_Network::UpdateInU),
             R"#()#"  , py::arg("CuttingValue")
          )
        .def("UpdateInV",
             (void (AdvApp2Var_Network::*)(  const double  ) ) static_cast<void (AdvApp2Var_Network::*)(  const double  ) >(&AdvApp2Var_Network::UpdateInV),
             R"#()#"  , py::arg("CuttingValue")
          )
        .def("NbPatch",
             (int (AdvApp2Var_Network::*)() const) static_cast<int (AdvApp2Var_Network::*)() const>(&AdvApp2Var_Network::NbPatch),
             R"#()#" 
          )
        .def("NbPatchInU",
             (int (AdvApp2Var_Network::*)() const) static_cast<int (AdvApp2Var_Network::*)() const>(&AdvApp2Var_Network::NbPatchInU),
             R"#()#" 
          )
        .def("NbPatchInV",
             (int (AdvApp2Var_Network::*)() const) static_cast<int (AdvApp2Var_Network::*)() const>(&AdvApp2Var_Network::NbPatchInV),
             R"#()#" 
          )
        .def("UParameter",
             (double (AdvApp2Var_Network::*)(  const int  ) const) static_cast<double (AdvApp2Var_Network::*)(  const int  ) const>(&AdvApp2Var_Network::UParameter),
             R"#()#"  , py::arg("Index")
          )
        .def("VParameter",
             (double (AdvApp2Var_Network::*)(  const int  ) const) static_cast<double (AdvApp2Var_Network::*)(  const int  ) const>(&AdvApp2Var_Network::VParameter),
             R"#()#"  , py::arg("Index")
          )
        .def("Patch",
             ( const AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int ,   const int  ) const) static_cast< const AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int ,   const int  ) const>(&AdvApp2Var_Network::Patch),
             R"#()#"  , py::arg("UIndex"),  py::arg("VIndex")
          )
    // methods using call by reference i.s.o. return
        .def("SameDegree",
             []( AdvApp2Var_Network &self ,  const int iu, const int iv ){
                 int  ncfu;
                int  ncfv;

                 self.SameDegree(iu,iv,ncfu,ncfv);
                 return std::make_tuple(ncfu,ncfv); },
             R"#()#"  , py::arg("iu"),  py::arg("iv")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int  ) ) static_cast<AdvApp2Var_Patch & (AdvApp2Var_Network::*)(  const int  ) >(&AdvApp2Var_Network::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApp2Var_Node from ./opencascade/AdvApp2Var_Node.hxx
    klass = m.attr("AdvApp2Var_Node");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Node ,opencascade::handle<AdvApp2Var_Node>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_XY &, const int, const int >()  , py::arg("UV"),  py::arg("iu"),  py::arg("iv") )
        .def(py::init<  const int, const int >()  , py::arg("iu"),  py::arg("iv") )
    // custom constructors
    // methods
        .def("SetCoord",
             (void (AdvApp2Var_Node::*)(  const double ,   const double  ) ) static_cast<void (AdvApp2Var_Node::*)(  const double ,   const double  ) >(&AdvApp2Var_Node::SetCoord),
             R"#(changes the coordinates (U,V) to (x1,x2))#"  , py::arg("x1"),  py::arg("x2")
          )
        .def("UOrder",
             (int (AdvApp2Var_Node::*)() const) static_cast<int (AdvApp2Var_Node::*)() const>(&AdvApp2Var_Node::UOrder),
             R"#(returns the continuity order in U of the node)#" 
          )
        .def("VOrder",
             (int (AdvApp2Var_Node::*)() const) static_cast<int (AdvApp2Var_Node::*)() const>(&AdvApp2Var_Node::VOrder),
             R"#(returns the continuity order in V of the node)#" 
          )
        .def("SetPoint",
             (void (AdvApp2Var_Node::*)(  const int ,   const int ,   const gp_Pnt &  ) ) static_cast<void (AdvApp2Var_Node::*)(  const int ,   const int ,   const gp_Pnt &  ) >(&AdvApp2Var_Node::SetPoint),
             R"#(affects the value F(U,V) or its derivates on the node (U,V))#"  , py::arg("iu"),  py::arg("iv"),  py::arg("Pt")
          )
        .def("Point",
             ( const gp_Pnt & (AdvApp2Var_Node::*)(  const int ,   const int  ) const) static_cast< const gp_Pnt & (AdvApp2Var_Node::*)(  const int ,   const int  ) const>(&AdvApp2Var_Node::Point),
             R"#(returns the value F(U,V) or its derivates on the node (U,V))#"  , py::arg("iu"),  py::arg("iv")
          )
        .def("SetError",
             (void (AdvApp2Var_Node::*)(  const int ,   const int ,   const double  ) ) static_cast<void (AdvApp2Var_Node::*)(  const int ,   const int ,   const double  ) >(&AdvApp2Var_Node::SetError),
             R"#(affects the error between F(U,V) and its approximation)#"  , py::arg("iu"),  py::arg("iv"),  py::arg("error")
          )
        .def("Error",
             (double (AdvApp2Var_Node::*)(  const int ,   const int  ) const) static_cast<double (AdvApp2Var_Node::*)(  const int ,   const int  ) const>(&AdvApp2Var_Node::Error),
             R"#(returns the error between F(U,V) and its approximation)#"  , py::arg("iu"),  py::arg("iv")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AdvApp2Var_Node::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AdvApp2Var_Node::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AdvApp2Var_Node::*)() const) static_cast< const handle<Standard_Type> & (AdvApp2Var_Node::*)() const>(&AdvApp2Var_Node::DynamicType),
             R"#()#"
             
         )
       .def("Coord",
             ( const gp_XY & (AdvApp2Var_Node::*)() const) static_cast< const gp_XY & (AdvApp2Var_Node::*)() const>(&AdvApp2Var_Node::Coord),
             R"#(Returns the coordinates (U,V) of the node)#"
             
         )
;

    // Class AdvApp2Var_Patch from ./opencascade/AdvApp2Var_Patch.hxx
    klass = m.attr("AdvApp2Var_Patch");


    // nested enums

    static_cast<py::class_<AdvApp2Var_Patch ,opencascade::handle<AdvApp2Var_Patch>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const double, const double, const int, const int >()  , py::arg("U0"),  py::arg("U1"),  py::arg("V0"),  py::arg("V1"),  py::arg("iu"),  py::arg("iv") )
    // custom constructors
    // methods
        .def("IsDiscretised",
             (bool (AdvApp2Var_Patch::*)() const) static_cast<bool (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::IsDiscretised),
             R"#()#" 
          )
        .def("Discretise",
             (void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework & ,   const AdvApp2Var_EvaluatorFunc2Var &  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework & ,   const AdvApp2Var_EvaluatorFunc2Var &  ) >(&AdvApp2Var_Patch::Discretise),
             R"#()#"  , py::arg("Conditions"),  py::arg("Constraints"),  py::arg("func")
          )
        .def("IsApproximated",
             (bool (AdvApp2Var_Patch::*)() const) static_cast<bool (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::IsApproximated),
             R"#()#" 
          )
        .def("HasResult",
             (bool (AdvApp2Var_Patch::*)() const) static_cast<bool (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::HasResult),
             R"#()#" 
          )
        .def("MakeApprox",
             (void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework & ,   const int  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework & ,   const int  ) >(&AdvApp2Var_Patch::MakeApprox),
             R"#()#"  , py::arg("Conditions"),  py::arg("Constraints"),  py::arg("NumDec")
          )
        .def("AddConstraints",
             (void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework &  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Context & ,   const AdvApp2Var_Framework &  ) >(&AdvApp2Var_Patch::AddConstraints),
             R"#()#"  , py::arg("Conditions"),  py::arg("Constraints")
          )
        .def("AddErrors",
             (void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Framework &  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const AdvApp2Var_Framework &  ) >(&AdvApp2Var_Patch::AddErrors),
             R"#()#"  , py::arg("Constraints")
          )
        .def("ChangeDomain",
             (void (AdvApp2Var_Patch::*)(  const double ,   const double ,   const double ,   const double  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const double ,   const double ,   const double ,   const double  ) >(&AdvApp2Var_Patch::ChangeDomain),
             R"#()#"  , py::arg("a"),  py::arg("b"),  py::arg("c"),  py::arg("d")
          )
        .def("ResetApprox",
             (void (AdvApp2Var_Patch::*)() ) static_cast<void (AdvApp2Var_Patch::*)() >(&AdvApp2Var_Patch::ResetApprox),
             R"#()#" 
          )
        .def("OverwriteApprox",
             (void (AdvApp2Var_Patch::*)() ) static_cast<void (AdvApp2Var_Patch::*)() >(&AdvApp2Var_Patch::OverwriteApprox),
             R"#()#" 
          )
        .def("U0",
             (double (AdvApp2Var_Patch::*)() const) static_cast<double (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::U0),
             R"#()#" 
          )
        .def("U1",
             (double (AdvApp2Var_Patch::*)() const) static_cast<double (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::U1),
             R"#()#" 
          )
        .def("V0",
             (double (AdvApp2Var_Patch::*)() const) static_cast<double (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::V0),
             R"#()#" 
          )
        .def("V1",
             (double (AdvApp2Var_Patch::*)() const) static_cast<double (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::V1),
             R"#()#" 
          )
        .def("UOrder",
             (int (AdvApp2Var_Patch::*)() const) static_cast<int (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::UOrder),
             R"#()#" 
          )
        .def("VOrder",
             (int (AdvApp2Var_Patch::*)() const) static_cast<int (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::VOrder),
             R"#()#" 
          )
        .def("CutSense",
             (int (AdvApp2Var_Patch::*)() const) static_cast<int (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::CutSense),
             R"#()#" 
          )
        .def("CutSense",
             (int (AdvApp2Var_Patch::*)(  const AdvApp2Var_Criterion & ,   const int  ) const) static_cast<int (AdvApp2Var_Patch::*)(  const AdvApp2Var_Criterion & ,   const int  ) const>(&AdvApp2Var_Patch::CutSense),
             R"#()#"  , py::arg("Crit"),  py::arg("NumDec")
          )
        .def("NbCoeffInU",
             (int (AdvApp2Var_Patch::*)() const) static_cast<int (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::NbCoeffInU),
             R"#()#" 
          )
        .def("NbCoeffInV",
             (int (AdvApp2Var_Patch::*)() const) static_cast<int (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::NbCoeffInV),
             R"#()#" 
          )
        .def("ChangeNbCoeff",
             (void (AdvApp2Var_Patch::*)(  const int ,   const int  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const int ,   const int  ) >(&AdvApp2Var_Patch::ChangeNbCoeff),
             R"#()#"  , py::arg("NbCoeffU"),  py::arg("NbCoeffV")
          )
        .def("Poles",
             (handle<NCollection_HArray2<gp_Pnt>> (AdvApp2Var_Patch::*)(  const int ,   const AdvApp2Var_Context &  ) const) static_cast<handle<NCollection_HArray2<gp_Pnt>> (AdvApp2Var_Patch::*)(  const int ,   const AdvApp2Var_Context &  ) const>(&AdvApp2Var_Patch::Poles),
             R"#()#"  , py::arg("SSPIndex"),  py::arg("Conditions")
          )
        .def("Coefficients",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)(  const int ,   const AdvApp2Var_Context &  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)(  const int ,   const AdvApp2Var_Context &  ) const>(&AdvApp2Var_Patch::Coefficients),
             R"#()#"  , py::arg("SSPIndex"),  py::arg("Conditions")
          )
        .def("MaxErrors",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::MaxErrors),
             R"#()#" 
          )
        .def("AverageErrors",
             (handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::AverageErrors),
             R"#()#" 
          )
        .def("IsoErrors",
             (handle<NCollection_HArray2<double>> (AdvApp2Var_Patch::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::IsoErrors),
             R"#()#" 
          )
        .def("CritValue",
             (double (AdvApp2Var_Patch::*)() const) static_cast<double (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::CritValue),
             R"#()#" 
          )
        .def("SetCritValue",
             (void (AdvApp2Var_Patch::*)(  const double  ) ) static_cast<void (AdvApp2Var_Patch::*)(  const double  ) >(&AdvApp2Var_Patch::SetCritValue),
             R"#()#"  , py::arg("dist")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AdvApp2Var_Patch::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AdvApp2Var_Patch::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AdvApp2Var_Patch::*)() const) static_cast< const handle<Standard_Type> & (AdvApp2Var_Patch::*)() const>(&AdvApp2Var_Patch::DynamicType),
             R"#()#"
             
         )
;

    // Class AdvApp2Var_SysBase from ./opencascade/AdvApp2Var_SysBase.hxx
    klass = m.attr("AdvApp2Var_SysBase");


    // nested enums

    static_cast<py::class_<AdvApp2Var_SysBase , shared_ptr<AdvApp2Var_SysBase>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("mainial_",
             (int (AdvApp2Var_SysBase::*)() ) static_cast<int (AdvApp2Var_SysBase::*)() >(&AdvApp2Var_SysBase::mainial_),
             R"#()#" 
          )
        .def("mcrdelt_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  void * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  void * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::mcrdelt_),
             R"#()#"  , py::arg("iunit"),  py::arg("isize"),  py::arg("t"),  py::arg("iofset"),  py::arg("iercod")
          )
        .def("mcrrqst_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  void * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  void * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::mcrrqst_),
             R"#()#"  , py::arg("iunit"),  py::arg("isize"),  py::arg("t"),  py::arg("iofset"),  py::arg("iercod")
          )
        .def("macrai4_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  int * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  int * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::macrai4_),
             R"#()#"  , py::arg("nbelem"),  py::arg("maxelm"),  py::arg("itablo"),  py::arg("iofset"),  py::arg("iercod")
          )
        .def("macrar8_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  double * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  double * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::macrar8_),
             R"#()#"  , py::arg("nbelem"),  py::arg("maxelm"),  py::arg("xtablo"),  py::arg("iofset"),  py::arg("iercod")
          )
        .def("macrdi4_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  int * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  int * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::macrdi4_),
             R"#()#"  , py::arg("nbelem"),  py::arg("maxelm"),  py::arg("itablo"),  py::arg("iofset"),  py::arg("iercod")
          )
        .def("macrdr8_",
             (int (AdvApp2Var_SysBase::*)( int * ,  int * ,  double * ,  intptr_t * ,  int *  ) ) static_cast<int (AdvApp2Var_SysBase::*)( int * ,  int * ,  double * ,  intptr_t * ,  int *  ) >(&AdvApp2Var_SysBase::macrdr8_),
             R"#()#"  , py::arg("nbelem"),  py::arg("maxelm"),  py::arg("xtablo"),  py::arg("iofset"),  py::arg("iercod")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("macinit__s",
                    (int (*)( int * ,  int *  ) ) static_cast<int (*)( int * ,  int *  ) >(&AdvApp2Var_SysBase::macinit_),
                    R"#()#"  , py::arg("arg0"),  py::arg("arg1")
          )
        .def_static("mcrfill__s",
                    (int (*)( int * ,  void * ,  void *  ) ) static_cast<int (*)( int * ,  void * ,  void *  ) >(&AdvApp2Var_SysBase::mcrfill_),
                    R"#()#"  , py::arg("size"),  py::arg("tin"),  py::arg("tout")
          )
        .def_static("mnfndeb__s",
                    (int (*)() ) static_cast<int (*)() >(&AdvApp2Var_SysBase::mnfndeb_),
                    R"#()#" 
          )
        .def_static("maermsg__s",
                    (int (*)(  const char * ,  int * ,  long  ) ) static_cast<int (*)(  const char * ,  int * ,  long  ) >(&AdvApp2Var_SysBase::maermsg_),
                    R"#()#"  , py::arg("cnompg"),  py::arg("icoder"),  py::arg("cnompg_len")
          )
        .def_static("maitbr8__s",
                    (int (*)( int * ,  double * ,  double *  ) ) static_cast<int (*)( int * ,  double * ,  double *  ) >(&AdvApp2Var_SysBase::maitbr8_),
                    R"#()#"  , py::arg("itaill"),  py::arg("xtab"),  py::arg("xval")
          )
        .def_static("maovsr8__s",
                    (int (*)( int *  ) ) static_cast<int (*)( int *  ) >(&AdvApp2Var_SysBase::maovsr8_),
                    R"#()#"  , py::arg("ivalcs")
          )
        .def_static("mgenmsg__s",
                    (int (*)(  const char * ,  long  ) ) static_cast<int (*)(  const char * ,  long  ) >(&AdvApp2Var_SysBase::mgenmsg_),
                    R"#()#"  , py::arg("nomprg"),  py::arg("nomprg_len")
          )
        .def_static("mgsomsg__s",
                    (int (*)(  const char * ,  long  ) ) static_cast<int (*)(  const char * ,  long  ) >(&AdvApp2Var_SysBase::mgsomsg_),
                    R"#()#"  , py::arg("nomprg"),  py::arg("nomprg_len")
          )
        .def_static("miraz__s",
                    (void (*)( int * ,  void *  ) ) static_cast<void (*)( int * ,  void *  ) >(&AdvApp2Var_SysBase::miraz_),
                    R"#()#"  , py::arg("taille"),  py::arg("adt")
          )
        .def_static("msifill__s",
                    (int (*)( int * ,  int * ,  int *  ) ) static_cast<int (*)( int * ,  int * ,  int *  ) >(&AdvApp2Var_SysBase::msifill_),
                    R"#()#"  , py::arg("nbintg"),  py::arg("ivecin"),  py::arg("ivecou")
          )
        .def_static("msrfill__s",
                    (int (*)( int * ,  double * ,  double *  ) ) static_cast<int (*)( int * ,  double * ,  double *  ) >(&AdvApp2Var_SysBase::msrfill_),
                    R"#()#"  , py::arg("nbreel"),  py::arg("vecent"),  py::arg("vecsor")
          )
        .def_static("mswrdbg__s",
                    (int (*)(  const char * ,  long  ) ) static_cast<int (*)(  const char * ,  long  ) >(&AdvApp2Var_SysBase::mswrdbg_),
                    R"#()#"  , py::arg("ctexte"),  py::arg("ctexte_len")
          )
        .def_static("mvriraz__s",
                    (void (*)( int * ,  void *  ) ) static_cast<void (*)( int * ,  void *  ) >(&AdvApp2Var_SysBase::mvriraz_),
                    R"#()#"  , py::arg("taille"),  py::arg("adt")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/AdvApp2Var_ApproxAFunc2Var.hxx
// ./opencascade/AdvApp2Var_ApproxF2var.hxx
// ./opencascade/AdvApp2Var_Context.hxx
// ./opencascade/AdvApp2Var_Criterion.hxx
// ./opencascade/AdvApp2Var_CriterionRepartition.hxx
// ./opencascade/AdvApp2Var_CriterionType.hxx
// ./opencascade/AdvApp2Var_EvaluatorFunc2Var.hxx
// ./opencascade/AdvApp2Var_Framework.hxx
// ./opencascade/AdvApp2Var_Iso.hxx
// ./opencascade/AdvApp2Var_MathBase.hxx
// ./opencascade/AdvApp2Var_Network.hxx
// ./opencascade/AdvApp2Var_Node.hxx
// ./opencascade/AdvApp2Var_Patch.hxx
// ./opencascade/AdvApp2Var_SysBase.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
