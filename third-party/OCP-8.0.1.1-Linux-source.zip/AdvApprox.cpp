
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AdvApprox_Cutting.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <AdvApprox_ApproxAFunction.hxx>
#include <AdvApprox_Cutting.hxx>
#include <AdvApprox_DichoCutting.hxx>
#include <AdvApprox_EvaluatorFunction.hxx>
#include <AdvApprox_PrefAndRec.hxx>
#include <AdvApprox_PrefCutting.hxx>
#include <AdvApprox_SimpleApprox.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AdvApprox(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("AdvApprox"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_AdvApprox_Cutting : public AdvApprox_Cutting{
    public:
        using AdvApprox_Cutting::AdvApprox_Cutting;


        // public pure virtual
        bool Value( const double a, const double b,double & cuttingvalue) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AdvApprox_Cutting,Value,a,b,cuttingvalue) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class AdvApprox_ApproxAFunction from ./opencascade/AdvApprox_ApproxAFunction.hxx
    klass = m.attr("AdvApprox_ApproxAFunction");


    // nested enums

    static_cast<py::class_<AdvApprox_ApproxAFunction , shared_ptr<AdvApprox_ApproxAFunction>  >>(klass)
    // constructors
        .def(py::init<  const int, const int, const int, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const double, const double, const GeomAbs_Shape, const int, const int, const AdvApprox_EvaluatorFunction & >()  , py::arg("Num1DSS"),  py::arg("Num2DSS"),  py::arg("Num3DSS"),  py::arg("OneDTol"),  py::arg("TwoDTol"),  py::arg("ThreeDTol"),  py::arg("First"),  py::arg("Last"),  py::arg("Continuity"),  py::arg("MaxDeg"),  py::arg("MaxSeg"),  py::arg("Func") )
        .def(py::init<  const int, const int, const int, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const double, const double, const GeomAbs_Shape, const int, const int, const AdvApprox_EvaluatorFunction &, const AdvApprox_Cutting & >()  , py::arg("Num1DSS"),  py::arg("Num2DSS"),  py::arg("Num3DSS"),  py::arg("OneDTol"),  py::arg("TwoDTol"),  py::arg("ThreeDTol"),  py::arg("First"),  py::arg("Last"),  py::arg("Continuity"),  py::arg("MaxDeg"),  py::arg("MaxSeg"),  py::arg("Func"),  py::arg("CutTool") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (AdvApprox_ApproxAFunction::*)() const) static_cast<bool (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::IsDone),
             R"#()#" 
          )
        .def("HasResult",
             (bool (AdvApprox_ApproxAFunction::*)() const) static_cast<bool (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::HasResult),
             R"#()#" 
          )
        .def("Poles1d",
             (handle<NCollection_HArray2<double>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles1d),
             R"#(returns the poles from the algorithms as is)#" 
          )
        .def("Poles2d",
             (handle<NCollection_HArray2<gp_Pnt2d>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<gp_Pnt2d>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles2d),
             R"#(returns the poles from the algorithms as is)#" 
          )
        .def("Poles",
             (handle<NCollection_HArray2<gp_Pnt>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<gp_Pnt>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles),
             R"#(-- returns the poles from the algorithms as is)#" 
          )
        .def("NbPoles",
             (int (AdvApprox_ApproxAFunction::*)() const) static_cast<int (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::NbPoles),
             R"#(as the name says)#" 
          )
        .def("Poles1d",
             (void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<double> &  ) const) static_cast<void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<double> &  ) const>(&AdvApprox_ApproxAFunction::Poles1d),
             R"#(returns the poles at Index from the 1d subspace)#"  , py::arg("Index"),  py::arg("P")
          )
        .def("Poles2d",
             (void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<gp_Pnt2d> &  ) const) static_cast<void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<gp_Pnt2d> &  ) const>(&AdvApprox_ApproxAFunction::Poles2d),
             R"#(returns the poles at Index from the 2d subspace)#"  , py::arg("Index"),  py::arg("P")
          )
        .def("Poles",
             (void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<gp_Pnt> &  ) const) static_cast<void (AdvApprox_ApproxAFunction::*)(  const int ,  NCollection_Array1<gp_Pnt> &  ) const>(&AdvApprox_ApproxAFunction::Poles),
             R"#(returns the poles at Index from the 3d subspace)#"  , py::arg("Index"),  py::arg("P")
          )
        .def("Degree",
             (int (AdvApprox_ApproxAFunction::*)() const) static_cast<int (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Degree),
             R"#()#" 
          )
        .def("NbKnots",
             (int (AdvApprox_ApproxAFunction::*)() const) static_cast<int (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::NbKnots),
             R"#()#" 
          )
        .def("NumSubSpaces",
             (int (AdvApprox_ApproxAFunction::*)(  const int  ) const) static_cast<int (AdvApprox_ApproxAFunction::*)(  const int  ) const>(&AdvApprox_ApproxAFunction::NumSubSpaces),
             R"#()#"  , py::arg("Dimension")
          )
        .def("Knots",
             (handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Knots),
             R"#()#" 
          )
        .def("Multiplicities",
             (handle<NCollection_HArray1<int>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray1<int>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Multiplicities),
             R"#()#" 
          )
        .def("MaxError",
             (handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)(  const int  ) const>(&AdvApprox_ApproxAFunction::MaxError),
             R"#(returns the error as is in the algorithms)#"  , py::arg("Dimension")
          )
        .def("AverageError",
             (handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)(  const int  ) const>(&AdvApprox_ApproxAFunction::AverageError),
             R"#(returns the error as is in the algorithms)#"  , py::arg("Dimension")
          )
        .def("MaxError",
             (double (AdvApprox_ApproxAFunction::*)(  const int ,   const int  ) const) static_cast<double (AdvApprox_ApproxAFunction::*)(  const int ,   const int  ) const>(&AdvApprox_ApproxAFunction::MaxError),
             R"#()#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("AverageError",
             (double (AdvApprox_ApproxAFunction::*)(  const int ,   const int  ) const) static_cast<double (AdvApprox_ApproxAFunction::*)(  const int ,   const int  ) const>(&AdvApprox_ApproxAFunction::AverageError),
             R"#()#"  , py::arg("Dimension"),  py::arg("Index")
          )
        .def("Dump",
             (void (AdvApprox_ApproxAFunction::*)( Standard_OStream &  ) const) static_cast<void (AdvApprox_ApproxAFunction::*)( Standard_OStream &  ) const>(&AdvApprox_ApproxAFunction::Dump),
             R"#(display information on approximation.)#"  , py::arg("o")
          )
        .def("HasResult",
             (bool (AdvApprox_ApproxAFunction::*)() const) static_cast<bool (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::HasResult),
             R"#()#" 
          )
        .def("IsDone",
             (bool (AdvApprox_ApproxAFunction::*)() const) static_cast<bool (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::IsDone),
             R"#()#" 
          )
        .def("Poles1d",
             (handle<NCollection_HArray2<double>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles1d),
             R"#(returns the poles from the algorithms as is)#" 
          )
        .def("Poles2d",
             (handle<NCollection_HArray2<gp_Pnt2d>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<gp_Pnt2d>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles2d),
             R"#(returns the poles from the algorithms as is)#" 
          )
        .def("Poles",
             (handle<NCollection_HArray2<gp_Pnt>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray2<gp_Pnt>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Poles),
             R"#(-- returns the poles from the algorithms as is)#" 
          )
        .def("Degree",
             (int (AdvApprox_ApproxAFunction::*)() const) static_cast<int (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Degree),
             R"#()#" 
          )
        .def("NbKnots",
             (int (AdvApprox_ApproxAFunction::*)() const) static_cast<int (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::NbKnots),
             R"#()#" 
          )
        .def("Knots",
             (handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Knots),
             R"#()#" 
          )
        .def("Multiplicities",
             (handle<NCollection_HArray1<int>> (AdvApprox_ApproxAFunction::*)() const) static_cast<handle<NCollection_HArray1<int>> (AdvApprox_ApproxAFunction::*)() const>(&AdvApprox_ApproxAFunction::Multiplicities),
             R"#()#" 
          )
        .def("NumSubSpaces",
             (int (AdvApprox_ApproxAFunction::*)(  const int  ) const) static_cast<int (AdvApprox_ApproxAFunction::*)(  const int  ) const>(&AdvApprox_ApproxAFunction::NumSubSpaces),
             R"#()#"  , py::arg("Dimension")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
        .def_static("Approximation_s",
            []( const int TotalDimension, const int TotalNumSS, const NCollection_Array1<int> & LocalDimension, const double First, const double Last,AdvApprox_EvaluatorFunction & Evaluator, const AdvApprox_Cutting & CutTool, const int ContinuityOrder, const int NumMaxCoeffs, const int MaxSegments, const NCollection_Array1<double> & TolerancesArray, const int code_precis,NCollection_Array1<int> & NumCoeffPerCurveArray,NCollection_Array1<double> & LocalCoefficientArray,NCollection_Array1<double> & IntervalsArray,NCollection_Array1<double> & ErrorMaxArray,NCollection_Array1<double> & AverageErrorArray ){
                int  NumCurves;
                int  ErrorCode;

                AdvApprox_ApproxAFunction::Approximation(TotalDimension,TotalNumSS,LocalDimension,First,Last,Evaluator,CutTool,ContinuityOrder,NumMaxCoeffs,MaxSegments,TolerancesArray,code_precis,NumCurves,NumCoeffPerCurveArray,LocalCoefficientArray,IntervalsArray,ErrorMaxArray,AverageErrorArray,ErrorCode);
                
return std::make_tuple(NumCurves,ErrorCode); },
            R"#()#"  , py::arg("TotalDimension"),  py::arg("TotalNumSS"),  py::arg("LocalDimension"),  py::arg("First"),  py::arg("Last"),  py::arg("Evaluator"),  py::arg("CutTool"),  py::arg("ContinuityOrder"),  py::arg("NumMaxCoeffs"),  py::arg("MaxSegments"),  py::arg("TolerancesArray"),  py::arg("code_precis"),  py::arg("NumCoeffPerCurveArray"),  py::arg("LocalCoefficientArray"),  py::arg("IntervalsArray"),  py::arg("ErrorMaxArray"),  py::arg("AverageErrorArray")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApprox_Cutting from ./opencascade/AdvApprox_Cutting.hxx
    klass = m.attr("AdvApprox_Cutting");


    // nested enums

    static_cast<py::class_<AdvApprox_Cutting , shared_ptr<AdvApprox_Cutting> ,Py_AdvApprox_Cutting >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Value",
             (bool (AdvApprox_Cutting::*)(  const double ,   const double ,  double &  ) const) static_cast<bool (AdvApprox_Cutting::*)(  const double ,   const double ,  double &  ) const>(&AdvApprox_Cutting::Value),
             R"#()#"  , py::arg("a"),  py::arg("b"),  py::arg("cuttingvalue")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApprox_SimpleApprox from ./opencascade/AdvApprox_SimpleApprox.hxx
    klass = m.attr("AdvApprox_SimpleApprox");


    // nested enums

    static_cast<py::class_<AdvApprox_SimpleApprox , shared_ptr<AdvApprox_SimpleApprox>  >>(klass)
    // constructors
        .def(py::init<  const int, const int, const GeomAbs_Shape, const int, const int, const PLib_JacobiPolynomial &, const AdvApprox_EvaluatorFunction & >()  , py::arg("TotalDimension"),  py::arg("TotalNumSS"),  py::arg("Continuity"),  py::arg("WorkDegree"),  py::arg("NbGaussPoints"),  py::arg("JacobiBase"),  py::arg("Func") )
    // custom constructors
    // methods
        .def("Perform",
             (void (AdvApprox_SimpleApprox::*)(  const NCollection_Array1<int> & ,   const NCollection_Array1<double> & ,   const double ,   const double ,   const int  ) ) static_cast<void (AdvApprox_SimpleApprox::*)(  const NCollection_Array1<int> & ,   const NCollection_Array1<double> & ,   const double ,   const double ,   const int  ) >(&AdvApprox_SimpleApprox::Perform),
             R"#(Constructs approximator tool.)#"  , py::arg("LocalDimension"),  py::arg("LocalTolerancesArray"),  py::arg("First"),  py::arg("Last"),  py::arg("MaxDegree")
          )
        .def("IsDone",
             (bool (AdvApprox_SimpleApprox::*)() const) static_cast<bool (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::IsDone),
             R"#()#" 
          )
        .def("Degree",
             (int (AdvApprox_SimpleApprox::*)() const) static_cast<int (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::Degree),
             R"#()#" 
          )
        .def("Coefficients",
             (handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::Coefficients),
             R"#(returns the coefficients in the Jacobi Base)#" 
          )
        .def("FirstConstr",
             (handle<NCollection_HArray2<double>> (AdvApprox_SimpleApprox::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::FirstConstr),
             R"#(returns the constraints at First)#" 
          )
        .def("LastConstr",
             (handle<NCollection_HArray2<double>> (AdvApprox_SimpleApprox::*)() const) static_cast<handle<NCollection_HArray2<double>> (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::LastConstr),
             R"#(returns the constraints at Last)#" 
          )
        .def("SomTab",
             (handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::SomTab),
             R"#()#" 
          )
        .def("DifTab",
             (handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const) static_cast<handle<NCollection_HArray1<double>> (AdvApprox_SimpleApprox::*)() const>(&AdvApprox_SimpleApprox::DifTab),
             R"#()#" 
          )
        .def("MaxError",
             (double (AdvApprox_SimpleApprox::*)(  const int  ) const) static_cast<double (AdvApprox_SimpleApprox::*)(  const int  ) const>(&AdvApprox_SimpleApprox::MaxError),
             R"#()#"  , py::arg("Index")
          )
        .def("AverageError",
             (double (AdvApprox_SimpleApprox::*)(  const int  ) const) static_cast<double (AdvApprox_SimpleApprox::*)(  const int  ) const>(&AdvApprox_SimpleApprox::AverageError),
             R"#()#"  , py::arg("Index")
          )
        .def("Dump",
             (void (AdvApprox_SimpleApprox::*)( Standard_OStream &  ) const) static_cast<void (AdvApprox_SimpleApprox::*)( Standard_OStream &  ) const>(&AdvApprox_SimpleApprox::Dump),
             R"#(display information on approximation)#"  , py::arg("o")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApprox_DichoCutting from ./opencascade/AdvApprox_DichoCutting.hxx
    klass = m.attr("AdvApprox_DichoCutting");


    // nested enums

    static_cast<py::class_<AdvApprox_DichoCutting , shared_ptr<AdvApprox_DichoCutting>  , AdvApprox_Cutting >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Value",
             (bool (AdvApprox_DichoCutting::*)(  const double ,   const double ,  double &  ) const) static_cast<bool (AdvApprox_DichoCutting::*)(  const double ,   const double ,  double &  ) const>(&AdvApprox_DichoCutting::Value),
             R"#()#"  , py::arg("a"),  py::arg("b"),  py::arg("cuttingvalue")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApprox_PrefAndRec from ./opencascade/AdvApprox_PrefAndRec.hxx
    klass = m.attr("AdvApprox_PrefAndRec");


    // nested enums

    static_cast<py::class_<AdvApprox_PrefAndRec , shared_ptr<AdvApprox_PrefAndRec>  , AdvApprox_Cutting >>(klass)
    // constructors
        .def(py::init<  const NCollection_Array1<double> &, const NCollection_Array1<double> &, const double >()  , py::arg("RecomendedCut"),  py::arg("PrefferedCut"),  py::arg("Weight")=static_cast< const double>(5) )
    // custom constructors
    // methods
        .def("Value",
             (bool (AdvApprox_PrefAndRec::*)(  const double ,   const double ,  double &  ) const) static_cast<bool (AdvApprox_PrefAndRec::*)(  const double ,   const double ,  double &  ) const>(&AdvApprox_PrefAndRec::Value),
             R"#(cuting value is - the recommended point nerest of (a+b)/2 if pi is in ]a,b[ or else - the preferential point nearest of (a+b) / 2 if pi is in ](r*a+b)/(r+1) , (a+r*b)/(r+1)[ where r = Weight - or (a+b)/2 else.)#"  , py::arg("a"),  py::arg("b"),  py::arg("cuttingvalue")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AdvApprox_PrefCutting from ./opencascade/AdvApprox_PrefCutting.hxx
    klass = m.attr("AdvApprox_PrefCutting");


    // nested enums

    static_cast<py::class_<AdvApprox_PrefCutting , shared_ptr<AdvApprox_PrefCutting>  , AdvApprox_Cutting >>(klass)
    // constructors
        .def(py::init<  const NCollection_Array1<double> & >()  , py::arg("CutPnts") )
    // custom constructors
    // methods
        .def("Value",
             (bool (AdvApprox_PrefCutting::*)(  const double ,   const double ,  double &  ) const) static_cast<bool (AdvApprox_PrefCutting::*)(  const double ,   const double ,  double &  ) const>(&AdvApprox_PrefCutting::Value),
             R"#()#"  , py::arg("a"),  py::arg("b"),  py::arg("cuttingvalue")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/AdvApprox_ApproxAFunction.hxx
// ./opencascade/AdvApprox_Cutting.hxx
// ./opencascade/AdvApprox_DichoCutting.hxx
// ./opencascade/AdvApprox_EvaluatorFunction.hxx
// ./opencascade/AdvApprox_PrefAndRec.hxx
// ./opencascade/AdvApprox_PrefCutting.hxx
// ./opencascade/AdvApprox_SimpleApprox.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
