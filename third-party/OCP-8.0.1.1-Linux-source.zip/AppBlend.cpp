
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <AppBlend_Approx.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AppBlend(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("AppBlend"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_AppBlend_Approx : public AppBlend_Approx{
    public:
        using AppBlend_Approx::AppBlend_Approx;


        // public pure virtual
        bool IsDone() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,IsDone,) };
        void Surface(NCollection_Array2<gp_Pnt> & TPoles,NCollection_Array2<double> & TWeights,NCollection_Array1<double> & TUKnots,NCollection_Array1<double> & TVKnots,NCollection_Array1<int> & TUMults,NCollection_Array1<int> & TVMults) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Surface,TPoles,TWeights,TUKnots,TVKnots,TUMults,TVMults) };
        int UDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,UDegree,) };
        int VDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,VDegree,) };
         const NCollection_Array2<gp_Pnt> & SurfPoles() const  override { using return_type =  const NCollection_Array2<gp_Pnt> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfPoles,) };
         const NCollection_Array2<double> & SurfWeights() const  override { using return_type =  const NCollection_Array2<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfWeights,) };
         const NCollection_Array1<double> & SurfUKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfUKnots,) };
         const NCollection_Array1<double> & SurfVKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfVKnots,) };
         const NCollection_Array1<int> & SurfUMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfUMults,) };
         const NCollection_Array1<int> & SurfVMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfVMults,) };
        int NbCurves2d() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,NbCurves2d,) };
        void Curve2d( const int Index,NCollection_Array1<gp_Pnt2d> & TPoles,NCollection_Array1<double> & TKnots,NCollection_Array1<int> & TMults) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curve2d,Index,TPoles,TKnots,TMults) };
        int Curves2dDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dDegree,) };
         const NCollection_Array1<gp_Pnt2d> & Curve2dPoles( const int Index) const  override { using return_type =  const NCollection_Array1<gp_Pnt2d> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curve2dPoles,Index) };
         const NCollection_Array1<double> & Curves2dKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dKnots,) };
         const NCollection_Array1<int> & Curves2dMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dMults,) };
        double TolCurveOnSurf( const int Index) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,TolCurveOnSurf,Index) };
        void SurfShape(int & UDegree,int & VDegree,int & NbUPoles,int & NbVPoles,int & NbUKnots,int & NbVKnots) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfShape,UDegree,VDegree,NbUPoles,NbVPoles,NbUKnots,NbVKnots) };
        void Curves2dShape(int & Degree,int & NbPoles,int & NbKnots) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dShape,Degree,NbPoles,NbKnots) };
        void TolReached(double & Tol3d,double & Tol2d) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,TolReached,Tol3d,Tol2d) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class AppBlend_Approx from ./opencascade/AppBlend_Approx.hxx
    klass = m.attr("AppBlend_Approx");


    // nested enums

    static_cast<py::class_<AppBlend_Approx , shared_ptr<AppBlend_Approx> ,Py_AppBlend_Approx >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsDone",
             (bool (AppBlend_Approx::*)() const) static_cast<bool (AppBlend_Approx::*)() const>(&AppBlend_Approx::IsDone),
             R"#()#" 
          )
        .def("Surface",
             (void (AppBlend_Approx::*)( NCollection_Array2<gp_Pnt> & ,  NCollection_Array2<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> & ,  NCollection_Array1<int> &  ) const) static_cast<void (AppBlend_Approx::*)( NCollection_Array2<gp_Pnt> & ,  NCollection_Array2<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> & ,  NCollection_Array1<int> &  ) const>(&AppBlend_Approx::Surface),
             R"#()#"  , py::arg("TPoles"),  py::arg("TWeights"),  py::arg("TUKnots"),  py::arg("TVKnots"),  py::arg("TUMults"),  py::arg("TVMults")
          )
        .def("UDegree",
             (int (AppBlend_Approx::*)() const) static_cast<int (AppBlend_Approx::*)() const>(&AppBlend_Approx::UDegree),
             R"#()#" 
          )
        .def("VDegree",
             (int (AppBlend_Approx::*)() const) static_cast<int (AppBlend_Approx::*)() const>(&AppBlend_Approx::VDegree),
             R"#()#" 
          )
        .def("SurfPoles",
             ( const NCollection_Array2<gp_Pnt> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array2<gp_Pnt> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfPoles),
             R"#()#" 
          )
        .def("SurfWeights",
             ( const NCollection_Array2<double> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array2<double> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfWeights),
             R"#()#" 
          )
        .def("SurfUKnots",
             ( const NCollection_Array1<double> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<double> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfUKnots),
             R"#()#" 
          )
        .def("SurfVKnots",
             ( const NCollection_Array1<double> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<double> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfVKnots),
             R"#()#" 
          )
        .def("SurfUMults",
             ( const NCollection_Array1<int> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<int> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfUMults),
             R"#()#" 
          )
        .def("SurfVMults",
             ( const NCollection_Array1<int> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<int> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::SurfVMults),
             R"#()#" 
          )
        .def("NbCurves2d",
             (int (AppBlend_Approx::*)() const) static_cast<int (AppBlend_Approx::*)() const>(&AppBlend_Approx::NbCurves2d),
             R"#()#" 
          )
        .def("Curve2d",
             (void (AppBlend_Approx::*)(  const int ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> &  ) const) static_cast<void (AppBlend_Approx::*)(  const int ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> &  ) const>(&AppBlend_Approx::Curve2d),
             R"#()#"  , py::arg("Index"),  py::arg("TPoles"),  py::arg("TKnots"),  py::arg("TMults")
          )
        .def("Curves2dDegree",
             (int (AppBlend_Approx::*)() const) static_cast<int (AppBlend_Approx::*)() const>(&AppBlend_Approx::Curves2dDegree),
             R"#()#" 
          )
        .def("Curve2dPoles",
             ( const NCollection_Array1<gp_Pnt2d> & (AppBlend_Approx::*)(  const int  ) const) static_cast< const NCollection_Array1<gp_Pnt2d> & (AppBlend_Approx::*)(  const int  ) const>(&AppBlend_Approx::Curve2dPoles),
             R"#()#"  , py::arg("Index")
          )
        .def("Curves2dKnots",
             ( const NCollection_Array1<double> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<double> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::Curves2dKnots),
             R"#()#" 
          )
        .def("Curves2dMults",
             ( const NCollection_Array1<int> & (AppBlend_Approx::*)() const) static_cast< const NCollection_Array1<int> & (AppBlend_Approx::*)() const>(&AppBlend_Approx::Curves2dMults),
             R"#()#" 
          )
        .def("TolCurveOnSurf",
             (double (AppBlend_Approx::*)(  const int  ) const) static_cast<double (AppBlend_Approx::*)(  const int  ) const>(&AppBlend_Approx::TolCurveOnSurf),
             R"#()#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
        .def("SurfShape",
             []( AppBlend_Approx &self   ){
                 int  UDegree;
                int  VDegree;
                int  NbUPoles;
                int  NbVPoles;
                int  NbUKnots;
                int  NbVKnots;

                 self.SurfShape(UDegree,VDegree,NbUPoles,NbVPoles,NbUKnots,NbVKnots);
                 return std::make_tuple(UDegree,VDegree,NbUPoles,NbVPoles,NbUKnots,NbVKnots); },
             R"#()#" 
          )
        .def("Curves2dShape",
             []( AppBlend_Approx &self   ){
                 int  Degree;
                int  NbPoles;
                int  NbKnots;

                 self.Curves2dShape(Degree,NbPoles,NbKnots);
                 return std::make_tuple(Degree,NbPoles,NbKnots); },
             R"#()#" 
          )
        .def("TolReached",
             []( AppBlend_Approx &self   ){
                 double  Tol3d;
                double  Tol2d;

                 self.TolReached(Tol3d,Tol2d);
                 return std::make_tuple(Tol3d,Tol2d); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/AppBlend_Approx.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
