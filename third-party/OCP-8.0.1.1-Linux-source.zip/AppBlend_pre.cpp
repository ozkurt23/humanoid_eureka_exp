
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <AppBlend_Approx.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AppBlend_enums(py::module &main_module) {


py::module m = main_module.def_submodule("AppBlend", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes
    class Py_AppBlend_Approx : public AppBlend_Approx{
    public:
        using AppBlend_Approx::AppBlend_Approx;


        // public pure virtual
        bool IsDone() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,IsDone,) };
        void Surface(NCollection_Array2<gp_Pnt> & TPoles,NCollection_Array2<double> & TWeights,NCollection_Array1<double> & TUKnots,NCollection_Array1<double> & TVKnots,NCollection_Array1<int> & TUMults,NCollection_Array1<int> & TVMults) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Surface,TPoles,TWeights,TUKnots,TVKnots,TUMults,TVMults) };
        int UDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,UDegree,) };
        int VDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,VDegree,) };
         const NCollection_Array2<gp_Pnt> & SurfPoles() const  override { using return_type =  const NCollection_Array2<gp_Pnt> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfPoles,) };
         const NCollection_Array2<double> & SurfWeights() const  override { using return_type =  const NCollection_Array2<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfWeights,) };
         const NCollection_Array1<double> & SurfUKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfUKnots,) };
         const NCollection_Array1<double> & SurfVKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfVKnots,) };
         const NCollection_Array1<int> & SurfUMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfUMults,) };
         const NCollection_Array1<int> & SurfVMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfVMults,) };
        int NbCurves2d() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,NbCurves2d,) };
        void Curve2d( const int Index,NCollection_Array1<gp_Pnt2d> & TPoles,NCollection_Array1<double> & TKnots,NCollection_Array1<int> & TMults) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curve2d,Index,TPoles,TKnots,TMults) };
        int Curves2dDegree() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dDegree,) };
         const NCollection_Array1<gp_Pnt2d> & Curve2dPoles( const int Index) const  override { using return_type =  const NCollection_Array1<gp_Pnt2d> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curve2dPoles,Index) };
         const NCollection_Array1<double> & Curves2dKnots() const  override { using return_type =  const NCollection_Array1<double> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dKnots,) };
         const NCollection_Array1<int> & Curves2dMults() const  override { using return_type =  const NCollection_Array1<int> &;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dMults,) };
        double TolCurveOnSurf( const int Index) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,TolCurveOnSurf,Index) };
        void SurfShape(int & UDegree,int & VDegree,int & NbUPoles,int & NbVPoles,int & NbUKnots,int & NbVKnots) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,SurfShape,UDegree,VDegree,NbUPoles,NbVPoles,NbUKnots,NbVKnots) };
        void Curves2dShape(int & Degree,int & NbPoles,int & NbKnots) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,Curves2dShape,Degree,NbPoles,NbKnots) };
        void TolReached(double & Tol3d,double & Tol2d) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppBlend_Approx,TolReached,Tol3d,Tol2d) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<AppBlend_Approx , shared_ptr<AppBlend_Approx> ,Py_AppBlend_Approx >(
      m,
      "AppBlend_Approx",R"#(Bspline approximation of a surface.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
