
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <AppCont_Function.hxx>
#include <AppCont_LeastSquare.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AppCont(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("AppCont"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_AppCont_Function : public AppCont_Function{
    public:
        using AppCont_Function::AppCont_Function;


        // public pure virtual
        double FirstParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,AppCont_Function,FirstParameter,) };
        double LastParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,AppCont_Function,LastParameter,) };
        bool Value( const double theU,NCollection_Array1<gp_Pnt2d> & thePnt2d,NCollection_Array1<gp_Pnt> & thePnt) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AppCont_Function,Value,theU,thePnt2d,thePnt) };
        bool D1( const double theU,NCollection_Array1<gp_Vec2d> & theVec2d,NCollection_Array1<gp_Vec> & theVec) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,AppCont_Function,D1,theU,theVec2d,theVec) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class AppCont_Function from ./opencascade/AppCont_Function.hxx
    klass = m.attr("AppCont_Function");


    // nested enums

    static_cast<py::class_<AppCont_Function , shared_ptr<AppCont_Function> ,Py_AppCont_Function >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetNbOf3dPoints",
             (int (AppCont_Function::*)() const) static_cast<int (AppCont_Function::*)() const>(&AppCont_Function::GetNbOf3dPoints),
             R"#(Get number of 3d points returned by "Value" and "D1" functions.)#" 
          )
        .def("GetNbOf2dPoints",
             (int (AppCont_Function::*)() const) static_cast<int (AppCont_Function::*)() const>(&AppCont_Function::GetNbOf2dPoints),
             R"#(Get number of 2d points returned by "Value" and "D1" functions.)#" 
          )
        .def("FirstParameter",
             (double (AppCont_Function::*)() const) static_cast<double (AppCont_Function::*)() const>(&AppCont_Function::FirstParameter),
             R"#(Returns the first parameter of the function.)#" 
          )
        .def("LastParameter",
             (double (AppCont_Function::*)() const) static_cast<double (AppCont_Function::*)() const>(&AppCont_Function::LastParameter),
             R"#(Returns the last parameter of the function.)#" 
          )
        .def("Value",
             (bool (AppCont_Function::*)(  const double ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<gp_Pnt> &  ) const) static_cast<bool (AppCont_Function::*)(  const double ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<gp_Pnt> &  ) const>(&AppCont_Function::Value),
             R"#(Returns the point at parameter <theU>.)#"  , py::arg("theU"),  py::arg("thePnt2d"),  py::arg("thePnt")
          )
        .def("D1",
             (bool (AppCont_Function::*)(  const double ,  NCollection_Array1<gp_Vec2d> & ,  NCollection_Array1<gp_Vec> &  ) const) static_cast<bool (AppCont_Function::*)(  const double ,  NCollection_Array1<gp_Vec2d> & ,  NCollection_Array1<gp_Vec> &  ) const>(&AppCont_Function::D1),
             R"#(Returns the derivative at parameter <theU>.)#"  , py::arg("theU"),  py::arg("theVec2d"),  py::arg("theVec")
          )
    // methods using call by reference i.s.o. return
        .def("GetNumberOfPoints",
             []( AppCont_Function &self   ){
                 int  theNbPnt;
                int  theNbPnt2d;

                 self.GetNumberOfPoints(theNbPnt,theNbPnt2d);
                 return std::make_tuple(theNbPnt,theNbPnt2d); },
             R"#(Get number of 3d and 2d points returned by "Value" and "D1" functions.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AppCont_LeastSquare from ./opencascade/AppCont_LeastSquare.hxx
    klass = m.attr("AppCont_LeastSquare");


    // nested enums

    static_cast<py::class_<AppCont_LeastSquare , shared_ptr<AppCont_LeastSquare>  >>(klass)
    // constructors
        .def(py::init<  const AppCont_Function &, const double, const double, const AppParCurves_Constraint, const AppParCurves_Constraint, const int, const int >()  , py::arg("SSP"),  py::arg("U0"),  py::arg("U1"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Deg"),  py::arg("NbPoints") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (AppCont_LeastSquare::*)() const) static_cast<bool (AppCont_LeastSquare::*)() const>(&AppCont_LeastSquare::IsDone),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Error",
             []( AppCont_LeastSquare &self   ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.Error(F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const AppParCurves_MultiCurve & (AppCont_LeastSquare::*)() ) static_cast< const AppParCurves_MultiCurve & (AppCont_LeastSquare::*)() >(&AppCont_LeastSquare::Value),
             R"#()#"
             
         )
;

    // Class PeriodicityInfo from ./opencascade/AppCont_LeastSquare.hxx
    klass = m.attr("PeriodicityInfo");

    // default constructor
    register_default_constructor<PeriodicityInfo , shared_ptr<PeriodicityInfo>>(m,"PeriodicityInfo");

    // nested enums

    static_cast<py::class_<PeriodicityInfo , shared_ptr<PeriodicityInfo>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("isPeriodic", &PeriodicityInfo::isPeriodic)
        .def_readwrite("myPeriod", &PeriodicityInfo::myPeriod)
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/AppCont_Function.hxx
// ./opencascade/AppCont_LeastSquare.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
