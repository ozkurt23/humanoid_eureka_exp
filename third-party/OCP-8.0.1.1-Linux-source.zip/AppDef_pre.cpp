
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_MyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_MyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_MyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_MyGradientOfCompute.hxx>
#include <AppDef_ParLeastSquareOfMyGradientOfCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientOfCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientOfCompute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientOfCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_MyGradientOfCompute.hxx>
#include <AppDef_ParLeastSquareOfMyGradientOfCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientOfCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientOfCompute.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_MyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientbisOfBSplineCompute.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_TheGradient.hxx>
#include <AppDef_ParLeastSquareOfTheGradient.hxx>
#include <AppDef_ResConstraintOfTheGradient.hxx>
#include <AppDef_ParFunctionOfTheGradient.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <FEmTool_ElementaryCriterion.hxx>
#include <FEmTool_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ParLeastSquareOfMyGradientOfCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientOfCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientOfCompute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientOfCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ResConstraintOfMyGradientOfCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ResConstraintOfTheGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <FEmTool_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_TheResol.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ParLeastSquareOfTheGradient.hxx>
#include <AppDef_ResConstraintOfTheGradient.hxx>
#include <AppDef_ParFunctionOfTheGradient.hxx>
#include <AppDef_Gradient_BFGSOfTheGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AppDef_SmoothCriterion.hxx>
#include <FEmTool_Curve.hxx>
#include <FEmTool_Assembly.hxx>

// module includes
#include <AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSplineCompute.hxx>
#include <AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_Compute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_Gradient_BFGSOfMyGradientOfCompute.hxx>
#include <AppDef_Gradient_BFGSOfTheGradient.hxx>
#include <AppDef_LinearCriteria.hxx>
#include <AppDef_MultiLine.hxx>
#include <AppDef_MultiPointConstraint.hxx>
#include <AppDef_MyBSplGradientOfBSplineCompute.hxx>
#include <AppDef_MyGradientbisOfBSplineCompute.hxx>
#include <AppDef_MyGradientOfCompute.hxx>
#include <AppDef_MyLineTool.hxx>
#include <AppDef_ParFunctionOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParFunctionOfMyGradientOfCompute.hxx>
#include <AppDef_ParFunctionOfTheGradient.hxx>
#include <AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ParLeastSquareOfMyGradientOfCompute.hxx>
#include <AppDef_ParLeastSquareOfTheGradient.hxx>
#include <AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx>
#include <AppDef_ResConstraintOfMyGradientOfCompute.hxx>
#include <AppDef_ResConstraintOfTheGradient.hxx>
#include <AppDef_SmoothCriterion.hxx>
#include <AppDef_TheFunction.hxx>
#include <AppDef_TheGradient.hxx>
#include <AppDef_TheLeastSquares.hxx>
#include <AppDef_TheResol.hxx>
#include <AppDef_Variational.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_AppDef_enums(py::module &main_module) {


py::module m = main_module.def_submodule("AppDef", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes
    class Py_AppDef_SmoothCriterion : public AppDef_SmoothCriterion{
    public:
        using AppDef_SmoothCriterion::AppDef_SmoothCriterion;


        // public pure virtual
        void SetParameters( const handle<NCollection_HArray1<double>> & Parameters) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,SetParameters,Parameters) };
        void SetCurve( const handle<FEmTool_Curve> & C) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,SetCurve,C) };
        void SetEstimation( const double E1, const double E2, const double E3) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,SetEstimation,E1,E2,E3) };
        double & EstLength() override { using return_type = double &;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,EstLength,) };
        handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>> AssemblyTable() const  override { using return_type = handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>>;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,AssemblyTable,) };
        handle<NCollection_HArray2<int>> DependenceTable() const  override { using return_type = handle<NCollection_HArray2<int>>;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,DependenceTable,) };
        int QualityValues( const double J1min, const double J2min, const double J3min,double & J1,double & J2,double & J3) override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,QualityValues,J1min,J2min,J3min,J1,J2,J3) };
        void Hessian( const int Element, const int Dimension1, const int Dimension2,math_Matrix & H) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,Hessian,Element,Dimension1,Dimension2,H) };
        void Gradient( const int Element, const int Dimension,math_Vector & G) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,Gradient,Element,Dimension,G) };
        void InputVector( const math_Vector & X, const handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>> & AssTable) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,InputVector,X,AssTable) };
        void SetWeight( const double QuadraticWeight, const double QualityWeight, const double percentJ1, const double percentJ2, const double percentJ3) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,SetWeight,QuadraticWeight,QualityWeight,percentJ1,percentJ2,percentJ3) };
        void SetWeight( const NCollection_Array1<double> & Weight) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,SetWeight,Weight) };
        void GetCurve(handle<FEmTool_Curve> & C) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,GetCurve,C) };
        void GetEstimation(double & E1,double & E2,double & E3) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,GetEstimation,E1,E2,E3) };
        void ErrorValues(double & MaxError,double & QuadraticError,double & AverageError) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,ErrorValues,MaxError,QuadraticError,AverageError) };
        void GetWeight(double & QuadraticWeight,double & QualityWeight) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,AppDef_SmoothCriterion,GetWeight,QuadraticWeight,QualityWeight) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute , shared_ptr<AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute>  >(
      m,
      "AppDef_BSpParLeastSquareOfMyBSplGradientOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_BSplineCompute , shared_ptr<AppDef_BSplineCompute>  >(
      m,
      "AppDef_BSplineCompute",R"#()#"
    );
    py::class_<AppDef_Compute , shared_ptr<AppDef_Compute>  >(
      m,
      "AppDef_Compute",R"#()#"
    );
    py::class_<AppDef_MultiLine , shared_ptr<AppDef_MultiLine>  >(
      m,
      "AppDef_MultiLine",R"#(This class describes the organized set of points used in the approximations. A MultiLine is composed of n MultiPointConstraints. The approximation of the MultiLine will be done in the order of the given n MultiPointConstraints.)#"
    );
    py::class_<AppDef_MyBSplGradientOfBSplineCompute , shared_ptr<AppDef_MyBSplGradientOfBSplineCompute>  >(
      m,
      "AppDef_MyBSplGradientOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_MyGradientOfCompute , shared_ptr<AppDef_MyGradientOfCompute>  >(
      m,
      "AppDef_MyGradientOfCompute",R"#()#"
    );
    py::class_<AppDef_MyGradientbisOfBSplineCompute , shared_ptr<AppDef_MyGradientbisOfBSplineCompute>  >(
      m,
      "AppDef_MyGradientbisOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_MyLineTool , shared_ptr<AppDef_MyLineTool>  >(
      m,
      "AppDef_MyLineTool",R"#(Example of MultiLine tool corresponding to the tools of the packages AppParCurves and Approx. For Approx, the tool will not add points if the algorithms want some.)#"
    );
    py::class_<AppDef_ParLeastSquareOfMyGradientOfCompute , shared_ptr<AppDef_ParLeastSquareOfMyGradientOfCompute>  >(
      m,
      "AppDef_ParLeastSquareOfMyGradientOfCompute",R"#()#"
    );
    py::class_<AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute , shared_ptr<AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute>  >(
      m,
      "AppDef_ParLeastSquareOfMyGradientbisOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_ParLeastSquareOfTheGradient , shared_ptr<AppDef_ParLeastSquareOfTheGradient>  >(
      m,
      "AppDef_ParLeastSquareOfTheGradient",R"#()#"
    );
    py::class_<AppDef_ResConstraintOfMyGradientOfCompute , shared_ptr<AppDef_ResConstraintOfMyGradientOfCompute>  >(
      m,
      "AppDef_ResConstraintOfMyGradientOfCompute",R"#()#"
    );
    py::class_<AppDef_ResConstraintOfMyGradientbisOfBSplineCompute , shared_ptr<AppDef_ResConstraintOfMyGradientbisOfBSplineCompute>  >(
      m,
      "AppDef_ResConstraintOfMyGradientbisOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_ResConstraintOfTheGradient , shared_ptr<AppDef_ResConstraintOfTheGradient>  >(
      m,
      "AppDef_ResConstraintOfTheGradient",R"#()#"
    );
    py::class_<AppDef_TheGradient , shared_ptr<AppDef_TheGradient>  >(
      m,
      "AppDef_TheGradient",R"#()#"
    );
    py::class_<AppDef_TheLeastSquares , shared_ptr<AppDef_TheLeastSquares>  >(
      m,
      "AppDef_TheLeastSquares",R"#()#"
    );
    py::class_<AppDef_TheResol , shared_ptr<AppDef_TheResol>  >(
      m,
      "AppDef_TheResol",R"#()#"
    );
    py::class_<AppDef_Variational , shared_ptr<AppDef_Variational>  >(
      m,
      "AppDef_Variational",R"#(This class is used to smooth N points with constraints by minimization of quadratic criterium but also variational criterium in order to obtain " fair Curve " Computes the approximation of a Multiline by Variational optimization.)#"
    );
    py::class_<AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute , shared_ptr<AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute>  , math_BFGS >(
      m,
      "AppDef_BSpGradient_BFGSOfMyBSplGradientOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute , shared_ptr<AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute>  , math_MultipleVarFunctionWithGradient >(
      m,
      "AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_Gradient_BFGSOfMyGradientOfCompute , shared_ptr<AppDef_Gradient_BFGSOfMyGradientOfCompute>  , math_BFGS >(
      m,
      "AppDef_Gradient_BFGSOfMyGradientOfCompute",R"#()#"
    );
    py::class_<AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute , shared_ptr<AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute>  , math_BFGS >(
      m,
      "AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_Gradient_BFGSOfTheGradient , shared_ptr<AppDef_Gradient_BFGSOfTheGradient>  , math_BFGS >(
      m,
      "AppDef_Gradient_BFGSOfTheGradient",R"#()#"
    );
    py::class_<AppDef_MultiPointConstraint , shared_ptr<AppDef_MultiPointConstraint>  , AppParCurves_MultiPoint >(
      m,
      "AppDef_MultiPointConstraint",R"#(Describes a MultiPointConstraint used in a Multiline. MultiPointConstraints are composed of several two or three-dimensional points. The purpose is to define the corresponding points that share a common constraint in order to compute the approximation of several lines in parallel. Notes: - The order of points of a MultiPointConstraints is very important. Users must give 3D points first, and then 2D points. - The constraints for the points included in a MultiPointConstraint are always identical for all points, including the parameter. - If a MultiPointConstraint is a "tangency" point, the point is also a "passing" point.)#"
    );
    py::class_<AppDef_ParFunctionOfMyGradientOfCompute , shared_ptr<AppDef_ParFunctionOfMyGradientOfCompute>  , math_MultipleVarFunctionWithGradient >(
      m,
      "AppDef_ParFunctionOfMyGradientOfCompute",R"#()#"
    );
    py::class_<AppDef_ParFunctionOfMyGradientbisOfBSplineCompute , shared_ptr<AppDef_ParFunctionOfMyGradientbisOfBSplineCompute>  , math_MultipleVarFunctionWithGradient >(
      m,
      "AppDef_ParFunctionOfMyGradientbisOfBSplineCompute",R"#()#"
    );
    py::class_<AppDef_ParFunctionOfTheGradient , shared_ptr<AppDef_ParFunctionOfTheGradient>  , math_MultipleVarFunctionWithGradient >(
      m,
      "AppDef_ParFunctionOfTheGradient",R"#()#"
    );
    py::class_<AppDef_SmoothCriterion ,opencascade::handle<AppDef_SmoothCriterion> ,Py_AppDef_SmoothCriterion , Standard_Transient >(
      m,
      "AppDef_SmoothCriterion",R"#(defined criterion to smooth points in curve)#"
    );
    py::class_<AppDef_TheFunction , shared_ptr<AppDef_TheFunction>  , math_MultipleVarFunctionWithGradient >(
      m,
      "AppDef_TheFunction",R"#()#"
    );
    py::class_<AppDef_LinearCriteria ,opencascade::handle<AppDef_LinearCriteria>  , AppDef_SmoothCriterion >(
      m,
      "AppDef_LinearCriteria",R"#(defined an Linear Criteria to used in variational Smoothing of points.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
