
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPDS_PaveBlock.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPDS_DS.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <BOPDS_CommonBlock.hxx>
#include <BOPDS_CoupleOfPaveBlocks.hxx>
#include <BOPDS_Curve.hxx>
#include <BOPDS_DS.hxx>
#include <BOPDS_FaceInfo.hxx>
#include <BOPDS_IndexRange.hxx>
#include <BOPDS_Interf.hxx>
#include <BOPDS_Pair.hxx>
#include <BOPDS_Pave.hxx>
#include <BOPDS_PaveBlock.hxx>
#include <BOPDS_PDS.hxx>
#include <BOPDS_PIterator.hxx>
#include <BOPDS_PIteratorSI.hxx>
#include <BOPDS_Point.hxx>
#include <BOPDS_ShapeInfo.hxx>
#include <BOPDS_SubIterator.hxx>
#include <BOPDS_Tools.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BOPDS(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BOPDS"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BOPDS_CommonBlock from ./opencascade/BOPDS_CommonBlock.hxx
    klass = m.attr("BOPDS_CommonBlock");


    // nested enums

    static_cast<py::class_<BOPDS_CommonBlock ,opencascade::handle<BOPDS_CommonBlock>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("AddPaveBlock",
             (void (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_CommonBlock::AddPaveBlock),
             R"#(Modifier Adds the pave block <aPB> to the list of pave blocks of the common block)#"  , py::arg("aPB")
          )
        .def("SetPaveBlocks",
             (void (BOPDS_CommonBlock::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) >(&BOPDS_CommonBlock::SetPaveBlocks),
             R"#(Modifier Sets the list of pave blocks for the common block)#"  , py::arg("aLPB")
          )
        .def("AddFace",
             (void (BOPDS_CommonBlock::*)(  const int  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const int  ) >(&BOPDS_CommonBlock::AddFace),
             R"#(Modifier Adds the index of the face <aF> to the list of indices of faces of the common block)#"  , py::arg("aF")
          )
        .def("SetFaces",
             (void (BOPDS_CommonBlock::*)(  const NCollection_List<int> &  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const NCollection_List<int> &  ) >(&BOPDS_CommonBlock::SetFaces),
             R"#(Modifier Sets the list of indices of faces <aLF> of the common block)#"  , py::arg("aLF")
          )
        .def("AppendFaces",
             (void (BOPDS_CommonBlock::*)( NCollection_List<int> &  ) ) static_cast<void (BOPDS_CommonBlock::*)( NCollection_List<int> &  ) >(&BOPDS_CommonBlock::AppendFaces),
             R"#(Modifier Appends the list of indices of faces <aLF> to the list of indices of faces of the common block (the input list is emptied))#"  , py::arg("aLF")
          )
        .def("PaveBlockOnEdge",
             (handle<BOPDS_PaveBlock> & (BOPDS_CommonBlock::*)(  const int  ) ) static_cast<handle<BOPDS_PaveBlock> & (BOPDS_CommonBlock::*)(  const int  ) >(&BOPDS_CommonBlock::PaveBlockOnEdge),
             R"#(Selector Returns the pave block that belongs to the edge with index <theIx>)#"  , py::arg("theIndex")
          )
        .def("IsPaveBlockOnFace",
             (bool (BOPDS_CommonBlock::*)(  const int  ) const) static_cast<bool (BOPDS_CommonBlock::*)(  const int  ) const>(&BOPDS_CommonBlock::IsPaveBlockOnFace),
             R"#(Query Returns true if the common block contains a pave block that belongs to the face with index <theIx>)#"  , py::arg("theIndex")
          )
        .def("IsPaveBlockOnEdge",
             (bool (BOPDS_CommonBlock::*)(  const int  ) const) static_cast<bool (BOPDS_CommonBlock::*)(  const int  ) const>(&BOPDS_CommonBlock::IsPaveBlockOnEdge),
             R"#(Query Returns true if the common block contains a pave block that belongs to the edge with index <theIx>)#"  , py::arg("theIndex")
          )
        .def("Contains",
             (bool (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<bool (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_CommonBlock::Contains),
             R"#(Query Returns true if the common block contains a pave block that is equal to <thePB>)#"  , py::arg("thePB")
          )
        .def("Contains",
             (bool (BOPDS_CommonBlock::*)(  const int  ) const) static_cast<bool (BOPDS_CommonBlock::*)(  const int  ) const>(&BOPDS_CommonBlock::Contains),
             R"#(Query Returns true if the common block contains the face with index equal to <theF>)#"  , py::arg("theF")
          )
        .def("SetEdge",
             (void (BOPDS_CommonBlock::*)(  const int  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const int  ) >(&BOPDS_CommonBlock::SetEdge),
             R"#(Modifier Assign the index <theEdge> as the edge index to all pave blocks of the common block)#"  , py::arg("theEdge")
          )
        .def("Edge",
             (int (BOPDS_CommonBlock::*)() const) static_cast<int (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::Edge),
             R"#(Selector Returns the index of the edge of all pave blocks of the common block)#" 
          )
        .def("Dump",
             (void (BOPDS_CommonBlock::*)() const) static_cast<void (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::Dump),
             R"#()#" 
          )
        .def("SetRealPaveBlock",
             (void (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_CommonBlock::SetRealPaveBlock),
             R"#(Moves the pave blocks in the list to make the given pave block to be the first. It will be representative for the whole group.)#"  , py::arg("thePB")
          )
        .def("SetTolerance",
             (void (BOPDS_CommonBlock::*)(  const double  ) ) static_cast<void (BOPDS_CommonBlock::*)(  const double  ) >(&BOPDS_CommonBlock::SetTolerance),
             R"#(Sets the tolerance for the common block)#"  , py::arg("theTol")
          )
        .def("Tolerance",
             (double (BOPDS_CommonBlock::*)() const) static_cast<double (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::Tolerance),
             R"#(Return the tolerance of common block)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPDS_CommonBlock::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPDS_CommonBlock::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PaveBlocks",
             ( const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_CommonBlock::*)() const) static_cast< const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::PaveBlocks),
             R"#(Selector Returns the list of pave blocks of the common block)#"
             
         )
       .def("Faces",
             ( const NCollection_List<int> & (BOPDS_CommonBlock::*)() const) static_cast< const NCollection_List<int> & (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::Faces),
             R"#(Selector Returns the list of indices of faces of the common block)#"
             
         )
       .def("PaveBlock1",
             ( const handle<BOPDS_PaveBlock> & (BOPDS_CommonBlock::*)() const) static_cast< const handle<BOPDS_PaveBlock> & (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::PaveBlock1),
             R"#(Selector Returns the first pave block of the common block)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPDS_CommonBlock::*)() const) static_cast< const handle<Standard_Type> & (BOPDS_CommonBlock::*)() const>(&BOPDS_CommonBlock::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPDS_CoupleOfPaveBlocks from ./opencascade/BOPDS_CoupleOfPaveBlocks.hxx
    klass = m.attr("BOPDS_CoupleOfPaveBlocks");


    // nested enums

    static_cast<py::class_<BOPDS_CoupleOfPaveBlocks , shared_ptr<BOPDS_CoupleOfPaveBlocks>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<BOPDS_PaveBlock> &, const handle<BOPDS_PaveBlock> & >()  , py::arg("thePB1"),  py::arg("thePB2") )
    // custom constructors
    // methods
        .def("SetIndex",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const int  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const int  ) >(&BOPDS_CoupleOfPaveBlocks::SetIndex),
             R"#(Sets the index.)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_CoupleOfPaveBlocks::*)() const) static_cast<int (BOPDS_CoupleOfPaveBlocks::*)() const>(&BOPDS_CoupleOfPaveBlocks::Index),
             R"#(Returns the index.)#" 
          )
        .def("SetIndexInterf",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const int  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const int  ) >(&BOPDS_CoupleOfPaveBlocks::SetIndexInterf),
             R"#(Sets the index of an interference.)#"  , py::arg("theIndex")
          )
        .def("IndexInterf",
             (int (BOPDS_CoupleOfPaveBlocks::*)() const) static_cast<int (BOPDS_CoupleOfPaveBlocks::*)() const>(&BOPDS_CoupleOfPaveBlocks::IndexInterf),
             R"#(Returns the index of an interference.)#" 
          )
        .def("SetPaveBlocks",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> & ,   const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> & ,   const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_CoupleOfPaveBlocks::SetPaveBlocks),
             R"#(Sets both pave blocks.)#"  , py::arg("thePB1"),  py::arg("thePB2")
          )
        .def("SetPaveBlock1",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_CoupleOfPaveBlocks::SetPaveBlock1),
             R"#(Sets the first pave block.)#"  , py::arg("thePB")
          )
        .def("SetPaveBlock2",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_CoupleOfPaveBlocks::SetPaveBlock2),
             R"#(Sets the second pave block.)#"  , py::arg("thePB")
          )
        .def("SetTolerance",
             (void (BOPDS_CoupleOfPaveBlocks::*)(  const double  ) ) static_cast<void (BOPDS_CoupleOfPaveBlocks::*)(  const double  ) >(&BOPDS_CoupleOfPaveBlocks::SetTolerance),
             R"#(Sets the tolerance associated with this couple.)#"  , py::arg("theTol")
          )
        .def("Tolerance",
             (double (BOPDS_CoupleOfPaveBlocks::*)() const) static_cast<double (BOPDS_CoupleOfPaveBlocks::*)() const>(&BOPDS_CoupleOfPaveBlocks::Tolerance),
             R"#(Returns the tolerance associated with this couple.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("PaveBlocks",
             []( BOPDS_CoupleOfPaveBlocks &self , BOPDS_PaveBlock& thePB1,BOPDS_PaveBlock& thePB2 ){
                 handle<BOPDS_PaveBlock>  thePB1_ptr; thePB1_ptr = &thePB1;
                handle<BOPDS_PaveBlock>  thePB2_ptr; thePB2_ptr = &thePB2;

                 self.PaveBlocks(thePB1_ptr,thePB2_ptr);
                 return std::make_tuple(thePB1_ptr,thePB2_ptr); },
             R"#()#"  , py::arg("thePB1"),  py::arg("thePB2")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PaveBlock1",
             ( const handle<BOPDS_PaveBlock> & (BOPDS_CoupleOfPaveBlocks::*)() const) static_cast< const handle<BOPDS_PaveBlock> & (BOPDS_CoupleOfPaveBlocks::*)() const>(&BOPDS_CoupleOfPaveBlocks::PaveBlock1),
             R"#(Returns the first pave block.)#"
             
         )
       .def("PaveBlock2",
             ( const handle<BOPDS_PaveBlock> & (BOPDS_CoupleOfPaveBlocks::*)() const) static_cast< const handle<BOPDS_PaveBlock> & (BOPDS_CoupleOfPaveBlocks::*)() const>(&BOPDS_CoupleOfPaveBlocks::PaveBlock2),
             R"#(Returns the second pave block.)#"
             
         )
;

    // Class BOPDS_Curve from ./opencascade/BOPDS_Curve.hxx
    klass = m.attr("BOPDS_Curve");


    // nested enums

    static_cast<py::class_<BOPDS_Curve , shared_ptr<BOPDS_Curve>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetCurve",
             (void (BOPDS_Curve::*)(  const IntTools_Curve &  ) ) static_cast<void (BOPDS_Curve::*)(  const IntTools_Curve &  ) >(&BOPDS_Curve::SetCurve),
             R"#(Modifier Sets the curve <theC>)#"  , py::arg("theC")
          )
        .def("SetBox",
             (void (BOPDS_Curve::*)(  const Bnd_Box &  ) ) static_cast<void (BOPDS_Curve::*)(  const Bnd_Box &  ) >(&BOPDS_Curve::SetBox),
             R"#(Modifier Sets the bounding box <theBox> of the curve)#"  , py::arg("theBox")
          )
        .def("SetPaveBlocks",
             (void (BOPDS_Curve::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) ) static_cast<void (BOPDS_Curve::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) >(&BOPDS_Curve::SetPaveBlocks),
             R"#()#"  , py::arg("theLPB")
          )
        .def("InitPaveBlock1",
             (void (BOPDS_Curve::*)() ) static_cast<void (BOPDS_Curve::*)() >(&BOPDS_Curve::InitPaveBlock1),
             R"#(Creates initial pave block of the curve)#" 
          )
        .def("HasEdge",
             (bool (BOPDS_Curve::*)() const) static_cast<bool (BOPDS_Curve::*)() const>(&BOPDS_Curve::HasEdge),
             R"#(Query Returns true if at least one pave block of the curve has edge)#" 
          )
        .def("SetTolerance",
             (void (BOPDS_Curve::*)(  const double  ) ) static_cast<void (BOPDS_Curve::*)(  const double  ) >(&BOPDS_Curve::SetTolerance),
             R"#(Sets the tolerance for the curve.)#"  , py::arg("theTol")
          )
        .def("Tolerance",
             (double (BOPDS_Curve::*)() const) static_cast<double (BOPDS_Curve::*)() const>(&BOPDS_Curve::Tolerance),
             R"#(Returns the tolerance of the curve)#" 
          )
        .def("TangentialTolerance",
             (double (BOPDS_Curve::*)() const) static_cast<double (BOPDS_Curve::*)() const>(&BOPDS_Curve::TangentialTolerance),
             R"#(Returns the tangential tolerance of the curve)#" 
          )
        .def("SetCurve",
             (void (BOPDS_Curve::*)(  const IntTools_Curve &  ) ) static_cast<void (BOPDS_Curve::*)(  const IntTools_Curve &  ) >(&BOPDS_Curve::SetCurve),
             R"#(Modifier Sets the curve <theC>)#"  , py::arg("theCurve")
          )
        .def("SetPaveBlocks",
             (void (BOPDS_Curve::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) ) static_cast<void (BOPDS_Curve::*)(  const NCollection_List<handle<BOPDS_PaveBlock>> &  ) >(&BOPDS_Curve::SetPaveBlocks),
             R"#()#"  , py::arg("theLPB")
          )
        .def("InitPaveBlock1",
             (void (BOPDS_Curve::*)() ) static_cast<void (BOPDS_Curve::*)() >(&BOPDS_Curve::InitPaveBlock1),
             R"#(Creates initial pave block of the curve)#" 
          )
        .def("SetBox",
             (void (BOPDS_Curve::*)(  const Bnd_Box &  ) ) static_cast<void (BOPDS_Curve::*)(  const Bnd_Box &  ) >(&BOPDS_Curve::SetBox),
             R"#(Modifier Sets the bounding box <theBox> of the curve)#"  , py::arg("theBox")
          )
        .def("HasEdge",
             (bool (BOPDS_Curve::*)() const) static_cast<bool (BOPDS_Curve::*)() const>(&BOPDS_Curve::HasEdge),
             R"#(Query Returns true if at least one pave block of the curve has edge)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Curve",
             ( const IntTools_Curve & (BOPDS_Curve::*)() const) static_cast< const IntTools_Curve & (BOPDS_Curve::*)() const>(&BOPDS_Curve::Curve),
             R"#(Selector Returns the curve)#"
             
         )
       .def("Box",
             ( const Bnd_Box & (BOPDS_Curve::*)() const) static_cast< const Bnd_Box & (BOPDS_Curve::*)() const>(&BOPDS_Curve::Box),
             R"#(Selector Returns the bounding box of the curve)#"
             
         )
       .def("ChangeBox",
             (Bnd_Box & (BOPDS_Curve::*)() ) static_cast<Bnd_Box & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangeBox),
             R"#(Selector/Modifier Returns the bounding box of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocks",
             ( const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() const) static_cast< const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() const>(&BOPDS_Curve::PaveBlocks),
             R"#(Selector Returns the list of pave blocks of the curve)#"
             
         )
       .def("ChangePaveBlocks",
             (NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() ) static_cast<NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangePaveBlocks),
             R"#(Selector/Modifier Returns the list of pave blocks of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangePaveBlock1",
             (handle<BOPDS_PaveBlock> & (BOPDS_Curve::*)() ) static_cast<handle<BOPDS_PaveBlock> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangePaveBlock1),
             R"#(Selector/Modifier Returns initial pave block of the curve)#"
             
         )
       .def("TechnoVertices",
             ( const NCollection_List<int> & (BOPDS_Curve::*)() const) static_cast< const NCollection_List<int> & (BOPDS_Curve::*)() const>(&BOPDS_Curve::TechnoVertices),
             R"#(Selector Returns list of indices of technologic vertices of the curve)#"
             
         )
       .def("ChangeTechnoVertices",
             (NCollection_List<int> & (BOPDS_Curve::*)() ) static_cast<NCollection_List<int> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangeTechnoVertices),
             R"#(Selector/Modifier Returns list of indices of technologic vertices of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Curve",
             ( const IntTools_Curve & (BOPDS_Curve::*)() const) static_cast< const IntTools_Curve & (BOPDS_Curve::*)() const>(&BOPDS_Curve::Curve),
             R"#(Selector Returns the curve)#"
             
         )
       .def("PaveBlocks",
             ( const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() const) static_cast< const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() const>(&BOPDS_Curve::PaveBlocks),
             R"#(Selector Returns the list of pave blocks of the curve)#"
             
         )
       .def("ChangePaveBlocks",
             (NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() ) static_cast<NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangePaveBlocks),
             R"#(Selector/Modifier Returns the list of pave blocks of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangePaveBlock1",
             (handle<BOPDS_PaveBlock> & (BOPDS_Curve::*)() ) static_cast<handle<BOPDS_PaveBlock> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangePaveBlock1),
             R"#(Selector/Modifier Returns initial pave block of the curve)#"
             
         )
       .def("TechnoVertices",
             ( const NCollection_List<int> & (BOPDS_Curve::*)() const) static_cast< const NCollection_List<int> & (BOPDS_Curve::*)() const>(&BOPDS_Curve::TechnoVertices),
             R"#(Selector Returns list of indices of technologic vertices of the curve)#"
             
         )
       .def("ChangeTechnoVertices",
             (NCollection_List<int> & (BOPDS_Curve::*)() ) static_cast<NCollection_List<int> & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangeTechnoVertices),
             R"#(Selector/Modifier Returns list of indices of technologic vertices of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Box",
             ( const Bnd_Box & (BOPDS_Curve::*)() const) static_cast< const Bnd_Box & (BOPDS_Curve::*)() const>(&BOPDS_Curve::Box),
             R"#(Selector Returns the bounding box of the curve)#"
             
         )
       .def("ChangeBox",
             (Bnd_Box & (BOPDS_Curve::*)() ) static_cast<Bnd_Box & (BOPDS_Curve::*)() >(&BOPDS_Curve::ChangeBox),
             R"#(Selector/Modifier Returns the bounding box of the curve)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPDS_DS from ./opencascade/BOPDS_DS.hxx
    klass = m.attr("BOPDS_DS");


    // nested enums

    static_cast<py::class_<BOPDS_DS , shared_ptr<BOPDS_DS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::Clear),
             R"#(Clears the contents)#" 
          )
        .def("SetArguments",
             (void (BOPDS_DS::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPDS_DS::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPDS_DS::SetArguments),
             R"#(Modifier Sets the arguments [theLS] of an operation)#"  , py::arg("theLS")
          )
        .def("Init",
             (void (BOPDS_DS::*)(  const double  ) ) static_cast<void (BOPDS_DS::*)(  const double  ) >(&BOPDS_DS::Init),
             R"#(Initializes the data structure for the arguments)#"  , py::arg("theFuzz")=static_cast< const double>(Precision :: Confusion ( ))
          )
        .def("NbShapes",
             (int (BOPDS_DS::*)() const) static_cast<int (BOPDS_DS::*)() const>(&BOPDS_DS::NbShapes),
             R"#(Selector Returns the total number of shapes stored)#" 
          )
        .def("NbSourceShapes",
             (int (BOPDS_DS::*)() const) static_cast<int (BOPDS_DS::*)() const>(&BOPDS_DS::NbSourceShapes),
             R"#(Selector Returns the total number of source shapes stored)#" 
          )
        .def("NbRanges",
             (int (BOPDS_DS::*)() const) static_cast<int (BOPDS_DS::*)() const>(&BOPDS_DS::NbRanges),
             R"#(Selector Returns the number of index ranges)#" 
          )
        .def("Range",
             ( const BOPDS_IndexRange & (BOPDS_DS::*)(  const int  ) const) static_cast< const BOPDS_IndexRange & (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::Range),
             R"#(Selector Returns the index range "i")#"  , py::arg("theIndex")
          )
        .def("Rank",
             (int (BOPDS_DS::*)(  const int  ) const) static_cast<int (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::Rank),
             R"#(Selector Returns the rank of the shape of index "i")#"  , py::arg("theIndex")
          )
        .def("IsNewShape",
             (bool (BOPDS_DS::*)(  const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::IsNewShape),
             R"#(Returns true if the shape of index "i" is not the source shape/sub-shape)#"  , py::arg("theIndex")
          )
        .def("Append",
             (int (BOPDS_DS::*)(  const BOPDS_ShapeInfo &  ) ) static_cast<int (BOPDS_DS::*)(  const BOPDS_ShapeInfo &  ) >(&BOPDS_DS::Append),
             R"#(Modifier Appends the information about the shape [theSI] to the data structure Returns the index of theSI in the data structure)#"  , py::arg("theSI")
          )
        .def("Append",
             (int (BOPDS_DS::*)(  const TopoDS_Shape &  ) ) static_cast<int (BOPDS_DS::*)(  const TopoDS_Shape &  ) >(&BOPDS_DS::Append),
             R"#(Modifier Appends the default information about the shape [theS] to the data structure Returns the index of theS in the data structure)#"  , py::arg("theS")
          )
        .def("ShapeInfo",
             ( const BOPDS_ShapeInfo & (BOPDS_DS::*)(  const int  ) const) static_cast< const BOPDS_ShapeInfo & (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::ShapeInfo),
             R"#(Selector Returns the information about the shape with index theIndex)#"  , py::arg("theIndex")
          )
        .def("ChangeShapeInfo",
             (BOPDS_ShapeInfo & (BOPDS_DS::*)(  const int  ) ) static_cast<BOPDS_ShapeInfo & (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::ChangeShapeInfo),
             R"#(Selector/Modifier Returns the information about the shape with index theIndex)#"  , py::arg("theIndex")
          )
        .def("Shape",
             ( const TopoDS_Shape & (BOPDS_DS::*)(  const int  ) const) static_cast< const TopoDS_Shape & (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::Shape),
             R"#(Selector Returns the shape with index theIndex)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_DS::*)(  const TopoDS_Shape &  ) const) static_cast<int (BOPDS_DS::*)(  const TopoDS_Shape &  ) const>(&BOPDS_DS::Index),
             R"#(Selector Returns the index of the shape theS)#"  , py::arg("theS")
          )
        .def("HasPaveBlocks",
             (bool (BOPDS_DS::*)(  const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::HasPaveBlocks),
             R"#(Query Returns true if the shape with index theIndex has the information about pave blocks)#"  , py::arg("theIndex")
          )
        .def("PaveBlocks",
             ( const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_DS::*)(  const int  ) const) static_cast< const NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::PaveBlocks),
             R"#(Selector Returns the pave blocks for the shape with index theIndex)#"  , py::arg("theIndex")
          )
        .def("ChangePaveBlocks",
             (NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_DS::*)(  const int  ) ) static_cast<NCollection_List<handle<BOPDS_PaveBlock>> & (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::ChangePaveBlocks),
             R"#(Selector/Modifier Returns the pave blocks for the shape with index theIndex)#"  , py::arg("theIndex")
          )
        .def("UpdatePaveBlocks",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::UpdatePaveBlocks),
             R"#(Update the pave blocks for the all shapes in data structure)#" 
          )
        .def("UpdatePaveBlock",
             (void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_DS::UpdatePaveBlock),
             R"#(Update the pave block thePB)#"  , py::arg("thePB")
          )
        .def("UpdateCommonBlock",
             (void (BOPDS_DS::*)(  const handle<BOPDS_CommonBlock> & ,   const double  ) ) static_cast<void (BOPDS_DS::*)(  const handle<BOPDS_CommonBlock> & ,   const double  ) >(&BOPDS_DS::UpdateCommonBlock),
             R"#(Update the common block theCB)#"  , py::arg("theCB"),  py::arg("theFuzz")
          )
        .def("IsCommonBlock",
             (bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_DS::IsCommonBlock),
             R"#(Query Returns true if the pave block is common block)#"  , py::arg("thePB")
          )
        .def("CommonBlock",
             (handle<BOPDS_CommonBlock> (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<handle<BOPDS_CommonBlock> (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_DS::CommonBlock),
             R"#(Selector Returns the common block)#"  , py::arg("thePB")
          )
        .def("SetCommonBlock",
             (void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> & ,   const handle<BOPDS_CommonBlock> &  ) ) static_cast<void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> & ,   const handle<BOPDS_CommonBlock> &  ) >(&BOPDS_DS::SetCommonBlock),
             R"#(Modifier Sets the common block <theCB>)#"  , py::arg("thePB"),  py::arg("theCB")
          )
        .def("RealPaveBlock",
             (handle<BOPDS_PaveBlock> (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<handle<BOPDS_PaveBlock> (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_DS::RealPaveBlock),
             R"#(Selector Returns the real first pave block)#"  , py::arg("thePB")
          )
        .def("IsCommonBlockOnEdge",
             (bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_DS::IsCommonBlockOnEdge),
             R"#(Query Returns true if common block contains more then one pave block)#"  , py::arg("thePB")
          )
        .def("HasFaceInfo",
             (bool (BOPDS_DS::*)(  const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::HasFaceInfo),
             R"#(Query Returns true if the shape with index theIndex has the information about state of face)#"  , py::arg("theIndex")
          )
        .def("FaceInfo",
             ( const BOPDS_FaceInfo & (BOPDS_DS::*)(  const int  ) const) static_cast< const BOPDS_FaceInfo & (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::FaceInfo),
             R"#(Selector Returns the state of face with index theIndex)#"  , py::arg("theIndex")
          )
        .def("ChangeFaceInfo",
             (BOPDS_FaceInfo & (BOPDS_DS::*)(  const int  ) ) static_cast<BOPDS_FaceInfo & (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::ChangeFaceInfo),
             R"#(Selector/Modifier Returns the state of face with index theIndex)#"  , py::arg("theIndex")
          )
        .def("UpdateFaceInfoIn",
             (void (BOPDS_DS::*)(  const int  ) ) static_cast<void (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::UpdateFaceInfoIn),
             R"#(Update the state In of face with index theIndex)#"  , py::arg("theIndex")
          )
        .def("UpdateFaceInfoIn",
             (void (BOPDS_DS::*)(  const NCollection_Map<int> &  ) ) static_cast<void (BOPDS_DS::*)(  const NCollection_Map<int> &  ) >(&BOPDS_DS::UpdateFaceInfoIn),
             R"#(Update the state IN for all faces in the given map)#"  , py::arg("theFaces")
          )
        .def("UpdateFaceInfoOn",
             (void (BOPDS_DS::*)(  const int  ) ) static_cast<void (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::UpdateFaceInfoOn),
             R"#(Update the state On of face with index theIndex)#"  , py::arg("theIndex")
          )
        .def("UpdateFaceInfoOn",
             (void (BOPDS_DS::*)(  const NCollection_Map<int> &  ) ) static_cast<void (BOPDS_DS::*)(  const NCollection_Map<int> &  ) >(&BOPDS_DS::UpdateFaceInfoOn),
             R"#(Update the state ON for all faces in the given map)#"  , py::arg("theFaces")
          )
        .def("FaceInfoOn",
             (void (BOPDS_DS::*)(  const int ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<int> &  ) ) static_cast<void (BOPDS_DS::*)(  const int ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<int> &  ) >(&BOPDS_DS::FaceInfoOn),
             R"#(Selector Returns the state On [theMPB,theMVP] of face with index theIndex)#"  , py::arg("theIndex"),  py::arg("theMPB"),  py::arg("theMVP")
          )
        .def("FaceInfoIn",
             (void (BOPDS_DS::*)(  const int ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<int> &  ) ) static_cast<void (BOPDS_DS::*)(  const int ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<int> &  ) >(&BOPDS_DS::FaceInfoIn),
             R"#(Selector Returns the state In [theMPB,theMVP] of face with index theIndex)#"  , py::arg("theIndex"),  py::arg("theMPB"),  py::arg("theMVP")
          )
        .def("AloneVertices",
             (void (BOPDS_DS::*)(  const int ,  NCollection_List<int> &  ) const) static_cast<void (BOPDS_DS::*)(  const int ,  NCollection_List<int> &  ) const>(&BOPDS_DS::AloneVertices),
             R"#(Selector Returns the indices of alone vertices for the face with index theFaceIndex)#"  , py::arg("theFaceIndex"),  py::arg("theVertexList")
          )
        .def("RefineFaceInfoOn",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::RefineFaceInfoOn),
             R"#(Refine the state On for the all faces having state information)#" 
          )
        .def("RefineFaceInfoIn",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::RefineFaceInfoIn),
             R"#(Removes any pave block from list of having IN state if it has also the state ON.)#" 
          )
        .def("SubShapesOnIn",
             (void (BOPDS_DS::*)(  const int ,   const int ,  NCollection_Map<int> & ,  NCollection_Map<int> & ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<handle<BOPDS_PaveBlock>> &  ) const) static_cast<void (BOPDS_DS::*)(  const int ,   const int ,  NCollection_Map<int> & ,  NCollection_Map<int> & ,  NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & ,  NCollection_Map<handle<BOPDS_PaveBlock>> &  ) const>(&BOPDS_DS::SubShapesOnIn),
             R"#(Returns information about ON/IN sub-shapes of the given faces.)#"  , py::arg("theFaceIndex1"),  py::arg("theFaceIndex2"),  py::arg("theMVOnIn"),  py::arg("theMVCommon"),  py::arg("thePBOnIn"),  py::arg("theCommonPaveBlocks")
          )
        .def("SharedEdges",
             (void (BOPDS_DS::*)(  const int ,   const int ,  NCollection_List<int> & ,   const handle<NCollection_BaseAllocator> &  ) ) static_cast<void (BOPDS_DS::*)(  const int ,   const int ,  NCollection_List<int> & ,   const handle<NCollection_BaseAllocator> &  ) >(&BOPDS_DS::SharedEdges),
             R"#(Returns the indices of edges that are shared for the faces with indices theFaceIndex1 and theFaceIndex2.)#"  , py::arg("theFaceIndex1"),  py::arg("theFaceIndex2"),  py::arg("theEdgeList"),  py::arg("theAllocator")
          )
        .def("AddShapeSD",
             (void (BOPDS_DS::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_DS::*)(  const int ,   const int  ) >(&BOPDS_DS::AddShapeSD),
             R"#(Modifier Adds the information about same domain shapes with indices theIndex, theIndexSD)#"  , py::arg("theIndex"),  py::arg("theIndexSD")
          )
        .def("HasShapeSD",
             (bool (BOPDS_DS::*)(  const int ,  int &  ) const) static_cast<bool (BOPDS_DS::*)(  const int ,  int &  ) const>(&BOPDS_DS::HasShapeSD),
             R"#(Query Returns true if the shape with index theIndex has the same domain shape. In this case theIndexSD will contain the index of same domain shape found)#"  , py::arg("theIndex"),  py::arg("theIndexSD")
          )
        .def("GetSameDomainIndex",
             (int (BOPDS_DS::*)(  const int  ) const) static_cast<int (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::GetSameDomainIndex),
             R"#(Returns the index of same domain shape for the shape with index theIndex. If there is no same domain shape, returns theIndex itself.)#"  , py::arg("theIndex")
          )
        .def("AddInterf",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) ) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) >(&BOPDS_DS::AddInterf),
             R"#(Modifier Adds the information about an interference between shapes with indices theI1, theI2 to the summary table of interferences)#"  , py::arg("theI1"),  py::arg("theI2")
          )
        .def("HasInterf",
             (bool (BOPDS_DS::*)(  const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::HasInterf),
             R"#(Query Returns true if the shape with index theI is interferred)#"  , py::arg("theI")
          )
        .def("HasInterf",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) const>(&BOPDS_DS::HasInterf),
             R"#(Query Returns true if the shapes with indices theI1, theI2 are interferred)#"  , py::arg("theI1"),  py::arg("theI2")
          )
        .def("HasInterfShapeSubShapes",
             (bool (BOPDS_DS::*)(  const int ,   const int ,   const bool  ) const) static_cast<bool (BOPDS_DS::*)(  const int ,   const int ,   const bool  ) const>(&BOPDS_DS::HasInterfShapeSubShapes),
             R"#(Query Returns true if the shape with index theIndex1 is interfered with any sub-shape of the shape with index theIndex2 (theAnyInterference=true) all sub-shapes of the shape with index theIndex2 (theAnyInterference=false))#"  , py::arg("theIndex1"),  py::arg("theIndex2"),  py::arg("theAnyInterference")=static_cast< const bool>(true)
          )
        .def("HasInterfSubShapes",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) const>(&BOPDS_DS::HasInterfSubShapes),
             R"#(Query Returns true if the shapes with indices theIndex1, theIndex2 have interferred sub-shapes)#"  , py::arg("theIndex1"),  py::arg("theIndex2")
          )
        .def("Dump",
             (void (BOPDS_DS::*)() const) static_cast<void (BOPDS_DS::*)() const>(&BOPDS_DS::Dump),
             R"#()#" 
          )
        .def("IsSubShape",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) ) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) >(&BOPDS_DS::IsSubShape),
             R"#(Returns true if the shape with index theCandidate is a sub-shape of the shape with index theParent)#"  , py::arg("theCandidate"),  py::arg("theParent")
          )
        .def("Paves",
             (void (BOPDS_DS::*)(  const int ,  NCollection_List<BOPDS_Pave> &  ) ) static_cast<void (BOPDS_DS::*)(  const int ,  NCollection_List<BOPDS_Pave> &  ) >(&BOPDS_DS::Paves),
             R"#(Fills theLP with sorted paves of the shape with index theIndex)#"  , py::arg("theIndex"),  py::arg("theLP")
          )
        .def("UpdatePaveBlocksWithSDVertices",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::UpdatePaveBlocksWithSDVertices),
             R"#(Update the pave blocks for all shapes in data structure)#" 
          )
        .def("UpdatePaveBlockWithSDVertices",
             (void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<void (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_DS::UpdatePaveBlockWithSDVertices),
             R"#(Update the pave block for all shapes in data structure)#"  , py::arg("thePB")
          )
        .def("UpdateCommonBlockWithSDVertices",
             (void (BOPDS_DS::*)(  const handle<BOPDS_CommonBlock> &  ) ) static_cast<void (BOPDS_DS::*)(  const handle<BOPDS_CommonBlock> &  ) >(&BOPDS_DS::UpdateCommonBlockWithSDVertices),
             R"#(Update the pave block of the common block for all shapes in data structure)#"  , py::arg("theCB")
          )
        .def("InitPaveBlocksForVertex",
             (void (BOPDS_DS::*)(  const int  ) ) static_cast<void (BOPDS_DS::*)(  const int  ) >(&BOPDS_DS::InitPaveBlocksForVertex),
             R"#()#"  , py::arg("theNV")
          )
        .def("ReleasePaveBlocks",
             (void (BOPDS_DS::*)() ) static_cast<void (BOPDS_DS::*)() >(&BOPDS_DS::ReleasePaveBlocks),
             R"#(Clears information about PaveBlocks for the untouched edges)#" 
          )
        .def("IsValidShrunkData",
             (bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) ) static_cast<bool (BOPDS_DS::*)(  const handle<BOPDS_PaveBlock> &  ) >(&BOPDS_DS::IsValidShrunkData),
             R"#(Checks if the existing shrunk data of the pave block is still valid. The shrunk data may become invalid if e.g. the vertices of the pave block have been replaced with the new one with bigger tolerances, or the tolerances of the existing vertices have been increased.)#"  , py::arg("thePB")
          )
        .def("BuildBndBoxSolid",
             (void (BOPDS_DS::*)(  const int ,  Bnd_Box & ,   const bool  ) ) static_cast<void (BOPDS_DS::*)(  const int ,  Bnd_Box & ,   const bool  ) >(&BOPDS_DS::BuildBndBoxSolid),
             R"#(Computes bounding box <theBox> for the solid with DS-index <theIndex>. The flag <theCheckInverted> enables/disables the check of the solid for inverted status. By default the solids will be checked.)#"  , py::arg("theIndex"),  py::arg("theBox"),  py::arg("theCheckInverted")=static_cast< const bool>(true)
          )
        .def("AddInterf",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) ) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) >(&BOPDS_DS::AddInterf),
             R"#(Modifier Adds the information about an interference between shapes with indices theI1, theI2 to the summary table of interferences)#"  , py::arg("theI1"),  py::arg("theI2")
          )
        .def("HasInterf",
             (bool (BOPDS_DS::*)(  const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int  ) const>(&BOPDS_DS::HasInterf),
             R"#(Query Returns true if the shape with index theI is interferred)#"  , py::arg("theI")
          )
        .def("HasInterf",
             (bool (BOPDS_DS::*)(  const int ,   const int  ) const) static_cast<bool (BOPDS_DS::*)(  const int ,   const int  ) const>(&BOPDS_DS::HasInterf),
             R"#(Query Returns true if the shapes with indices theI1, theI2 are interferred)#"  , py::arg("theI1"),  py::arg("theI2")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("NbInterfTypes_s",
                    (int (*)() ) static_cast<int (*)() >(&BOPDS_DS::NbInterfTypes),
                    R"#(Returns the number of types of the interferences)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (BOPDS_DS::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (BOPDS_DS::*)() const>(&BOPDS_DS::Allocator),
             R"#(Selector)#"
             
         )
       .def("Arguments",
             ( const NCollection_List<TopoDS_Shape> & (BOPDS_DS::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPDS_DS::*)() const>(&BOPDS_DS::Arguments),
             R"#(Selector Returns the arguments of an operation)#"
             
         )
       .def("PaveBlocksPool",
             ( const NCollection_DynamicArray<NCollection_List<handle<BOPDS_PaveBlock>>> & (BOPDS_DS::*)() const) static_cast< const NCollection_DynamicArray<NCollection_List<handle<BOPDS_PaveBlock>>> & (BOPDS_DS::*)() const>(&BOPDS_DS::PaveBlocksPool),
             R"#(Selector Returns the information about pave blocks on source edges)#"
             
         )
       .def("ChangePaveBlocksPool",
             (NCollection_DynamicArray<NCollection_List<handle<BOPDS_PaveBlock>>> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<NCollection_List<handle<BOPDS_PaveBlock>>> & (BOPDS_DS::*)() >(&BOPDS_DS::ChangePaveBlocksPool),
             R"#(Selector/Modifier Returns the information about pave blocks on source edges)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("FaceInfoPool",
             ( const NCollection_DynamicArray<BOPDS_FaceInfo> & (BOPDS_DS::*)() const) static_cast< const NCollection_DynamicArray<BOPDS_FaceInfo> & (BOPDS_DS::*)() const>(&BOPDS_DS::FaceInfoPool),
             R"#(Selector Returns the information about state of faces)#"
             
         )
       .def("ShapesSD",
             (NCollection_DataMap<int, int> & (BOPDS_DS::*)() ) static_cast<NCollection_DataMap<int, int> & (BOPDS_DS::*)() >(&BOPDS_DS::ShapesSD),
             R"#(Selector Returns the collection same domain shapes)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVV",
             (NCollection_DynamicArray<BOPDS_InterfVV> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVV> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVV),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Vertex)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVE",
             (NCollection_DynamicArray<BOPDS_InterfVE> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVE> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVE),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Edge)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVF",
             (NCollection_DynamicArray<BOPDS_InterfVF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVF),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEE",
             (NCollection_DynamicArray<BOPDS_InterfEE> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEE> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEE),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Edge)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEF",
             (NCollection_DynamicArray<BOPDS_InterfEF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEF),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfFF",
             (NCollection_DynamicArray<BOPDS_InterfFF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfFF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfFF),
             R"#(Selector/Modifier Returns the collection of interferences Face/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVZ",
             (NCollection_DynamicArray<BOPDS_InterfVZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVZ),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEZ",
             (NCollection_DynamicArray<BOPDS_InterfEZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEZ),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfFZ",
             (NCollection_DynamicArray<BOPDS_InterfFZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfFZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfFZ),
             R"#(Selector/Modifier Returns the collection of interferences Face/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfZZ",
             (NCollection_DynamicArray<BOPDS_InterfZZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfZZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfZZ),
             R"#(Selector/Modifier Returns the collection of interferences Solid/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Interferences",
             ( const NCollection_Map<BOPDS_Pair> & (BOPDS_DS::*)() const) static_cast< const NCollection_Map<BOPDS_Pair> & (BOPDS_DS::*)() const>(&BOPDS_DS::Interferences),
             R"#(Selector Returns the table of interferences)#"
             
         )
       .def("InterfVV",
             (NCollection_DynamicArray<BOPDS_InterfVV> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVV> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVV),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Vertex)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVE",
             (NCollection_DynamicArray<BOPDS_InterfVE> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVE> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVE),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Edge)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVF",
             (NCollection_DynamicArray<BOPDS_InterfVF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVF),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEE",
             (NCollection_DynamicArray<BOPDS_InterfEE> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEE> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEE),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Edge)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEF",
             (NCollection_DynamicArray<BOPDS_InterfEF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEF),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfFF",
             (NCollection_DynamicArray<BOPDS_InterfFF> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfFF> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfFF),
             R"#(Selector/Modifier Returns the collection of interferences Face/Face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfVZ",
             (NCollection_DynamicArray<BOPDS_InterfVZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfVZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfVZ),
             R"#(Selector/Modifier Returns the collection of interferences Vertex/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfEZ",
             (NCollection_DynamicArray<BOPDS_InterfEZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfEZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfEZ),
             R"#(Selector/Modifier Returns the collection of interferences Edge/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfFZ",
             (NCollection_DynamicArray<BOPDS_InterfFZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfFZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfFZ),
             R"#(Selector/Modifier Returns the collection of interferences Face/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("InterfZZ",
             (NCollection_DynamicArray<BOPDS_InterfZZ> & (BOPDS_DS::*)() ) static_cast<NCollection_DynamicArray<BOPDS_InterfZZ> & (BOPDS_DS::*)() >(&BOPDS_DS::InterfZZ),
             R"#(Selector/Modifier Returns the collection of interferences Solid/Solid)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Interferences",
             ( const NCollection_Map<BOPDS_Pair> & (BOPDS_DS::*)() const) static_cast< const NCollection_Map<BOPDS_Pair> & (BOPDS_DS::*)() const>(&BOPDS_DS::Interferences),
             R"#(Selector Returns the table of interferences)#"
             
         )
;

    // Class BOPDS_FaceInfo from ./opencascade/BOPDS_FaceInfo.hxx
    klass = m.attr("BOPDS_FaceInfo");


    // nested enums

    static_cast<py::class_<BOPDS_FaceInfo , shared_ptr<BOPDS_FaceInfo>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPDS_FaceInfo::*)() ) static_cast<void (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::Clear),
             R"#(Clears the contents)#" 
          )
        .def("SetIndex",
             (void (BOPDS_FaceInfo::*)(  const int  ) ) static_cast<void (BOPDS_FaceInfo::*)(  const int  ) >(&BOPDS_FaceInfo::SetIndex),
             R"#(Modifier Sets the index of the face <theI>)#"  , py::arg("theI")
          )
        .def("Index",
             (int (BOPDS_FaceInfo::*)() const) static_cast<int (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::Index),
             R"#(Selector Returns the index of the face)#" 
          )
        .def("Clear",
             (void (BOPDS_FaceInfo::*)() ) static_cast<void (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::Clear),
             R"#(Clears the contents)#" 
          )
        .def("SetIndex",
             (void (BOPDS_FaceInfo::*)(  const int  ) ) static_cast<void (BOPDS_FaceInfo::*)(  const int  ) >(&BOPDS_FaceInfo::SetIndex),
             R"#(Modifier Sets the index of the face <theI>)#"  , py::arg("theI")
          )
        .def("Index",
             (int (BOPDS_FaceInfo::*)() const) static_cast<int (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::Index),
             R"#(Selector Returns the index of the face)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PaveBlocksIn",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksIn),
             R"#(Selector Returns the pave blocks of the face that have state In)#"
             
         )
       .def("ChangePaveBlocksIn",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksIn),
             R"#(Selector/Modifier Returns the pave blocks of the face that have state In)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesIn",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesIn),
             R"#(Selector Returns the list of indices for vertices of the face that have state In)#"
             
         )
       .def("ChangeVerticesIn",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesIn),
             R"#(Selector/Modifier Returns the list of indices for vertices of the face that have state In)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocksOn",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksOn),
             R"#(Selector Returns the pave blocks of the face that have state On)#"
             
         )
       .def("ChangePaveBlocksOn",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksOn),
             R"#(Selector/Modifier Returns the pave blocks of the face that have state On)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesOn",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesOn),
             R"#(Selector Returns the list of indices for vertices of the face that have state On)#"
             
         )
       .def("ChangeVerticesOn",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesOn),
             R"#(Selector/Modifier Returns the list of indices for vertices of the face that have state On)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocksSc",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksSc),
             R"#(Selector Returns the pave blocks of the face that are pave blocks of section edges)#"
             
         )
       .def("ChangePaveBlocksSc",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksSc),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesSc",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesSc),
             R"#(Selector Returns the list of indices for section vertices of the face)#"
             
         )
       .def("ChangeVerticesSc",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesSc),
             R"#(Selector/Modifier Returns the list of indices for section vertices of the face)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocksIn",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksIn),
             R"#(Selector Returns the pave blocks of the face that have state In)#"
             
         )
       .def("ChangePaveBlocksIn",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksIn),
             R"#(Selector/Modifier Returns the pave blocks of the face that have state In)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesIn",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesIn),
             R"#(Selector Returns the list of indices for vertices of the face that have state In)#"
             
         )
       .def("ChangeVerticesIn",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesIn),
             R"#(Selector/Modifier Returns the list of indices for vertices of the face that have state In)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocksOn",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksOn),
             R"#(Selector Returns the pave blocks of the face that have state On)#"
             
         )
       .def("ChangePaveBlocksOn",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksOn),
             R"#(Selector/Modifier Returns the pave blocks of the face that have state On)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesOn",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesOn),
             R"#(Selector Returns the list of indices for vertices of the face that have state On)#"
             
         )
       .def("ChangeVerticesOn",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesOn),
             R"#(Selector/Modifier Returns the list of indices for vertices of the face that have state On)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PaveBlocksSc",
             ( const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::PaveBlocksSc),
             R"#(Selector Returns the pave blocks of the face that are pave blocks of section edges)#"
             
         )
       .def("ChangePaveBlocksSc",
             (NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_IndexedMap<handle<BOPDS_PaveBlock>> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangePaveBlocksSc),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("VerticesSc",
             ( const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const) static_cast< const NCollection_Map<int> & (BOPDS_FaceInfo::*)() const>(&BOPDS_FaceInfo::VerticesSc),
             R"#(Selector Returns the list of indices for section vertices of the face)#"
             
         )
       .def("ChangeVerticesSc",
             (NCollection_Map<int> & (BOPDS_FaceInfo::*)() ) static_cast<NCollection_Map<int> & (BOPDS_FaceInfo::*)() >(&BOPDS_FaceInfo::ChangeVerticesSc),
             R"#(Selector/Modifier Returns the list of indices for section vertices of the face)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPDS_IndexRange from ./opencascade/BOPDS_IndexRange.hxx
    klass = m.attr("BOPDS_IndexRange");


    // nested enums

    static_cast<py::class_<BOPDS_IndexRange , shared_ptr<BOPDS_IndexRange>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >()  , py::arg("theI1"),  py::arg("theI2") )
    // custom constructors
    // methods
        .def("SetFirst",
             (void (BOPDS_IndexRange::*)(  const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int  ) >(&BOPDS_IndexRange::SetFirst),
             R"#(Modifier Sets the first index <theI1> of the range)#"  , py::arg("theI1")
          )
        .def("SetLast",
             (void (BOPDS_IndexRange::*)(  const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int  ) >(&BOPDS_IndexRange::SetLast),
             R"#(Modifier Sets the second index <theI2> of the range)#"  , py::arg("theI2")
          )
        .def("First",
             (int (BOPDS_IndexRange::*)() const) static_cast<int (BOPDS_IndexRange::*)() const>(&BOPDS_IndexRange::First),
             R"#(Selector Returns the first index of the range)#" 
          )
        .def("Last",
             (int (BOPDS_IndexRange::*)() const) static_cast<int (BOPDS_IndexRange::*)() const>(&BOPDS_IndexRange::Last),
             R"#(Selector Returns the second index of the range)#" 
          )
        .def("SetIndices",
             (void (BOPDS_IndexRange::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int ,   const int  ) >(&BOPDS_IndexRange::SetIndices),
             R"#(Modifier Sets the first index of the range <theI1> Sets the second index of the range <theI2>)#"  , py::arg("theI1"),  py::arg("theI2")
          )
        .def("Contains",
             (bool (BOPDS_IndexRange::*)(  const int  ) const) static_cast<bool (BOPDS_IndexRange::*)(  const int  ) const>(&BOPDS_IndexRange::Contains),
             R"#(Query Returns true if the range contains <theIndex>)#"  , py::arg("theIndex")
          )
        .def("Dump",
             (void (BOPDS_IndexRange::*)() const) static_cast<void (BOPDS_IndexRange::*)() const>(&BOPDS_IndexRange::Dump),
             R"#()#" 
          )
        .def("SetFirst",
             (void (BOPDS_IndexRange::*)(  const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int  ) >(&BOPDS_IndexRange::SetFirst),
             R"#(Modifier Sets the first index <theI1> of the range)#"  , py::arg("aFirst")
          )
        .def("First",
             (int (BOPDS_IndexRange::*)() const) static_cast<int (BOPDS_IndexRange::*)() const>(&BOPDS_IndexRange::First),
             R"#(Selector Returns the first index of the range)#" 
          )
        .def("SetLast",
             (void (BOPDS_IndexRange::*)(  const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int  ) >(&BOPDS_IndexRange::SetLast),
             R"#(Modifier Sets the second index <theI2> of the range)#"  , py::arg("aLast")
          )
        .def("Last",
             (int (BOPDS_IndexRange::*)() const) static_cast<int (BOPDS_IndexRange::*)() const>(&BOPDS_IndexRange::Last),
             R"#(Selector Returns the second index of the range)#" 
          )
        .def("SetIndices",
             (void (BOPDS_IndexRange::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_IndexRange::*)(  const int ,   const int  ) >(&BOPDS_IndexRange::SetIndices),
             R"#(Modifier Sets the first index of the range <theI1> Sets the second index of the range <theI2>)#"  , py::arg("theI1"),  py::arg("theI2")
          )
        .def("Contains",
             (bool (BOPDS_IndexRange::*)(  const int  ) const) static_cast<bool (BOPDS_IndexRange::*)(  const int  ) const>(&BOPDS_IndexRange::Contains),
             R"#(Query Returns true if the range contains <theIndex>)#"  , py::arg("aIndex")
          )
    // methods using call by reference i.s.o. return
        .def("Indices",
             []( BOPDS_IndexRange &self   ){
                 int  theI1;
                int  theI2;

                 self.Indices(theI1,theI2);
                 return std::make_tuple(theI1,theI2); },
             R"#(Selector Returns the first index of the range <theI1> Returns the second index of the range <theI2>)#" 
          )
        .def("Indices",
             []( BOPDS_IndexRange &self   ){
                 int  theI1;
                int  theI2;

                 self.Indices(theI1,theI2);
                 return std::make_tuple(theI1,theI2); },
             R"#(Selector Returns the first index of the range <theI1> Returns the second index of the range <theI2>)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_Interf from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_Interf");


    // nested enums

    static_cast<py::class_<BOPDS_Interf , shared_ptr_nodelete<BOPDS_Interf>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetIndices",
             (void (BOPDS_Interf::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_Interf::*)(  const int ,   const int  ) >(&BOPDS_Interf::SetIndices),
             R"#(Sets the indices of interferred shapes)#"  , py::arg("theIndex1"),  py::arg("theIndex2")
          )
        .def("SetIndex1",
             (void (BOPDS_Interf::*)(  const int  ) ) static_cast<void (BOPDS_Interf::*)(  const int  ) >(&BOPDS_Interf::SetIndex1),
             R"#(Sets the index of the first interferred shape)#"  , py::arg("theIndex")
          )
        .def("SetIndex2",
             (void (BOPDS_Interf::*)(  const int  ) ) static_cast<void (BOPDS_Interf::*)(  const int  ) >(&BOPDS_Interf::SetIndex2),
             R"#(Sets the index of the second interferred shape)#"  , py::arg("theIndex")
          )
        .def("Index1",
             (int (BOPDS_Interf::*)() const) static_cast<int (BOPDS_Interf::*)() const>(&BOPDS_Interf::Index1),
             R"#(Returns the index of the first interferred shape)#" 
          )
        .def("Index2",
             (int (BOPDS_Interf::*)() const) static_cast<int (BOPDS_Interf::*)() const>(&BOPDS_Interf::Index2),
             R"#(Returns the index of the second interferred shape)#" 
          )
        .def("OppositeIndex",
             (int (BOPDS_Interf::*)(  const int  ) const) static_cast<int (BOPDS_Interf::*)(  const int  ) const>(&BOPDS_Interf::OppositeIndex),
             R"#(Returns the index of that are opposite to the given index)#"  , py::arg("theI")
          )
        .def("Contains",
             (bool (BOPDS_Interf::*)(  const int  ) const) static_cast<bool (BOPDS_Interf::*)(  const int  ) const>(&BOPDS_Interf::Contains),
             R"#(Returns true if the interference contains given index)#"  , py::arg("theIndex")
          )
        .def("SetIndexNew",
             (void (BOPDS_Interf::*)(  const int  ) ) static_cast<void (BOPDS_Interf::*)(  const int  ) >(&BOPDS_Interf::SetIndexNew),
             R"#(Sets the index of new shape)#"  , py::arg("theIndex")
          )
        .def("IndexNew",
             (int (BOPDS_Interf::*)() const) static_cast<int (BOPDS_Interf::*)() const>(&BOPDS_Interf::IndexNew),
             R"#(Returns the index of new shape)#" 
          )
        .def("HasIndexNew",
             (bool (BOPDS_Interf::*)( int &  ) const) static_cast<bool (BOPDS_Interf::*)( int &  ) const>(&BOPDS_Interf::HasIndexNew),
             R"#(Returns true if the interference has index of new shape that is equal to the given index)#"  , py::arg("theIndex")
          )
        .def("HasIndexNew",
             (bool (BOPDS_Interf::*)() const) static_cast<bool (BOPDS_Interf::*)() const>(&BOPDS_Interf::HasIndexNew),
             R"#(Returns true if the interference has index of new shape the index)#" 
          )
        .def("GetIndexNew",
             (std::optional<int> (BOPDS_Interf::*)() const) static_cast<std::optional<int> (BOPDS_Interf::*)() const>(&BOPDS_Interf::GetIndexNew),
             R"#(Returns the index of new shape. If the index is not set, returns std::nullopt.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Indices",
             []( BOPDS_Interf &self   ){
                 int  theIndex1;
                int  theIndex2;

                 self.Indices(theIndex1,theIndex2);
                 return std::make_tuple(theIndex1,theIndex2); },
             R"#(Returns the indices of interferred shapes)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_Pair from ./opencascade/BOPDS_Pair.hxx
    klass = m.attr("BOPDS_Pair");


    // nested enums

    static_cast<py::class_<BOPDS_Pair , shared_ptr<BOPDS_Pair>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >()  , py::arg("theIndex1"),  py::arg("theIndex2") )
    // custom constructors
    // methods
        .def("SetIndices",
             (void (BOPDS_Pair::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_Pair::*)(  const int ,   const int  ) >(&BOPDS_Pair::SetIndices),
             R"#(Sets the indices)#"  , py::arg("theIndex1"),  py::arg("theIndex2")
          )
        .def("IsEqual",
             (bool (BOPDS_Pair::*)(  const BOPDS_Pair &  ) const) static_cast<bool (BOPDS_Pair::*)(  const BOPDS_Pair &  ) const>(&BOPDS_Pair::IsEqual),
             R"#(Returns true if the Pair is equal to <the theOther>)#"  , py::arg("theOther")
          )
    // methods using call by reference i.s.o. return
        .def("Indices",
             []( BOPDS_Pair &self   ){
                 int  theIndex1;
                int  theIndex2;

                 self.Indices(theIndex1,theIndex2);
                 return std::make_tuple(theIndex1,theIndex2); },
             R"#(Gets the indices)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_Pave from ./opencascade/BOPDS_Pave.hxx
    klass = m.attr("BOPDS_Pave");


    // nested enums

    static_cast<py::class_<BOPDS_Pave , shared_ptr<BOPDS_Pave>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const double >()  , py::arg("theIndex"),  py::arg("theParameter") )
    // custom constructors
    // methods
        .def("SetIndex",
             (void (BOPDS_Pave::*)(  const int  ) ) static_cast<void (BOPDS_Pave::*)(  const int  ) >(&BOPDS_Pave::SetIndex),
             R"#(Modifier Sets the index of vertex <theIndex>)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_Pave::*)() const) static_cast<int (BOPDS_Pave::*)() const>(&BOPDS_Pave::Index),
             R"#(Selector Returns the index of vertex)#" 
          )
        .def("SetParameter",
             (void (BOPDS_Pave::*)(  const double  ) ) static_cast<void (BOPDS_Pave::*)(  const double  ) >(&BOPDS_Pave::SetParameter),
             R"#(Modifier Sets the parameter of vertex <theParameter>)#"  , py::arg("theParameter")
          )
        .def("Parameter",
             (double (BOPDS_Pave::*)() const) static_cast<double (BOPDS_Pave::*)() const>(&BOPDS_Pave::Parameter),
             R"#(Selector Returns the parameter of vertex)#" 
          )
        .def("IsLess",
             (bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const) static_cast<bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const>(&BOPDS_Pave::IsLess),
             R"#(Query Returns true if the parameter of this is less than the parameter of <theOther>)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const) static_cast<bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const>(&BOPDS_Pave::IsEqual),
             R"#(Query Returns true if the parameter of this is equal to the parameter of <theOther>)#"  , py::arg("theOther")
          )
        .def("Dump",
             (void (BOPDS_Pave::*)() const) static_cast<void (BOPDS_Pave::*)() const>(&BOPDS_Pave::Dump),
             R"#()#" 
          )
        .def("SetIndex",
             (void (BOPDS_Pave::*)(  const int  ) ) static_cast<void (BOPDS_Pave::*)(  const int  ) >(&BOPDS_Pave::SetIndex),
             R"#(Modifier Sets the index of vertex <theIndex>)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_Pave::*)() const) static_cast<int (BOPDS_Pave::*)() const>(&BOPDS_Pave::Index),
             R"#(Selector Returns the index of vertex)#" 
          )
        .def("SetParameter",
             (void (BOPDS_Pave::*)(  const double  ) ) static_cast<void (BOPDS_Pave::*)(  const double  ) >(&BOPDS_Pave::SetParameter),
             R"#(Modifier Sets the parameter of vertex <theParameter>)#"  , py::arg("theParameter")
          )
        .def("Parameter",
             (double (BOPDS_Pave::*)() const) static_cast<double (BOPDS_Pave::*)() const>(&BOPDS_Pave::Parameter),
             R"#(Selector Returns the parameter of vertex)#" 
          )
        .def("IsLess",
             (bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const) static_cast<bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const>(&BOPDS_Pave::IsLess),
             R"#(Query Returns true if the parameter of this is less than the parameter of <theOther>)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const) static_cast<bool (BOPDS_Pave::*)(  const BOPDS_Pave &  ) const>(&BOPDS_Pave::IsEqual),
             R"#(Query Returns true if the parameter of this is equal to the parameter of <theOther>)#"  , py::arg("theOther")
          )
    // methods using call by reference i.s.o. return
        .def("Contents",
             []( BOPDS_Pave &self   ){
                 int  theIndex;
                double  theParameter;

                 self.Contents(theIndex,theParameter);
                 return std::make_tuple(theIndex,theParameter); },
             R"#(Selector Returns the index of vertex <theIndex> Returns the parameter of vertex <theParameter>)#" 
          )
        .def("Contents",
             []( BOPDS_Pave &self   ){
                 int  theIndex;
                double  theParameter;

                 self.Contents(theIndex,theParameter);
                 return std::make_tuple(theIndex,theParameter); },
             R"#(Selector Returns the index of vertex <theIndex> Returns the parameter of vertex <theParameter>)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_PaveBlock from ./opencascade/BOPDS_PaveBlock.hxx
    klass = m.attr("BOPDS_PaveBlock");


    // nested enums

    static_cast<py::class_<BOPDS_PaveBlock ,opencascade::handle<BOPDS_PaveBlock>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetPave1",
             (void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) >(&BOPDS_PaveBlock::SetPave1),
             R"#(Modifier Sets the first pave <thePave>)#"  , py::arg("thePave")
          )
        .def("SetPave2",
             (void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) >(&BOPDS_PaveBlock::SetPave2),
             R"#(Modifier Sets the second pave <thePave>)#"  , py::arg("thePave")
          )
        .def("SetEdge",
             (void (BOPDS_PaveBlock::*)(  const int  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const int  ) >(&BOPDS_PaveBlock::SetEdge),
             R"#(Modifier Sets the index of edge of pave block <theEdge>)#"  , py::arg("theEdge")
          )
        .def("Edge",
             (int (BOPDS_PaveBlock::*)() const) static_cast<int (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::Edge),
             R"#(Selector Returns the index of edge of pave block)#" 
          )
        .def("HasEdge",
             (bool (BOPDS_PaveBlock::*)() const) static_cast<bool (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::HasEdge),
             R"#(Query Returns true if the pave block has edge)#" 
          )
        .def("HasEdge",
             (bool (BOPDS_PaveBlock::*)( int &  ) const) static_cast<bool (BOPDS_PaveBlock::*)( int &  ) const>(&BOPDS_PaveBlock::HasEdge),
             R"#(Query Returns true if the pave block has edge Returns the index of edge <theEdge>)#"  , py::arg("theEdge")
          )
        .def("SetOriginalEdge",
             (void (BOPDS_PaveBlock::*)(  const int  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const int  ) >(&BOPDS_PaveBlock::SetOriginalEdge),
             R"#(Modifier Sets the index of original edge of the pave block <theEdge>)#"  , py::arg("theEdge")
          )
        .def("OriginalEdge",
             (int (BOPDS_PaveBlock::*)() const) static_cast<int (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::OriginalEdge),
             R"#(Selector Returns the index of original edge of pave block)#" 
          )
        .def("IsSplitEdge",
             (bool (BOPDS_PaveBlock::*)() const) static_cast<bool (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::IsSplitEdge),
             R"#(Query Returns true if the edge is equal to the original edge of the pave block)#" 
          )
        .def("HasSameBounds",
             (bool (BOPDS_PaveBlock::*)(  const handle<BOPDS_PaveBlock> &  ) const) static_cast<bool (BOPDS_PaveBlock::*)(  const handle<BOPDS_PaveBlock> &  ) const>(&BOPDS_PaveBlock::HasSameBounds),
             R"#(Query Returns true if the pave block has pave indices that equal to the pave indices of the pave block <theOther>)#"  , py::arg("theOther")
          )
        .def("IsToUpdate",
             (bool (BOPDS_PaveBlock::*)() const) static_cast<bool (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::IsToUpdate),
             R"#(Query Returns true if the pave block contains extra paves)#" 
          )
        .def("AppendExtPave",
             (void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) >(&BOPDS_PaveBlock::AppendExtPave),
             R"#(Modifier Appends extra paves <thePave>)#"  , py::arg("thePave")
          )
        .def("AppendExtPave1",
             (void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const BOPDS_Pave &  ) >(&BOPDS_PaveBlock::AppendExtPave1),
             R"#(Modifier Appends extra pave <thePave>)#"  , py::arg("thePave")
          )
        .def("RemoveExtPave",
             (void (BOPDS_PaveBlock::*)(  const int  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const int  ) >(&BOPDS_PaveBlock::RemoveExtPave),
             R"#(Modifier Removes a pave with the given vertex number from extra paves)#"  , py::arg("theVertNum")
          )
        .def("Update",
             (void (BOPDS_PaveBlock::*)( NCollection_List<handle<BOPDS_PaveBlock>> & ,   const bool  ) ) static_cast<void (BOPDS_PaveBlock::*)( NCollection_List<handle<BOPDS_PaveBlock>> & ,   const bool  ) >(&BOPDS_PaveBlock::Update),
             R"#(Modifier Updates the pave block. The extra paves are used to create new pave blocks <theLPB>. <theFlag> - if true, the first and second pave are used to produce new pave blocks.)#"  , py::arg("theLPB"),  py::arg("theFlag")=static_cast< const bool>(true)
          )
        .def("ContainsParameter",
             (bool (BOPDS_PaveBlock::*)(  const double ,   const double ,  int &  ) const) static_cast<bool (BOPDS_PaveBlock::*)(  const double ,   const double ,  int &  ) const>(&BOPDS_PaveBlock::ContainsParameter),
             R"#(Query Returns true if the extra paves contain the pave with given value of the parameter <thePrm> <theTol> - the value of the tolerance to compare <theInd> - index of the found pave)#"  , py::arg("thePrm"),  py::arg("theTol"),  py::arg("theInd")
          )
        .def("SetShrunkData",
             (void (BOPDS_PaveBlock::*)(  const double ,   const double ,   const Bnd_Box & ,   const bool  ) ) static_cast<void (BOPDS_PaveBlock::*)(  const double ,   const double ,   const Bnd_Box & ,   const bool  ) >(&BOPDS_PaveBlock::SetShrunkData),
             R"#(Modifier Sets the shrunk data for the pave block <theTS1>, <theTS2> - shrunk range <theBox> - the bounding box <theIsSplittable> - defines whether the edge can be split)#"  , py::arg("theTS1"),  py::arg("theTS2"),  py::arg("theBox"),  py::arg("theIsSplittable")
          )
        .def("HasShrunkData",
             (bool (BOPDS_PaveBlock::*)() const) static_cast<bool (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::HasShrunkData),
             R"#(Query Returns true if the pave block contains the shrunk data)#" 
          )
        .def("Dump",
             (void (BOPDS_PaveBlock::*)() const) static_cast<void (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::Dump),
             R"#()#" 
          )
        .def("IsSplittable",
             (bool (BOPDS_PaveBlock::*)() const) static_cast<bool (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::IsSplittable),
             R"#(Query Returns FALSE if the pave block has a too short shrunk range and cannot be split, otherwise returns TRUE)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Range",
             []( BOPDS_PaveBlock &self   ){
                 double  theT1;
                double  theT2;

                 self.Range(theT1,theT2);
                 return std::make_tuple(theT1,theT2); },
             R"#(Selector Returns the parametric range <theT1,theT2> of the pave block)#" 
          )
        .def("Indices",
             []( BOPDS_PaveBlock &self   ){
                 int  theIndex1;
                int  theIndex2;

                 self.Indices(theIndex1,theIndex2);
                 return std::make_tuple(theIndex1,theIndex2); },
             R"#(Selector Returns the pave indices <theIndex1,theIndex2> of the pave block)#" 
          )
        .def("ShrunkData",
             []( BOPDS_PaveBlock &self , Bnd_Box & theBox ){
                 double  theTS1;
                double  theTS2;
                bool  theIsSplittable;

                 self.ShrunkData(theTS1,theTS2,theBox,theIsSplittable);
                 return std::make_tuple(theTS1,theTS2,theIsSplittable); },
             R"#(Selector Returns the shrunk data for the pave block <theTS1>, <theTS2> - shrunk range <theBox> - the bounding box <theIsSplittable> - defines whether the edge can be split)#"  , py::arg("theBox")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPDS_PaveBlock::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPDS_PaveBlock::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Pave1",
             ( const BOPDS_Pave & (BOPDS_PaveBlock::*)() const) static_cast< const BOPDS_Pave & (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::Pave1),
             R"#(Selector Returns the first pave)#"
             
         )
       .def("Pave2",
             ( const BOPDS_Pave & (BOPDS_PaveBlock::*)() const) static_cast< const BOPDS_Pave & (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::Pave2),
             R"#(Selector Returns the second pave)#"
             
         )
       .def("ExtPaves",
             ( const NCollection_List<BOPDS_Pave> & (BOPDS_PaveBlock::*)() const) static_cast< const NCollection_List<BOPDS_Pave> & (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::ExtPaves),
             R"#(Selector Returns the extra paves)#"
             
         )
       .def("ChangeExtPaves",
             (NCollection_List<BOPDS_Pave> & (BOPDS_PaveBlock::*)() ) static_cast<NCollection_List<BOPDS_Pave> & (BOPDS_PaveBlock::*)() >(&BOPDS_PaveBlock::ChangeExtPaves),
             R"#(Selector / Modifier Returns the extra paves)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPDS_PaveBlock::*)() const) static_cast< const handle<Standard_Type> & (BOPDS_PaveBlock::*)() const>(&BOPDS_PaveBlock::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPDS_Point from ./opencascade/BOPDS_Point.hxx
    klass = m.attr("BOPDS_Point");


    // nested enums

    static_cast<py::class_<BOPDS_Point , shared_ptr<BOPDS_Point>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetPnt",
             (void (BOPDS_Point::*)(  const gp_Pnt &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt &  ) >(&BOPDS_Point::SetPnt),
             R"#(Modifier Sets 3D point <thePnt>)#"  , py::arg("thePnt")
          )
        .def("SetPnt2D1",
             (void (BOPDS_Point::*)(  const gp_Pnt2d &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt2d &  ) >(&BOPDS_Point::SetPnt2D1),
             R"#(Modifier Sets 2D point on the first face <thePnt>)#"  , py::arg("thePnt")
          )
        .def("SetPnt2D2",
             (void (BOPDS_Point::*)(  const gp_Pnt2d &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt2d &  ) >(&BOPDS_Point::SetPnt2D2),
             R"#(Modifier Sets 2D point on the second face <thePnt>)#"  , py::arg("thePnt")
          )
        .def("SetIndex",
             (void (BOPDS_Point::*)(  const int  ) ) static_cast<void (BOPDS_Point::*)(  const int  ) >(&BOPDS_Point::SetIndex),
             R"#(Modifier Sets the index of the vertex <theIndex>)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_Point::*)() const) static_cast<int (BOPDS_Point::*)() const>(&BOPDS_Point::Index),
             R"#(Selector Returns index of the vertex)#" 
          )
        .def("SetIndex",
             (void (BOPDS_Point::*)(  const int  ) ) static_cast<void (BOPDS_Point::*)(  const int  ) >(&BOPDS_Point::SetIndex),
             R"#(Modifier Sets the index of the vertex <theIndex>)#"  , py::arg("theIndex")
          )
        .def("Index",
             (int (BOPDS_Point::*)() const) static_cast<int (BOPDS_Point::*)() const>(&BOPDS_Point::Index),
             R"#(Selector Returns index of the vertex)#" 
          )
        .def("SetPnt",
             (void (BOPDS_Point::*)(  const gp_Pnt &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt &  ) >(&BOPDS_Point::SetPnt),
             R"#(Modifier Sets 3D point <thePnt>)#"  , py::arg("thePnt")
          )
        .def("SetPnt2D1",
             (void (BOPDS_Point::*)(  const gp_Pnt2d &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt2d &  ) >(&BOPDS_Point::SetPnt2D1),
             R"#(Modifier Sets 2D point on the first face <thePnt>)#"  , py::arg("thePnt")
          )
        .def("SetPnt2D2",
             (void (BOPDS_Point::*)(  const gp_Pnt2d &  ) ) static_cast<void (BOPDS_Point::*)(  const gp_Pnt2d &  ) >(&BOPDS_Point::SetPnt2D2),
             R"#(Modifier Sets 2D point on the second face <thePnt>)#"  , py::arg("thePnt")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Pnt",
             ( const gp_Pnt & (BOPDS_Point::*)() const) static_cast< const gp_Pnt & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt),
             R"#(Selector Returns 3D point)#"
             
         )
       .def("Pnt2D1",
             ( const gp_Pnt2d & (BOPDS_Point::*)() const) static_cast< const gp_Pnt2d & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt2D1),
             R"#(Selector Returns 2D point on the first face <thePnt>)#"
             
         )
       .def("Pnt2D2",
             ( const gp_Pnt2d & (BOPDS_Point::*)() const) static_cast< const gp_Pnt2d & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt2D2),
             R"#(Selector Returns 2D point on the second face <thePnt>)#"
             
         )
       .def("Pnt",
             ( const gp_Pnt & (BOPDS_Point::*)() const) static_cast< const gp_Pnt & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt),
             R"#(Selector Returns 3D point)#"
             
         )
       .def("Pnt2D1",
             ( const gp_Pnt2d & (BOPDS_Point::*)() const) static_cast< const gp_Pnt2d & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt2D1),
             R"#(Selector Returns 2D point on the first face <thePnt>)#"
             
         )
       .def("Pnt2D2",
             ( const gp_Pnt2d & (BOPDS_Point::*)() const) static_cast< const gp_Pnt2d & (BOPDS_Point::*)() const>(&BOPDS_Point::Pnt2D2),
             R"#(Selector Returns 2D point on the second face <thePnt>)#"
             
         )
;

    // Class BOPDS_ShapeInfo from ./opencascade/BOPDS_ShapeInfo.hxx
    klass = m.attr("BOPDS_ShapeInfo");


    // nested enums

    static_cast<py::class_<BOPDS_ShapeInfo , shared_ptr<BOPDS_ShapeInfo>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetShape",
             (void (BOPDS_ShapeInfo::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const TopoDS_Shape &  ) >(&BOPDS_ShapeInfo::SetShape),
             R"#(Modifier Sets the shape <theS>)#"  , py::arg("theS")
          )
        .def("SetShapeType",
             (void (BOPDS_ShapeInfo::*)(  const TopAbs_ShapeEnum  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const TopAbs_ShapeEnum  ) >(&BOPDS_ShapeInfo::SetShapeType),
             R"#(Modifier Sets the type of shape theType)#"  , py::arg("theType")
          )
        .def("ShapeType",
             (TopAbs_ShapeEnum (BOPDS_ShapeInfo::*)() const) static_cast<TopAbs_ShapeEnum (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::ShapeType),
             R"#(Selector Returns the type of shape)#" 
          )
        .def("SetBox",
             (void (BOPDS_ShapeInfo::*)(  const Bnd_Box &  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const Bnd_Box &  ) >(&BOPDS_ShapeInfo::SetBox),
             R"#(Modifier Sets the boundung box of the shape theBox)#"  , py::arg("theBox")
          )
        .def("HasSubShape",
             (bool (BOPDS_ShapeInfo::*)(  const int  ) const) static_cast<bool (BOPDS_ShapeInfo::*)(  const int  ) const>(&BOPDS_ShapeInfo::HasSubShape),
             R"#(Query Returns true if the shape has sub-shape with index theI)#"  , py::arg("theI")
          )
        .def("HasReference",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasReference),
             R"#()#" 
          )
        .def("SetReference",
             (void (BOPDS_ShapeInfo::*)(  const int  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const int  ) >(&BOPDS_ShapeInfo::SetReference),
             R"#(Modifier Sets the index of a reference information)#"  , py::arg("theI")
          )
        .def("Reference",
             (int (BOPDS_ShapeInfo::*)() const) static_cast<int (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Reference),
             R"#(Selector Returns the index of a reference information)#" 
          )
        .def("HasBRep",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasBRep),
             R"#(Query Returns true if the shape has boundary representation)#" 
          )
        .def("IsInterfering",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::IsInterfering),
             R"#(Returns true if the shape can be participant of an interference)#" 
          )
        .def("HasFlag",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasFlag),
             R"#(Query Returns true if there is flag.)#" 
          )
        .def("HasFlag",
             (bool (BOPDS_ShapeInfo::*)( int &  ) const) static_cast<bool (BOPDS_ShapeInfo::*)( int &  ) const>(&BOPDS_ShapeInfo::HasFlag),
             R"#(Query Returns true if there is flag. Returns the flag theFlag)#"  , py::arg("theFlag")
          )
        .def("SetFlag",
             (void (BOPDS_ShapeInfo::*)(  const int  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const int  ) >(&BOPDS_ShapeInfo::SetFlag),
             R"#(Modifier Sets the flag)#"  , py::arg("theI")
          )
        .def("Flag",
             (int (BOPDS_ShapeInfo::*)() const) static_cast<int (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Flag),
             R"#(Returns the flag)#" 
          )
        .def("Dump",
             (void (BOPDS_ShapeInfo::*)() const) static_cast<void (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Dump),
             R"#()#" 
          )
        .def("SetShape",
             (void (BOPDS_ShapeInfo::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const TopoDS_Shape &  ) >(&BOPDS_ShapeInfo::SetShape),
             R"#(Modifier Sets the shape <theS>)#"  , py::arg("theS")
          )
        .def("SetShapeType",
             (void (BOPDS_ShapeInfo::*)(  const TopAbs_ShapeEnum  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const TopAbs_ShapeEnum  ) >(&BOPDS_ShapeInfo::SetShapeType),
             R"#(Modifier Sets the type of shape theType)#"  , py::arg("theType")
          )
        .def("ShapeType",
             (TopAbs_ShapeEnum (BOPDS_ShapeInfo::*)() const) static_cast<TopAbs_ShapeEnum (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::ShapeType),
             R"#(Selector Returns the type of shape)#" 
          )
        .def("SetBox",
             (void (BOPDS_ShapeInfo::*)(  const Bnd_Box &  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const Bnd_Box &  ) >(&BOPDS_ShapeInfo::SetBox),
             R"#(Modifier Sets the boundung box of the shape theBox)#"  , py::arg("theBox")
          )
        .def("HasSubShape",
             (bool (BOPDS_ShapeInfo::*)(  const int  ) const) static_cast<bool (BOPDS_ShapeInfo::*)(  const int  ) const>(&BOPDS_ShapeInfo::HasSubShape),
             R"#(Query Returns true if the shape has sub-shape with index theI)#"  , py::arg("theI")
          )
        .def("HasReference",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasReference),
             R"#()#" 
          )
        .def("SetReference",
             (void (BOPDS_ShapeInfo::*)(  const int  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const int  ) >(&BOPDS_ShapeInfo::SetReference),
             R"#(Modifier Sets the index of a reference information)#"  , py::arg("theI")
          )
        .def("Reference",
             (int (BOPDS_ShapeInfo::*)() const) static_cast<int (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Reference),
             R"#(Selector Returns the index of a reference information)#" 
          )
        .def("HasBRep",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasBRep),
             R"#(Query Returns true if the shape has boundary representation)#" 
          )
        .def("IsInterfering",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::IsInterfering),
             R"#(Returns true if the shape can be participant of an interference)#" 
          )
        .def("HasFlag",
             (bool (BOPDS_ShapeInfo::*)() const) static_cast<bool (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::HasFlag),
             R"#(Query Returns true if there is flag.)#" 
          )
        .def("HasFlag",
             (bool (BOPDS_ShapeInfo::*)( int &  ) const) static_cast<bool (BOPDS_ShapeInfo::*)( int &  ) const>(&BOPDS_ShapeInfo::HasFlag),
             R"#(Query Returns true if there is flag. Returns the flag theFlag)#"  , py::arg("theFlag")
          )
        .def("SetFlag",
             (void (BOPDS_ShapeInfo::*)(  const int  ) ) static_cast<void (BOPDS_ShapeInfo::*)(  const int  ) >(&BOPDS_ShapeInfo::SetFlag),
             R"#(Modifier Sets the flag)#"  , py::arg("theFlag")
          )
        .def("Flag",
             (int (BOPDS_ShapeInfo::*)() const) static_cast<int (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Flag),
             R"#(Returns the flag)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const TopoDS_Shape & (BOPDS_ShapeInfo::*)() const) static_cast< const TopoDS_Shape & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Shape),
             R"#(Selector Returns the shape)#"
             
         )
       .def("Box",
             ( const Bnd_Box & (BOPDS_ShapeInfo::*)() const) static_cast< const Bnd_Box & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Box),
             R"#(Selector Returns the boundung box of the shape)#"
             
         )
       .def("ChangeBox",
             (Bnd_Box & (BOPDS_ShapeInfo::*)() ) static_cast<Bnd_Box & (BOPDS_ShapeInfo::*)() >(&BOPDS_ShapeInfo::ChangeBox),
             R"#(Selector/Modifier Returns the boundung box of the shape)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("SubShapes",
             ( const NCollection_List<int> & (BOPDS_ShapeInfo::*)() const) static_cast< const NCollection_List<int> & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::SubShapes),
             R"#(Selector Returns the list of indices of sub-shapes)#"
             
         )
       .def("ChangeSubShapes",
             (NCollection_List<int> & (BOPDS_ShapeInfo::*)() ) static_cast<NCollection_List<int> & (BOPDS_ShapeInfo::*)() >(&BOPDS_ShapeInfo::ChangeSubShapes),
             R"#(Selector/ Modifier Returns the list of indices of sub-shapes)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Shape",
             ( const TopoDS_Shape & (BOPDS_ShapeInfo::*)() const) static_cast< const TopoDS_Shape & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Shape),
             R"#(Selector Returns the shape)#"
             
         )
       .def("Box",
             ( const Bnd_Box & (BOPDS_ShapeInfo::*)() const) static_cast< const Bnd_Box & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::Box),
             R"#(Selector Returns the boundung box of the shape)#"
             
         )
       .def("ChangeBox",
             (Bnd_Box & (BOPDS_ShapeInfo::*)() ) static_cast<Bnd_Box & (BOPDS_ShapeInfo::*)() >(&BOPDS_ShapeInfo::ChangeBox),
             R"#(Selector/Modifier Returns the boundung box of the shape)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("SubShapes",
             ( const NCollection_List<int> & (BOPDS_ShapeInfo::*)() const) static_cast< const NCollection_List<int> & (BOPDS_ShapeInfo::*)() const>(&BOPDS_ShapeInfo::SubShapes),
             R"#(Selector Returns the list of indices of sub-shapes)#"
             
         )
       .def("ChangeSubShapes",
             (NCollection_List<int> & (BOPDS_ShapeInfo::*)() ) static_cast<NCollection_List<int> & (BOPDS_ShapeInfo::*)() >(&BOPDS_ShapeInfo::ChangeSubShapes),
             R"#(Selector/ Modifier Returns the list of indices of sub-shapes)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPDS_SubIterator from ./opencascade/BOPDS_SubIterator.hxx
    klass = m.attr("BOPDS_SubIterator");


    // nested enums

    static_cast<py::class_<BOPDS_SubIterator , shared_ptr<BOPDS_SubIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetSubSet1",
             (void (BOPDS_SubIterator::*)(  const NCollection_List<int> &  ) ) static_cast<void (BOPDS_SubIterator::*)(  const NCollection_List<int> &  ) >(&BOPDS_SubIterator::SetSubSet1),
             R"#(Sets the first set of indices <theLI> to process)#"  , py::arg("theLI")
          )
        .def("SetSubSet2",
             (void (BOPDS_SubIterator::*)(  const NCollection_List<int> &  ) ) static_cast<void (BOPDS_SubIterator::*)(  const NCollection_List<int> &  ) >(&BOPDS_SubIterator::SetSubSet2),
             R"#(Sets the second set of indices <theLI> to process)#"  , py::arg("theLI")
          )
        .def("Initialize",
             (void (BOPDS_SubIterator::*)() ) static_cast<void (BOPDS_SubIterator::*)() >(&BOPDS_SubIterator::Initialize),
             R"#(Initializes the iterator)#" 
          )
        .def("More",
             (bool (BOPDS_SubIterator::*)() const) static_cast<bool (BOPDS_SubIterator::*)() const>(&BOPDS_SubIterator::More),
             R"#(Returns true if there are more pairs of intersected shapes)#" 
          )
        .def("Next",
             (void (BOPDS_SubIterator::*)() ) static_cast<void (BOPDS_SubIterator::*)() >(&BOPDS_SubIterator::Next),
             R"#(Moves iterations ahead)#" 
          )
        .def("Prepare",
             (void (BOPDS_SubIterator::*)() ) static_cast<void (BOPDS_SubIterator::*)() >(&BOPDS_SubIterator::Prepare),
             R"#(Perform the intersection algorithm and prepare the results to be used)#" 
          )
        .def("ExpectedLength",
             (int (BOPDS_SubIterator::*)() const) static_cast<int (BOPDS_SubIterator::*)() const>(&BOPDS_SubIterator::ExpectedLength),
             R"#(Returns the number of interfering pairs)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Value",
             []( BOPDS_SubIterator &self   ){
                 int  theIndex1;
                int  theIndex2;

                 self.Value(theIndex1,theIndex2);
                 return std::make_tuple(theIndex1,theIndex2); },
             R"#(Returns indices (DS) of intersected shapes theIndex1 - the index of the first shape theIndex2 - the index of the second shape)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DS",
             ( const BOPDS_DS & (BOPDS_SubIterator::*)() const) static_cast< const BOPDS_DS & (BOPDS_SubIterator::*)() const>(&BOPDS_SubIterator::DS),
             R"#(Returns the data structure)#"
             
         )
       .def("SubSet1",
             ( const NCollection_List<int> & (BOPDS_SubIterator::*)() const) static_cast< const NCollection_List<int> & (BOPDS_SubIterator::*)() const>(&BOPDS_SubIterator::SubSet1),
             R"#(Returns the first set of indices to process)#"
             
         )
       .def("SubSet2",
             ( const NCollection_List<int> & (BOPDS_SubIterator::*)() const) static_cast< const NCollection_List<int> & (BOPDS_SubIterator::*)() const>(&BOPDS_SubIterator::SubSet2),
             R"#(Returns the second set of indices to process)#"
             
         )
;

    // Class BOPDS_Tools from ./opencascade/BOPDS_Tools.hxx
    klass = m.attr("BOPDS_Tools");

    // default constructor
    register_default_constructor<BOPDS_Tools , shared_ptr<BOPDS_Tools>>(m,"BOPDS_Tools");

    // nested enums

    static_cast<py::class_<BOPDS_Tools , shared_ptr<BOPDS_Tools>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("TypeToInteger_s",
                    (int (*)(  const TopAbs_ShapeEnum ,   const TopAbs_ShapeEnum  ) ) static_cast<int (*)(  const TopAbs_ShapeEnum ,   const TopAbs_ShapeEnum  ) >(&BOPDS_Tools::TypeToInteger),
                    R"#(Converts the conmbination of two types of shape <theT1>,<theT2> to the one integer value, that is returned)#"  , py::arg("theT1"),  py::arg("theT2")
          )
        .def_static("TypeToInteger_s",
                    (int (*)(  const TopAbs_ShapeEnum  ) ) static_cast<int (*)(  const TopAbs_ShapeEnum  ) >(&BOPDS_Tools::TypeToInteger),
                    R"#(Converts the type of shape <theT>, to integer value, that is returned)#"  , py::arg("theT")
          )
        .def_static("HasBRep_s",
                    (bool (*)(  const TopAbs_ShapeEnum  ) ) static_cast<bool (*)(  const TopAbs_ShapeEnum  ) >(&BOPDS_Tools::HasBRep),
                    R"#(Returns true if the type <theT> correspond to a shape having boundary representation)#"  , py::arg("theT")
          )
        .def_static("IsInterfering_s",
                    (bool (*)(  const TopAbs_ShapeEnum  ) ) static_cast<bool (*)(  const TopAbs_ShapeEnum  ) >(&BOPDS_Tools::IsInterfering),
                    R"#(Returns true if the type <theT> can be participant of an interference)#"  , py::arg("theT")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfEE from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfEE");


    // nested enums

    static_cast<py::class_<BOPDS_InterfEE , shared_ptr<BOPDS_InterfEE>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetCommonPart",
             (void (BOPDS_InterfEE::*)(  const IntTools_CommonPrt &  ) ) static_cast<void (BOPDS_InterfEE::*)(  const IntTools_CommonPrt &  ) >(&BOPDS_InterfEE::SetCommonPart),
             R"#(Modifier Sets the info of common part)#"  , py::arg("theCP")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CommonPart",
             ( const IntTools_CommonPrt & (BOPDS_InterfEE::*)() const) static_cast< const IntTools_CommonPrt & (BOPDS_InterfEE::*)() const>(&BOPDS_InterfEE::CommonPart),
             R"#(Selector Returns the info of common part)#"
             
         )
;

    // Class BOPDS_InterfEF from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfEF");


    // nested enums

    static_cast<py::class_<BOPDS_InterfEF , shared_ptr<BOPDS_InterfEF>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetCommonPart",
             (void (BOPDS_InterfEF::*)(  const IntTools_CommonPrt &  ) ) static_cast<void (BOPDS_InterfEF::*)(  const IntTools_CommonPrt &  ) >(&BOPDS_InterfEF::SetCommonPart),
             R"#(Modifier Sets the info of common part)#"  , py::arg("theCP")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CommonPart",
             ( const IntTools_CommonPrt & (BOPDS_InterfEF::*)() const) static_cast< const IntTools_CommonPrt & (BOPDS_InterfEF::*)() const>(&BOPDS_InterfEF::CommonPart),
             R"#(Selector Returns the info of common part)#"
             
         )
;

    // Class BOPDS_InterfEZ from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfEZ");


    // nested enums

    static_cast<py::class_<BOPDS_InterfEZ , shared_ptr<BOPDS_InterfEZ>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfFF from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfFF");


    // nested enums

    static_cast<py::class_<BOPDS_InterfFF , shared_ptr<BOPDS_InterfFF>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (BOPDS_InterfFF::*)(  const int ,   const int  ) ) static_cast<void (BOPDS_InterfFF::*)(  const int ,   const int  ) >(&BOPDS_InterfFF::Init),
             R"#(Initializer)#"  , py::arg("theNbCurves"),  py::arg("theNbPoints")
          )
        .def("SetTangentFaces",
             (void (BOPDS_InterfFF::*)(  const bool  ) ) static_cast<void (BOPDS_InterfFF::*)(  const bool  ) >(&BOPDS_InterfFF::SetTangentFaces),
             R"#(Modifier Sets the flag of whether the faces are tangent)#"  , py::arg("theFlag")
          )
        .def("TangentFaces",
             (bool (BOPDS_InterfFF::*)() const) static_cast<bool (BOPDS_InterfFF::*)() const>(&BOPDS_InterfFF::TangentFaces),
             R"#(Selector Returns the flag whether the faces are tangent)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Curves",
             ( const NCollection_DynamicArray<BOPDS_Curve> & (BOPDS_InterfFF::*)() const) static_cast< const NCollection_DynamicArray<BOPDS_Curve> & (BOPDS_InterfFF::*)() const>(&BOPDS_InterfFF::Curves),
             R"#(Selector Returns the intersection curves)#"
             
         )
       .def("ChangeCurves",
             (NCollection_DynamicArray<BOPDS_Curve> & (BOPDS_InterfFF::*)() ) static_cast<NCollection_DynamicArray<BOPDS_Curve> & (BOPDS_InterfFF::*)() >(&BOPDS_InterfFF::ChangeCurves),
             R"#(Selector/Modifier Returns the intersection curves)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Points",
             ( const NCollection_DynamicArray<BOPDS_Point> & (BOPDS_InterfFF::*)() const) static_cast< const NCollection_DynamicArray<BOPDS_Point> & (BOPDS_InterfFF::*)() const>(&BOPDS_InterfFF::Points),
             R"#(Selector Returns the intersection points)#"
             
         )
       .def("ChangePoints",
             (NCollection_DynamicArray<BOPDS_Point> & (BOPDS_InterfFF::*)() ) static_cast<NCollection_DynamicArray<BOPDS_Point> & (BOPDS_InterfFF::*)() >(&BOPDS_InterfFF::ChangePoints),
             R"#(Selector/Modifier Returns the intersection points)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPDS_InterfFZ from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfFZ");


    // nested enums

    static_cast<py::class_<BOPDS_InterfFZ , shared_ptr<BOPDS_InterfFZ>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfVE from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfVE");


    // nested enums

    static_cast<py::class_<BOPDS_InterfVE , shared_ptr<BOPDS_InterfVE>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetParameter",
             (void (BOPDS_InterfVE::*)(  const double  ) ) static_cast<void (BOPDS_InterfVE::*)(  const double  ) >(&BOPDS_InterfVE::SetParameter),
             R"#(Modifier Sets the value of parameter of the point of the vertex on the curve of the edge)#"  , py::arg("theT")
          )
        .def("Parameter",
             (double (BOPDS_InterfVE::*)() const) static_cast<double (BOPDS_InterfVE::*)() const>(&BOPDS_InterfVE::Parameter),
             R"#(Selector Returrns the value of parameter of the point of the vertex on the curve of the edge)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfVF from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfVF");


    // nested enums

    static_cast<py::class_<BOPDS_InterfVF , shared_ptr<BOPDS_InterfVF>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetUV",
             (void (BOPDS_InterfVF::*)(  const double ,   const double  ) ) static_cast<void (BOPDS_InterfVF::*)(  const double ,   const double  ) >(&BOPDS_InterfVF::SetUV),
             R"#(Modifier Sets the value of parameters of the point of the vertex on the surface of of the face)#"  , py::arg("theU"),  py::arg("theV")
          )
    // methods using call by reference i.s.o. return
        .def("UV",
             []( BOPDS_InterfVF &self   ){
                 double  theU;
                double  theV;

                 self.UV(theU,theV);
                 return std::make_tuple(theU,theV); },
             R"#(Selector Returns the value of parameters of the point of the vertex on the surface of of the face)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfVV from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfVV");


    // nested enums

    static_cast<py::class_<BOPDS_InterfVV , shared_ptr<BOPDS_InterfVV>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfVZ from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfVZ");


    // nested enums

    static_cast<py::class_<BOPDS_InterfVZ , shared_ptr<BOPDS_InterfVZ>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPDS_InterfZZ from ./opencascade/BOPDS_Interf.hxx
    klass = m.attr("BOPDS_InterfZZ");


    // nested enums

    static_cast<py::class_<BOPDS_InterfZZ , shared_ptr<BOPDS_InterfZZ>  , BOPDS_Interf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/BOPDS_CommonBlock.hxx
// ./opencascade/BOPDS_CoupleOfPaveBlocks.hxx
// ./opencascade/BOPDS_Curve.hxx
// ./opencascade/BOPDS_DS.hxx
// ./opencascade/BOPDS_FaceInfo.hxx
// ./opencascade/BOPDS_IndexRange.hxx
// ./opencascade/BOPDS_Interf.hxx
// ./opencascade/BOPDS_PDS.hxx
// ./opencascade/BOPDS_PIterator.hxx
// ./opencascade/BOPDS_PIteratorSI.hxx
// ./opencascade/BOPDS_Pair.hxx
// ./opencascade/BOPDS_Pave.hxx
// ./opencascade/BOPDS_PaveBlock.hxx
// ./opencascade/BOPDS_Point.hxx
// ./opencascade/BOPDS_ShapeInfo.hxx
// ./opencascade/BOPDS_SubIterator.hxx
// ./opencascade/BOPDS_Tools.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
