
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPDS_PaveBlock.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPDS_DS.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <BOPDS_CommonBlock.hxx>
#include <BOPDS_CoupleOfPaveBlocks.hxx>
#include <BOPDS_Curve.hxx>
#include <BOPDS_DS.hxx>
#include <BOPDS_FaceInfo.hxx>
#include <BOPDS_IndexRange.hxx>
#include <BOPDS_Interf.hxx>
#include <BOPDS_Pair.hxx>
#include <BOPDS_Pave.hxx>
#include <BOPDS_PaveBlock.hxx>
#include <BOPDS_PDS.hxx>
#include <BOPDS_PIterator.hxx>
#include <BOPDS_PIteratorSI.hxx>
#include <BOPDS_Point.hxx>
#include <BOPDS_ShapeInfo.hxx>
#include <BOPDS_SubIterator.hxx>
#include <BOPDS_Tools.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BOPDS_enums(py::module &main_module) {


py::module m = main_module.def_submodule("BOPDS", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<BOPDS_CoupleOfPaveBlocks , shared_ptr<BOPDS_CoupleOfPaveBlocks>  >(
      m,
      "BOPDS_CoupleOfPaveBlocks",R"#(Stores information about two pave blocks and satellite data.)#"
    );
    py::class_<BOPDS_Curve , shared_ptr<BOPDS_Curve>  >(
      m,
      "BOPDS_Curve",R"#(The class BOPDS_Curve is to store the information about intersection curve)#"
    );
    py::class_<BOPDS_DS , shared_ptr<BOPDS_DS>  >(
      m,
      "BOPDS_DS",R"#(The class BOPDS_DS provides the control of data structure for the algorithms in the Boolean Component such as General Fuse, Boolean operations, Section, Maker Volume, Splitter and Cells Builder.)#"
    );
    py::class_<BOPDS_FaceInfo , shared_ptr<BOPDS_FaceInfo>  >(
      m,
      "BOPDS_FaceInfo",R"#(The class BOPDS_FaceInfo is to store handy information about state of face)#"
    );
    py::class_<BOPDS_IndexRange , shared_ptr<BOPDS_IndexRange>  >(
      m,
      "BOPDS_IndexRange",R"#(The class BOPDS_IndexRange is to store the information about range of two indices)#"
    );
    py::class_<BOPDS_Interf , shared_ptr_nodelete<BOPDS_Interf>  >(
      m,
      "BOPDS_Interf",R"#(The class BOPDS_Interf stores the information about the interference between two shapes. The class BOPDS_Interf is root class)#"
    );
    py::class_<BOPDS_Pair , shared_ptr<BOPDS_Pair>  >(
      m,
      "BOPDS_Pair",R"#(The class is to provide the pair of indices of interfering shapes.)#"
    );
    py::class_<BOPDS_Pave , shared_ptr<BOPDS_Pave>  >(
      m,
      "BOPDS_Pave",R"#(The class BOPDS_Pave is to store information about vertex on an edge)#"
    );
    py::class_<BOPDS_Point , shared_ptr<BOPDS_Point>  >(
      m,
      "BOPDS_Point",R"#(The class BOPDS_Point is to store the information about intersection point)#"
    );
    py::class_<BOPDS_ShapeInfo , shared_ptr<BOPDS_ShapeInfo>  >(
      m,
      "BOPDS_ShapeInfo",R"#(The class BOPDS_ShapeInfo is to store handy information about shape)#"
    );
    py::class_<BOPDS_SubIterator , shared_ptr<BOPDS_SubIterator>  >(
      m,
      "BOPDS_SubIterator",R"#(The class BOPDS_SubIterator is used to compute intersections between bounding boxes of two sub-sets of BRep sub-shapes of arguments of an operation (see the class BOPDS_DS). The class provides interface to iterate the pairs of intersected sub-shapes.)#"
    );
    py::class_<BOPDS_Tools , shared_ptr<BOPDS_Tools>  >(
      m,
      "BOPDS_Tools",R"#(The class BOPDS_Tools contains a set auxiliary static functions of the package BOPDS)#"
    );
    py::class_<BOPDS_CommonBlock ,opencascade::handle<BOPDS_CommonBlock>  , Standard_Transient >(
      m,
      "BOPDS_CommonBlock",R"#(The class BOPDS_CommonBlock is to store the information about pave blocks that have geometrical coincidence (in terms of a tolerance) with: a) other pave block(s); b) face(s). First pave block in the common block (real pave block) is always a pave block with the minimal index of the original edge.)#"
    );
    py::class_<BOPDS_InterfEE , shared_ptr<BOPDS_InterfEE>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfEE",R"#(The class BOPDS_InterfEE stores the information about the interference of the type edge/edge.)#"
    );
    py::class_<BOPDS_InterfEF , shared_ptr<BOPDS_InterfEF>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfEF",R"#(The class BOPDS_InterfEF stores the information about the interference of the type edge/face.)#"
    );
    py::class_<BOPDS_InterfEZ , shared_ptr<BOPDS_InterfEZ>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfEZ",R"#(The class BOPDS_InterfEZ stores the information about the interference of the type edge/solid.)#"
    );
    py::class_<BOPDS_InterfFF , shared_ptr<BOPDS_InterfFF>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfFF",R"#()#"
    );
    py::class_<BOPDS_InterfFZ , shared_ptr<BOPDS_InterfFZ>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfFZ",R"#(The class BOPDS_InterfFZ stores the information about the interference of the type face/solid.)#"
    );
    py::class_<BOPDS_InterfVE , shared_ptr<BOPDS_InterfVE>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfVE",R"#(The class BOPDS_InterfVE stores the information about the interference of the type vertex/edge.)#"
    );
    py::class_<BOPDS_InterfVF , shared_ptr<BOPDS_InterfVF>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfVF",R"#(The class BOPDS_InterfVF stores the information about the interference of the type vertex/face)#"
    );
    py::class_<BOPDS_InterfVV , shared_ptr<BOPDS_InterfVV>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfVV",R"#(The class BOPDS_InterfVV stores the information about the interference of the type vertex/vertex.)#"
    );
    py::class_<BOPDS_InterfVZ , shared_ptr<BOPDS_InterfVZ>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfVZ",R"#(The class BOPDS_InterfVZ stores the information about the interference of the type vertex/solid.)#"
    );
    py::class_<BOPDS_InterfZZ , shared_ptr<BOPDS_InterfZZ>  , BOPDS_Interf >(
      m,
      "BOPDS_InterfZZ",R"#(The class BOPDS_InterfZZ stores the information about the interference of the type solid/solid.)#"
    );
    py::class_<BOPDS_PaveBlock ,opencascade::handle<BOPDS_PaveBlock>  , Standard_Transient >(
      m,
      "BOPDS_PaveBlock",R"#(The class BOPDS_PaveBlock is to store the information about pave block on an edge. Two adjacent paves on edge make up pave block.The class BOPDS_PaveBlock is to store the information about pave block on an edge. Two adjacent paves on edge make up pave block.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
