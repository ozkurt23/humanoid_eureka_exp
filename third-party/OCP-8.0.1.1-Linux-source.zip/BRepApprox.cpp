
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <IntSurf_Quadric.hxx>
#include <IntSurf_QuadricTool.hxx>
#include <BRepApprox_ApproxLine.hxx>
#include <BRepApprox_ThePrmPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheImpPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom2d_BSplineCurve.hxx>
#include <IntSurf_LineOn2S.hxx>
#include <IntSurf_PntOn2S.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <AppParCurves_MultiCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <IntSurf_Quadric.hxx>
#include <IntSurf_QuadricTool.hxx>
#include <BRepApprox_ApproxLine.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <math_FunctionSetRoot.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepApprox_ApproxLine.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <BRepApprox_ApproxLine.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <IntSurf_Quadric.hxx>
#include <IntSurf_QuadricTool.hxx>

// module includes
#include <BRepApprox_Approx.hxx>
#include <BRepApprox_ApproxLine.hxx>
#include <BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx>
#include <BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_SurfaceTool.hxx>
#include <BRepApprox_TheComputeLineBezierOfApprox.hxx>
#include <BRepApprox_TheComputeLineOfApprox.hxx>
#include <BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheImpPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheMultiLineOfApprox.hxx>
#include <BRepApprox_TheMultiLineToolOfApprox.hxx>
#include <BRepApprox_ThePrmPrmSvSurfacesOfApprox.hxx>
#include <BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepApprox(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BRepApprox"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BRepApprox_Approx from ./opencascade/BRepApprox_Approx.hxx
    klass = m.attr("BRepApprox_Approx");


    // nested enums

    static_cast<py::class_<BRepApprox_Approx , shared_ptr<BRepApprox_Approx>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (BRepApprox_Approx::*)(  const BRepAdaptor_Surface & ,   const BRepAdaptor_Surface & ,   const handle<BRepApprox_ApproxLine> & ,   const bool ,   const bool ,   const bool ,   const int ,   const int  ) ) static_cast<void (BRepApprox_Approx::*)(  const BRepAdaptor_Surface & ,   const BRepAdaptor_Surface & ,   const handle<BRepApprox_ApproxLine> & ,   const bool ,   const bool ,   const bool ,   const int ,   const int  ) >(&BRepApprox_Approx::Perform),
             R"#()#"  , py::arg("Surf1"),  py::arg("Surf2"),  py::arg("aLine"),  py::arg("ApproxXYZ")=static_cast< const bool>(true),  py::arg("ApproxU1V1")=static_cast< const bool>(true),  py::arg("ApproxU2V2")=static_cast< const bool>(true),  py::arg("indicemin")=static_cast< const int>(0),  py::arg("indicemax")=static_cast< const int>(0)
          )
        .def("Perform",
             (void (BRepApprox_Approx::*)(  const handle<BRepApprox_ApproxLine> & ,   const bool ,   const bool ,   const bool ,   const int ,   const int  ) ) static_cast<void (BRepApprox_Approx::*)(  const handle<BRepApprox_ApproxLine> & ,   const bool ,   const bool ,   const bool ,   const int ,   const int  ) >(&BRepApprox_Approx::Perform),
             R"#()#"  , py::arg("aLine"),  py::arg("ApproxXYZ")=static_cast< const bool>(true),  py::arg("ApproxU1V1")=static_cast< const bool>(true),  py::arg("ApproxU2V2")=static_cast< const bool>(true),  py::arg("indicemin")=static_cast< const int>(0),  py::arg("indicemax")=static_cast< const int>(0)
          )
        .def("SetParameters",
             (void (BRepApprox_Approx::*)(  const double ,   const double ,   const int ,   const int ,   const int ,   const int ,   const bool ,   const Approx_ParametrizationType  ) ) static_cast<void (BRepApprox_Approx::*)(  const double ,   const double ,   const int ,   const int ,   const int ,   const int ,   const bool ,   const Approx_ParametrizationType  ) >(&BRepApprox_Approx::SetParameters),
             R"#()#"  , py::arg("Tol3d"),  py::arg("Tol2d"),  py::arg("DegMin"),  py::arg("DegMax"),  py::arg("NbIterMax"),  py::arg("NbPntMax")=static_cast< const int>(30),  py::arg("ApproxWithTangency")=static_cast< const bool>(true),  py::arg("Parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength)
          )
        .def("TolReached3d",
             (double (BRepApprox_Approx::*)() const) static_cast<double (BRepApprox_Approx::*)() const>(&BRepApprox_Approx::TolReached3d),
             R"#()#" 
          )
        .def("TolReached2d",
             (double (BRepApprox_Approx::*)() const) static_cast<double (BRepApprox_Approx::*)() const>(&BRepApprox_Approx::TolReached2d),
             R"#()#" 
          )
        .def("IsDone",
             (bool (BRepApprox_Approx::*)() const) static_cast<bool (BRepApprox_Approx::*)() const>(&BRepApprox_Approx::IsDone),
             R"#()#" 
          )
        .def("NbMultiCurves",
             (int (BRepApprox_Approx::*)() const) static_cast<int (BRepApprox_Approx::*)() const>(&BRepApprox_Approx::NbMultiCurves),
             R"#()#" 
          )
        .def("Value",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_Approx::*)(  const int  ) const) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_Approx::*)(  const int  ) const>(&BRepApprox_Approx::Value),
             R"#()#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Parameters_s",
                    (void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const Approx_ParametrizationType ,  math_Vector &  ) ) static_cast<void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const Approx_ParametrizationType ,  math_Vector &  ) >(&BRepApprox_Approx::Parameters),
                    R"#()#"  , py::arg("Line"),  py::arg("firstP"),  py::arg("lastP"),  py::arg("Par"),  py::arg("TheParameters")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_ApproxLine from ./opencascade/BRepApprox_ApproxLine.hxx
    klass = m.attr("BRepApprox_ApproxLine");


    // nested enums

    static_cast<py::class_<BRepApprox_ApproxLine ,opencascade::handle<BRepApprox_ApproxLine>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_BSplineCurve> &, const handle<Geom2d_BSplineCurve> &, const handle<Geom2d_BSplineCurve> & >()  , py::arg("CurveXYZ"),  py::arg("CurveUV1"),  py::arg("CurveUV2") )
        .def(py::init<  const handle<IntSurf_LineOn2S> &, const bool >()  , py::arg("lin"),  py::arg("theTang")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("NbPnts",
             (int (BRepApprox_ApproxLine::*)() const) static_cast<int (BRepApprox_ApproxLine::*)() const>(&BRepApprox_ApproxLine::NbPnts),
             R"#()#" 
          )
        .def("Point",
             (IntSurf_PntOn2S (BRepApprox_ApproxLine::*)(  const int  ) ) static_cast<IntSurf_PntOn2S (BRepApprox_ApproxLine::*)(  const int  ) >(&BRepApprox_ApproxLine::Point),
             R"#()#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepApprox_ApproxLine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepApprox_ApproxLine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepApprox_ApproxLine::*)() const) static_cast< const handle<Standard_Type> & (BRepApprox_ApproxLine::*)() const>(&BRepApprox_ApproxLine::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox from ./opencascade/BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox , shared_ptr<BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox>  , math_BFGS >>(klass)
    // constructors
        .def(py::init< math_MultipleVarFunctionWithGradient &, const math_Vector &, const double, const double, const double, const int >()  , py::arg("F"),  py::arg("StartingPoint"),  py::arg("Tolerance3d"),  py::arg("Tolerance2d"),  py::arg("Eps"),  py::arg("NbIterations")=static_cast< const int>(200) )
    // custom constructors
    // methods
        .def("IsSolutionReached",
             (bool (BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const) static_cast<bool (BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const>(&BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox::IsSolutionReached),
             R"#()#"  , py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox from ./opencascade/BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox , shared_ptr<BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox>  , math_MultipleVarFunctionWithGradient >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &, const math_Vector &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("NbPol") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<int (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::NbVariables),
             R"#(returns the number of variables of the function. It corresponds to the number of MultiPoints.)#" 
          )
        .def("Value",
             (bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double &  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::Value),
             R"#(this method computes the new approximation of the MultiLine SSP and calculates F = sum (||Pui - Bi*Pi||2) for each point of the MultiLine.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  math_Vector &  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::Gradient),
             R"#(returns the gradient G of the sum above for the parameters Xi.)#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::Values),
             R"#(returns the value F=sum(||Pui - Bi*Pi||)2. returns the value G = grad(F) for the parameters Xi.)#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
        .def("CurveValue",
             (AppParCurves_MultiBSpCurve (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() ) static_cast<AppParCurves_MultiBSpCurve (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::CurveValue),
             R"#(returns the MultiBSpCurve approximating the set after computing the value F or Grad(F).)#" 
          )
        .def("Error",
             (double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const int ,   const int  ) ) static_cast<double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const int ,   const int  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::Error),
             R"#(returns the distance between the MultiPoint of range IPoint and the curve CurveIndex.)#"  , py::arg("IPoint"),  py::arg("CurveIndex")
          )
        .def("MaxError3d",
             (double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::MaxError3d),
             R"#(returns the maximum distance between the points and the MultiBSpCurve.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::MaxError2d),
             R"#(returns the maximum distance between the points and the MultiBSpCurve.)#" 
          )
        .def("FirstConstraint",
             (AppParCurves_Constraint (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::FirstConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("FirstPoint")
          )
        .def("LastConstraint",
             (AppParCurves_Constraint (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::LastConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("LastPoint")
          )
        .def("SetFirstLambda",
             (void (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const double  ) ) static_cast<void (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const double  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::SetFirstLambda),
             R"#()#"  , py::arg("l1")
          )
        .def("SetLastLambda",
             (void (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const double  ) ) static_cast<void (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const double  ) >(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::SetLastLambda),
             R"#()#"  , py::arg("l2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("NewParameters",
             ( const math_Vector & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Vector & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::NewParameters),
             R"#(returns the new parameters of the MultiLine.)#"
             
         )
       .def("FunctionMatrix",
             ( const math_Matrix & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::FunctionMatrix),
             R"#(returns the function matrix used to approximate the multiline.)#"
             
         )
       .def("DerivativeFunctionMatrix",
             ( const math_Matrix & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::DerivativeFunctionMatrix),
             R"#(returns the derivative function matrix used to approximate the multiline.)#"
             
         )
       .def("Index",
             ( const math_IntegerVector & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_IntegerVector & (BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox::Index),
             R"#(Returns the indexes of the first non null values of A and DA. The values are non null from Index(ieme point) +1 to Index(ieme point) + degree +1.)#"
             
         )
;

    // Class BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox from ./opencascade/BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox , shared_ptr<BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector &  ) ) static_cast<void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector &  ) >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. The case "CurvaturePoint" is not treated in this method.)#"  , py::arg("Parameters")
          )
        .def("Perform",
             (void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields.)#"  , py::arg("Parameters"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point. <V1c> is the tangent vector at the first point. <V2c> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("V1c"),  py::arg("V2c"),  py::arg("l1"),  py::arg("l2")
          )
        .def("IsDone",
             (bool (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("BezierValue",
             (AppParCurves_MultiCurve (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() ) static_cast<AppParCurves_MultiCurve (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::BezierValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#" 
          )
        .def("FirstLambda",
             (double (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::FirstLambda),
             R"#(returns the value (P2 - P1)/ V1 if the first point was a tangency point.)#" 
          )
        .def("LastLambda",
             (double (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::LastLambda),
             R"#(returns the value (PN - PN-1)/ VN if the last point was a tangency point.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("ErrorGradient",
             []( BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox &self , math_Vector & Grad ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.ErrorGradient(Grad,F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances. Grad is the derivative vector of the function F.)#"  , py::arg("Grad")
          )
        .def("Error",
             []( BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox &self   ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.Error(F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("BSplineValue",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() ) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::BSplineValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#"
             
         )
       .def("FunctionMatrix",
             ( const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::FunctionMatrix),
             R"#(returns the function matrix used to approximate the set.)#"
             
         )
       .def("DerivativeFunctionMatrix",
             ( const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::DerivativeFunctionMatrix),
             R"#(returns the derivative function matrix used to approximate the set.)#"
             
         )
       .def("Distance",
             ( const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() ) static_cast< const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() >(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Distance),
             R"#(returns the distances between the points of the multiline and the approximation curves.)#"
             
         )
       .def("Points",
             ( const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Points),
             R"#(returns the matrix of points value.)#"
             
         )
       .def("Poles",
             ( const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::Poles),
             R"#(returns the matrix of resulting control points value.)#"
             
         )
       .def("KIndex",
             ( const math_IntegerVector & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast< const math_IntegerVector & (BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox::KIndex),
             R"#(Returns the indexes of the first non null values of A and DA. The values are non null from Index(ieme point) +1 to Index(ieme point) + degree +1.)#"
             
         )
;

    // Class BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox from ./opencascade/BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox , shared_ptr<BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox>  , math_BFGS >>(klass)
    // constructors
        .def(py::init< math_MultipleVarFunctionWithGradient &, const math_Vector &, const double, const double, const double, const int >()  , py::arg("F"),  py::arg("StartingPoint"),  py::arg("Tolerance3d"),  py::arg("Tolerance2d"),  py::arg("Eps"),  py::arg("NbIterations")=static_cast< const int>(200) )
    // custom constructors
    // methods
        .def("IsSolutionReached",
             (bool (BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const) static_cast<bool (BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const>(&BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox::IsSolutionReached),
             R"#()#"  , py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox from ./opencascade/BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox , shared_ptr<BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox>  , math_BFGS >>(klass)
    // constructors
        .def(py::init< math_MultipleVarFunctionWithGradient &, const math_Vector &, const double, const double, const double, const int >()  , py::arg("F"),  py::arg("StartingPoint"),  py::arg("Tolerance3d"),  py::arg("Tolerance2d"),  py::arg("Eps"),  py::arg("NbIterations")=static_cast< const int>(200) )
    // custom constructors
    // methods
        .def("IsSolutionReached",
             (bool (BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const) static_cast<bool (BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox::*)( math_MultipleVarFunctionWithGradient &  ) const>(&BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox::IsSolutionReached),
             R"#()#"  , py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_MyBSplGradientOfTheComputeLineOfApprox from ./opencascade/BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_MyBSplGradientOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_MyBSplGradientOfTheComputeLineOfApprox , shared_ptr<BRepApprox_MyBSplGradientOfTheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &,math_Vector &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const double, const double, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("Deg"),  py::arg("Tol3d"),  py::arg("Tol2d"),  py::arg("NbIterations")=static_cast< const int>(1) )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &,math_Vector &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const double, const double, const int, const double, const double >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("Deg"),  py::arg("Tol3d"),  py::arg("Tol2d"),  py::arg("NbIterations"),  py::arg("lambda1"),  py::arg("lambda2") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("Value",
             (AppParCurves_MultiBSpCurve (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<AppParCurves_MultiBSpCurve (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::Value),
             R"#(returns all the BSpline curves approximating the MultiLine SSP after minimization of the parameter.)#" 
          )
        .def("Error",
             (double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)(  const int  ) const) static_cast<double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)(  const int  ) const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::Error),
             R"#(returns the difference between the old and the new approximation. An exception is raised if NotDone. An exception is raised if Index<1 or Index>NbParameters.)#"  , py::arg("Index")
          )
        .def("MaxError3d",
             (double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::MaxError3d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::MaxError2d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("AverageError",
             (double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyBSplGradientOfTheComputeLineOfApprox::AverageError),
             R"#(returns the average error between the old and the new approximation.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_MyGradientOfTheComputeLineBezierOfApprox from ./opencascade/BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_MyGradientOfTheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_MyGradientOfTheComputeLineBezierOfApprox , shared_ptr<BRepApprox_MyGradientOfTheComputeLineBezierOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &,math_Vector &, const int, const double, const double, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Deg"),  py::arg("Tol3d"),  py::arg("Tol2d"),  py::arg("NbIterations")=static_cast< const int>(200) )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<bool (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("Value",
             (AppParCurves_MultiCurve (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<AppParCurves_MultiCurve (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::Value),
             R"#(returns all the Bezier curves approximating the MultiLine SSP after minimization of the parameter.)#" 
          )
        .def("Error",
             (double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)(  const int  ) const) static_cast<double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)(  const int  ) const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::Error),
             R"#(returns the difference between the old and the new approximation. An exception is raised if NotDone. An exception is raised if Index<1 or Index>NbParameters.)#"  , py::arg("Index")
          )
        .def("MaxError3d",
             (double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::MaxError3d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::MaxError2d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("AverageError",
             (double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_MyGradientOfTheComputeLineBezierOfApprox::AverageError),
             R"#(returns the average error between the old and the new approximation.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_MyGradientbisOfTheComputeLineOfApprox from ./opencascade/BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_MyGradientbisOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_MyGradientbisOfTheComputeLineOfApprox , shared_ptr<BRepApprox_MyGradientbisOfTheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &,math_Vector &, const int, const double, const double, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Deg"),  py::arg("Tol3d"),  py::arg("Tol2d"),  py::arg("NbIterations")=static_cast< const int>(200) )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("Value",
             (AppParCurves_MultiCurve (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<AppParCurves_MultiCurve (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::Value),
             R"#(returns all the Bezier curves approximating the MultiLine SSP after minimization of the parameter.)#" 
          )
        .def("Error",
             (double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)(  const int  ) const) static_cast<double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)(  const int  ) const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::Error),
             R"#(returns the difference between the old and the new approximation. An exception is raised if NotDone. An exception is raised if Index<1 or Index>NbParameters.)#"  , py::arg("Index")
          )
        .def("MaxError3d",
             (double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::MaxError3d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::MaxError2d),
             R"#(returns the maximum difference between the old and the new approximation.)#" 
          )
        .def("AverageError",
             (double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_MyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_MyGradientbisOfTheComputeLineOfApprox::AverageError),
             R"#(returns the average error between the old and the new approximation.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox from ./opencascade/BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox , shared_ptr<BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox>  , math_MultipleVarFunctionWithGradient >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Deg") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<int (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::NbVariables),
             R"#(returns the number of variables of the function. It corresponds to the number of MultiPoints.)#" 
          )
        .def("Value",
             (bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  double &  ) >(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::Value),
             R"#(this method computes the new approximation of the MultiLine SSP and calculates F = sum (||Pui - Bi*Pi||2) for each point of the MultiLine.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  math_Vector &  ) >(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::Gradient),
             R"#(returns the gradient G of the sum above for the parameters Xi.)#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::Values),
             R"#(returns the value F=sum(||Pui - Bi*Pi||)2. returns the value G = grad(F) for the parameters Xi.)#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
        .def("Error",
             (double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const int ,   const int  ) const) static_cast<double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const int ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::Error),
             R"#(returns the distance between the MultiPoint of range IPoint and the curve CurveIndex.)#"  , py::arg("IPoint"),  py::arg("CurveIndex")
          )
        .def("MaxError3d",
             (double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::MaxError3d),
             R"#(returns the maximum distance between the points and the MultiCurve.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::MaxError2d),
             R"#(returns the maximum distance between the points and the MultiCurve.)#" 
          )
        .def("FirstConstraint",
             (AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::FirstConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("FirstPoint")
          )
        .def("LastConstraint",
             (AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::LastConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("LastPoint")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("NewParameters",
             ( const math_Vector & (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Vector & (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::NewParameters),
             R"#(returns the new parameters of the MultiLine.)#"
             
         )
       .def("CurveValue",
             ( const AppParCurves_MultiCurve & (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() ) static_cast< const AppParCurves_MultiCurve & (BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::*)() >(&BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox::CurveValue),
             R"#(returns the MultiCurve approximating the set after computing the value F or Grad(F).)#"
             
         )
;

    // Class BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox from ./opencascade/BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox , shared_ptr<BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox>  , math_MultipleVarFunctionWithGradient >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("TheConstraints"),  py::arg("Parameters"),  py::arg("Deg") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<int (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::NbVariables),
             R"#(returns the number of variables of the function. It corresponds to the number of MultiPoints.)#" 
          )
        .def("Value",
             (bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double &  ) >(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::Value),
             R"#(this method computes the new approximation of the MultiLine SSP and calculates F = sum (||Pui - Bi*Pi||2) for each point of the MultiLine.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  math_Vector &  ) >(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::Gradient),
             R"#(returns the gradient G of the sum above for the parameters Xi.)#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::Values),
             R"#(returns the value F=sum(||Pui - Bi*Pi||)2. returns the value G = grad(F) for the parameters Xi.)#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
        .def("Error",
             (double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const int ,   const int  ) const) static_cast<double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const int ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::Error),
             R"#(returns the distance between the MultiPoint of range IPoint and the curve CurveIndex.)#"  , py::arg("IPoint"),  py::arg("CurveIndex")
          )
        .def("MaxError3d",
             (double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::MaxError3d),
             R"#(returns the maximum distance between the points and the MultiCurve.)#" 
          )
        .def("MaxError2d",
             (double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::MaxError2d),
             R"#(returns the maximum distance between the points and the MultiCurve.)#" 
          )
        .def("FirstConstraint",
             (AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::FirstConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("FirstPoint")
          )
        .def("LastConstraint",
             (AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const) static_cast<AppParCurves_Constraint (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)(  const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> & ,   const int  ) const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::LastConstraint),
             R"#()#"  , py::arg("TheConstraints"),  py::arg("LastPoint")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("NewParameters",
             ( const math_Vector & (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Vector & (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::NewParameters),
             R"#(returns the new parameters of the MultiLine.)#"
             
         )
       .def("CurveValue",
             ( const AppParCurves_MultiCurve & (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() ) static_cast< const AppParCurves_MultiCurve & (BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::*)() >(&BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox::CurveValue),
             R"#(returns the MultiCurve approximating the set after computing the value F or Grad(F).)#"
             
         )
;

    // Class BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox from ./opencascade/BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox , shared_ptr<BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector &  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector &  ) >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Perform),
             R"#(Is used after having initialized the fields. The case "CurvaturePoint" is not treated in this method.)#"  , py::arg("Parameters")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Perform),
             R"#(Is used after having initialized the fields.)#"  , py::arg("Parameters"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point. <V1c> is the tangent vector at the first point. <V2c> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("V1c"),  py::arg("V2c"),  py::arg("l1"),  py::arg("l2")
          )
        .def("IsDone",
             (bool (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<bool (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("BezierValue",
             (AppParCurves_MultiCurve (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() ) static_cast<AppParCurves_MultiCurve (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::BezierValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#" 
          )
        .def("FirstLambda",
             (double (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::FirstLambda),
             R"#(returns the value (P2 - P1)/ V1 if the first point was a tangency point.)#" 
          )
        .def("LastLambda",
             (double (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<double (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::LastLambda),
             R"#(returns the value (PN - PN-1)/ VN if the last point was a tangency point.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("ErrorGradient",
             []( BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox &self , math_Vector & Grad ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.ErrorGradient(Grad,F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances. Grad is the derivative vector of the function F.)#"  , py::arg("Grad")
          )
        .def("Error",
             []( BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox &self   ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.Error(F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("BSplineValue",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() ) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::BSplineValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#"
             
         )
       .def("FunctionMatrix",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::FunctionMatrix),
             R"#(returns the function matrix used to approximate the set.)#"
             
         )
       .def("DerivativeFunctionMatrix",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::DerivativeFunctionMatrix),
             R"#(returns the derivative function matrix used to approximate the set.)#"
             
         )
       .def("Distance",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() ) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Distance),
             R"#(returns the distances between the points of the multiline and the approximation curves.)#"
             
         )
       .def("Points",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Points),
             R"#(returns the matrix of points value.)#"
             
         )
       .def("Poles",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::Poles),
             R"#(returns the matrix of resulting control points value.)#"
             
         )
       .def("KIndex",
             ( const math_IntegerVector & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_IntegerVector & (BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox::KIndex),
             R"#(Returns the indexes of the first non null values of A and DA. The values are non null from Index(ieme point) +1 to Index(ieme point) + degree +1.)#"
             
         )
;

    // Class BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox from ./opencascade/BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox , shared_ptr<BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const NCollection_Array1<double> &, const NCollection_Array1<int> &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("Knots"),  py::arg("Mults"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("NbPol") )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const AppParCurves_Constraint, const AppParCurves_Constraint, const math_Vector &, const int >()  , py::arg("SSP"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("FirstCons"),  py::arg("LastCons"),  py::arg("Parameters"),  py::arg("NbPol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector &  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector &  ) >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. The case "CurvaturePoint" is not treated in this method.)#"  , py::arg("Parameters")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields.)#"  , py::arg("Parameters"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("l1"),  py::arg("l2")
          )
        .def("Perform",
             (void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) ) static_cast<void (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)(  const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const math_Vector & ,   const double ,   const double  ) >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Perform),
             R"#(Is used after having initialized the fields. <V1t> is the tangent vector at the first point. <V2t> is the tangent vector at the last point. <V1c> is the tangent vector at the first point. <V2c> is the tangent vector at the last point.)#"  , py::arg("Parameters"),  py::arg("V1t"),  py::arg("V2t"),  py::arg("V1c"),  py::arg("V2c"),  py::arg("l1"),  py::arg("l2")
          )
        .def("IsDone",
             (bool (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("BezierValue",
             (AppParCurves_MultiCurve (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() ) static_cast<AppParCurves_MultiCurve (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::BezierValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#" 
          )
        .def("FirstLambda",
             (double (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::FirstLambda),
             R"#(returns the value (P2 - P1)/ V1 if the first point was a tangency point.)#" 
          )
        .def("LastLambda",
             (double (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<double (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::LastLambda),
             R"#(returns the value (PN - PN-1)/ VN if the last point was a tangency point.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("ErrorGradient",
             []( BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox &self , math_Vector & Grad ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.ErrorGradient(Grad,F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances. Grad is the derivative vector of the function F.)#"  , py::arg("Grad")
          )
        .def("Error",
             []( BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox &self   ){
                 double  F;
                double  MaxE3d;
                double  MaxE2d;

                 self.Error(F,MaxE3d,MaxE2d);
                 return std::make_tuple(F,MaxE3d,MaxE2d); },
             R"#(returns the maximum errors between the MultiLine and the approximation curves. F is the sum of the square distances.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("BSplineValue",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() ) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::BSplineValue),
             R"#(returns the result of the approximation, i.e. all the Curves. An exception is raised if NotDone.)#"
             
         )
       .def("FunctionMatrix",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::FunctionMatrix),
             R"#(returns the function matrix used to approximate the set.)#"
             
         )
       .def("DerivativeFunctionMatrix",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::DerivativeFunctionMatrix),
             R"#(returns the derivative function matrix used to approximate the set.)#"
             
         )
       .def("Distance",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() ) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() >(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Distance),
             R"#(returns the distances between the points of the multiline and the approximation curves.)#"
             
         )
       .def("Points",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Points),
             R"#(returns the matrix of points value.)#"
             
         )
       .def("Poles",
             ( const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::Poles),
             R"#(returns the matrix of resulting control points value.)#"
             
         )
       .def("KIndex",
             ( const math_IntegerVector & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_IntegerVector & (BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox::KIndex),
             R"#(Returns the indexes of the first non null values of A and DA. The values are non null from Index(ieme point) +1 to Index(ieme point) + degree +1.)#"
             
         )
;

    // Class BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox from ./opencascade/BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox , shared_ptr<BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &,AppParCurves_MultiCurve &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &, const math_Matrix &, const math_Matrix &, const double >()  , py::arg("SSP"),  py::arg("SCurv"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("Constraints"),  py::arg("Bern"),  py::arg("DerivativeBern"),  py::arg("Tolerance")=static_cast< const double>(1.0e-10) )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast<bool (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("ConstraintDerivative",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox & ,   const math_Vector & ,   const int ,   const math_Matrix &  ) ) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox & ,   const math_Vector & ,   const int ,   const math_Matrix &  ) >(&BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::ConstraintDerivative),
             R"#(Returns the derivative of the constraint matrix.)#"  , py::arg("SSP"),  py::arg("Parameters"),  py::arg("Deg"),  py::arg("DA")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ConstraintMatrix",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::ConstraintMatrix),
             R"#()#"
             
         )
       .def("Duale",
             ( const math_Vector & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Vector & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::Duale),
             R"#(returns the duale variables of the system.)#"
             
         )
       .def("InverseMatrix",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox::InverseMatrix),
             R"#(returns the Inverse of Cont*Transposed(Cont), where Cont is the constraint matrix for the algorithm.)#"
             
         )
;

    // Class BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox from ./opencascade/BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox , shared_ptr<BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &,AppParCurves_MultiCurve &, const int, const int, const handle<NCollection_HArray1<AppParCurves_ConstraintCouple>> &, const math_Matrix &, const math_Matrix &, const double >()  , py::arg("SSP"),  py::arg("SCurv"),  py::arg("FirstPoint"),  py::arg("LastPoint"),  py::arg("Constraints"),  py::arg("Bern"),  py::arg("DerivativeBern"),  py::arg("Tolerance")=static_cast< const double>(1.0e-10) )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::IsDone),
             R"#(returns True if all has been correctly done.)#" 
          )
        .def("ConstraintDerivative",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox & ,   const math_Vector & ,   const int ,   const math_Matrix &  ) ) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox & ,   const math_Vector & ,   const int ,   const math_Matrix &  ) >(&BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::ConstraintDerivative),
             R"#(Returns the derivative of the constraint matrix.)#"  , py::arg("SSP"),  py::arg("Parameters"),  py::arg("Deg"),  py::arg("DA")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ConstraintMatrix",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::ConstraintMatrix),
             R"#()#"
             
         )
       .def("Duale",
             ( const math_Vector & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Vector & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::Duale),
             R"#(returns the duale variables of the system.)#"
             
         )
       .def("InverseMatrix",
             ( const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const) static_cast< const math_Matrix & (BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::*)() const>(&BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox::InverseMatrix),
             R"#(returns the Inverse of Cont*Transposed(Cont), where Cont is the constraint matrix for the algorithm.)#"
             
         )
;

    // Class BRepApprox_SurfaceTool from ./opencascade/BRepApprox_SurfaceTool.hxx
    klass = m.attr("BRepApprox_SurfaceTool");

    // default constructor
    register_default_constructor<BRepApprox_SurfaceTool , shared_ptr<BRepApprox_SurfaceTool>>(m,"BRepApprox_SurfaceTool");

    // nested enums

    static_cast<py::class_<BRepApprox_SurfaceTool , shared_ptr<BRepApprox_SurfaceTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstUParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::FirstUParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("FirstVParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::FirstVParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("LastUParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::LastUParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("LastVParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::LastVParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbUIntervals_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) >(&BRepApprox_SurfaceTool::NbUIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("Sh")
          )
        .def_static("NbVIntervals_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) >(&BRepApprox_SurfaceTool::NbVIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("Sh")
          )
        .def_static("UIntervals_s",
                    (void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&BRepApprox_SurfaceTool::UIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("T"),  py::arg("Sh")
          )
        .def_static("VIntervals_s",
                    (void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&BRepApprox_SurfaceTool::VIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("T"),  py::arg("Sh")
          )
        .def_static("UTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) >(&BRepApprox_SurfaceTool::UTrim),
                    R"#(If <First> >= <Last>)#"  , py::arg("S"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def_static("VTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) >(&BRepApprox_SurfaceTool::VTrim),
                    R"#(If <First> >= <Last>)#"  , py::arg("S"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def_static("IsUClosed_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::IsUClosed),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsVClosed_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::IsVClosed),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsUPeriodic_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::IsUPeriodic),
                    R"#()#"  , py::arg("S")
          )
        .def_static("UPeriod_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::UPeriod),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsVPeriodic_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::IsVPeriodic),
                    R"#()#"  , py::arg("S")
          )
        .def_static("VPeriod_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::VPeriod),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<gp_Pnt (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&BRepApprox_SurfaceTool::Value),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v")
          )
        .def_static("D0_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) >(&BRepApprox_SurfaceTool::D0),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&BRepApprox_SurfaceTool::D1),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1u"),  py::arg("D1v")
          )
        .def_static("D2_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&BRepApprox_SurfaceTool::D2),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV")
          )
        .def_static("D3_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&BRepApprox_SurfaceTool::D3),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV"),  py::arg("D3U"),  py::arg("D3V"),  py::arg("D3UUV"),  py::arg("D3UVV")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) ) static_cast<gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) >(&BRepApprox_SurfaceTool::DN),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("Nu"),  py::arg("Nv")
          )
        .def_static("UResolution_s",
                    (double (*)(  const BRepAdaptor_Surface & ,   const double  ) ) static_cast<double (*)(  const BRepAdaptor_Surface & ,   const double  ) >(&BRepApprox_SurfaceTool::UResolution),
                    R"#()#"  , py::arg("S"),  py::arg("R3d")
          )
        .def_static("VResolution_s",
                    (double (*)(  const BRepAdaptor_Surface & ,   const double  ) ) static_cast<double (*)(  const BRepAdaptor_Surface & ,   const double  ) >(&BRepApprox_SurfaceTool::VResolution),
                    R"#()#"  , py::arg("S"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_SurfaceType (*)(  const BRepAdaptor_Surface &  ) ) static_cast<GeomAbs_SurfaceType (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::GetType),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Plane_s",
                    (gp_Pln (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Pln (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Plane),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Cylinder_s",
                    (gp_Cylinder (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Cylinder (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Cylinder),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Cone_s",
                    (gp_Cone (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Cone (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Cone),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Torus_s",
                    (gp_Torus (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Torus (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Torus),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Sphere_s",
                    (gp_Sphere (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Sphere (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Sphere),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierSurface> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Geom_BezierSurface> (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Bezier),
                    R"#()#"  , py::arg("S")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineSurface> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Geom_BSplineSurface> (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::BSpline),
                    R"#()#"  , py::arg("S")
          )
        .def_static("AxeOfRevolution_s",
                    (gp_Ax1 (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Ax1 (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::AxeOfRevolution),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Direction_s",
                    (gp_Dir (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Dir (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::Direction),
                    R"#()#"  , py::arg("S")
          )
        .def_static("BasisCurve_s",
                    (handle<Adaptor3d_Curve> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Adaptor3d_Curve> (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::BasisCurve),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_SurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&BRepApprox_SurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("S"),  py::arg("u1"),  py::arg("u2")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&BRepApprox_SurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("S"),  py::arg("v1"),  py::arg("v2")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_TheComputeLineBezierOfApprox from ./opencascade/BRepApprox_TheComputeLineBezierOfApprox.hxx
    klass = m.attr("BRepApprox_TheComputeLineBezierOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheComputeLineBezierOfApprox , shared_ptr<BRepApprox_TheComputeLineBezierOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const double, const double, const int, const bool, const Approx_ParametrizationType, const bool >()  , py::arg("Line"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-3),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-6),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const math_Vector &, const int, const int, const double, const double, const int, const bool, const bool >()  , py::arg("Line"),  py::arg("Parameters"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const int, const int, const double, const double, const int, const bool, const Approx_ParametrizationType, const bool >()  , py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const math_Vector &, const int, const int, const double, const double, const int, const bool, const bool >()  , py::arg("Parameters"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("Squares")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Init",
             (void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int ,   const int ,   const double ,   const double ,   const int ,   const bool ,   const Approx_ParametrizationType ,   const bool  ) ) static_cast<void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int ,   const int ,   const double ,   const double ,   const int ,   const bool ,   const Approx_ParametrizationType ,   const bool  ) >(&BRepApprox_TheComputeLineBezierOfApprox::Init),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false)
          )
        .def("Perform",
             (void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheComputeLineBezierOfApprox::Perform),
             R"#(runs the algorithm after having initialized the fields.)#"  , py::arg("Line")
          )
        .def("SetDegrees",
             (void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int ,   const int  ) ) static_cast<void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int ,   const int  ) >(&BRepApprox_TheComputeLineBezierOfApprox::SetDegrees),
             R"#(changes the degrees of the approximation.)#"  , py::arg("degreemin"),  py::arg("degreemax")
          )
        .def("SetTolerances",
             (void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const double ,   const double  ) ) static_cast<void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const double ,   const double  ) >(&BRepApprox_TheComputeLineBezierOfApprox::SetTolerances),
             R"#(Changes the tolerances of the approximation.)#"  , py::arg("Tolerance3d"),  py::arg("Tolerance2d")
          )
        .def("SetConstraints",
             (void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const AppParCurves_Constraint ,   const AppParCurves_Constraint  ) ) static_cast<void (BRepApprox_TheComputeLineBezierOfApprox::*)(  const AppParCurves_Constraint ,   const AppParCurves_Constraint  ) >(&BRepApprox_TheComputeLineBezierOfApprox::SetConstraints),
             R"#(changes the first and the last constraint points.)#"  , py::arg("firstC"),  py::arg("lastC")
          )
        .def("IsAllApproximated",
             (bool (BRepApprox_TheComputeLineBezierOfApprox::*)() const) static_cast<bool (BRepApprox_TheComputeLineBezierOfApprox::*)() const>(&BRepApprox_TheComputeLineBezierOfApprox::IsAllApproximated),
             R"#(returns False if at a moment of the approximation, the status NoApproximation has been sent by the user when more points were needed.)#" 
          )
        .def("IsToleranceReached",
             (bool (BRepApprox_TheComputeLineBezierOfApprox::*)() const) static_cast<bool (BRepApprox_TheComputeLineBezierOfApprox::*)() const>(&BRepApprox_TheComputeLineBezierOfApprox::IsToleranceReached),
             R"#(returns False if the status NoPointsAdded has been sent.)#" 
          )
        .def("NbMultiCurves",
             (int (BRepApprox_TheComputeLineBezierOfApprox::*)() const) static_cast<int (BRepApprox_TheComputeLineBezierOfApprox::*)() const>(&BRepApprox_TheComputeLineBezierOfApprox::NbMultiCurves),
             R"#(Returns the number of MultiCurve doing the approximation of the MultiLine.)#" 
          )
        .def("Value",
             ( const AppParCurves_MultiCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) const) static_cast< const AppParCurves_MultiCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) const>(&BRepApprox_TheComputeLineBezierOfApprox::Value),
             R"#(returns the result of the approximation.)#"  , py::arg("Index")=static_cast< const int>(1)
          )
        .def("ChangeValue",
             (AppParCurves_MultiCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) ) static_cast<AppParCurves_MultiCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) >(&BRepApprox_TheComputeLineBezierOfApprox::ChangeValue),
             R"#(returns the result of the approximation.)#"  , py::arg("Index")=static_cast< const int>(1)
          )
        .def("Parametrization",
             (Approx_ParametrizationType (BRepApprox_TheComputeLineBezierOfApprox::*)() const) static_cast<Approx_ParametrizationType (BRepApprox_TheComputeLineBezierOfApprox::*)() const>(&BRepApprox_TheComputeLineBezierOfApprox::Parametrization),
             R"#(returns the type of parametrization)#" 
          )
        .def("Parameters",
             ( const NCollection_Array1<double> & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) const) static_cast< const NCollection_Array1<double> & (BRepApprox_TheComputeLineBezierOfApprox::*)(  const int  ) const>(&BRepApprox_TheComputeLineBezierOfApprox::Parameters),
             R"#(returns the new parameters of the approximation corresponding to the points of the multicurve <Index>.)#"  , py::arg("Index")=static_cast< const int>(1)
          )
    // methods using call by reference i.s.o. return
        .def("Error",
             []( BRepApprox_TheComputeLineBezierOfApprox &self ,  const int Index ){
                 double  tol3d;
                double  tol2d;

                 self.Error(Index,tol3d,tol2d);
                 return std::make_tuple(tol3d,tol2d); },
             R"#(returns the tolerances 2d and 3d of the <Index> MultiCurve.)#"  , py::arg("Index")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SplineValue",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)() ) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineBezierOfApprox::*)() >(&BRepApprox_TheComputeLineBezierOfApprox::SplineValue),
             R"#(returns the result of the approximation.)#"
             
         )
;

    // Class BRepApprox_TheComputeLineOfApprox from ./opencascade/BRepApprox_TheComputeLineOfApprox.hxx
    klass = m.attr("BRepApprox_TheComputeLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheComputeLineOfApprox , shared_ptr<BRepApprox_TheComputeLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const int, const int, const double, const double, const int, const bool, const Approx_ParametrizationType, const bool >()  , py::arg("Line"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-3),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-6),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const BRepApprox_TheMultiLineOfApprox &, const math_Vector &, const int, const int, const double, const double, const int, const bool, const bool >()  , py::arg("Line"),  py::arg("Parameters"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const int, const int, const double, const double, const int, const bool, const Approx_ParametrizationType, const bool >()  , py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false) )
        .def(py::init<  const math_Vector &, const int, const int, const double, const double, const int, const bool, const bool >()  , py::arg("Parameters"),  py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("Squares")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Interpol",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheComputeLineOfApprox::Interpol),
             R"#(Constructs an interpolation of the MultiLine <Line> The result will be a C2 curve of degree 3.)#"  , py::arg("Line")
          )
        .def("Init",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const int ,   const int ,   const double ,   const double ,   const int ,   const bool ,   const Approx_ParametrizationType ,   const bool  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const int ,   const int ,   const double ,   const double ,   const int ,   const bool ,   const Approx_ParametrizationType ,   const bool  ) >(&BRepApprox_TheComputeLineOfApprox::Init),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("degreemin")=static_cast< const int>(4),  py::arg("degreemax")=static_cast< const int>(8),  py::arg("Tolerance3d")=static_cast< const double>(1.0e-03),  py::arg("Tolerance2d")=static_cast< const double>(1.0e-06),  py::arg("NbIterations")=static_cast< const int>(5),  py::arg("cutting")=static_cast< const bool>(true),  py::arg("parametrization")=static_cast< const Approx_ParametrizationType>(Approx_ChordLength),  py::arg("Squares")=static_cast< const bool>(false)
          )
        .def("Perform",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheComputeLineOfApprox::Perform),
             R"#(runs the algorithm after having initialized the fields.)#"  , py::arg("Line")
          )
        .def("SetParameters",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const math_Vector &  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const math_Vector &  ) >(&BRepApprox_TheComputeLineOfApprox::SetParameters),
             R"#(The approximation will begin with the set of parameters <ThePar>.)#"  , py::arg("ThePar")
          )
        .def("SetKnots",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const NCollection_Array1<double> &  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const NCollection_Array1<double> &  ) >(&BRepApprox_TheComputeLineOfApprox::SetKnots),
             R"#(The approximation will be done with the set of knots <Knots>. The multiplicities will be set with the degree and the desired continuity.)#"  , py::arg("Knots")
          )
        .def("SetKnotsAndMultiplicities",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const NCollection_Array1<double> & ,   const NCollection_Array1<int> &  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const NCollection_Array1<double> & ,   const NCollection_Array1<int> &  ) >(&BRepApprox_TheComputeLineOfApprox::SetKnotsAndMultiplicities),
             R"#(The approximation will be done with the set of knots <Knots> and the multiplicities <Mults>.)#"  , py::arg("Knots"),  py::arg("Mults")
          )
        .def("SetDegrees",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const int ,   const int  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const int ,   const int  ) >(&BRepApprox_TheComputeLineOfApprox::SetDegrees),
             R"#(changes the degrees of the approximation.)#"  , py::arg("degreemin"),  py::arg("degreemax")
          )
        .def("SetTolerances",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const double ,   const double  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const double ,   const double  ) >(&BRepApprox_TheComputeLineOfApprox::SetTolerances),
             R"#(Changes the tolerances of the approximation.)#"  , py::arg("Tolerance3d"),  py::arg("Tolerance2d")
          )
        .def("SetContinuity",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const int  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const int  ) >(&BRepApprox_TheComputeLineOfApprox::SetContinuity),
             R"#(sets the continuity of the spline. if C = 2, the spline will be C2.)#"  , py::arg("C")
          )
        .def("SetConstraints",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const AppParCurves_Constraint ,   const AppParCurves_Constraint  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const AppParCurves_Constraint ,   const AppParCurves_Constraint  ) >(&BRepApprox_TheComputeLineOfApprox::SetConstraints),
             R"#(changes the first and the last constraint points.)#"  , py::arg("firstC"),  py::arg("lastC")
          )
        .def("SetPeriodic",
             (void (BRepApprox_TheComputeLineOfApprox::*)(  const bool  ) ) static_cast<void (BRepApprox_TheComputeLineOfApprox::*)(  const bool  ) >(&BRepApprox_TheComputeLineOfApprox::SetPeriodic),
             R"#(Sets periodic flag. If thePeriodic = true, algorithm tries to build periodic multicurve using corresponding C1 boundary condition for first and last multipoints. Multiline must be closed.)#"  , py::arg("thePeriodic")
          )
        .def("IsAllApproximated",
             (bool (BRepApprox_TheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_TheComputeLineOfApprox::*)() const>(&BRepApprox_TheComputeLineOfApprox::IsAllApproximated),
             R"#(returns False if at a moment of the approximation, the status NoApproximation has been sent by the user when more points were needed.)#" 
          )
        .def("IsToleranceReached",
             (bool (BRepApprox_TheComputeLineOfApprox::*)() const) static_cast<bool (BRepApprox_TheComputeLineOfApprox::*)() const>(&BRepApprox_TheComputeLineOfApprox::IsToleranceReached),
             R"#(returns False if the status NoPointsAdded has been sent.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Error",
             []( BRepApprox_TheComputeLineOfApprox &self   ){
                 double  tol3d;
                double  tol2d;

                 self.Error(tol3d,tol2d);
                 return std::make_tuple(tol3d,tol2d); },
             R"#(returns the tolerances 2d and 3d of the MultiBSpCurve.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineOfApprox::*)() const) static_cast< const AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineOfApprox::*)() const>(&BRepApprox_TheComputeLineOfApprox::Value),
             R"#(returns the result of the approximation.)#"
             
         )
       .def("ChangeValue",
             (AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineOfApprox::*)() ) static_cast<AppParCurves_MultiBSpCurve & (BRepApprox_TheComputeLineOfApprox::*)() >(&BRepApprox_TheComputeLineOfApprox::ChangeValue),
             R"#(returns the result of the approximation.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Parameters",
             ( const NCollection_Array1<double> & (BRepApprox_TheComputeLineOfApprox::*)() const) static_cast< const NCollection_Array1<double> & (BRepApprox_TheComputeLineOfApprox::*)() const>(&BRepApprox_TheComputeLineOfApprox::Parameters),
             R"#(returns the new parameters of the approximation corresponding to the points of the MultiBSpCurve.)#"
             
         )
;

    // Class BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox from ./opencascade/BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx
    klass = m.attr("BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox , shared_ptr<BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  const BRepAdaptor_Surface &, const BRepAdaptor_Surface & >()  , py::arg("S1"),  py::arg("S2") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<int (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::NbVariables),
             R"#()#" 
          )
        .def("NbEquations",
             (int (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<int (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::NbEquations),
             R"#()#" 
          )
        .def("Value",
             (bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector &  ) >(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Matrix &  ) >(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Derivatives),
             R"#()#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
        .def("ComputeParameters",
             (void (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const IntImp_ConstIsoparametric ,   const NCollection_Array1<double> & ,  math_Vector & ,  math_Vector & ,  math_Vector & ,  math_Vector &  ) ) static_cast<void (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const IntImp_ConstIsoparametric ,   const NCollection_Array1<double> & ,  math_Vector & ,  math_Vector & ,  math_Vector & ,  math_Vector &  ) >(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::ComputeParameters),
             R"#()#"  , py::arg("ChoixIso"),  py::arg("Param"),  py::arg("UVap"),  py::arg("BornInf"),  py::arg("BornSup"),  py::arg("Tolerance")
          )
        .def("Root",
             (double (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<double (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Root),
             R"#(returns somme des fi*fi)#" 
          )
        .def("Point",
             (gp_Pnt (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<gp_Pnt (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Point),
             R"#()#" 
          )
        .def("IsTangent",
             (bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  NCollection_Array1<double> & ,  IntImp_ConstIsoparametric &  ) ) static_cast<bool (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  NCollection_Array1<double> & ,  IntImp_ConstIsoparametric &  ) >(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::IsTangent),
             R"#()#"  , py::arg("UVap"),  py::arg("Param"),  py::arg("BestChoix")
          )
        .def("Direction",
             (gp_Dir (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<gp_Dir (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::Direction),
             R"#()#" 
          )
        .def("DirectionOnS1",
             (gp_Dir2d (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<gp_Dir2d (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::DirectionOnS1),
             R"#()#" 
          )
        .def("DirectionOnS2",
             (gp_Dir2d (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<gp_Dir2d (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::DirectionOnS2),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("AuxillarSurface1",
             ( const BRepAdaptor_Surface & (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const BRepAdaptor_Surface & (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::AuxillarSurface1),
             R"#()#"
             
         )
       .def("AuxillarSurface2",
             ( const BRepAdaptor_Surface & (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const BRepAdaptor_Surface & (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox::AuxillarSurface2),
             R"#()#"
             
         )
;

    // Class BRepApprox_TheImpPrmSvSurfacesOfApprox from ./opencascade/BRepApprox_TheImpPrmSvSurfacesOfApprox.hxx
    klass = m.attr("BRepApprox_TheImpPrmSvSurfacesOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheImpPrmSvSurfacesOfApprox , shared_ptr<BRepApprox_TheImpPrmSvSurfacesOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepAdaptor_Surface &, const IntSurf_Quadric & >()  , py::arg("Surf1"),  py::arg("Surf2") )
        .def(py::init<  const IntSurf_Quadric &, const BRepAdaptor_Surface & >()  , py::arg("Surf1"),  py::arg("Surf2") )
    // custom constructors
    // methods
        .def("Compute",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)( double & ,  double & ,  double & ,  double & ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)( double & ,  double & ,  double & ,  double & ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::Compute),
             R"#(returns True if Tg,Tguv1 Tguv2 can be computed.)#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Pt"),  py::arg("Tg"),  py::arg("Tguv1"),  py::arg("Tguv2")
          )
        .def("Pnt",
             (void (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Pnt &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::Pnt),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("P")
          )
        .def("SeekPoint",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  IntSurf_PntOn2S &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  IntSurf_PntOn2S &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::SeekPoint),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Point")
          )
        .def("Tangency",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::Tangency),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
        .def("TangencyOnSurf1",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::TangencyOnSurf1),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
        .def("TangencyOnSurf2",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::TangencyOnSurf2),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
        .def("FillInitialVectorOfSolution",
             (bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double ,  math_Vector & ,  double & ,  double &  ) ) static_cast<bool (BRepApprox_TheImpPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double ,  math_Vector & ,  double & ,  double &  ) >(&BRepApprox_TheImpPrmSvSurfacesOfApprox::FillInitialVectorOfSolution),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("binfu"),  py::arg("bsupu"),  py::arg("binfv"),  py::arg("bsupv"),  py::arg("X"),  py::arg("TranslationU"),  py::arg("TranslationV")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox from ./opencascade/BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx
    klass = m.attr("BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox , shared_ptr<BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepAdaptor_Surface &, const BRepAdaptor_Surface &, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("TolTangency") )
        .def(py::init<  const NCollection_Array1<double> &, const BRepAdaptor_Surface &, const BRepAdaptor_Surface &, const double >()  , py::arg("Param"),  py::arg("S1"),  py::arg("S2"),  py::arg("TolTangency") )
    // custom constructors
    // methods
        .def("Perform",
             (IntImp_ConstIsoparametric (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const NCollection_Array1<double> & ,  math_FunctionSetRoot &  ) ) static_cast<IntImp_ConstIsoparametric (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const NCollection_Array1<double> & ,  math_FunctionSetRoot &  ) >(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::Perform),
             R"#(returns the best constant isoparametric to find the next intersection's point +stores the solution point (the solution point is found with the close point to intersect the isoparametric with the other patch; the choice of the isoparametic is calculated))#"  , py::arg("Param"),  py::arg("Rsnld")
          )
        .def("Perform",
             (IntImp_ConstIsoparametric (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const NCollection_Array1<double> & ,  math_FunctionSetRoot & ,   const IntImp_ConstIsoparametric  ) ) static_cast<IntImp_ConstIsoparametric (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)(  const NCollection_Array1<double> & ,  math_FunctionSetRoot & ,   const IntImp_ConstIsoparametric  ) >(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::Perform),
             R"#(returns the best constant isoparametric to find the next intersection's point +stores the solution point (the solution point is found with the close point to intersect the isoparametric with the other patch; the choice of the isoparametic is given by ChoixIso))#"  , py::arg("Param"),  py::arg("Rsnld"),  py::arg("ChoixIso")
          )
        .def("IsDone",
             (bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::IsDone),
             R"#(Returns TRUE if the creation completed without failure.)#" 
          )
        .def("IsEmpty",
             (bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::IsEmpty),
             R"#(Returns TRUE when there is no solution to the problem.)#" 
          )
        .def("IsTangent",
             (bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast<bool (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::IsTangent),
             R"#(Returns True if the surfaces are tangent at the intersection point.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Point",
             ( const IntSurf_PntOn2S & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const IntSurf_PntOn2S & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::Point),
             R"#(Returns the intersection point.)#"
             
         )
       .def("Direction",
             ( const gp_Dir & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const gp_Dir & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::Direction),
             R"#(Returns the tangent at the intersection line.)#"
             
         )
       .def("DirectionOnS1",
             ( const gp_Dir2d & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const gp_Dir2d & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::DirectionOnS1),
             R"#(Returns the tangent at the intersection line in the parametric space of the first surface.)#"
             
         )
       .def("DirectionOnS2",
             ( const gp_Dir2d & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const) static_cast< const gp_Dir2d & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::DirectionOnS2),
             R"#(Returns the tangent at the intersection line in the parametric space of the second surface.)#"
             
         )
       .def("Function",
             (BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() ) static_cast<BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() >(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::Function),
             R"#(return the math function which is used to compute the intersection)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangePoint",
             (IntSurf_PntOn2S & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() ) static_cast<IntSurf_PntOn2S & (BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::*)() >(&BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox::ChangePoint),
             R"#(return the intersection point which is enable for changing.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BRepApprox_TheMultiLineOfApprox from ./opencascade/BRepApprox_TheMultiLineOfApprox.hxx
    klass = m.attr("BRepApprox_TheMultiLineOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheMultiLineOfApprox , shared_ptr<BRepApprox_TheMultiLineOfApprox>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<BRepApprox_ApproxLine> &, const int, const int, const bool, const bool, const double, const double, const double, const double, const double, const double, const double, const bool, const int, const int >()  , py::arg("line"),  py::arg("NbP3d"),  py::arg("NbP2d"),  py::arg("ApproxU1V1"),  py::arg("ApproxU2V2"),  py::arg("xo"),  py::arg("yo"),  py::arg("zo"),  py::arg("u1o"),  py::arg("v1o"),  py::arg("u2o"),  py::arg("v2o"),  py::arg("P2DOnFirst"),  py::arg("IndMin")=static_cast< const int>(0),  py::arg("IndMax")=static_cast< const int>(0) )
        .def(py::init<  const handle<BRepApprox_ApproxLine> &,void * const , const int, const int, const bool, const bool, const double, const double, const double, const double, const double, const double, const double, const bool, const int, const int >()  , py::arg("line"),  py::arg("PtrSvSurfaces"),  py::arg("NbP3d"),  py::arg("NbP2d"),  py::arg("ApproxU1V1"),  py::arg("ApproxU2V2"),  py::arg("xo"),  py::arg("yo"),  py::arg("zo"),  py::arg("u1o"),  py::arg("v1o"),  py::arg("u2o"),  py::arg("v2o"),  py::arg("P2DOnFirst"),  py::arg("IndMin")=static_cast< const int>(0),  py::arg("IndMax")=static_cast< const int>(0) )
    // custom constructors
    // methods
        .def("FirstPoint",
             (int (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<int (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::FirstPoint),
             R"#()#" 
          )
        .def("LastPoint",
             (int (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<int (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::LastPoint),
             R"#()#" 
          )
        .def("NbP2d",
             (int (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<int (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::NbP2d),
             R"#(Returns the number of 2d points of a TheLine.)#" 
          )
        .def("NbP3d",
             (int (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<int (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::NbP3d),
             R"#(Returns the number of 3d points of a TheLine.)#" 
          )
        .def("WhatStatus",
             (Approx_Status (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<Approx_Status (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::WhatStatus),
             R"#()#" 
          )
        .def("Value",
             (void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt> &  ) const) static_cast<void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Value),
             R"#(Returns the 3d points of the multipoint <MPointIndex> when only 3d points exist.)#"  , py::arg("MPointIndex"),  py::arg("tabPt")
          )
        .def("Value",
             (void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt2d> &  ) const) static_cast<void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt2d> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Value),
             R"#(Returns the 2d points of the multipoint <MPointIndex> when only 2d points exist.)#"  , py::arg("MPointIndex"),  py::arg("tabPt2d")
          )
        .def("Value",
             (void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<gp_Pnt2d> &  ) const) static_cast<void (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<gp_Pnt2d> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Value),
             R"#(Returns the 3d and 2d points of the multipoint <MPointIndex>.)#"  , py::arg("MPointIndex"),  py::arg("tabPt"),  py::arg("tabPt2d")
          )
        .def("Tangency",
             (bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec> &  ) const) static_cast<bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Tangency),
             R"#(Returns the 3d tangency points of the multipoint <MPointIndex> only when 3d points exist.)#"  , py::arg("MPointIndex"),  py::arg("tabV")
          )
        .def("Tangency",
             (bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec2d> &  ) const) static_cast<bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec2d> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Tangency),
             R"#(Returns the 2d tangency points of the multipoint <MPointIndex> only when 2d points exist.)#"  , py::arg("MPointIndex"),  py::arg("tabV2d")
          )
        .def("Tangency",
             (bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) const) static_cast<bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) const>(&BRepApprox_TheMultiLineOfApprox::Tangency),
             R"#(Returns the 3d and 2d points of the multipoint <MPointIndex>.)#"  , py::arg("MPointIndex"),  py::arg("tabV"),  py::arg("tabV2d")
          )
        .def("MakeMLBetween",
             (BRepApprox_TheMultiLineOfApprox (BRepApprox_TheMultiLineOfApprox::*)(  const int ,   const int ,   const int  ) const) static_cast<BRepApprox_TheMultiLineOfApprox (BRepApprox_TheMultiLineOfApprox::*)(  const int ,   const int ,   const int  ) const>(&BRepApprox_TheMultiLineOfApprox::MakeMLBetween),
             R"#(Tries to make a sub-line between <Low> and <High> points of this line by adding <NbPointsToInsert> new points)#"  , py::arg("Low"),  py::arg("High"),  py::arg("NbPointsToInsert")
          )
        .def("MakeMLOneMorePoint",
             (bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,   const int ,   const int ,  BRepApprox_TheMultiLineOfApprox &  ) const) static_cast<bool (BRepApprox_TheMultiLineOfApprox::*)(  const int ,   const int ,   const int ,  BRepApprox_TheMultiLineOfApprox &  ) const>(&BRepApprox_TheMultiLineOfApprox::MakeMLOneMorePoint),
             R"#(Tries to make a sub-line between <Low> and <High> points of this line by adding one more point between (indbad-1)-th and indbad-th points)#"  , py::arg("Low"),  py::arg("High"),  py::arg("indbad"),  py::arg("OtherLine")
          )
        .def("Dump",
             (void (BRepApprox_TheMultiLineOfApprox::*)() const) static_cast<void (BRepApprox_TheMultiLineOfApprox::*)() const>(&BRepApprox_TheMultiLineOfApprox::Dump),
             R"#(Dump of the current multi-line.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_TheMultiLineToolOfApprox from ./opencascade/BRepApprox_TheMultiLineToolOfApprox.hxx
    klass = m.attr("BRepApprox_TheMultiLineToolOfApprox");

    // default constructor
    register_default_constructor<BRepApprox_TheMultiLineToolOfApprox , shared_ptr<BRepApprox_TheMultiLineToolOfApprox>>(m,"BRepApprox_TheMultiLineToolOfApprox");

    // nested enums

    static_cast<py::class_<BRepApprox_TheMultiLineToolOfApprox , shared_ptr<BRepApprox_TheMultiLineToolOfApprox>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstPoint_s",
                    (int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::FirstPoint),
                    R"#(Returns the number of multipoints of the TheMultiLine.)#"  , py::arg("ML")
          )
        .def_static("LastPoint_s",
                    (int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::LastPoint),
                    R"#(Returns the number of multipoints of the TheMultiLine.)#"  , py::arg("ML")
          )
        .def_static("NbP2d_s",
                    (int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::NbP2d),
                    R"#(Returns the number of 2d points of a TheMultiLine.)#"  , py::arg("ML")
          )
        .def_static("NbP3d_s",
                    (int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<int (*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::NbP3d),
                    R"#(Returns the number of 3d points of a TheMultiLine.)#"  , py::arg("ML")
          )
        .def_static("Value_s",
                    (void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt> &  ) ) static_cast<void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Value),
                    R"#(returns the 3d points of the multipoint <MPointIndex> when only 3d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabPt")
          )
        .def_static("Value_s",
                    (void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt2d> &  ) ) static_cast<void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Value),
                    R"#(returns the 2d points of the multipoint <MPointIndex> when only 2d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabPt2d")
          )
        .def_static("Value_s",
                    (void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<gp_Pnt2d> &  ) ) static_cast<void (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<gp_Pnt2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Value),
                    R"#(returns the 3d and 2d points of the multipoint <MPointIndex>.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabPt"),  py::arg("tabPt2d")
          )
        .def_static("Tangency_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Tangency),
                    R"#(returns the 3d points of the multipoint <MPointIndex> when only 3d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV")
          )
        .def_static("Tangency_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec2d> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Tangency),
                    R"#(returns the 2d tangency points of the multipoint <MPointIndex> only when 2d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV2d")
          )
        .def_static("Tangency_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Tangency),
                    R"#(returns the 3d and 2d points of the multipoint <MPointIndex>.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV"),  py::arg("tabV2d")
          )
        .def_static("Curvature_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Curvature),
                    R"#(returns the 3d curvature of the multipoint <MPointIndex> when only 3d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV")
          )
        .def_static("Curvature_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec2d> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Curvature),
                    R"#(returns the 2d curvature points of the multipoint <MPointIndex> only when 2d points exist.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV2d")
          )
        .def_static("Curvature_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,  NCollection_Array1<gp_Vec> & ,  NCollection_Array1<gp_Vec2d> &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Curvature),
                    R"#(returns the 3d and 2d curvature of the multipoint <MPointIndex>.)#"  , py::arg("ML"),  py::arg("MPointIndex"),  py::arg("tabV"),  py::arg("tabV2d")
          )
        .def_static("MakeMLBetween_s",
                    (BRepApprox_TheMultiLineOfApprox (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const int  ) ) static_cast<BRepApprox_TheMultiLineOfApprox (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const int  ) >(&BRepApprox_TheMultiLineToolOfApprox::MakeMLBetween),
                    R"#(Is called if WhatStatus returned "PointsAdded".)#"  , py::arg("ML"),  py::arg("I1"),  py::arg("I2"),  py::arg("NbPMin")
          )
        .def_static("MakeMLOneMorePoint_s",
                    (bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const int ,  BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<bool (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int ,   const int ,  BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::MakeMLOneMorePoint),
                    R"#(Is called when the Bezier curve contains a loop)#"  , py::arg("ML"),  py::arg("I1"),  py::arg("I2"),  py::arg("indbad"),  py::arg("OtherLine")
          )
        .def_static("WhatStatus_s",
                    (Approx_Status (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int  ) ) static_cast<Approx_Status (*)(  const BRepApprox_TheMultiLineOfApprox & ,   const int ,   const int  ) >(&BRepApprox_TheMultiLineToolOfApprox::WhatStatus),
                    R"#()#"  , py::arg("ML"),  py::arg("I1"),  py::arg("I2")
          )
        .def_static("Dump_s",
                    (void (*)(  const BRepApprox_TheMultiLineOfApprox &  ) ) static_cast<void (*)(  const BRepApprox_TheMultiLineOfApprox &  ) >(&BRepApprox_TheMultiLineToolOfApprox::Dump),
                    R"#(Dump of the current multi-line.)#"  , py::arg("ML")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_ThePrmPrmSvSurfacesOfApprox from ./opencascade/BRepApprox_ThePrmPrmSvSurfacesOfApprox.hxx
    klass = m.attr("BRepApprox_ThePrmPrmSvSurfacesOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_ThePrmPrmSvSurfacesOfApprox , shared_ptr<BRepApprox_ThePrmPrmSvSurfacesOfApprox>  >>(klass)
    // constructors
        .def(py::init<  const BRepAdaptor_Surface &, const BRepAdaptor_Surface & >()  , py::arg("Surf1"),  py::arg("Surf2") )
    // custom constructors
    // methods
        .def("Compute",
             (bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)( double & ,  double & ,  double & ,  double & ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)( double & ,  double & ,  double & ,  double & ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::Compute),
             R"#(returns True if Tg,Tguv1 Tguv2 can be computed.)#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Pt"),  py::arg("Tg"),  py::arg("Tguv1"),  py::arg("Tguv2")
          )
        .def("Pnt",
             (void (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Pnt &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::Pnt),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("P")
          )
        .def("SeekPoint",
             (bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  IntSurf_PntOn2S &  ) ) static_cast<bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  IntSurf_PntOn2S &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::SeekPoint),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Point")
          )
        .def("Tangency",
             (bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec &  ) ) static_cast<bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::Tangency),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
        .def("TangencyOnSurf1",
             (bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::TangencyOnSurf1),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
        .def("TangencyOnSurf2",
             (bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) ) static_cast<bool (BRepApprox_ThePrmPrmSvSurfacesOfApprox::*)(  const double ,   const double ,   const double ,   const double ,  gp_Vec2d &  ) >(&BRepApprox_ThePrmPrmSvSurfacesOfApprox::TangencyOnSurf2),
             R"#()#"  , py::arg("u1"),  py::arg("v1"),  py::arg("u2"),  py::arg("v2"),  py::arg("Tg")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox from ./opencascade/BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox.hxx
    klass = m.attr("BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox");


    // nested enums

    static_cast<py::class_<BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox , shared_ptr<BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const BRepAdaptor_Surface &, const IntSurf_Quadric & >()  , py::arg("PS"),  py::arg("IS") )
        .def(py::init<  const IntSurf_Quadric & >()  , py::arg("IS") )
    // custom constructors
    // methods
        .def("Set",
             (void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const BRepAdaptor_Surface &  ) ) static_cast<void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const BRepAdaptor_Surface &  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Set),
             R"#()#"  , py::arg("PS")
          )
        .def("SetImplicitSurface",
             (void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const IntSurf_Quadric &  ) ) static_cast<void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const IntSurf_Quadric &  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::SetImplicitSurface),
             R"#()#"  , py::arg("IS")
          )
        .def("Set",
             (void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const double  ) ) static_cast<void (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const double  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Set),
             R"#()#"  , py::arg("Tolerance")
          )
        .def("NbVariables",
             (int (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast<int (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::NbVariables),
             R"#()#" 
          )
        .def("NbEquations",
             (int (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast<int (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::NbEquations),
             R"#()#" 
          )
        .def("Value",
             (bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector &  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Matrix &  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Derivatives),
             R"#()#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
        .def("Root",
             (double (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast<double (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Root),
             R"#()#" 
          )
        .def("Tolerance",
             (double (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast<double (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Tolerance),
             R"#(Returns the value Tol so that if std::abs(Func.Root())<Tol the function is considered null.)#" 
          )
        .def("IsTangent",
             (bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() ) static_cast<bool (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::IsTangent),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Point",
             ( const gp_Pnt & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast< const gp_Pnt & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Point),
             R"#()#"
             
         )
       .def("Direction3d",
             ( const gp_Vec & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() ) static_cast< const gp_Vec & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Direction3d),
             R"#()#"
             
         )
       .def("Direction2d",
             ( const gp_Dir2d & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() ) static_cast< const gp_Dir2d & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() >(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::Direction2d),
             R"#()#"
             
         )
       .def("PSurface",
             ( const BRepAdaptor_Surface & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast< const BRepAdaptor_Surface & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::PSurface),
             R"#()#"
             
         )
       .def("ISurface",
             ( const IntSurf_Quadric & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const) static_cast< const IntSurf_Quadric & (BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::*)() const>(&BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox::ISurface),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BRepApprox_Approx.hxx
// ./opencascade/BRepApprox_ApproxLine.hxx
// ./opencascade/BRepApprox_BSpGradient_BFGSOfMyBSplGradientOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_BSpParFunctionOfMyBSplGradientOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_BSpParLeastSquareOfMyBSplGradientOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_Gradient_BFGSOfMyGradientOfTheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_Gradient_BFGSOfMyGradientbisOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_MyBSplGradientOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_MyGradientOfTheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_MyGradientbisOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_ParFunctionOfMyGradientOfTheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_ParFunctionOfMyGradientbisOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_ParLeastSquareOfMyGradientOfTheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_ParLeastSquareOfMyGradientbisOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_ResConstraintOfMyGradientOfTheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_ResConstraintOfMyGradientbisOfTheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_SurfaceTool.hxx
// ./opencascade/BRepApprox_TheComputeLineBezierOfApprox.hxx
// ./opencascade/BRepApprox_TheComputeLineOfApprox.hxx
// ./opencascade/BRepApprox_TheFunctionOfTheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx
// ./opencascade/BRepApprox_TheImpPrmSvSurfacesOfApprox.hxx
// ./opencascade/BRepApprox_TheInt2SOfThePrmPrmSvSurfacesOfApprox.hxx
// ./opencascade/BRepApprox_TheMultiLineOfApprox.hxx
// ./opencascade/BRepApprox_TheMultiLineToolOfApprox.hxx
// ./opencascade/BRepApprox_ThePrmPrmSvSurfacesOfApprox.hxx
// ./opencascade/BRepApprox_TheZerImpFuncOfTheImpPrmSvSurfacesOfApprox.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
