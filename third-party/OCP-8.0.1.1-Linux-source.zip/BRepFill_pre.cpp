
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Shell.hxx>
#include <TopoDS_Wire.hxx>
#include <TopoDS_Shape.hxx>
#include <gp_Ax3.hxx>
#include <gp_Pnt.hxx>
#include <gp_Vec.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <GeomFill_LocationGuide.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_MakerVolume.hxx>
#include <TopoDS_Face.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Edge.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_DraftLaw.hxx>
#include <BRepFill_SectionLaw.hxx>
#include <Geom_Surface.hxx>
#include <Bnd_Box.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <GeomFill_LocationDraft.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax3.hxx>
#include <BRepMAT2d_BisectingLocus.hxx>
#include <BRepMAT2d_LinkTopoBilo.hxx>
#include <BRepTools_Quilt.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Wire.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_OffsetWire.hxx>
#include <TopoDS_Edge.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_TrimEdgeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_LocationLaw.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <BRepFill_Sweep.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Law_Function.hxx>
#include <BRepFill_LocationLaw.hxx>
#include <BRepFill_SectionLaw.hxx>
#include <gp_Ax2.hxx>
#include <BRepFill_Sweep.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Wire.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_LocationLaw.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Law_Function.hxx>
#include <TopoDS_Wire.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepFill_LocationLaw.hxx>
#include <BRepFill_SectionLaw.hxx>
#include <TopoDS_Edge.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Vertex.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <BRepFill.hxx>
#include <BRepFill_ACRLaw.hxx>
#include <BRepFill_AdvancedEvolved.hxx>
#include <BRepFill_ApproxSeewing.hxx>
#include <BRepFill_CompatibleWires.hxx>
#include <BRepFill_ComputeCLine.hxx>
#include <BRepFill_CurveConstraint.hxx>
#include <BRepFill_Draft.hxx>
#include <BRepFill_DraftLaw.hxx>
#include <BRepFill_Edge3DLaw.hxx>
#include <BRepFill_EdgeFaceAndOrder.hxx>
#include <BRepFill_EdgeOnSurfLaw.hxx>
#include <BRepFill_Evolved.hxx>
#include <BRepFill_FaceAndOrder.hxx>
#include <BRepFill_Filling.hxx>
#include <BRepFill_Generator.hxx>
#include <BRepFill_LocationLaw.hxx>
#include <BRepFill_MultiLine.hxx>
#include <BRepFill_NSections.hxx>
#include <BRepFill_OffsetAncestors.hxx>
#include <BRepFill_OffsetWire.hxx>
#include <BRepFill_Pipe.hxx>
#include <BRepFill_PipeShell.hxx>
#include <BRepFill_Section.hxx>
#include <BRepFill_SectionLaw.hxx>
#include <BRepFill_SectionPlacement.hxx>
#include <BRepFill_ShapeLaw.hxx>
#include <BRepFill_Sweep.hxx>
#include <BRepFill_ThruSectionErrorStatus.hxx>
#include <BRepFill_TransitionStyle.hxx>
#include <BRepFill_TrimEdgeTool.hxx>
#include <BRepFill_TrimShellCorner.hxx>
#include <BRepFill_TrimSurfaceTool.hxx>
#include <BRepFill_TypeOfContact.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepFill_enums(py::module &main_module) {


py::module m = main_module.def_submodule("BRepFill", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<BRepFill_TypeOfContact>(m, "BRepFill_TypeOfContact",R"#(A pair of bound shapes with the result.)#")
        .value("BRepFill_NoContact",BRepFill_TypeOfContact::BRepFill_NoContact)
        .value("BRepFill_Contact",BRepFill_TypeOfContact::BRepFill_Contact)
        .value("BRepFill_ContactOnBorder",BRepFill_TypeOfContact::BRepFill_ContactOnBorder).export_values();
    py::enum_<BRepFill_ThruSectionErrorStatus>(m, "BRepFill_ThruSectionErrorStatus",R"#(Errors that can occur at thrusection algorithm.)#")
        .value("BRepFill_ThruSectionErrorStatus_Done",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_Done)
        .value("BRepFill_ThruSectionErrorStatus_NotDone",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_NotDone)
        .value("BRepFill_ThruSectionErrorStatus_NotSameTopology",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_NotSameTopology)
        .value("BRepFill_ThruSectionErrorStatus_ProfilesInconsistent",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_ProfilesInconsistent)
        .value("BRepFill_ThruSectionErrorStatus_WrongUsage",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_WrongUsage)
        .value("BRepFill_ThruSectionErrorStatus_Null3DCurve",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_Null3DCurve)
        .value("BRepFill_ThruSectionErrorStatus_Failed",BRepFill_ThruSectionErrorStatus::BRepFill_ThruSectionErrorStatus_Failed).export_values();
    py::enum_<BRepFill_TransitionStyle>(m, "BRepFill_TransitionStyle",R"#()#")
        .value("BRepFill_Modified",BRepFill_TransitionStyle::BRepFill_Modified)
        .value("BRepFill_Right",BRepFill_TransitionStyle::BRepFill_Right)
        .value("BRepFill_Round",BRepFill_TransitionStyle::BRepFill_Round).export_values();

//Python trampoline classes
    class Py_BRepFill_SectionLaw : public BRepFill_SectionLaw{
    public:
        using BRepFill_SectionLaw::BRepFill_SectionLaw;


        // public pure virtual
        bool IsConstant() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,IsConstant,) };
        bool IsVertex() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,IsVertex,) };
        handle<GeomFill_SectionLaw> ConcatenedLaw() const  override { using return_type = handle<GeomFill_SectionLaw>;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,ConcatenedLaw,) };
        GeomAbs_Shape Continuity( const int Index, const double TolAngular) const  override { using return_type = GeomAbs_Shape;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,Continuity,Index,TolAngular) };
        double VertexTol( const int Index, const double Param) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,VertexTol,Index,Param) };
        TopoDS_Vertex Vertex( const int Index, const double Param) const  override { using return_type = TopoDS_Vertex;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,Vertex,Index,Param) };
        void D0( const double U,TopoDS_Shape & S) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BRepFill_SectionLaw,D0,U,S) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<BRepFill , shared_ptr<BRepFill>  >(
      m,
      "BRepFill",R"#()#"
    );
    py::class_<BRepFill_AdvancedEvolved , shared_ptr<BRepFill_AdvancedEvolved>  >(
      m,
      "BRepFill_AdvancedEvolved",R"#(Constructs an evolved volume from a spine (wire or face) and a profile (wire).)#"
    );
    py::class_<BRepFill_ApproxSeewing , shared_ptr<BRepFill_ApproxSeewing>  >(
      m,
      "BRepFill_ApproxSeewing",R"#(Evaluate the 3dCurve and the PCurves described in a MultiLine from BRepFill. The parametrization of those curves is not imposed by the Bissectrice. The parametrization is given approximately by the abscissa of the curve3d.)#"
    );
    py::class_<BRepFill_CompatibleWires , shared_ptr<BRepFill_CompatibleWires>  >(
      m,
      "BRepFill_CompatibleWires",R"#(Constructs a sequence of Wires (with good orientation and origin) agreed each other so that the surface passing through these sections is not twisted)#"
    );
    py::class_<BRepFill_ComputeCLine , shared_ptr<BRepFill_ComputeCLine>  >(
      m,
      "BRepFill_ComputeCLine",R"#()#"
    );
    py::class_<BRepFill_Draft , shared_ptr<BRepFill_Draft>  >(
      m,
      "BRepFill_Draft",R"#()#"
    );
    py::class_<BRepFill_EdgeFaceAndOrder , shared_ptr<BRepFill_EdgeFaceAndOrder>  >(
      m,
      "BRepFill_EdgeFaceAndOrder",R"#()#"
    );
    py::class_<BRepFill_Evolved , shared_ptr<BRepFill_Evolved>  >(
      m,
      "BRepFill_Evolved",R"#(Constructs an evolved volume from a spine (wire or face) and a profile ( wire).)#"
    );
    py::class_<BRepFill_FaceAndOrder , shared_ptr<BRepFill_FaceAndOrder>  >(
      m,
      "BRepFill_FaceAndOrder",R"#(A structure containing Face and Order of constraint)#"
    );
    py::class_<BRepFill_Filling , shared_ptr<BRepFill_Filling>  >(
      m,
      "BRepFill_Filling",R"#(N-Side Filling This algorithm avoids to build a face from: * a set of edges defining the bounds of the face and some constraints the surface support has to satisfy * a set of edges and points defining some constraints the support surface has to satisfy * an initial surface to deform for satisfying the constraints * a set of parameters to control the constraints.)#"
    );
    py::class_<BRepFill_Generator , shared_ptr<BRepFill_Generator>  >(
      m,
      "BRepFill_Generator",R"#(Compute a topological surface (a shell) using generating wires. The face of the shell will be ruled surfaces passing by the wires. The wires must have the same number of edges.)#"
    );
    py::class_<BRepFill_OffsetAncestors , shared_ptr<BRepFill_OffsetAncestors>  >(
      m,
      "BRepFill_OffsetAncestors",R"#(this class is used to find the generating shapes of an OffsetWire.)#"
    );
    py::class_<BRepFill_OffsetWire , shared_ptr<BRepFill_OffsetWire>  >(
      m,
      "BRepFill_OffsetWire",R"#(Constructs a Offset Wire to a spine (wire or face). Offset direction will be to outer region in case of positive offset value and to inner region in case of negative offset value. Inner/Outer region for open wire is defined by the following rule: when we go along the wire (taking into account of edges orientation) then outer region will be on the right side, inner region will be on the left side. In case of closed wire, inner region will always be inside the wire (at that, edges orientation is not taken into account). The Wire or the Face must be planar and oriented correctly.)#"
    );
    py::class_<BRepFill_Pipe , shared_ptr<BRepFill_Pipe>  >(
      m,
      "BRepFill_Pipe",R"#(Create a shape by sweeping a shape (the profile) along a wire (the spine).)#"
    );
    py::class_<BRepFill_Section , shared_ptr<BRepFill_Section>  >(
      m,
      "BRepFill_Section",R"#(To store section definition)#"
    );
    py::class_<BRepFill_SectionPlacement , shared_ptr<BRepFill_SectionPlacement>  >(
      m,
      "BRepFill_SectionPlacement",R"#(Place a shape in a local axis coordinate)#"
    );
    py::class_<BRepFill_Sweep , shared_ptr<BRepFill_Sweep>  >(
      m,
      "BRepFill_Sweep",R"#(Topological Sweep Algorithm Computes an Sweep shell using a generating wire, an SectionLaw and an LocationLaw.)#"
    );
    py::class_<BRepFill_TrimEdgeTool , shared_ptr<BRepFill_TrimEdgeTool>  >(
      m,
      "BRepFill_TrimEdgeTool",R"#(Geometric Tool using to construct Offset Wires.)#"
    );
    py::class_<BRepFill_TrimShellCorner , shared_ptr<BRepFill_TrimShellCorner>  >(
      m,
      "BRepFill_TrimShellCorner",R"#(Trims sets of faces in the corner to make proper parts of pipe)#"
    );
    py::class_<BRepFill_TrimSurfaceTool , shared_ptr<BRepFill_TrimSurfaceTool>  >(
      m,
      "BRepFill_TrimSurfaceTool",R"#(Compute the Pcurves and the 3d curves resulting of the trimming of a face by an extruded surface.)#"
    );
    py::class_<BRepFill_CurveConstraint ,opencascade::handle<BRepFill_CurveConstraint>  , GeomPlate_CurveConstraint >(
      m,
      "BRepFill_CurveConstraint",R"#(same as CurveConstraint from GeomPlate with BRepAdaptor_Surface instead of GeomAdaptor_Surface)#"
    );
    py::class_<BRepFill_LocationLaw ,opencascade::handle<BRepFill_LocationLaw>  , Standard_Transient >(
      m,
      "BRepFill_LocationLaw",R"#(Location Law on a Wire.)#"
    );
    py::class_<BRepFill_MultiLine , shared_ptr<BRepFill_MultiLine>  , AppCont_Function >(
      m,
      "BRepFill_MultiLine",R"#(Class used to compute the 3d curve and the two 2d curves resulting from the intersection of a surface of linear extrusion( Bissec, Dz) and the 2 faces. These 3 curves will have the same parametrization as the Bissectrice. This class is to be sent to an approximation routine.)#"
    );
    py::class_<BRepFill_PipeShell ,opencascade::handle<BRepFill_PipeShell>  , Standard_Transient >(
      m,
      "BRepFill_PipeShell",R"#(Computes a topological shell using some wires (spines and profiles) and displacement option Perform general sweeping construction)#"
    );
    py::class_<BRepFill_SectionLaw ,opencascade::handle<BRepFill_SectionLaw> ,Py_BRepFill_SectionLaw , Standard_Transient >(
      m,
      "BRepFill_SectionLaw",R"#(Build Section Law, with an Vertex, or an Wire)#"
    );
    py::class_<BRepFill_ACRLaw ,opencascade::handle<BRepFill_ACRLaw>  , BRepFill_LocationLaw >(
      m,
      "BRepFill_ACRLaw",R"#(Build Location Law, with a Wire. In the case of guided contour and trihedron by reduced curvilinear abscissa)#"
    );
    py::class_<BRepFill_Edge3DLaw ,opencascade::handle<BRepFill_Edge3DLaw>  , BRepFill_LocationLaw >(
      m,
      "BRepFill_Edge3DLaw",R"#(Build Location Law, with a Wire.)#"
    );
    py::class_<BRepFill_EdgeOnSurfLaw ,opencascade::handle<BRepFill_EdgeOnSurfLaw>  , BRepFill_LocationLaw >(
      m,
      "BRepFill_EdgeOnSurfLaw",R"#(Build Location Law, with a Wire and a Surface.)#"
    );
    py::class_<BRepFill_NSections ,opencascade::handle<BRepFill_NSections>  , BRepFill_SectionLaw >(
      m,
      "BRepFill_NSections",R"#(Build Section Law, with N Sections)#"
    );
    py::class_<BRepFill_ShapeLaw ,opencascade::handle<BRepFill_ShapeLaw>  , BRepFill_SectionLaw >(
      m,
      "BRepFill_ShapeLaw",R"#(Build Section Law, with an Vertex, or an Wire)#"
    );
    py::class_<BRepFill_DraftLaw ,opencascade::handle<BRepFill_DraftLaw>  , BRepFill_Edge3DLaw >(
      m,
      "BRepFill_DraftLaw",R"#(Build Location Law, with a Wire.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
