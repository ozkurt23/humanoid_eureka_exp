
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <gp_Pnt.hxx>
#include <gp_Vec.hxx>

// module includes
#include <BRepLProp.hxx>
#include <BRepLProp_CLProps.hxx>
#include <BRepLProp_SLProps.hxx>
#include <BRepLProp_SurfaceTool.hxx>

// template related includes

// ./opencascade/BRepLProp_CLProps.hxx
#include "GeomLProp_tmpl.hxx"

// ./opencascade/BRepLProp_SLProps.hxx
#include "GeomLProp_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepLProp(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BRepLProp"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BRepLProp from ./opencascade/BRepLProp.hxx
    klass = m.attr("BRepLProp");

    // default constructor
    register_default_constructor<BRepLProp , shared_ptr<BRepLProp>>(m,"BRepLProp");

    // nested enums

    static_cast<py::class_<BRepLProp , shared_ptr<BRepLProp>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const BRepAdaptor_Curve & ,   const BRepAdaptor_Curve & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<GeomAbs_Shape (*)(  const BRepAdaptor_Curve & ,   const BRepAdaptor_Curve & ,   const double ,   const double ,   const double ,   const double  ) >(&BRepLProp::Continuity),
                    R"#(Computes the regularity at the junction between C1 and C2. The point u1 on C1 and the point u2 on C2 must be confused. tl and ta are the linear and angular tolerance used two compare the derivative.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("u1"),  py::arg("u2"),  py::arg("tl"),  py::arg("ta")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const BRepAdaptor_Curve & ,   const BRepAdaptor_Curve & ,   const double ,   const double  ) ) static_cast<GeomAbs_Shape (*)(  const BRepAdaptor_Curve & ,   const BRepAdaptor_Curve & ,   const double ,   const double  ) >(&BRepLProp::Continuity),
                    R"#(The same as preceding but using the standard tolerances from package Precision.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("u1"),  py::arg("u2")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepLProp_SurfaceTool from ./opencascade/BRepLProp_SurfaceTool.hxx
    klass = m.attr("BRepLProp_SurfaceTool");

    // default constructor
    register_default_constructor<BRepLProp_SurfaceTool , shared_ptr<BRepLProp_SurfaceTool>>(m,"BRepLProp_SurfaceTool");

    // nested enums

    static_cast<py::class_<BRepLProp_SurfaceTool , shared_ptr<BRepLProp_SurfaceTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Value_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) >(&BRepLProp_SurfaceTool::Value),
                    R"#(Computes the point <P> of parameter <U> and <V> on the Surface <S>.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&BRepLProp_SurfaceTool::D1),
                    R"#(Computes the point <P> and first derivative <D1*> of parameter <U> and <V> on the Surface <S>.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V")
          )
        .def_static("D2_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&BRepLProp_SurfaceTool::D2),
                    R"#(Computes the point <P>, the first derivative <D1*> and second derivative <D2*> of parameter <U> and <V> on the Surface <S>.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("DUV")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) ) static_cast<gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) >(&BRepLProp_SurfaceTool::DN),
                    R"#()#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("IU"),  py::arg("IV")
          )
        .def_static("Continuity_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&BRepLProp_SurfaceTool::Continuity),
                    R"#(returns the order of continuity of the Surface <S>. returns 1 : first derivative only is computable returns 2 : first and second derivative only are computable.)#"  , py::arg("S")
          )
    // static methods using call by reference i.s.o. return
        .def_static("Bounds_s",
            []( const BRepAdaptor_Surface & S ){
                double  U1;
                double  V1;
                double  U2;
                double  V2;

                BRepLProp_SurfaceTool::Bounds(S,U1,V1,U2,V2);
                
return std::make_tuple(U1,V1,U2,V2); },
            R"#(returns the bounds of the Surface.)#"  , py::arg("S")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/BRepLProp.hxx
// ./opencascade/BRepLProp_CLProps.hxx
// ./opencascade/BRepLProp_SLProps.hxx
// ./opencascade/BRepLProp_SurfaceTool.hxx

// Additional functions


// operators

// register typdefs
    register_template_GeomLProp_CLPropsBase<gp_Pnt, gp_Vec, gp_Dir, BRepAdaptor_Curve>(m,"BRepLProp_CLProps");
    register_template_GeomLProp_SLPropsBase<BRepAdaptor_Surface>(m,"BRepLProp_SLProps");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
