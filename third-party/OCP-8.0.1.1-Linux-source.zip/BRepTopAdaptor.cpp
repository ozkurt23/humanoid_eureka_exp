
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <BRepTopAdaptor_TopolTool.hxx>
#include <TopoDS_Face.hxx>

// module includes
#include <BRepTopAdaptor_FClass2d.hxx>
#include <BRepTopAdaptor_HVertex.hxx>
#include <BRepTopAdaptor_Tool.hxx>
#include <BRepTopAdaptor_TopolTool.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepTopAdaptor(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BRepTopAdaptor"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BRepTopAdaptor_HVertex from ./opencascade/BRepTopAdaptor_HVertex.hxx
    klass = m.attr("BRepTopAdaptor_HVertex");


    // nested enums

    static_cast<py::class_<BRepTopAdaptor_HVertex ,opencascade::handle<BRepTopAdaptor_HVertex>  , Adaptor3d_HVertex >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Vertex &, const handle<BRepAdaptor_Curve2d> & >()  , py::arg("Vtx"),  py::arg("Curve") )
    // custom constructors
    // methods
        .def("Value",
             (gp_Pnt2d (BRepTopAdaptor_HVertex::*)() ) static_cast<gp_Pnt2d (BRepTopAdaptor_HVertex::*)() >(&BRepTopAdaptor_HVertex::Value),
             R"#()#" 
          )
        .def("Parameter",
             (double (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&BRepTopAdaptor_HVertex::Parameter),
             R"#()#"  , py::arg("C")
          )
        .def("Resolution",
             (double (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&BRepTopAdaptor_HVertex::Resolution),
             R"#(Parametric resolution (2d).)#"  , py::arg("C")
          )
        .def("Orientation",
             (TopAbs_Orientation (BRepTopAdaptor_HVertex::*)() ) static_cast<TopAbs_Orientation (BRepTopAdaptor_HVertex::*)() >(&BRepTopAdaptor_HVertex::Orientation),
             R"#()#" 
          )
        .def("IsSame",
             (bool (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor3d_HVertex> &  ) ) static_cast<bool (BRepTopAdaptor_HVertex::*)(  const handle<Adaptor3d_HVertex> &  ) >(&BRepTopAdaptor_HVertex::IsSame),
             R"#()#"  , py::arg("Other")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepTopAdaptor_HVertex::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepTopAdaptor_HVertex::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Vertex",
             ( const TopoDS_Vertex & (BRepTopAdaptor_HVertex::*)() const) static_cast< const TopoDS_Vertex & (BRepTopAdaptor_HVertex::*)() const>(&BRepTopAdaptor_HVertex::Vertex),
             R"#()#"
             
         )
       .def("ChangeVertex",
             (TopoDS_Vertex & (BRepTopAdaptor_HVertex::*)() ) static_cast<TopoDS_Vertex & (BRepTopAdaptor_HVertex::*)() >(&BRepTopAdaptor_HVertex::ChangeVertex),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepTopAdaptor_HVertex::*)() const) static_cast< const handle<Standard_Type> & (BRepTopAdaptor_HVertex::*)() const>(&BRepTopAdaptor_HVertex::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepTopAdaptor_Tool from ./opencascade/BRepTopAdaptor_Tool.hxx
    klass = m.attr("BRepTopAdaptor_Tool");


    // nested enums

    static_cast<py::class_<BRepTopAdaptor_Tool , shared_ptr<BRepTopAdaptor_Tool>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Face &, const double >()  , py::arg("F"),  py::arg("Tol2d") )
        .def(py::init<  const handle<Adaptor3d_Surface> &, const double >()  , py::arg("Surface"),  py::arg("Tol2d") )
    // custom constructors
    // methods
        .def("Init",
             (void (BRepTopAdaptor_Tool::*)(  const TopoDS_Face & ,   const double  ) ) static_cast<void (BRepTopAdaptor_Tool::*)(  const TopoDS_Face & ,   const double  ) >(&BRepTopAdaptor_Tool::Init),
             R"#()#"  , py::arg("F"),  py::arg("Tol2d")
          )
        .def("Init",
             (void (BRepTopAdaptor_Tool::*)(  const handle<Adaptor3d_Surface> & ,   const double  ) ) static_cast<void (BRepTopAdaptor_Tool::*)(  const handle<Adaptor3d_Surface> & ,   const double  ) >(&BRepTopAdaptor_Tool::Init),
             R"#()#"  , py::arg("Surface"),  py::arg("Tol2d")
          )
        .def("GetTopolTool",
             (handle<BRepTopAdaptor_TopolTool> (BRepTopAdaptor_Tool::*)() ) static_cast<handle<BRepTopAdaptor_TopolTool> (BRepTopAdaptor_Tool::*)() >(&BRepTopAdaptor_Tool::GetTopolTool),
             R"#()#" 
          )
        .def("SetTopolTool",
             (void (BRepTopAdaptor_Tool::*)(  const handle<BRepTopAdaptor_TopolTool> &  ) ) static_cast<void (BRepTopAdaptor_Tool::*)(  const handle<BRepTopAdaptor_TopolTool> &  ) >(&BRepTopAdaptor_Tool::SetTopolTool),
             R"#()#"  , py::arg("TT")
          )
        .def("GetSurface",
             (handle<Adaptor3d_Surface> (BRepTopAdaptor_Tool::*)() ) static_cast<handle<Adaptor3d_Surface> (BRepTopAdaptor_Tool::*)() >(&BRepTopAdaptor_Tool::GetSurface),
             R"#()#" 
          )
        .def("Destroy",
             (void (BRepTopAdaptor_Tool::*)() ) static_cast<void (BRepTopAdaptor_Tool::*)() >(&BRepTopAdaptor_Tool::Destroy),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepTopAdaptor_TopolTool from ./opencascade/BRepTopAdaptor_TopolTool.hxx
    klass = m.attr("BRepTopAdaptor_TopolTool");


    // nested enums

    static_cast<py::class_<BRepTopAdaptor_TopolTool ,opencascade::handle<BRepTopAdaptor_TopolTool>  , Adaptor3d_TopolTool >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Adaptor3d_Surface> & >()  , py::arg("Surface") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Initialize),
             R"#()#" 
          )
        .def("Initialize",
             (void (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_Surface> &  ) ) static_cast<void (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_Surface> &  ) >(&BRepTopAdaptor_TopolTool::Initialize),
             R"#()#"  , py::arg("S")
          )
        .def("Initialize",
             (void (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&BRepTopAdaptor_TopolTool::Initialize),
             R"#()#"  , py::arg("Curve")
          )
        .def("Init",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Init),
             R"#()#" 
          )
        .def("More",
             (bool (BRepTopAdaptor_TopolTool::*)() ) static_cast<bool (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::More),
             R"#()#" 
          )
        .def("Value",
             (handle<Adaptor2d_Curve2d> (BRepTopAdaptor_TopolTool::*)() ) static_cast<handle<Adaptor2d_Curve2d> (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Value),
             R"#()#" 
          )
        .def("Next",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Next),
             R"#()#" 
          )
        .def("Edge",
             (void * (BRepTopAdaptor_TopolTool::*)() const) static_cast<void * (BRepTopAdaptor_TopolTool::*)() const>(&BRepTopAdaptor_TopolTool::Edge),
             R"#()#" 
          )
        .def("InitVertexIterator",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::InitVertexIterator),
             R"#()#" 
          )
        .def("MoreVertex",
             (bool (BRepTopAdaptor_TopolTool::*)() ) static_cast<bool (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::MoreVertex),
             R"#()#" 
          )
        .def("Vertex",
             (handle<Adaptor3d_HVertex> (BRepTopAdaptor_TopolTool::*)() ) static_cast<handle<Adaptor3d_HVertex> (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Vertex),
             R"#()#" 
          )
        .def("NextVertex",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::NextVertex),
             R"#()#" 
          )
        .def("Classify",
             (TopAbs_State (BRepTopAdaptor_TopolTool::*)(  const gp_Pnt2d & ,   const double ,   const bool  ) ) static_cast<TopAbs_State (BRepTopAdaptor_TopolTool::*)(  const gp_Pnt2d & ,   const double ,   const bool  ) >(&BRepTopAdaptor_TopolTool::Classify),
             R"#()#"  , py::arg("P2d"),  py::arg("Tol"),  py::arg("RecadreOnPeriodic")=static_cast< const bool>(true)
          )
        .def("IsThePointOn",
             (bool (BRepTopAdaptor_TopolTool::*)(  const gp_Pnt2d & ,   const double ,   const bool  ) ) static_cast<bool (BRepTopAdaptor_TopolTool::*)(  const gp_Pnt2d & ,   const double ,   const bool  ) >(&BRepTopAdaptor_TopolTool::IsThePointOn),
             R"#(see the code for specifications))#"  , py::arg("P2d"),  py::arg("Tol"),  py::arg("RecadreOnPeriodic")=static_cast< const bool>(true)
          )
        .def("Orientation",
             (TopAbs_Orientation (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<TopAbs_Orientation (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&BRepTopAdaptor_TopolTool::Orientation),
             R"#(If the function returns the orientation of the arc. If the orientation is FORWARD or REVERSED, the arc is a "real" limit of the surface. If the orientation is INTERNAL or EXTERNAL, the arc is considered as an arc on the surface.)#"  , py::arg("C")
          )
        .def("Orientation",
             (TopAbs_Orientation (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) ) static_cast<TopAbs_Orientation (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) >(&BRepTopAdaptor_TopolTool::Orientation),
             R"#(If the function returns the orientation of the arc. If the orientation is FORWARD or REVERSED, the arc is a "real" limit of the surface. If the orientation is INTERNAL or EXTERNAL, the arc is considered as an arc on the surface.)#"  , py::arg("C")
          )
        .def("Destroy",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::Destroy),
             R"#()#" 
          )
        .def("Has3d",
             (bool (BRepTopAdaptor_TopolTool::*)() const) static_cast<bool (BRepTopAdaptor_TopolTool::*)() const>(&BRepTopAdaptor_TopolTool::Has3d),
             R"#(answers if arcs and vertices may have 3d representations, so that we could use Tol3d and Pnt methods.)#" 
          )
        .def("Tol3d",
             (double (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) const) static_cast<double (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor2d_Curve2d> &  ) const>(&BRepTopAdaptor_TopolTool::Tol3d),
             R"#(returns 3d tolerance of the arc C)#"  , py::arg("C")
          )
        .def("Tol3d",
             (double (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) const) static_cast<double (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) const>(&BRepTopAdaptor_TopolTool::Tol3d),
             R"#(returns 3d tolerance of the vertex V)#"  , py::arg("V")
          )
        .def("Pnt",
             (gp_Pnt (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) const) static_cast<gp_Pnt (BRepTopAdaptor_TopolTool::*)(  const handle<Adaptor3d_HVertex> &  ) const>(&BRepTopAdaptor_TopolTool::Pnt),
             R"#(returns 3d point of the vertex V)#"  , py::arg("V")
          )
        .def("ComputeSamplePoints",
             (void (BRepTopAdaptor_TopolTool::*)() ) static_cast<void (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::ComputeSamplePoints),
             R"#()#" 
          )
        .def("NbSamplesU",
             (int (BRepTopAdaptor_TopolTool::*)() ) static_cast<int (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::NbSamplesU),
             R"#(compute the sample-points for the intersections algorithms)#" 
          )
        .def("NbSamplesV",
             (int (BRepTopAdaptor_TopolTool::*)() ) static_cast<int (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::NbSamplesV),
             R"#(compute the sample-points for the intersections algorithms)#" 
          )
        .def("NbSamples",
             (int (BRepTopAdaptor_TopolTool::*)() ) static_cast<int (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::NbSamples),
             R"#(compute the sample-points for the intersections algorithms)#" 
          )
        .def("SamplePoint",
             (void (BRepTopAdaptor_TopolTool::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt &  ) ) static_cast<void (BRepTopAdaptor_TopolTool::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt &  ) >(&BRepTopAdaptor_TopolTool::SamplePoint),
             R"#()#"  , py::arg("Index"),  py::arg("P2d"),  py::arg("P3d")
          )
        .def("DomainIsInfinite",
             (bool (BRepTopAdaptor_TopolTool::*)() ) static_cast<bool (BRepTopAdaptor_TopolTool::*)() >(&BRepTopAdaptor_TopolTool::DomainIsInfinite),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepTopAdaptor_TopolTool::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepTopAdaptor_TopolTool::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepTopAdaptor_TopolTool::*)() const) static_cast< const handle<Standard_Type> & (BRepTopAdaptor_TopolTool::*)() const>(&BRepTopAdaptor_TopolTool::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BRepTopAdaptor_FClass2d.hxx
// ./opencascade/BRepTopAdaptor_HVertex.hxx
// ./opencascade/BRepTopAdaptor_Tool.hxx
// ./opencascade/BRepTopAdaptor_TopolTool.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
