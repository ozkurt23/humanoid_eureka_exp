
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAlgo_AsDes.hxx>
#include <TopoDS_Edge.hxx>
#include <Geom_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Geom2d_Curve.hxx>
#include <BRepOffset_Inter3d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Vertex.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>

// module includes
#include <BiTgte_Blend.hxx>
#include <BiTgte_ContactType.hxx>
#include <BiTgte_CurveOnEdge.hxx>
#include <BiTgte_CurveOnVertex.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BiTgte(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BiTgte"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BiTgte_Blend from ./opencascade/BiTgte_Blend.hxx
    klass = m.attr("BiTgte_Blend");


    // nested enums

    static_cast<py::class_<BiTgte_Blend , shared_ptr<BiTgte_Blend>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Shape &, const double, const double, const bool >()  , py::arg("S"),  py::arg("Radius"),  py::arg("Tol"),  py::arg("NUBS") )
    // custom constructors
    // methods
        .def("Init",
             (void (BiTgte_Blend::*)(  const TopoDS_Shape & ,   const double ,   const double ,   const bool  ) ) static_cast<void (BiTgte_Blend::*)(  const TopoDS_Shape & ,   const double ,   const double ,   const bool  ) >(&BiTgte_Blend::Init),
             R"#()#"  , py::arg("S"),  py::arg("Radius"),  py::arg("Tol"),  py::arg("NUBS")
          )
        .def("Clear",
             (void (BiTgte_Blend::*)() ) static_cast<void (BiTgte_Blend::*)() >(&BiTgte_Blend::Clear),
             R"#(Clear all the Fields.)#" 
          )
        .def("SetFaces",
             (void (BiTgte_Blend::*)(  const TopoDS_Face & ,   const TopoDS_Face &  ) ) static_cast<void (BiTgte_Blend::*)(  const TopoDS_Face & ,   const TopoDS_Face &  ) >(&BiTgte_Blend::SetFaces),
             R"#(Set two faces of <myShape> on which the Sphere must roll.)#"  , py::arg("F1"),  py::arg("F2")
          )
        .def("SetEdge",
             (void (BiTgte_Blend::*)(  const TopoDS_Edge &  ) ) static_cast<void (BiTgte_Blend::*)(  const TopoDS_Edge &  ) >(&BiTgte_Blend::SetEdge),
             R"#(Set an edge of <myShape> to be rounded.)#"  , py::arg("Edge")
          )
        .def("SetStoppingFace",
             (void (BiTgte_Blend::*)(  const TopoDS_Face &  ) ) static_cast<void (BiTgte_Blend::*)(  const TopoDS_Face &  ) >(&BiTgte_Blend::SetStoppingFace),
             R"#(Set a face on which the fillet must stop.)#"  , py::arg("Face")
          )
        .def("Perform",
             (void (BiTgte_Blend::*)(  const bool  ) ) static_cast<void (BiTgte_Blend::*)(  const bool  ) >(&BiTgte_Blend::Perform),
             R"#(Compute the generated surfaces. If <BuildShape> is true, compute the resulting Shape. If false, only the blending surfaces are computed.)#"  , py::arg("BuildShape")=static_cast< const bool>(true)
          )
        .def("IsDone",
             (bool (BiTgte_Blend::*)() const) static_cast<bool (BiTgte_Blend::*)() const>(&BiTgte_Blend::IsDone),
             R"#()#" 
          )
        .def("NbSurfaces",
             (int (BiTgte_Blend::*)() const) static_cast<int (BiTgte_Blend::*)() const>(&BiTgte_Blend::NbSurfaces),
             R"#(returns the Number of generated surfaces.)#" 
          )
        .def("Surface",
             (handle<Geom_Surface> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom_Surface> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::Surface),
             R"#(returns the surface of range Index)#"  , py::arg("Index")
          )
        .def("Face",
             ( const TopoDS_Face & (BiTgte_Blend::*)(  const int  ) const) static_cast< const TopoDS_Face & (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::Face),
             R"#(returns the surface of range Index)#"  , py::arg("Index")
          )
        .def("CenterLines",
             (void (BiTgte_Blend::*)( NCollection_List<TopoDS_Shape> &  ) const) static_cast<void (BiTgte_Blend::*)( NCollection_List<TopoDS_Shape> &  ) const>(&BiTgte_Blend::CenterLines),
             R"#(set in <LC> all the center lines)#"  , py::arg("LC")
          )
        .def("Surface",
             (handle<Geom_Surface> (BiTgte_Blend::*)(  const TopoDS_Shape &  ) const) static_cast<handle<Geom_Surface> (BiTgte_Blend::*)(  const TopoDS_Shape &  ) const>(&BiTgte_Blend::Surface),
             R"#(returns the surface generated by the centerline. <CenterLine> may be - an edge : generate a pipe. - a vertex : generate a sphere. Warning: returns a Null Handle if <CenterLine> generates no surface.)#"  , py::arg("CenterLine")
          )
        .def("Face",
             ( const TopoDS_Face & (BiTgte_Blend::*)(  const TopoDS_Shape &  ) const) static_cast< const TopoDS_Face & (BiTgte_Blend::*)(  const TopoDS_Shape &  ) const>(&BiTgte_Blend::Face),
             R"#(returns the face generated by the centerline. <CenterLine> may be - an edge : generate a pipe. - a vertex : generate a sphere. Warning: returns a Null Shape if <CenterLine> generates no surface.)#"  , py::arg("CenterLine")
          )
        .def("ContactType",
             (BiTgte_ContactType (BiTgte_Blend::*)(  const int  ) const) static_cast<BiTgte_ContactType (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::ContactType),
             R"#(returns the type of contact)#"  , py::arg("Index")
          )
        .def("SupportShape1",
             ( const TopoDS_Shape & (BiTgte_Blend::*)(  const int  ) const) static_cast< const TopoDS_Shape & (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::SupportShape1),
             R"#(gives the first support shape relative to SurfaceFillet(Index);)#"  , py::arg("Index")
          )
        .def("SupportShape2",
             ( const TopoDS_Shape & (BiTgte_Blend::*)(  const int  ) const) static_cast< const TopoDS_Shape & (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::SupportShape2),
             R"#(gives the second support shape relative to SurfaceFillet(Index);)#"  , py::arg("Index")
          )
        .def("CurveOnShape1",
             (handle<Geom_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::CurveOnShape1),
             R"#(gives the 3d curve of SurfaceFillet(Index) on SupportShape1(Index))#"  , py::arg("Index")
          )
        .def("CurveOnShape2",
             (handle<Geom_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::CurveOnShape2),
             R"#(gives the 3d curve of SurfaceFillet(Index) on SupportShape2(Index))#"  , py::arg("Index")
          )
        .def("PCurveOnFace1",
             (handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::PCurveOnFace1),
             R"#(gives the PCurve associated to CurvOnShape1(Index) on the support face Warning: returns a Null Handle if SupportShape1 is not a Face)#"  , py::arg("Index")
          )
        .def("PCurve1OnFillet",
             (handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::PCurve1OnFillet),
             R"#(gives the PCurve associated to CurveOnShape1(Index) on the Fillet)#"  , py::arg("Index")
          )
        .def("PCurveOnFace2",
             (handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::PCurveOnFace2),
             R"#(gives the PCurve associated to CurveOnShape2(Index) on the support face Warning: returns a Null Handle if SupportShape2 is not a Face)#"  , py::arg("Index")
          )
        .def("PCurve2OnFillet",
             (handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const) static_cast<handle<Geom2d_Curve> (BiTgte_Blend::*)(  const int  ) const>(&BiTgte_Blend::PCurve2OnFillet),
             R"#(gives the PCurve associated to CurveOnShape2(Index) on the fillet)#"  , py::arg("Index")
          )
        .def("NbBranches",
             (int (BiTgte_Blend::*)() ) static_cast<int (BiTgte_Blend::*)() >(&BiTgte_Blend::NbBranches),
             R"#()#" 
          )
        .def("ComputeCenters",
             (void (BiTgte_Blend::*)() ) static_cast<void (BiTgte_Blend::*)() >(&BiTgte_Blend::ComputeCenters),
             R"#(Computes the center lines)#" 
          )
    // methods using call by reference i.s.o. return
        .def("IndicesOfBranche",
             []( BiTgte_Blend &self ,  const int Index ){
                 int  From;
                int  To;

                 self.IndicesOfBranche(Index,From,To);
                 return std::make_tuple(From,To); },
             R"#(Set in <From>,<To> the indices of the faces of the branche <Index>.)#"  , py::arg("Index")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const TopoDS_Shape & (BiTgte_Blend::*)() const) static_cast< const TopoDS_Shape & (BiTgte_Blend::*)() const>(&BiTgte_Blend::Shape),
             R"#(returns the result)#"
             
         )
;

    // Class BiTgte_CurveOnEdge from ./opencascade/BiTgte_CurveOnEdge.hxx
    klass = m.attr("BiTgte_CurveOnEdge");


    // nested enums

    static_cast<py::class_<BiTgte_CurveOnEdge ,opencascade::handle<BiTgte_CurveOnEdge>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Edge &, const TopoDS_Edge & >()  , py::arg("EonF"),  py::arg("Edge") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (BiTgte_CurveOnEdge::*)() const) static_cast<handle<Adaptor3d_Curve> (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Init",
             (void (BiTgte_CurveOnEdge::*)(  const TopoDS_Edge & ,   const TopoDS_Edge &  ) ) static_cast<void (BiTgte_CurveOnEdge::*)(  const TopoDS_Edge & ,   const TopoDS_Edge &  ) >(&BiTgte_CurveOnEdge::Init),
             R"#()#"  , py::arg("EonF"),  py::arg("Edge")
          )
        .def("FirstParameter",
             (double (BiTgte_CurveOnEdge::*)() const) static_cast<double (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (BiTgte_CurveOnEdge::*)() const) static_cast<double (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (BiTgte_CurveOnEdge::*)() const) static_cast<GeomAbs_Shape (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (BiTgte_CurveOnEdge::*)(  const GeomAbs_Shape  ) const) static_cast<int (BiTgte_CurveOnEdge::*)(  const GeomAbs_Shape  ) const>(&BiTgte_CurveOnEdge::NbIntervals),
             R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (BiTgte_CurveOnEdge::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (BiTgte_CurveOnEdge::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&BiTgte_CurveOnEdge::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (BiTgte_CurveOnEdge::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (BiTgte_CurveOnEdge::*)(  const double ,   const double ,   const double  ) const>(&BiTgte_CurveOnEdge::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsClosed",
             (bool (BiTgte_CurveOnEdge::*)() const) static_cast<bool (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (BiTgte_CurveOnEdge::*)() const) static_cast<bool (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (BiTgte_CurveOnEdge::*)() const) static_cast<double (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Period),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (BiTgte_CurveOnEdge::*)(  const double  ) const) static_cast<gp_Pnt (BiTgte_CurveOnEdge::*)(  const double  ) const>(&BiTgte_CurveOnEdge::EvalD0),
             R"#(Computes the point of parameter theU on the curve.)#"  , py::arg("theU")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (BiTgte_CurveOnEdge::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (BiTgte_CurveOnEdge::*)(  const double  ) const>(&BiTgte_CurveOnEdge::EvalD1),
             R"#(Computes the point and first derivative at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (BiTgte_CurveOnEdge::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (BiTgte_CurveOnEdge::*)(  const double  ) const>(&BiTgte_CurveOnEdge::EvalD2),
             R"#(Computes the point and first two derivatives at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (BiTgte_CurveOnEdge::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (BiTgte_CurveOnEdge::*)(  const double  ) const>(&BiTgte_CurveOnEdge::EvalD3),
             R"#(Computes the point and first three derivatives at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalDN",
             (gp_Vec (BiTgte_CurveOnEdge::*)(  const double ,   const int  ) const) static_cast<gp_Vec (BiTgte_CurveOnEdge::*)(  const double ,   const int  ) const>(&BiTgte_CurveOnEdge::EvalDN),
             R"#(Returns the derivative of order theN at parameter theU.)#"  , py::arg("theU"),  py::arg("theN")
          )
        .def("Resolution",
             (double (BiTgte_CurveOnEdge::*)(  const double  ) const) static_cast<double (BiTgte_CurveOnEdge::*)(  const double  ) const>(&BiTgte_CurveOnEdge::Resolution),
             R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (BiTgte_CurveOnEdge::*)() const) static_cast<GeomAbs_CurveType (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::GetType),
             R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#" 
          )
        .def("Line",
             (gp_Lin (BiTgte_CurveOnEdge::*)() const) static_cast<gp_Lin (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (BiTgte_CurveOnEdge::*)() const) static_cast<gp_Circ (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (BiTgte_CurveOnEdge::*)() const) static_cast<gp_Elips (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (BiTgte_CurveOnEdge::*)() const) static_cast<gp_Hypr (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (BiTgte_CurveOnEdge::*)() const) static_cast<gp_Parab (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Parabola),
             R"#()#" 
          )
        .def("Degree",
             (int (BiTgte_CurveOnEdge::*)() const) static_cast<int (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Degree),
             R"#()#" 
          )
        .def("IsRational",
             (bool (BiTgte_CurveOnEdge::*)() const) static_cast<bool (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::IsRational),
             R"#()#" 
          )
        .def("NbPoles",
             (int (BiTgte_CurveOnEdge::*)() const) static_cast<int (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::NbPoles),
             R"#()#" 
          )
        .def("NbKnots",
             (int (BiTgte_CurveOnEdge::*)() const) static_cast<int (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::NbKnots),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (BiTgte_CurveOnEdge::*)() const) static_cast<handle<Geom_BezierCurve> (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (BiTgte_CurveOnEdge::*)() const) static_cast<handle<Geom_BSplineCurve> (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::BSpline),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BiTgte_CurveOnEdge::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BiTgte_CurveOnEdge::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BiTgte_CurveOnEdge::*)() const) static_cast< const handle<Standard_Type> & (BiTgte_CurveOnEdge::*)() const>(&BiTgte_CurveOnEdge::DynamicType),
             R"#()#"
             
         )
;

    // Class BiTgte_CurveOnVertex from ./opencascade/BiTgte_CurveOnVertex.hxx
    klass = m.attr("BiTgte_CurveOnVertex");


    // nested enums

    static_cast<py::class_<BiTgte_CurveOnVertex ,opencascade::handle<BiTgte_CurveOnVertex>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Edge &, const TopoDS_Vertex & >()  , py::arg("EonF"),  py::arg("V") )
    // custom constructors
    // methods
        .def("Init",
             (void (BiTgte_CurveOnVertex::*)(  const TopoDS_Edge & ,   const TopoDS_Vertex &  ) ) static_cast<void (BiTgte_CurveOnVertex::*)(  const TopoDS_Edge & ,   const TopoDS_Vertex &  ) >(&BiTgte_CurveOnVertex::Init),
             R"#()#"  , py::arg("EonF"),  py::arg("V")
          )
        .def("FirstParameter",
             (double (BiTgte_CurveOnVertex::*)() const) static_cast<double (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (BiTgte_CurveOnVertex::*)() const) static_cast<double (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (BiTgte_CurveOnVertex::*)() const) static_cast<GeomAbs_Shape (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (BiTgte_CurveOnVertex::*)(  const GeomAbs_Shape  ) const) static_cast<int (BiTgte_CurveOnVertex::*)(  const GeomAbs_Shape  ) const>(&BiTgte_CurveOnVertex::NbIntervals),
             R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (BiTgte_CurveOnVertex::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (BiTgte_CurveOnVertex::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&BiTgte_CurveOnVertex::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (BiTgte_CurveOnVertex::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (BiTgte_CurveOnVertex::*)(  const double ,   const double ,   const double  ) const>(&BiTgte_CurveOnVertex::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsClosed",
             (bool (BiTgte_CurveOnVertex::*)() const) static_cast<bool (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (BiTgte_CurveOnVertex::*)() const) static_cast<bool (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (BiTgte_CurveOnVertex::*)() const) static_cast<double (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Period),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (BiTgte_CurveOnVertex::*)(  const double  ) const) static_cast<gp_Pnt (BiTgte_CurveOnVertex::*)(  const double  ) const>(&BiTgte_CurveOnVertex::EvalD0),
             R"#(Computes the point of parameter theU on the curve.)#"  , py::arg("theU")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (BiTgte_CurveOnVertex::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (BiTgte_CurveOnVertex::*)(  const double  ) const>(&BiTgte_CurveOnVertex::EvalD1),
             R"#(Computes the point and first derivative at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (BiTgte_CurveOnVertex::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (BiTgte_CurveOnVertex::*)(  const double  ) const>(&BiTgte_CurveOnVertex::EvalD2),
             R"#(Computes the point and first two derivatives at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (BiTgte_CurveOnVertex::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (BiTgte_CurveOnVertex::*)(  const double  ) const>(&BiTgte_CurveOnVertex::EvalD3),
             R"#(Computes the point and first three derivatives at parameter theU.)#"  , py::arg("theU")
          )
        .def("EvalDN",
             (gp_Vec (BiTgte_CurveOnVertex::*)(  const double ,   const int  ) const) static_cast<gp_Vec (BiTgte_CurveOnVertex::*)(  const double ,   const int  ) const>(&BiTgte_CurveOnVertex::EvalDN),
             R"#(Returns the derivative of order theN at parameter theU.)#"  , py::arg("theU"),  py::arg("theN")
          )
        .def("Resolution",
             (double (BiTgte_CurveOnVertex::*)(  const double  ) const) static_cast<double (BiTgte_CurveOnVertex::*)(  const double  ) const>(&BiTgte_CurveOnVertex::Resolution),
             R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (BiTgte_CurveOnVertex::*)() const) static_cast<GeomAbs_CurveType (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::GetType),
             R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#" 
          )
        .def("Line",
             (gp_Lin (BiTgte_CurveOnVertex::*)() const) static_cast<gp_Lin (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (BiTgte_CurveOnVertex::*)() const) static_cast<gp_Circ (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (BiTgte_CurveOnVertex::*)() const) static_cast<gp_Elips (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (BiTgte_CurveOnVertex::*)() const) static_cast<gp_Hypr (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (BiTgte_CurveOnVertex::*)() const) static_cast<gp_Parab (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Parabola),
             R"#()#" 
          )
        .def("Degree",
             (int (BiTgte_CurveOnVertex::*)() const) static_cast<int (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Degree),
             R"#()#" 
          )
        .def("IsRational",
             (bool (BiTgte_CurveOnVertex::*)() const) static_cast<bool (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::IsRational),
             R"#()#" 
          )
        .def("NbPoles",
             (int (BiTgte_CurveOnVertex::*)() const) static_cast<int (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::NbPoles),
             R"#()#" 
          )
        .def("NbKnots",
             (int (BiTgte_CurveOnVertex::*)() const) static_cast<int (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::NbKnots),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (BiTgte_CurveOnVertex::*)() const) static_cast<handle<Geom_BezierCurve> (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (BiTgte_CurveOnVertex::*)() const) static_cast<handle<Geom_BSplineCurve> (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::BSpline),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BiTgte_CurveOnVertex::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BiTgte_CurveOnVertex::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BiTgte_CurveOnVertex::*)() const) static_cast< const handle<Standard_Type> & (BiTgte_CurveOnVertex::*)() const>(&BiTgte_CurveOnVertex::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BiTgte_Blend.hxx
// ./opencascade/BiTgte_ContactType.hxx
// ./opencascade/BiTgte_CurveOnEdge.hxx
// ./opencascade/BiTgte_CurveOnVertex.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
