
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinMDF_ADriverTable.hxx>
#include <Message_Messenger.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>

// module includes
#include <BinMDF.hxx>
#include <BinMDF_ADriver.hxx>
#include <BinMDF_ADriverTable.hxx>
#include <BinMDF_DerivedDriver.hxx>
#include <BinMDF_ReferenceDriver.hxx>
#include <BinMDF_TagSourceDriver.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BinMDF_enums(py::module &main_module) {


py::module m = main_module.def_submodule("BinMDF", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes
    class Py_BinMDF_ADriver : public BinMDF_ADriver{
    public:
        using BinMDF_ADriver::BinMDF_ADriver;


        // public pure virtual
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,BinMDF_ADriver,NewEmpty,) };
        bool Paste( const BinObjMgt_Persistent & aSource, const handle<TDF_Attribute> & aTarget,BinObjMgt_RRelocationTable & aRelocTable) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,BinMDF_ADriver,Paste,aSource,aTarget,aRelocTable) };
        void Paste( const handle<TDF_Attribute> & aSource,BinObjMgt_Persistent & aTarget,NCollection_IndexedMap<handle<Standard_Transient>> & aRelocTable) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BinMDF_ADriver,Paste,aSource,aTarget,aRelocTable) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<BinMDF , shared_ptr<BinMDF>  >(
      m,
      "BinMDF",R"#(This package provides classes and methods to translate a transient DF into a persistent one and vice versa.)#"
    );
    py::class_<BinMDF_ADriver ,opencascade::handle<BinMDF_ADriver> ,Py_BinMDF_ADriver , Standard_Transient >(
      m,
      "BinMDF_ADriver",R"#(Attribute Storage/Retrieval Driver.)#"
    );
    py::class_<BinMDF_ADriverTable ,opencascade::handle<BinMDF_ADriverTable>  , Standard_Transient >(
      m,
      "BinMDF_ADriverTable",R"#(A driver table is an object building links between object types and object drivers. In the translation process, a driver table is asked to give a translation driver for each current object to be translated.)#"
    );
    py::class_<BinMDF_DerivedDriver ,opencascade::handle<BinMDF_DerivedDriver>  , BinMDF_ADriver >(
      m,
      "BinMDF_DerivedDriver",R"#(A universal driver for the attribute that inherits another attribute with ready to used persistence mechanism implemented (already has a driver to store/retrieve).)#"
    );
    py::class_<BinMDF_ReferenceDriver ,opencascade::handle<BinMDF_ReferenceDriver>  , BinMDF_ADriver >(
      m,
      "BinMDF_ReferenceDriver",R"#(Reference attribute Driver.)#"
    );
    py::class_<BinMDF_TagSourceDriver ,opencascade::handle<BinMDF_TagSourceDriver>  , BinMDF_ADriver >(
      m,
      "BinMDF_TagSourceDriver",R"#(TDF_TagSource Driver.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
