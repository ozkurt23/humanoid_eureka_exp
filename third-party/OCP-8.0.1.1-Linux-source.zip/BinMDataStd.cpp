
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinMDF_ADriverTable.hxx>
#include <Message_Messenger.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BinObjMgt_Persistent.hxx>

// module includes
#include <BinMDataStd.hxx>
#include <BinMDataStd_AsciiStringDriver.hxx>
#include <BinMDataStd_BooleanArrayDriver.hxx>
#include <BinMDataStd_BooleanListDriver.hxx>
#include <BinMDataStd_ByteArrayDriver.hxx>
#include <BinMDataStd_ExpressionDriver.hxx>
#include <BinMDataStd_ExtStringArrayDriver.hxx>
#include <BinMDataStd_ExtStringListDriver.hxx>
#include <BinMDataStd_GenericEmptyDriver.hxx>
#include <BinMDataStd_GenericExtStringDriver.hxx>
#include <BinMDataStd_IntegerArrayDriver.hxx>
#include <BinMDataStd_IntegerDriver.hxx>
#include <BinMDataStd_IntegerListDriver.hxx>
#include <BinMDataStd_IntPackedMapDriver.hxx>
#include <BinMDataStd_NamedDataDriver.hxx>
#include <BinMDataStd_RealArrayDriver.hxx>
#include <BinMDataStd_RealDriver.hxx>
#include <BinMDataStd_RealListDriver.hxx>
#include <BinMDataStd_ReferenceArrayDriver.hxx>
#include <BinMDataStd_ReferenceListDriver.hxx>
#include <BinMDataStd_TreeNodeDriver.hxx>
#include <BinMDataStd_UAttributeDriver.hxx>
#include <BinMDataStd_VariableDriver.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BinMDataStd(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BinMDataStd"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BinMDataStd from ./opencascade/BinMDataStd.hxx
    klass = m.attr("BinMDataStd");

    // default constructor
    register_default_constructor<BinMDataStd , shared_ptr<BinMDataStd>>(m,"BinMDataStd");

    // nested enums

    static_cast<py::class_<BinMDataStd , shared_ptr<BinMDataStd>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("AddDrivers_s",
                    (void (*)(  const handle<BinMDF_ADriverTable> & ,   const handle<Message_Messenger> &  ) ) static_cast<void (*)(  const handle<BinMDF_ADriverTable> & ,   const handle<Message_Messenger> &  ) >(&BinMDataStd::AddDrivers),
                    R"#(Adds the attribute drivers to <theDriverTable>.)#"  , py::arg("theDriverTable"),  py::arg("aMsgDrv")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BinMDataStd_AsciiStringDriver from ./opencascade/BinMDataStd_AsciiStringDriver.hxx
    klass = m.attr("BinMDataStd_AsciiStringDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_AsciiStringDriver ,opencascade::handle<BinMDataStd_AsciiStringDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_AsciiStringDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_AsciiStringDriver::*)() const>(&BinMDataStd_AsciiStringDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_AsciiStringDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_AsciiStringDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_AsciiStringDriver::Paste),
             R"#(persistent -> transient (retrieve))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_AsciiStringDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_AsciiStringDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_AsciiStringDriver::Paste),
             R"#(transient -> persistent (store))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_AsciiStringDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_AsciiStringDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_AsciiStringDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_AsciiStringDriver::*)() const>(&BinMDataStd_AsciiStringDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_BooleanArrayDriver from ./opencascade/BinMDataStd_BooleanArrayDriver.hxx
    klass = m.attr("BinMDataStd_BooleanArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_BooleanArrayDriver ,opencascade::handle<BinMDataStd_BooleanArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_BooleanArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_BooleanArrayDriver::*)() const>(&BinMDataStd_BooleanArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_BooleanArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_BooleanArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_BooleanArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_BooleanArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_BooleanArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_BooleanArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_BooleanArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_BooleanArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_BooleanArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_BooleanArrayDriver::*)() const>(&BinMDataStd_BooleanArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_BooleanListDriver from ./opencascade/BinMDataStd_BooleanListDriver.hxx
    klass = m.attr("BinMDataStd_BooleanListDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_BooleanListDriver ,opencascade::handle<BinMDataStd_BooleanListDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_BooleanListDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_BooleanListDriver::*)() const>(&BinMDataStd_BooleanListDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_BooleanListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_BooleanListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_BooleanListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_BooleanListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_BooleanListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_BooleanListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_BooleanListDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_BooleanListDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_BooleanListDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_BooleanListDriver::*)() const>(&BinMDataStd_BooleanListDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ByteArrayDriver from ./opencascade/BinMDataStd_ByteArrayDriver.hxx
    klass = m.attr("BinMDataStd_ByteArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ByteArrayDriver ,opencascade::handle<BinMDataStd_ByteArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ByteArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ByteArrayDriver::*)() const>(&BinMDataStd_ByteArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ByteArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ByteArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ByteArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ByteArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ByteArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ByteArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ByteArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ByteArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ByteArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ByteArrayDriver::*)() const>(&BinMDataStd_ByteArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ExpressionDriver from ./opencascade/BinMDataStd_ExpressionDriver.hxx
    klass = m.attr("BinMDataStd_ExpressionDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ExpressionDriver ,opencascade::handle<BinMDataStd_ExpressionDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ExpressionDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ExpressionDriver::*)() const>(&BinMDataStd_ExpressionDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ExpressionDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ExpressionDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ExpressionDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ExpressionDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ExpressionDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ExpressionDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ExpressionDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ExpressionDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ExpressionDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ExpressionDriver::*)() const>(&BinMDataStd_ExpressionDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ExtStringArrayDriver from ./opencascade/BinMDataStd_ExtStringArrayDriver.hxx
    klass = m.attr("BinMDataStd_ExtStringArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ExtStringArrayDriver ,opencascade::handle<BinMDataStd_ExtStringArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ExtStringArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ExtStringArrayDriver::*)() const>(&BinMDataStd_ExtStringArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ExtStringArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ExtStringArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ExtStringArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ExtStringArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ExtStringArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ExtStringArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ExtStringArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ExtStringArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ExtStringArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ExtStringArrayDriver::*)() const>(&BinMDataStd_ExtStringArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ExtStringListDriver from ./opencascade/BinMDataStd_ExtStringListDriver.hxx
    klass = m.attr("BinMDataStd_ExtStringListDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ExtStringListDriver ,opencascade::handle<BinMDataStd_ExtStringListDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ExtStringListDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ExtStringListDriver::*)() const>(&BinMDataStd_ExtStringListDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ExtStringListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ExtStringListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ExtStringListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ExtStringListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ExtStringListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ExtStringListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ExtStringListDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ExtStringListDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ExtStringListDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ExtStringListDriver::*)() const>(&BinMDataStd_ExtStringListDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_GenericEmptyDriver from ./opencascade/BinMDataStd_GenericEmptyDriver.hxx
    klass = m.attr("BinMDataStd_GenericEmptyDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_GenericEmptyDriver ,opencascade::handle<BinMDataStd_GenericEmptyDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_GenericEmptyDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_GenericEmptyDriver::*)() const>(&BinMDataStd_GenericEmptyDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_GenericEmptyDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_GenericEmptyDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_GenericEmptyDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_GenericEmptyDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_GenericEmptyDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_GenericEmptyDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_GenericEmptyDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_GenericEmptyDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SourceType",
             ( const handle<Standard_Type> & (BinMDataStd_GenericEmptyDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_GenericEmptyDriver::*)() const>(&BinMDataStd_GenericEmptyDriver::SourceType),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_GenericEmptyDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_GenericEmptyDriver::*)() const>(&BinMDataStd_GenericEmptyDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_GenericExtStringDriver from ./opencascade/BinMDataStd_GenericExtStringDriver.hxx
    klass = m.attr("BinMDataStd_GenericExtStringDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_GenericExtStringDriver ,opencascade::handle<BinMDataStd_GenericExtStringDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_GenericExtStringDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_GenericExtStringDriver::*)() const>(&BinMDataStd_GenericExtStringDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_GenericExtStringDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_GenericExtStringDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_GenericExtStringDriver::Paste),
             R"#(persistent -> transient (retrieve))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_GenericExtStringDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_GenericExtStringDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_GenericExtStringDriver::Paste),
             R"#(transient -> persistent (store))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_GenericExtStringDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_GenericExtStringDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SourceType",
             ( const handle<Standard_Type> & (BinMDataStd_GenericExtStringDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_GenericExtStringDriver::*)() const>(&BinMDataStd_GenericExtStringDriver::SourceType),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_GenericExtStringDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_GenericExtStringDriver::*)() const>(&BinMDataStd_GenericExtStringDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_IntPackedMapDriver from ./opencascade/BinMDataStd_IntPackedMapDriver.hxx
    klass = m.attr("BinMDataStd_IntPackedMapDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_IntPackedMapDriver ,opencascade::handle<BinMDataStd_IntPackedMapDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_IntPackedMapDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_IntPackedMapDriver::*)() const>(&BinMDataStd_IntPackedMapDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_IntPackedMapDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_IntPackedMapDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_IntPackedMapDriver::Paste),
             R"#(persistent -> transient (retrieve))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_IntPackedMapDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_IntPackedMapDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_IntPackedMapDriver::Paste),
             R"#(transient -> persistent (store))#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_IntPackedMapDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_IntPackedMapDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_IntPackedMapDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_IntPackedMapDriver::*)() const>(&BinMDataStd_IntPackedMapDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_IntegerArrayDriver from ./opencascade/BinMDataStd_IntegerArrayDriver.hxx
    klass = m.attr("BinMDataStd_IntegerArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_IntegerArrayDriver ,opencascade::handle<BinMDataStd_IntegerArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_IntegerArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_IntegerArrayDriver::*)() const>(&BinMDataStd_IntegerArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_IntegerArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_IntegerArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_IntegerArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_IntegerArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_IntegerArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_IntegerArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_IntegerArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_IntegerArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_IntegerArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_IntegerArrayDriver::*)() const>(&BinMDataStd_IntegerArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_IntegerDriver from ./opencascade/BinMDataStd_IntegerDriver.hxx
    klass = m.attr("BinMDataStd_IntegerDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_IntegerDriver ,opencascade::handle<BinMDataStd_IntegerDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_IntegerDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_IntegerDriver::*)() const>(&BinMDataStd_IntegerDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_IntegerDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_IntegerDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_IntegerDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_IntegerDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_IntegerDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_IntegerDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_IntegerDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_IntegerDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_IntegerDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_IntegerDriver::*)() const>(&BinMDataStd_IntegerDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_IntegerListDriver from ./opencascade/BinMDataStd_IntegerListDriver.hxx
    klass = m.attr("BinMDataStd_IntegerListDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_IntegerListDriver ,opencascade::handle<BinMDataStd_IntegerListDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_IntegerListDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_IntegerListDriver::*)() const>(&BinMDataStd_IntegerListDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_IntegerListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_IntegerListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_IntegerListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_IntegerListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_IntegerListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_IntegerListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_IntegerListDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_IntegerListDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_IntegerListDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_IntegerListDriver::*)() const>(&BinMDataStd_IntegerListDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_NamedDataDriver from ./opencascade/BinMDataStd_NamedDataDriver.hxx
    klass = m.attr("BinMDataStd_NamedDataDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_NamedDataDriver ,opencascade::handle<BinMDataStd_NamedDataDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_NamedDataDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_NamedDataDriver::*)() const>(&BinMDataStd_NamedDataDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_NamedDataDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_NamedDataDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_NamedDataDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_NamedDataDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_NamedDataDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_NamedDataDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_NamedDataDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_NamedDataDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_NamedDataDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_NamedDataDriver::*)() const>(&BinMDataStd_NamedDataDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_RealArrayDriver from ./opencascade/BinMDataStd_RealArrayDriver.hxx
    klass = m.attr("BinMDataStd_RealArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_RealArrayDriver ,opencascade::handle<BinMDataStd_RealArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_RealArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_RealArrayDriver::*)() const>(&BinMDataStd_RealArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_RealArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_RealArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_RealArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_RealArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_RealArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_RealArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_RealArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_RealArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_RealArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_RealArrayDriver::*)() const>(&BinMDataStd_RealArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_RealDriver from ./opencascade/BinMDataStd_RealDriver.hxx
    klass = m.attr("BinMDataStd_RealDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_RealDriver ,opencascade::handle<BinMDataStd_RealDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_RealDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_RealDriver::*)() const>(&BinMDataStd_RealDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_RealDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_RealDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_RealDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_RealDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_RealDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_RealDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_RealDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_RealDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_RealDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_RealDriver::*)() const>(&BinMDataStd_RealDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_RealListDriver from ./opencascade/BinMDataStd_RealListDriver.hxx
    klass = m.attr("BinMDataStd_RealListDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_RealListDriver ,opencascade::handle<BinMDataStd_RealListDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_RealListDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_RealListDriver::*)() const>(&BinMDataStd_RealListDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_RealListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_RealListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_RealListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_RealListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_RealListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_RealListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_RealListDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_RealListDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_RealListDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_RealListDriver::*)() const>(&BinMDataStd_RealListDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ReferenceArrayDriver from ./opencascade/BinMDataStd_ReferenceArrayDriver.hxx
    klass = m.attr("BinMDataStd_ReferenceArrayDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ReferenceArrayDriver ,opencascade::handle<BinMDataStd_ReferenceArrayDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ReferenceArrayDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ReferenceArrayDriver::*)() const>(&BinMDataStd_ReferenceArrayDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ReferenceArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ReferenceArrayDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ReferenceArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ReferenceArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ReferenceArrayDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ReferenceArrayDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ReferenceArrayDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ReferenceArrayDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ReferenceArrayDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ReferenceArrayDriver::*)() const>(&BinMDataStd_ReferenceArrayDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_ReferenceListDriver from ./opencascade/BinMDataStd_ReferenceListDriver.hxx
    klass = m.attr("BinMDataStd_ReferenceListDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_ReferenceListDriver ,opencascade::handle<BinMDataStd_ReferenceListDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_ReferenceListDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_ReferenceListDriver::*)() const>(&BinMDataStd_ReferenceListDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_ReferenceListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_ReferenceListDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_ReferenceListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_ReferenceListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_ReferenceListDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_ReferenceListDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_ReferenceListDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_ReferenceListDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_ReferenceListDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_ReferenceListDriver::*)() const>(&BinMDataStd_ReferenceListDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_TreeNodeDriver from ./opencascade/BinMDataStd_TreeNodeDriver.hxx
    klass = m.attr("BinMDataStd_TreeNodeDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_TreeNodeDriver ,opencascade::handle<BinMDataStd_TreeNodeDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_TreeNodeDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_TreeNodeDriver::*)() const>(&BinMDataStd_TreeNodeDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_TreeNodeDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_TreeNodeDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_TreeNodeDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_TreeNodeDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_TreeNodeDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_TreeNodeDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_TreeNodeDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_TreeNodeDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_TreeNodeDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_TreeNodeDriver::*)() const>(&BinMDataStd_TreeNodeDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_UAttributeDriver from ./opencascade/BinMDataStd_UAttributeDriver.hxx
    klass = m.attr("BinMDataStd_UAttributeDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_UAttributeDriver ,opencascade::handle<BinMDataStd_UAttributeDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_UAttributeDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_UAttributeDriver::*)() const>(&BinMDataStd_UAttributeDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_UAttributeDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_UAttributeDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_UAttributeDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_UAttributeDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_UAttributeDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_UAttributeDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_UAttributeDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_UAttributeDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_UAttributeDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_UAttributeDriver::*)() const>(&BinMDataStd_UAttributeDriver::DynamicType),
             R"#()#"
             
         )
;

    // Class BinMDataStd_VariableDriver from ./opencascade/BinMDataStd_VariableDriver.hxx
    klass = m.attr("BinMDataStd_VariableDriver");


    // nested enums

    static_cast<py::class_<BinMDataStd_VariableDriver ,opencascade::handle<BinMDataStd_VariableDriver>  , BinMDF_ADriver >>(klass)
    // constructors
        .def(py::init<  const handle<Message_Messenger> & >()  , py::arg("theMessageDriver") )
    // custom constructors
    // methods
        .def("NewEmpty",
             (handle<TDF_Attribute> (BinMDataStd_VariableDriver::*)() const) static_cast<handle<TDF_Attribute> (BinMDataStd_VariableDriver::*)() const>(&BinMDataStd_VariableDriver::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (bool (BinMDataStd_VariableDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const) static_cast<bool (BinMDataStd_VariableDriver::*)(  const BinObjMgt_Persistent & ,   const handle<TDF_Attribute> & ,  BinObjMgt_RRelocationTable &  ) const>(&BinMDataStd_VariableDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
        .def("Paste",
             (void (BinMDataStd_VariableDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const) static_cast<void (BinMDataStd_VariableDriver::*)(  const handle<TDF_Attribute> & ,  BinObjMgt_Persistent & ,  NCollection_IndexedMap<handle<Standard_Transient>> &  ) const>(&BinMDataStd_VariableDriver::Paste),
             R"#()#"  , py::arg("Source"),  py::arg("Target"),  py::arg("RelocTable")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BinMDataStd_VariableDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BinMDataStd_VariableDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BinMDataStd_VariableDriver::*)() const) static_cast< const handle<Standard_Type> & (BinMDataStd_VariableDriver::*)() const>(&BinMDataStd_VariableDriver::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BinMDataStd.hxx
// ./opencascade/BinMDataStd_AsciiStringDriver.hxx
// ./opencascade/BinMDataStd_BooleanArrayDriver.hxx
// ./opencascade/BinMDataStd_BooleanListDriver.hxx
// ./opencascade/BinMDataStd_ByteArrayDriver.hxx
// ./opencascade/BinMDataStd_ExpressionDriver.hxx
// ./opencascade/BinMDataStd_ExtStringArrayDriver.hxx
// ./opencascade/BinMDataStd_ExtStringListDriver.hxx
// ./opencascade/BinMDataStd_GenericEmptyDriver.hxx
// ./opencascade/BinMDataStd_GenericExtStringDriver.hxx
// ./opencascade/BinMDataStd_IntPackedMapDriver.hxx
// ./opencascade/BinMDataStd_IntegerArrayDriver.hxx
// ./opencascade/BinMDataStd_IntegerDriver.hxx
// ./opencascade/BinMDataStd_IntegerListDriver.hxx
// ./opencascade/BinMDataStd_NamedDataDriver.hxx
// ./opencascade/BinMDataStd_RealArrayDriver.hxx
// ./opencascade/BinMDataStd_RealDriver.hxx
// ./opencascade/BinMDataStd_RealListDriver.hxx
// ./opencascade/BinMDataStd_ReferenceArrayDriver.hxx
// ./opencascade/BinMDataStd_ReferenceListDriver.hxx
// ./opencascade/BinMDataStd_TreeNodeDriver.hxx
// ./opencascade/BinMDataStd_UAttributeDriver.hxx
// ./opencascade/BinMDataStd_VariableDriver.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
