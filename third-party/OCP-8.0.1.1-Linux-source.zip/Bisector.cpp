
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_TrimmedCurve.hxx>
#include <Geom2d_Curve.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_Vec2d.hxx>
#include <Geom2d_Point.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_TrimmedCurve.hxx>
#include <Geom2d_Point.hxx>
#include <GccInt_Bisec.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Bisector_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Bisector_Bisec.hxx>
#include <IntRes2d_Domain.hxx>
#include <Geom2d_Curve.hxx>
#include <Bisector_BisecCC.hxx>
#include <Geom2d_Line.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Bisector.hxx>
#include <Bisector_Bisec.hxx>
#include <Bisector_BisecAna.hxx>
#include <Bisector_BisecCC.hxx>
#include <Bisector_BisecPC.hxx>
#include <Bisector_Curve.hxx>
#include <Bisector_FunctionH.hxx>
#include <Bisector_FunctionInter.hxx>
#include <Bisector_Inter.hxx>
#include <Bisector_PointOnBis.hxx>
#include <Bisector_PolyBis.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Bisector(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Bisector"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_Bisector_Curve : public Bisector_Curve{
    public:
        using Bisector_Curve::Bisector_Curve;


        // public pure virtual
        double Parameter( const gp_Pnt2d & P) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,Parameter,P) };
        bool IsExtendAtStart() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,IsExtendAtStart,) };
        bool IsExtendAtEnd() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,IsExtendAtEnd,) };
        int NbIntervals() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,NbIntervals,) };
        double IntervalFirst( const int Index) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,IntervalFirst,Index) };
        double IntervalLast( const int Index) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Bisector_Curve,IntervalLast,Index) };

        void Reverse() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Reverse,) };
        double ReversedParameter( const double U) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,ReversedParameter,U) };
        double FirstParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,FirstParameter,) };
        double LastParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,LastParameter,) };
        bool IsClosed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsClosed,) };
        bool IsPeriodic() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsPeriodic,) };
        GeomAbs_Shape Continuity() const  override { using return_type = GeomAbs_Shape;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Continuity,) };
        bool IsCN( const int N) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsCN,N) };
        gp_Pnt2d EvalD0( const double U) const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD0,U) };
        Geom2d_Curve::ResD1 EvalD1( const double U) const  override { using return_type = Geom2d_Curve::ResD1;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD1,U) };
        Geom2d_Curve::ResD2 EvalD2( const double U) const  override { using return_type = Geom2d_Curve::ResD2;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD2,U) };
        Geom2d_Curve::ResD3 EvalD3( const double U) const  override { using return_type = Geom2d_Curve::ResD3;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD3,U) };
        gp_Vec2d EvalDN( const double U, const int N) const  override { using return_type = gp_Vec2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalDN,U,N) };
        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class Bisector from ./opencascade/Bisector.hxx
    klass = m.attr("Bisector");

    // default constructor
    register_default_constructor<Bisector , shared_ptr<Bisector>>(m,"Bisector");

    // nested enums

    static_cast<py::class_<Bisector , shared_ptr<Bisector>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IsConvex_s",
                    (bool (*)(  const handle<Geom2d_Curve> & ,   const double  ) ) static_cast<bool (*)(  const handle<Geom2d_Curve> & ,   const double  ) >(&Bisector::IsConvex),
                    R"#()#"  , py::arg("Cu"),  py::arg("Sign")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bisector_Bisec from ./opencascade/Bisector_Bisec.hxx
    klass = m.attr("Bisector_Bisec");


    // nested enums

    static_cast<py::class_<Bisector_Bisec , shared_ptr<Bisector_Bisec>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_Bisec::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const GeomAbs_JoinType ,   const double ,   const bool  ) ) static_cast<void (Bisector_Bisec::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const GeomAbs_JoinType ,   const double ,   const bool  ) >(&Bisector_Bisec::Perform),
             R"#(Performs the bisecting line between the curves <Cu1> and <Cu2>. <oncurve> is True if the point <P> is common to <Cu1> and <Cu2>.)#"  , py::arg("Cu1"),  py::arg("Cu2"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("ajointype"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_Bisec::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_Bisec::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_Bisec::Perform),
             R"#(Performs the bisecting line between the curve <Cu1> and the point <Pnt>. <oncurve> is True if the point <P> is the point <Pnt>.)#"  , py::arg("Cu"),  py::arg("Pnt"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_Bisec::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_Bisec::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_Bisec::Perform),
             R"#(Performs the bisecting line between the curve <Cu> and the point <Pnt>. <oncurve> is True if the point <P> is the point <Pnt>.)#"  , py::arg("Pnt"),  py::arg("Cu"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_Bisec::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_Bisec::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_Bisec::Perform),
             R"#(Performs the bisecting line between the two points <Pnt1> and <Pnt2>.)#"  , py::arg("Pnt1"),  py::arg("Pnt2"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance")=static_cast< const double>(0.0),  py::arg("oncurve")=static_cast< const bool>(true)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (Bisector_Bisec::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (Bisector_Bisec::*)() const>(&Bisector_Bisec::Value),
             R"#(Returns the Curve of <me>.)#"
             
         )
       .def("ChangeValue",
             ( const handle<Geom2d_TrimmedCurve> & (Bisector_Bisec::*)() ) static_cast< const handle<Geom2d_TrimmedCurve> & (Bisector_Bisec::*)() >(&Bisector_Bisec::ChangeValue),
             R"#(Returns the Curve of <me>.)#"
             
         )
;

    // Class Bisector_Curve from ./opencascade/Bisector_Curve.hxx
    klass = m.attr("Bisector_Curve");


    // nested enums

    static_cast<py::class_<Bisector_Curve ,opencascade::handle<Bisector_Curve> ,Py_Bisector_Curve , Geom2d_Curve >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Parameter",
             (double (Bisector_Curve::*)(  const gp_Pnt2d &  ) const) static_cast<double (Bisector_Curve::*)(  const gp_Pnt2d &  ) const>(&Bisector_Curve::Parameter),
             R"#()#"  , py::arg("P")
          )
        .def("IsExtendAtStart",
             (bool (Bisector_Curve::*)() const) static_cast<bool (Bisector_Curve::*)() const>(&Bisector_Curve::IsExtendAtStart),
             R"#()#" 
          )
        .def("IsExtendAtEnd",
             (bool (Bisector_Curve::*)() const) static_cast<bool (Bisector_Curve::*)() const>(&Bisector_Curve::IsExtendAtEnd),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (Bisector_Curve::*)() const) static_cast<int (Bisector_Curve::*)() const>(&Bisector_Curve::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <C1>. And returns the number of intervals.)#" 
          )
        .def("IntervalFirst",
             (double (Bisector_Curve::*)(  const int  ) const) static_cast<double (Bisector_Curve::*)(  const int  ) const>(&Bisector_Curve::IntervalFirst),
             R"#(Returns the first parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalLast",
             (double (Bisector_Curve::*)(  const int  ) const) static_cast<double (Bisector_Curve::*)(  const int  ) const>(&Bisector_Curve::IntervalLast),
             R"#(Returns the last parameter of the current interval.)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Bisector_Curve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Bisector_Curve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Bisector_Curve::*)() const) static_cast< const handle<Standard_Type> & (Bisector_Curve::*)() const>(&Bisector_Curve::DynamicType),
             R"#()#"
             
         )
;

    // Class Bisector_FunctionH from ./opencascade/Bisector_FunctionH.hxx
    klass = m.attr("Bisector_FunctionH");


    // nested enums

    static_cast<py::class_<Bisector_FunctionH , shared_ptr<Bisector_FunctionH>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init<  const handle<Geom2d_Curve> &, const gp_Pnt2d &, const gp_Vec2d & >()  , py::arg("C2"),  py::arg("P1"),  py::arg("T1") )
    // custom constructors
    // methods
        .def("Value",
             (bool (Bisector_FunctionH::*)(  const double ,  double &  ) ) static_cast<bool (Bisector_FunctionH::*)(  const double ,  double &  ) >(&Bisector_FunctionH::Value),
             R"#(Computes the values of the Functions for the variable <X>.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivative",
             (bool (Bisector_FunctionH::*)(  const double ,  double &  ) ) static_cast<bool (Bisector_FunctionH::*)(  const double ,  double &  ) >(&Bisector_FunctionH::Derivative),
             R"#()#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (Bisector_FunctionH::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (Bisector_FunctionH::*)(  const double ,  double & ,  double &  ) >(&Bisector_FunctionH::Values),
             R"#(Returns the values of the functions and the derivatives for the variable <X>.)#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bisector_FunctionInter from ./opencascade/Bisector_FunctionInter.hxx
    klass = m.attr("Bisector_FunctionInter");


    // nested enums

    static_cast<py::class_<Bisector_FunctionInter , shared_ptr<Bisector_FunctionInter>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom2d_Curve> &, const handle<Bisector_Curve> &, const handle<Bisector_Curve> & >()  , py::arg("C"),  py::arg("Bis1"),  py::arg("Bis2") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_FunctionInter::*)(  const handle<Geom2d_Curve> & ,   const handle<Bisector_Curve> & ,   const handle<Bisector_Curve> &  ) ) static_cast<void (Bisector_FunctionInter::*)(  const handle<Geom2d_Curve> & ,   const handle<Bisector_Curve> & ,   const handle<Bisector_Curve> &  ) >(&Bisector_FunctionInter::Perform),
             R"#()#"  , py::arg("C"),  py::arg("Bis1"),  py::arg("Bis2")
          )
        .def("Value",
             (bool (Bisector_FunctionInter::*)(  const double ,  double &  ) ) static_cast<bool (Bisector_FunctionInter::*)(  const double ,  double &  ) >(&Bisector_FunctionInter::Value),
             R"#(Computes the values of the Functions for the variable <X>.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivative",
             (bool (Bisector_FunctionInter::*)(  const double ,  double &  ) ) static_cast<bool (Bisector_FunctionInter::*)(  const double ,  double &  ) >(&Bisector_FunctionInter::Derivative),
             R"#()#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (Bisector_FunctionInter::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (Bisector_FunctionInter::*)(  const double ,  double & ,  double &  ) >(&Bisector_FunctionInter::Values),
             R"#(Returns the values of the functions and the derivatives for the variable <X>.)#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bisector_Inter from ./opencascade/Bisector_Inter.hxx
    klass = m.attr("Bisector_Inter");


    // nested enums

    static_cast<py::class_<Bisector_Inter , shared_ptr<Bisector_Inter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Bisector_Bisec &, const IntRes2d_Domain &, const Bisector_Bisec &, const IntRes2d_Domain &, const double, const double, const bool >()  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol"),  py::arg("ComunElement") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_Inter::*)(  const Bisector_Bisec & ,   const IntRes2d_Domain & ,   const Bisector_Bisec & ,   const IntRes2d_Domain & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_Inter::*)(  const Bisector_Bisec & ,   const IntRes2d_Domain & ,   const Bisector_Bisec & ,   const IntRes2d_Domain & ,   const double ,   const double ,   const bool  ) >(&Bisector_Inter::Perform),
             R"#(Intersection between 2 curves. C1 separates the element A and B. C2 separates the elements C et D. If B an C have the same geometry. <ComunElement> Has to be True. It Permits an optimization of the computation.)#"  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol"),  py::arg("ComunElement")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bisector_PointOnBis from ./opencascade/Bisector_PointOnBis.hxx
    klass = m.attr("Bisector_PointOnBis");


    // nested enums

    static_cast<py::class_<Bisector_PointOnBis , shared_ptr<Bisector_PointOnBis>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const double, const double, const gp_Pnt2d & >()  , py::arg("Param1"),  py::arg("Param2"),  py::arg("ParamBis"),  py::arg("Distance"),  py::arg("Point") )
    // custom constructors
    // methods
        .def("ParamOnC1",
             (void (Bisector_PointOnBis::*)(  const double  ) ) static_cast<void (Bisector_PointOnBis::*)(  const double  ) >(&Bisector_PointOnBis::ParamOnC1),
             R"#()#"  , py::arg("Param")
          )
        .def("ParamOnC2",
             (void (Bisector_PointOnBis::*)(  const double  ) ) static_cast<void (Bisector_PointOnBis::*)(  const double  ) >(&Bisector_PointOnBis::ParamOnC2),
             R"#()#"  , py::arg("Param")
          )
        .def("ParamOnBis",
             (void (Bisector_PointOnBis::*)(  const double  ) ) static_cast<void (Bisector_PointOnBis::*)(  const double  ) >(&Bisector_PointOnBis::ParamOnBis),
             R"#()#"  , py::arg("Param")
          )
        .def("Distance",
             (void (Bisector_PointOnBis::*)(  const double  ) ) static_cast<void (Bisector_PointOnBis::*)(  const double  ) >(&Bisector_PointOnBis::Distance),
             R"#()#"  , py::arg("Distance")
          )
        .def("IsInfinite",
             (void (Bisector_PointOnBis::*)(  const bool  ) ) static_cast<void (Bisector_PointOnBis::*)(  const bool  ) >(&Bisector_PointOnBis::IsInfinite),
             R"#()#"  , py::arg("Infinite")
          )
        .def("Point",
             (void (Bisector_PointOnBis::*)(  const gp_Pnt2d &  ) ) static_cast<void (Bisector_PointOnBis::*)(  const gp_Pnt2d &  ) >(&Bisector_PointOnBis::Point),
             R"#()#"  , py::arg("P")
          )
        .def("ParamOnC1",
             (double (Bisector_PointOnBis::*)() const) static_cast<double (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::ParamOnC1),
             R"#()#" 
          )
        .def("ParamOnC2",
             (double (Bisector_PointOnBis::*)() const) static_cast<double (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::ParamOnC2),
             R"#()#" 
          )
        .def("ParamOnBis",
             (double (Bisector_PointOnBis::*)() const) static_cast<double (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::ParamOnBis),
             R"#()#" 
          )
        .def("Distance",
             (double (Bisector_PointOnBis::*)() const) static_cast<double (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::Distance),
             R"#()#" 
          )
        .def("Point",
             (gp_Pnt2d (Bisector_PointOnBis::*)() const) static_cast<gp_Pnt2d (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::Point),
             R"#()#" 
          )
        .def("IsInfinite",
             (bool (Bisector_PointOnBis::*)() const) static_cast<bool (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::IsInfinite),
             R"#()#" 
          )
        .def("Dump",
             (void (Bisector_PointOnBis::*)() const) static_cast<void (Bisector_PointOnBis::*)() const>(&Bisector_PointOnBis::Dump),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bisector_PolyBis from ./opencascade/Bisector_PolyBis.hxx
    klass = m.attr("Bisector_PolyBis");


    // nested enums

    static_cast<py::class_<Bisector_PolyBis , shared_ptr<Bisector_PolyBis>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Append",
             (void (Bisector_PolyBis::*)(  const Bisector_PointOnBis &  ) ) static_cast<void (Bisector_PolyBis::*)(  const Bisector_PointOnBis &  ) >(&Bisector_PolyBis::Append),
             R"#()#"  , py::arg("Point")
          )
        .def("Length",
             (int (Bisector_PolyBis::*)() const) static_cast<int (Bisector_PolyBis::*)() const>(&Bisector_PolyBis::Length),
             R"#()#" 
          )
        .def("IsEmpty",
             (bool (Bisector_PolyBis::*)() const) static_cast<bool (Bisector_PolyBis::*)() const>(&Bisector_PolyBis::IsEmpty),
             R"#()#" 
          )
        .def("Value",
             ( const Bisector_PointOnBis & (Bisector_PolyBis::*)(  const int  ) const) static_cast< const Bisector_PointOnBis & (Bisector_PolyBis::*)(  const int  ) const>(&Bisector_PolyBis::Value),
             R"#()#"  , py::arg("Index")
          )
        .def("Interval",
             (int (Bisector_PolyBis::*)(  const double  ) const) static_cast<int (Bisector_PolyBis::*)(  const double  ) const>(&Bisector_PolyBis::Interval),
             R"#()#"  , py::arg("U")
          )
        .def("Transform",
             (void (Bisector_PolyBis::*)(  const gp_Trsf2d &  ) ) static_cast<void (Bisector_PolyBis::*)(  const gp_Trsf2d &  ) >(&Bisector_PolyBis::Transform),
             R"#()#"  , py::arg("T")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("First",
             ( const Bisector_PointOnBis & (Bisector_PolyBis::*)() const) static_cast< const Bisector_PointOnBis & (Bisector_PolyBis::*)() const>(&Bisector_PolyBis::First),
             R"#()#"
             
         )
       .def("Last",
             ( const Bisector_PointOnBis & (Bisector_PolyBis::*)() const) static_cast< const Bisector_PointOnBis & (Bisector_PolyBis::*)() const>(&Bisector_PolyBis::Last),
             R"#()#"
             
         )
;

    // Class Bisector_BisecAna from ./opencascade/Bisector_BisecAna.hxx
    klass = m.attr("Bisector_BisecAna");


    // nested enums

    static_cast<py::class_<Bisector_BisecAna ,opencascade::handle<Bisector_BisecAna>  , Bisector_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const GeomAbs_JoinType ,   const double ,   const bool  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const GeomAbs_JoinType ,   const double ,   const bool  ) >(&Bisector_BisecAna::Perform),
             R"#(Performs the bisecting line between the curves <Cu1> and <Cu2>. <oncurve> is True if the point <P> is common to <Cu1> and <Cu2>.)#"  , py::arg("Cu1"),  py::arg("Cu2"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("jointype"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_BisecAna::Perform),
             R"#(Performs the bisecting line between the curve <Cu1> and the point <Pnt>. <oncurve> is True if the point <P> is the point <Pnt>.)#"  , py::arg("Cu"),  py::arg("Pnt"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_BisecAna::Perform),
             R"#(Performs the bisecting line between the curve <Cu> and the point <Pnt>. <oncurve> is True if the point <P> is the point <Pnt>.)#"  , py::arg("Pnt"),  py::arg("Cu"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance"),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Perform",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_Point> & ,   const handle<Geom2d_Point> & ,   const gp_Pnt2d & ,   const gp_Vec2d & ,   const gp_Vec2d & ,   const double ,   const double ,   const bool  ) >(&Bisector_BisecAna::Perform),
             R"#(Performs the bisecting line between the two points <Pnt1> and <Pnt2>.)#"  , py::arg("Pnt1"),  py::arg("Pnt2"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("Sense"),  py::arg("Tolerance")=static_cast< const double>(0.0),  py::arg("oncurve")=static_cast< const bool>(true)
          )
        .def("Init",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_TrimmedCurve> &  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_TrimmedCurve> &  ) >(&Bisector_BisecAna::Init),
             R"#()#"  , py::arg("bisector")
          )
        .def("IsExtendAtStart",
             (bool (Bisector_BisecAna::*)() const) static_cast<bool (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::IsExtendAtStart),
             R"#()#" 
          )
        .def("IsExtendAtEnd",
             (bool (Bisector_BisecAna::*)() const) static_cast<bool (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::IsExtendAtEnd),
             R"#()#" 
          )
        .def("SetTrim",
             (void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> &  ) ) static_cast<void (Bisector_BisecAna::*)(  const handle<Geom2d_Curve> &  ) >(&Bisector_BisecAna::SetTrim),
             R"#(Trim <me> by a domain defined by the curve <Cu>. This domain is the set of the points which are nearest from <Cu> than the extremitis of <Cu>.)#"  , py::arg("Cu")
          )
        .def("SetTrim",
             (void (Bisector_BisecAna::*)(  const double ,   const double  ) ) static_cast<void (Bisector_BisecAna::*)(  const double ,   const double  ) >(&Bisector_BisecAna::SetTrim),
             R"#(Trim <me> by a domain defined by uf and ul)#"  , py::arg("uf"),  py::arg("ul")
          )
        .def("Reverse",
             (void (Bisector_BisecAna::*)() ) static_cast<void (Bisector_BisecAna::*)() >(&Bisector_BisecAna::Reverse),
             R"#()#" 
          )
        .def("ReversedParameter",
             (double (Bisector_BisecAna::*)(  const double  ) const) static_cast<double (Bisector_BisecAna::*)(  const double  ) const>(&Bisector_BisecAna::ReversedParameter),
             R"#()#"  , py::arg("U")
          )
        .def("IsCN",
             (bool (Bisector_BisecAna::*)(  const int  ) const) static_cast<bool (Bisector_BisecAna::*)(  const int  ) const>(&Bisector_BisecAna::IsCN),
             R"#(Returns the order of continuity of the curve. Raised if N < 0.)#"  , py::arg("N")
          )
        .def("Copy",
             (handle<Geom2d_Geometry> (Bisector_BisecAna::*)() const) static_cast<handle<Geom2d_Geometry> (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::Copy),
             R"#()#" 
          )
        .def("Transform",
             (void (Bisector_BisecAna::*)(  const gp_Trsf2d &  ) ) static_cast<void (Bisector_BisecAna::*)(  const gp_Trsf2d &  ) >(&Bisector_BisecAna::Transform),
             R"#()#"  , py::arg("T")
          )
        .def("FirstParameter",
             (double (Bisector_BisecAna::*)() const) static_cast<double (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (Bisector_BisecAna::*)() const) static_cast<double (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::LastParameter),
             R"#()#" 
          )
        .def("IsClosed",
             (bool (Bisector_BisecAna::*)() const) static_cast<bool (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (Bisector_BisecAna::*)() const) static_cast<bool (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::IsPeriodic),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (Bisector_BisecAna::*)() const) static_cast<GeomAbs_Shape (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::Continuity),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt2d (Bisector_BisecAna::*)(  const double  ) const) static_cast<gp_Pnt2d (Bisector_BisecAna::*)(  const double  ) const>(&Bisector_BisecAna::EvalD0),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD1",
             (Geom2d_Curve::ResD1 (Bisector_BisecAna::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD1 (Bisector_BisecAna::*)(  const double  ) const>(&Bisector_BisecAna::EvalD1),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD2",
             (Geom2d_Curve::ResD2 (Bisector_BisecAna::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD2 (Bisector_BisecAna::*)(  const double  ) const>(&Bisector_BisecAna::EvalD2),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD3",
             (Geom2d_Curve::ResD3 (Bisector_BisecAna::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD3 (Bisector_BisecAna::*)(  const double  ) const>(&Bisector_BisecAna::EvalD3),
             R"#()#"  , py::arg("U")
          )
        .def("EvalDN",
             (gp_Vec2d (Bisector_BisecAna::*)(  const double ,   const int  ) const) static_cast<gp_Vec2d (Bisector_BisecAna::*)(  const double ,   const int  ) const>(&Bisector_BisecAna::EvalDN),
             R"#()#"  , py::arg("U"),  py::arg("N")
          )
        .def("Geom2dCurve",
             (handle<Geom2d_Curve> (Bisector_BisecAna::*)() const) static_cast<handle<Geom2d_Curve> (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::Geom2dCurve),
             R"#()#" 
          )
        .def("Parameter",
             (double (Bisector_BisecAna::*)(  const gp_Pnt2d &  ) const) static_cast<double (Bisector_BisecAna::*)(  const gp_Pnt2d &  ) const>(&Bisector_BisecAna::Parameter),
             R"#()#"  , py::arg("P")
          )
        .def("ParameterOfStartPoint",
             (double (Bisector_BisecAna::*)() const) static_cast<double (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::ParameterOfStartPoint),
             R"#()#" 
          )
        .def("ParameterOfEndPoint",
             (double (Bisector_BisecAna::*)() const) static_cast<double (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::ParameterOfEndPoint),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (Bisector_BisecAna::*)() const) static_cast<int (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <C1>. And returns the number of intervals.)#" 
          )
        .def("IntervalFirst",
             (double (Bisector_BisecAna::*)(  const int  ) const) static_cast<double (Bisector_BisecAna::*)(  const int  ) const>(&Bisector_BisecAna::IntervalFirst),
             R"#(Returns the first parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalLast",
             (double (Bisector_BisecAna::*)(  const int  ) const) static_cast<double (Bisector_BisecAna::*)(  const int  ) const>(&Bisector_BisecAna::IntervalLast),
             R"#(Returns the last parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("Dump",
             (void (Bisector_BisecAna::*)(  const int ,   const int  ) const) static_cast<void (Bisector_BisecAna::*)(  const int ,   const int  ) const>(&Bisector_BisecAna::Dump),
             R"#()#"  , py::arg("Deep")=static_cast< const int>(0),  py::arg("Offset")=static_cast< const int>(0)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Bisector_BisecAna::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Bisector_BisecAna::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Bisector_BisecAna::*)() const) static_cast< const handle<Standard_Type> & (Bisector_BisecAna::*)() const>(&Bisector_BisecAna::DynamicType),
             R"#()#"
             
         )
;

    // Class Bisector_BisecCC from ./opencascade/Bisector_BisecCC.hxx
    klass = m.attr("Bisector_BisecCC");


    // nested enums

    static_cast<py::class_<Bisector_BisecCC ,opencascade::handle<Bisector_BisecCC>  , Bisector_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom2d_Curve> &, const handle<Geom2d_Curve> &, const double, const double, const gp_Pnt2d &, const double >()  , py::arg("Cu1"),  py::arg("Cu2"),  py::arg("Side1"),  py::arg("Side2"),  py::arg("Origin"),  py::arg("DistMax")=static_cast< const double>(500) )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_BisecCC::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const double ,   const double ,   const gp_Pnt2d & ,   const double  ) ) static_cast<void (Bisector_BisecCC::*)(  const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> & ,   const double ,   const double ,   const gp_Pnt2d & ,   const double  ) >(&Bisector_BisecCC::Perform),
             R"#(Computes the bisector between the curves <Cu1> and <Cu2>.)#"  , py::arg("Cu1"),  py::arg("Cu2"),  py::arg("Side1"),  py::arg("Side2"),  py::arg("Origin"),  py::arg("DistMax")=static_cast< const double>(500)
          )
        .def("IsExtendAtStart",
             (bool (Bisector_BisecCC::*)() const) static_cast<bool (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IsExtendAtStart),
             R"#()#" 
          )
        .def("IsExtendAtEnd",
             (bool (Bisector_BisecCC::*)() const) static_cast<bool (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IsExtendAtEnd),
             R"#()#" 
          )
        .def("Reverse",
             (void (Bisector_BisecCC::*)() ) static_cast<void (Bisector_BisecCC::*)() >(&Bisector_BisecCC::Reverse),
             R"#()#" 
          )
        .def("ReversedParameter",
             (double (Bisector_BisecCC::*)(  const double  ) const) static_cast<double (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::ReversedParameter),
             R"#()#"  , py::arg("U")
          )
        .def("IsCN",
             (bool (Bisector_BisecCC::*)(  const int  ) const) static_cast<bool (Bisector_BisecCC::*)(  const int  ) const>(&Bisector_BisecCC::IsCN),
             R"#(Returns the order of continuity of the curve. Raised if N < 0.)#"  , py::arg("N")
          )
        .def("ChangeGuide",
             (handle<Bisector_BisecCC> (Bisector_BisecCC::*)() const) static_cast<handle<Bisector_BisecCC> (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::ChangeGuide),
             R"#(The parameter on <me> is linked to the parameter on the first curve. This method creates the same bisector where the curves are inversed.)#" 
          )
        .def("Copy",
             (handle<Geom2d_Geometry> (Bisector_BisecCC::*)() const) static_cast<handle<Geom2d_Geometry> (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::Copy),
             R"#()#" 
          )
        .def("Transform",
             (void (Bisector_BisecCC::*)(  const gp_Trsf2d &  ) ) static_cast<void (Bisector_BisecCC::*)(  const gp_Trsf2d &  ) >(&Bisector_BisecCC::Transform),
             R"#(Transformation of a geometric object. This transformation can be a translation, a rotation, a symmetry, a scaling or a complex transformation obtained by combination of the previous elementaries transformations.)#"  , py::arg("T")
          )
        .def("FirstParameter",
             (double (Bisector_BisecCC::*)() const) static_cast<double (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (Bisector_BisecCC::*)() const) static_cast<double (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (Bisector_BisecCC::*)() const) static_cast<GeomAbs_Shape (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (Bisector_BisecCC::*)() const) static_cast<int (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <C1>. And returns the number of intervals.)#" 
          )
        .def("IntervalFirst",
             (double (Bisector_BisecCC::*)(  const int  ) const) static_cast<double (Bisector_BisecCC::*)(  const int  ) const>(&Bisector_BisecCC::IntervalFirst),
             R"#(Returns the first parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalLast",
             (double (Bisector_BisecCC::*)(  const int  ) const) static_cast<double (Bisector_BisecCC::*)(  const int  ) const>(&Bisector_BisecCC::IntervalLast),
             R"#(Returns the last parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalContinuity",
             (GeomAbs_Shape (Bisector_BisecCC::*)() const) static_cast<GeomAbs_Shape (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IntervalContinuity),
             R"#()#" 
          )
        .def("IsClosed",
             (bool (Bisector_BisecCC::*)() const) static_cast<bool (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (Bisector_BisecCC::*)() const) static_cast<bool (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IsPeriodic),
             R"#()#" 
          )
        .def("ValueAndDist",
             (gp_Pnt2d (Bisector_BisecCC::*)(  const double ,  double & ,  double & ,  double &  ) const) static_cast<gp_Pnt2d (Bisector_BisecCC::*)(  const double ,  double & ,  double & ,  double &  ) const>(&Bisector_BisecCC::ValueAndDist),
             R"#(Returns the point of parameter U. Computes the distance between the current point and the two curves I separate. Computes the parameters on each curve corresponding of the projection of the current point.)#"  , py::arg("U"),  py::arg("U1"),  py::arg("U2"),  py::arg("Distance")
          )
        .def("ValueByInt",
             (gp_Pnt2d (Bisector_BisecCC::*)(  const double ,  double & ,  double & ,  double &  ) const) static_cast<gp_Pnt2d (Bisector_BisecCC::*)(  const double ,  double & ,  double & ,  double &  ) const>(&Bisector_BisecCC::ValueByInt),
             R"#(Returns the point of parameter U. Computes the distance between the current point and the two curves I separate. Computes the parameters on each curve corresponding of the projection of the current point.)#"  , py::arg("U"),  py::arg("U1"),  py::arg("U2"),  py::arg("Distance")
          )
        .def("EvalD0",
             (gp_Pnt2d (Bisector_BisecCC::*)(  const double  ) const) static_cast<gp_Pnt2d (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::EvalD0),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD1",
             (Geom2d_Curve::ResD1 (Bisector_BisecCC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD1 (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::EvalD1),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD2",
             (Geom2d_Curve::ResD2 (Bisector_BisecCC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD2 (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::EvalD2),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD3",
             (Geom2d_Curve::ResD3 (Bisector_BisecCC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD3 (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::EvalD3),
             R"#()#"  , py::arg("U")
          )
        .def("EvalDN",
             (gp_Vec2d (Bisector_BisecCC::*)(  const double ,   const int  ) const) static_cast<gp_Vec2d (Bisector_BisecCC::*)(  const double ,   const int  ) const>(&Bisector_BisecCC::EvalDN),
             R"#()#"  , py::arg("U"),  py::arg("N")
          )
        .def("IsEmpty",
             (bool (Bisector_BisecCC::*)() const) static_cast<bool (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::IsEmpty),
             R"#()#" 
          )
        .def("LinkBisCurve",
             (double (Bisector_BisecCC::*)(  const double  ) const) static_cast<double (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::LinkBisCurve),
             R"#(Returns the parameter on the curve1 of the projection of the point of parameter U on <me>.)#"  , py::arg("U")
          )
        .def("LinkCurveBis",
             (double (Bisector_BisecCC::*)(  const double  ) const) static_cast<double (Bisector_BisecCC::*)(  const double  ) const>(&Bisector_BisecCC::LinkCurveBis),
             R"#(Returns the reciproque of LinkBisCurve.)#"  , py::arg("U")
          )
        .def("Parameter",
             (double (Bisector_BisecCC::*)(  const gp_Pnt2d &  ) const) static_cast<double (Bisector_BisecCC::*)(  const gp_Pnt2d &  ) const>(&Bisector_BisecCC::Parameter),
             R"#()#"  , py::arg("P")
          )
        .def("Curve",
             (handle<Geom2d_Curve> (Bisector_BisecCC::*)(  const int  ) const) static_cast<handle<Geom2d_Curve> (Bisector_BisecCC::*)(  const int  ) const>(&Bisector_BisecCC::Curve),
             R"#()#"  , py::arg("IndCurve")
          )
        .def("Dump",
             (void (Bisector_BisecCC::*)(  const int ,   const int  ) const) static_cast<void (Bisector_BisecCC::*)(  const int ,   const int  ) const>(&Bisector_BisecCC::Dump),
             R"#()#"  , py::arg("Deep")=static_cast< const int>(0),  py::arg("Offset")=static_cast< const int>(0)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Bisector_BisecCC::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Bisector_BisecCC::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Polygon",
             ( const Bisector_PolyBis & (Bisector_BisecCC::*)() const) static_cast< const Bisector_PolyBis & (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::Polygon),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (Bisector_BisecCC::*)() const) static_cast< const handle<Standard_Type> & (Bisector_BisecCC::*)() const>(&Bisector_BisecCC::DynamicType),
             R"#()#"
             
         )
;

    // Class Bisector_BisecPC from ./opencascade/Bisector_BisecPC.hxx
    klass = m.attr("Bisector_BisecPC");


    // nested enums

    static_cast<py::class_<Bisector_BisecPC ,opencascade::handle<Bisector_BisecPC>  , Bisector_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom2d_Curve> &, const gp_Pnt2d &, const double, const double >()  , py::arg("Cu"),  py::arg("P"),  py::arg("Side"),  py::arg("DistMax")=static_cast< const double>(500) )
        .def(py::init<  const handle<Geom2d_Curve> &, const gp_Pnt2d &, const double, const double, const double >()  , py::arg("Cu"),  py::arg("P"),  py::arg("Side"),  py::arg("UMin"),  py::arg("UMax") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Bisector_BisecPC::*)(  const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const double ,   const double  ) ) static_cast<void (Bisector_BisecPC::*)(  const handle<Geom2d_Curve> & ,   const gp_Pnt2d & ,   const double ,   const double  ) >(&Bisector_BisecPC::Perform),
             R"#(Construct the bisector between the point <P> and the curve <Cu>. <Side> = 1. if the bisector curve is on the Left of <Cu> else <Side> = -1. <DistMax> is used to trim the bisector.The distance between the points of the bisector and <Cu> is smaller than <DistMax>.)#"  , py::arg("Cu"),  py::arg("P"),  py::arg("Side"),  py::arg("DistMax")=static_cast< const double>(500)
          )
        .def("IsExtendAtStart",
             (bool (Bisector_BisecPC::*)() const) static_cast<bool (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IsExtendAtStart),
             R"#(Returns True if the bisector is extended at start.)#" 
          )
        .def("IsExtendAtEnd",
             (bool (Bisector_BisecPC::*)() const) static_cast<bool (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IsExtendAtEnd),
             R"#(Returns True if the bisector is extended at end.)#" 
          )
        .def("Reverse",
             (void (Bisector_BisecPC::*)() ) static_cast<void (Bisector_BisecPC::*)() >(&Bisector_BisecPC::Reverse),
             R"#(Changes the direction of parametrization of <me>. The orientation of the curve is modified. If the curve is bounded the StartPoint of the initial curve becomes the EndPoint of the reversed curve and the EndPoint of the initial curve becomes the StartPoint of the reversed curve.)#" 
          )
        .def("ReversedParameter",
             (double (Bisector_BisecPC::*)(  const double  ) const) static_cast<double (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::ReversedParameter),
             R"#(Returns the parameter on the reversed curve for the point of parameter U on <me>.)#"  , py::arg("U")
          )
        .def("Copy",
             (handle<Geom2d_Geometry> (Bisector_BisecPC::*)() const) static_cast<handle<Geom2d_Geometry> (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::Copy),
             R"#()#" 
          )
        .def("Transform",
             (void (Bisector_BisecPC::*)(  const gp_Trsf2d &  ) ) static_cast<void (Bisector_BisecPC::*)(  const gp_Trsf2d &  ) >(&Bisector_BisecPC::Transform),
             R"#(Transformation of a geometric object. This transformation can be a translation, a rotation, a symmetry, a scaling or a complex transformation obtained by combination of the previous elementaries transformations.)#"  , py::arg("T")
          )
        .def("IsCN",
             (bool (Bisector_BisecPC::*)(  const int  ) const) static_cast<bool (Bisector_BisecPC::*)(  const int  ) const>(&Bisector_BisecPC::IsCN),
             R"#(Returns the order of continuity of the curve. Raised if N < 0.)#"  , py::arg("N")
          )
        .def("FirstParameter",
             (double (Bisector_BisecPC::*)() const) static_cast<double (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::FirstParameter),
             R"#(Value of the first parameter.)#" 
          )
        .def("LastParameter",
             (double (Bisector_BisecPC::*)() const) static_cast<double (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::LastParameter),
             R"#(Value of the last parameter.)#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (Bisector_BisecPC::*)() const) static_cast<GeomAbs_Shape (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (Bisector_BisecPC::*)() const) static_cast<int (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <C1>. And returns the number of intervals.)#" 
          )
        .def("IntervalFirst",
             (double (Bisector_BisecPC::*)(  const int  ) const) static_cast<double (Bisector_BisecPC::*)(  const int  ) const>(&Bisector_BisecPC::IntervalFirst),
             R"#(Returns the first parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalLast",
             (double (Bisector_BisecPC::*)(  const int  ) const) static_cast<double (Bisector_BisecPC::*)(  const int  ) const>(&Bisector_BisecPC::IntervalLast),
             R"#(Returns the last parameter of the current interval.)#"  , py::arg("Index")
          )
        .def("IntervalContinuity",
             (GeomAbs_Shape (Bisector_BisecPC::*)() const) static_cast<GeomAbs_Shape (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IntervalContinuity),
             R"#()#" 
          )
        .def("IsClosed",
             (bool (Bisector_BisecPC::*)() const) static_cast<bool (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (Bisector_BisecPC::*)() const) static_cast<bool (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IsPeriodic),
             R"#()#" 
          )
        .def("Distance",
             (double (Bisector_BisecPC::*)(  const double  ) const) static_cast<double (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::Distance),
             R"#(Returns the distance between the point of parameter U on <me> and my point or my curve.)#"  , py::arg("U")
          )
        .def("EvalD0",
             (gp_Pnt2d (Bisector_BisecPC::*)(  const double  ) const) static_cast<gp_Pnt2d (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::EvalD0),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD1",
             (Geom2d_Curve::ResD1 (Bisector_BisecPC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD1 (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::EvalD1),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD2",
             (Geom2d_Curve::ResD2 (Bisector_BisecPC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD2 (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::EvalD2),
             R"#()#"  , py::arg("U")
          )
        .def("EvalD3",
             (Geom2d_Curve::ResD3 (Bisector_BisecPC::*)(  const double  ) const) static_cast<Geom2d_Curve::ResD3 (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::EvalD3),
             R"#()#"  , py::arg("U")
          )
        .def("EvalDN",
             (gp_Vec2d (Bisector_BisecPC::*)(  const double ,   const int  ) const) static_cast<gp_Vec2d (Bisector_BisecPC::*)(  const double ,   const int  ) const>(&Bisector_BisecPC::EvalDN),
             R"#()#"  , py::arg("U"),  py::arg("N")
          )
        .def("Dump",
             (void (Bisector_BisecPC::*)(  const int ,   const int  ) const) static_cast<void (Bisector_BisecPC::*)(  const int ,   const int  ) const>(&Bisector_BisecPC::Dump),
             R"#()#"  , py::arg("Deep")=static_cast< const int>(0),  py::arg("Offset")=static_cast< const int>(0)
          )
        .def("LinkBisCurve",
             (double (Bisector_BisecPC::*)(  const double  ) const) static_cast<double (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::LinkBisCurve),
             R"#(Returns the parameter on the curve1 of the projection of the point of parameter U on <me>.)#"  , py::arg("U")
          )
        .def("LinkCurveBis",
             (double (Bisector_BisecPC::*)(  const double  ) const) static_cast<double (Bisector_BisecPC::*)(  const double  ) const>(&Bisector_BisecPC::LinkCurveBis),
             R"#(Returns the reciproque of LinkBisCurve.)#"  , py::arg("U")
          )
        .def("Parameter",
             (double (Bisector_BisecPC::*)(  const gp_Pnt2d &  ) const) static_cast<double (Bisector_BisecPC::*)(  const gp_Pnt2d &  ) const>(&Bisector_BisecPC::Parameter),
             R"#(Returns the parameter on <me> corresponding to <P>.)#"  , py::arg("P")
          )
        .def("IsEmpty",
             (bool (Bisector_BisecPC::*)() const) static_cast<bool (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::IsEmpty),
             R"#(Returns <True> if the bisector is empty.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Bisector_BisecPC::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Bisector_BisecPC::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Bisector_BisecPC::*)() const) static_cast< const handle<Standard_Type> & (Bisector_BisecPC::*)() const>(&Bisector_BisecPC::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/Bisector.hxx
// ./opencascade/Bisector_Bisec.hxx
// ./opencascade/Bisector_BisecAna.hxx
// ./opencascade/Bisector_BisecCC.hxx
// ./opencascade/Bisector_BisecPC.hxx
// ./opencascade/Bisector_Curve.hxx
// ./opencascade/Bisector_FunctionH.hxx
// ./opencascade/Bisector_FunctionInter.hxx
// ./opencascade/Bisector_Inter.hxx
// ./opencascade/Bisector_PointOnBis.hxx
// ./opencascade/Bisector_PolyBis.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
