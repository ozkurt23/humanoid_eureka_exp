
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <CSLib.hxx>
#include <CSLib_Class2d.hxx>
#include <CSLib_DerivativeStatus.hxx>
#include <CSLib_NormalPolyDef.hxx>
#include <CSLib_NormalStatus.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_CSLib(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("CSLib"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class CSLib from ./opencascade/CSLib.hxx
    klass = m.attr("CSLib");

    // default constructor
    register_default_constructor<CSLib , shared_ptr<CSLib>>(m,"CSLib");

    // nested enums

    static_cast<py::class_<CSLib , shared_ptr<CSLib>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Normal_s",
                    (void (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  CSLib_DerivativeStatus & ,  gp_Dir &  ) ) static_cast<void (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  CSLib_DerivativeStatus & ,  gp_Dir &  ) >(&CSLib::Normal),
                    R"#(Computes the normal direction of a surface as the cross product D1U ^ D1V.)#"  , py::arg("theD1U"),  py::arg("theD1V"),  py::arg("theSinTol"),  py::arg("theStatus"),  py::arg("theNormal")
          )
        .def_static("Normal_s",
                    (void (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  CSLib_NormalStatus & ,  gp_Dir &  ) ) static_cast<void (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  CSLib_NormalStatus & ,  gp_Dir &  ) >(&CSLib::Normal),
                    R"#(Computes the normal direction using magnitude tolerance.)#"  , py::arg("theD1U"),  py::arg("theD1V"),  py::arg("theMagTol"),  py::arg("theStatus"),  py::arg("theNormal")
          )
        .def_static("DNNUV_s",
                    (gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> &  ) ) static_cast<gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> &  ) >(&CSLib::DNNUV),
                    R"#(Computes the derivative of order (theNu, theNv) of the non-normalized normal vector.)#"  , py::arg("theNu"),  py::arg("theNv"),  py::arg("theDerSurf")
          )
        .def_static("DNNUV_s",
                    (gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> & ,   const NCollection_Array2<gp_Vec> &  ) ) static_cast<gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> & ,   const NCollection_Array2<gp_Vec> &  ) >(&CSLib::DNNUV),
                    R"#(Computes the derivative of the non-normalized vector N = dS1/du ^ dS2/dv.)#"  , py::arg("theNu"),  py::arg("theNv"),  py::arg("theDerSurf1"),  py::arg("theDerSurf2")
          )
        .def_static("DNNormal_s",
                    (gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> & ,  int ,  int  ) ) static_cast<gp_Vec (*)( int ,  int ,   const NCollection_Array2<gp_Vec> & ,  int ,  int  ) >(&CSLib::DNNormal),
                    R"#(Computes the derivative of order (theNu, theNv) of the normalized normal vector.)#"  , py::arg("theNu"),  py::arg("theNv"),  py::arg("theDerNUV"),  py::arg("theIduref")=static_cast<int>(0),  py::arg("theIdvref")=static_cast<int>(0)
          )
    // static methods using call by reference i.s.o. return
        .def_static("Normal_s",
            []( const gp_Vec & theD1U, const gp_Vec & theD1V, const gp_Vec & theD2U, const gp_Vec & theD2V, const gp_Vec & theD2UV,double theSinTol,CSLib_NormalStatus & theStatus,gp_Dir & theNormal ){
                bool  theDone;

                CSLib::Normal(theD1U,theD1V,theD2U,theD2V,theD2UV,theSinTol,theDone,theStatus,theNormal);
                
return std::make_tuple(theDone); },
            R"#(Computes an approximate normal direction at a singular point using second derivatives.)#"  , py::arg("theD1U"),  py::arg("theD1V"),  py::arg("theD2U"),  py::arg("theD2V"),  py::arg("theD2UV"),  py::arg("theSinTol"),  py::arg("theStatus"),  py::arg("theNormal")
          )
        .def_static("Normal_s",
            [](int theMaxOrder, const NCollection_Array2<gp_Vec> & theDerNUV,double theMagTol,double theU,double theV,double theUmin,double theUmax,double theVmin,double theVmax,CSLib_NormalStatus & theStatus,gp_Dir & theNormal ){
                int  theOrderU;
                int  theOrderV;

                CSLib::Normal(theMaxOrder,theDerNUV,theMagTol,theU,theV,theUmin,theUmax,theVmin,theVmax,theStatus,theNormal,theOrderU,theOrderV);
                
return std::make_tuple(theOrderU,theOrderV); },
            R"#(Computes the normal at a singular point using higher-order derivatives.)#"  , py::arg("theMaxOrder"),  py::arg("theDerNUV"),  py::arg("theMagTol"),  py::arg("theU"),  py::arg("theV"),  py::arg("theUmin"),  py::arg("theUmax"),  py::arg("theVmin"),  py::arg("theVmax"),  py::arg("theStatus"),  py::arg("theNormal")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class CSLib_Class2d from ./opencascade/CSLib_Class2d.hxx
    klass = m.attr("CSLib_Class2d");


    // nested enums
        py::enum_<CSLib_Class2d::Result>(klass, "Result_e", R"#(Classification result for point-in-polygon tests.)#")
            .value("Result_Inside", CSLib_Class2d::Result::Result_Inside)
            .value("Result_Outside", CSLib_Class2d::Result::Result_Outside)
            .value("Result_Uncertain", CSLib_Class2d::Result::Result_Uncertain);

    static_cast<py::class_<CSLib_Class2d , shared_ptr<CSLib_Class2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Array1<gp_Pnt2d> &,double,double,double,double,double,double >()  , py::arg("thePnts2d"),  py::arg("theTolU"),  py::arg("theTolV"),  py::arg("theUMin"),  py::arg("theVMin"),  py::arg("theUMax"),  py::arg("theVMax") )
        .def(py::init<  const NCollection_DynamicArray<gp_Pnt2d> &,double,double,double,double,double,double >()  , py::arg("thePnts2d"),  py::arg("theTolU"),  py::arg("theTolV"),  py::arg("theUMin"),  py::arg("theVMin"),  py::arg("theUMax"),  py::arg("theVMax") )
        .def(py::init<  const NCollection_Sequence<gp_Pnt2d> &,double,double,double,double,double,double >()  , py::arg("thePnts2d"),  py::arg("theTolU"),  py::arg("theTolV"),  py::arg("theUMin"),  py::arg("theVMin"),  py::arg("theUMax"),  py::arg("theVMax") )
    // custom constructors
    // methods
        .def("SiDans",
             (CSLib_Class2d::Result (CSLib_Class2d::*)(  const gp_Pnt2d &  ) const) static_cast<CSLib_Class2d::Result (CSLib_Class2d::*)(  const gp_Pnt2d &  ) const>(&CSLib_Class2d::SiDans),
             R"#(Classifies a point relative to the polygon.)#"  , py::arg("thePoint")
          )
        .def("SiDans_OnMode",
             (CSLib_Class2d::Result (CSLib_Class2d::*)(  const gp_Pnt2d & ,  double  ) const) static_cast<CSLib_Class2d::Result (CSLib_Class2d::*)(  const gp_Pnt2d & ,  double  ) const>(&CSLib_Class2d::SiDans_OnMode),
             R"#(Classifies a point with explicit ON tolerance.)#"  , py::arg("thePoint"),  py::arg("theTol")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class CSLib_NormalPolyDef from ./opencascade/CSLib_NormalPolyDef.hxx
    klass = m.attr("CSLib_NormalPolyDef");


    // nested enums

    static_cast<py::class_<CSLib_NormalPolyDef , shared_ptr<CSLib_NormalPolyDef>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init< int, const NCollection_Array1<double> & >()  , py::arg("theK0"),  py::arg("theLi") )
    // custom constructors
    // methods
        .def("Value",
             (bool (CSLib_NormalPolyDef::*)(  const double ,  double &  ) ) static_cast<bool (CSLib_NormalPolyDef::*)(  const double ,  double &  ) >(&CSLib_NormalPolyDef::Value),
             R"#(Computes the value of the function for the given variable.)#"  , py::arg("theX"),  py::arg("theF")
          )
        .def("Derivative",
             (bool (CSLib_NormalPolyDef::*)(  const double ,  double &  ) ) static_cast<bool (CSLib_NormalPolyDef::*)(  const double ,  double &  ) >(&CSLib_NormalPolyDef::Derivative),
             R"#(Computes the derivative of the function for the given variable.)#"  , py::arg("theX"),  py::arg("theD")
          )
        .def("Values",
             (bool (CSLib_NormalPolyDef::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (CSLib_NormalPolyDef::*)(  const double ,  double & ,  double &  ) >(&CSLib_NormalPolyDef::Values),
             R"#(Computes both the value and derivative of the function.)#"  , py::arg("theX"),  py::arg("theF"),  py::arg("theD")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/CSLib.hxx
// ./opencascade/CSLib_Class2d.hxx
// ./opencascade/CSLib_DerivativeStatus.hxx
// ./opencascade/CSLib_NormalPolyDef.hxx
// ./opencascade/CSLib_NormalStatus.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
