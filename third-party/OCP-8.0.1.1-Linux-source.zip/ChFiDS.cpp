
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <ChFiDS_SurfData.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <TopoDS_Vertex.hxx>
#include <Law_Composite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Vertex.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <ChFiDS_Spine.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <ChFiDS_ChamfMethod.hxx>
#include <ChFiDS_ChamfMode.hxx>
#include <ChFiDS_ChamfSpine.hxx>
#include <ChFiDS_CircSection.hxx>
#include <ChFiDS_CommonPoint.hxx>
#include <ChFiDS_ElSpine.hxx>
#include <ChFiDS_ErrorStatus.hxx>
#include <ChFiDS_FaceInterference.hxx>
#include <ChFiDS_FilSpine.hxx>
#include <ChFiDS_Map.hxx>
#include <ChFiDS_Regul.hxx>
#include <ChFiDS_Spine.hxx>
#include <ChFiDS_State.hxx>
#include <ChFiDS_Stripe.hxx>
#include <ChFiDS_StripeMap.hxx>
#include <ChFiDS_SurfData.hxx>
#include <ChFiDS_TypeOfConcavity.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_ChFiDS(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("ChFiDS"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class ChFiDS_CircSection from ./opencascade/ChFiDS_CircSection.hxx
    klass = m.attr("ChFiDS_CircSection");


    // nested enums

    static_cast<py::class_<ChFiDS_CircSection , shared_ptr<ChFiDS_CircSection>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (ChFiDS_CircSection::*)(  const gp_Circ & ,   const double ,   const double  ) ) static_cast<void (ChFiDS_CircSection::*)(  const gp_Circ & ,   const double ,   const double  ) >(&ChFiDS_CircSection::Set),
             R"#()#"  , py::arg("C"),  py::arg("F"),  py::arg("L")
          )
        .def("Set",
             (void (ChFiDS_CircSection::*)(  const gp_Lin & ,   const double ,   const double  ) ) static_cast<void (ChFiDS_CircSection::*)(  const gp_Lin & ,   const double ,   const double  ) >(&ChFiDS_CircSection::Set),
             R"#()#"  , py::arg("C"),  py::arg("F"),  py::arg("L")
          )
    // methods using call by reference i.s.o. return
        .def("Get",
             []( ChFiDS_CircSection &self , gp_Circ & C ){
                 double  F;
                double  L;

                 self.Get(C,F,L);
                 return std::make_tuple(F,L); },
             R"#()#"  , py::arg("C")
          )
        .def("Get",
             []( ChFiDS_CircSection &self , gp_Lin & C ){
                 double  F;
                double  L;

                 self.Get(C,F,L);
                 return std::make_tuple(F,L); },
             R"#()#"  , py::arg("C")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class ChFiDS_CommonPoint from ./opencascade/ChFiDS_CommonPoint.hxx
    klass = m.attr("ChFiDS_CommonPoint");


    // nested enums

    static_cast<py::class_<ChFiDS_CommonPoint , shared_ptr<ChFiDS_CommonPoint>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Reset",
             (void (ChFiDS_CommonPoint::*)() ) static_cast<void (ChFiDS_CommonPoint::*)() >(&ChFiDS_CommonPoint::Reset),
             R"#(default value for all fields)#" 
          )
        .def("SetVertex",
             (void (ChFiDS_CommonPoint::*)(  const TopoDS_Vertex &  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const TopoDS_Vertex &  ) >(&ChFiDS_CommonPoint::SetVertex),
             R"#(Sets the values of a point which is a vertex on the initial facet of restriction of one of the surface.)#"  , py::arg("theVertex")
          )
        .def("SetArc",
             (void (ChFiDS_CommonPoint::*)(  const double ,   const TopoDS_Edge & ,   const double ,   const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const double ,   const TopoDS_Edge & ,   const double ,   const TopAbs_Orientation  ) >(&ChFiDS_CommonPoint::SetArc),
             R"#(Sets the values of a point which is on the arc A, at parameter Param.)#"  , py::arg("Tol"),  py::arg("A"),  py::arg("Param"),  py::arg("TArc")
          )
        .def("SetParameter",
             (void (ChFiDS_CommonPoint::*)(  const double  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const double  ) >(&ChFiDS_CommonPoint::SetParameter),
             R"#(Sets the value of the parameter on the spine)#"  , py::arg("Param")
          )
        .def("SetPoint",
             (void (ChFiDS_CommonPoint::*)(  const gp_Pnt &  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const gp_Pnt &  ) >(&ChFiDS_CommonPoint::SetPoint),
             R"#(Set the 3d point for a commonpoint that is not a vertex or on an arc.)#"  , py::arg("thePoint")
          )
        .def("SetVector",
             (void (ChFiDS_CommonPoint::*)(  const gp_Vec &  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const gp_Vec &  ) >(&ChFiDS_CommonPoint::SetVector),
             R"#(Set the output 3d vector)#"  , py::arg("theVector")
          )
        .def("SetTolerance",
             (void (ChFiDS_CommonPoint::*)(  const double  ) ) static_cast<void (ChFiDS_CommonPoint::*)(  const double  ) >(&ChFiDS_CommonPoint::SetTolerance),
             R"#(This method set the fuzziness on the point.)#"  , py::arg("Tol")
          )
        .def("Tolerance",
             (double (ChFiDS_CommonPoint::*)() const) static_cast<double (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Tolerance),
             R"#(This method returns the fuzziness on the point.)#" 
          )
        .def("IsVertex",
             (bool (ChFiDS_CommonPoint::*)() const) static_cast<bool (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::IsVertex),
             R"#(Returns TRUE if the point is a vertex on the initial restriction facet of the surface.)#" 
          )
        .def("IsOnArc",
             (bool (ChFiDS_CommonPoint::*)() const) static_cast<bool (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::IsOnArc),
             R"#(Returns TRUE if the point is a on an edge of the initial restriction facet of the surface.)#" 
          )
        .def("TransitionOnArc",
             (TopAbs_Orientation (ChFiDS_CommonPoint::*)() const) static_cast<TopAbs_Orientation (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::TransitionOnArc),
             R"#(Returns the transition of the point on the arc returned by Arc().)#" 
          )
        .def("ParameterOnArc",
             (double (ChFiDS_CommonPoint::*)() const) static_cast<double (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::ParameterOnArc),
             R"#(Returns the parameter of the point on the arc returned by the method Arc().)#" 
          )
        .def("Parameter",
             (double (ChFiDS_CommonPoint::*)() const) static_cast<double (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Parameter),
             R"#(Returns the parameter on the spine)#" 
          )
        .def("HasVector",
             (bool (ChFiDS_CommonPoint::*)() const) static_cast<bool (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::HasVector),
             R"#(Returns TRUE if the output vector is stored.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Vertex",
             ( const TopoDS_Vertex & (ChFiDS_CommonPoint::*)() const) static_cast< const TopoDS_Vertex & (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Vertex),
             R"#(Returns the information about the point when it is on the domain of the first patch, i-e when the function IsVertex returns True. Otherwise, an exception is raised.)#"
             
         )
       .def("Arc",
             ( const TopoDS_Edge & (ChFiDS_CommonPoint::*)() const) static_cast< const TopoDS_Edge & (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Arc),
             R"#(Returns the arc of restriction containing the vertex.)#"
             
         )
       .def("Point",
             ( const gp_Pnt & (ChFiDS_CommonPoint::*)() const) static_cast< const gp_Pnt & (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Point),
             R"#(Returns the 3d point)#"
             
         )
       .def("Vector",
             ( const gp_Vec & (ChFiDS_CommonPoint::*)() const) static_cast< const gp_Vec & (ChFiDS_CommonPoint::*)() const>(&ChFiDS_CommonPoint::Vector),
             R"#(Returns the output 3d vector)#"
             
         )
;

    // Class ChFiDS_ElSpine from ./opencascade/ChFiDS_ElSpine.hxx
    klass = m.attr("ChFiDS_ElSpine");


    // nested enums

    static_cast<py::class_<ChFiDS_ElSpine ,opencascade::handle<ChFiDS_ElSpine>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (ChFiDS_ElSpine::*)() const) static_cast<handle<Adaptor3d_Curve> (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("FirstParameter",
             (double (ChFiDS_ElSpine::*)() const) static_cast<double (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (ChFiDS_ElSpine::*)() const) static_cast<double (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::LastParameter),
             R"#()#" 
          )
        .def("GetSavedFirstParameter",
             (double (ChFiDS_ElSpine::*)() const) static_cast<double (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::GetSavedFirstParameter),
             R"#()#" 
          )
        .def("GetSavedLastParameter",
             (double (ChFiDS_ElSpine::*)() const) static_cast<double (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::GetSavedLastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (ChFiDS_ElSpine::*)() const) static_cast<GeomAbs_Shape (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (ChFiDS_ElSpine::*)(  const GeomAbs_Shape  ) const) static_cast<int (ChFiDS_ElSpine::*)(  const GeomAbs_Shape  ) const>(&ChFiDS_ElSpine::NbIntervals),
             R"#()#"  , py::arg("S")
          )
        .def("Intervals",
             (void (ChFiDS_ElSpine::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (ChFiDS_ElSpine::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&ChFiDS_ElSpine::Intervals),
             R"#()#"  , py::arg("T"),  py::arg("S")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (ChFiDS_ElSpine::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (ChFiDS_ElSpine::*)(  const double ,   const double ,   const double  ) const>(&ChFiDS_ElSpine::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion.)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("Resolution",
             (double (ChFiDS_ElSpine::*)(  const double  ) const) static_cast<double (ChFiDS_ElSpine::*)(  const double  ) const>(&ChFiDS_ElSpine::Resolution),
             R"#()#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (ChFiDS_ElSpine::*)() const) static_cast<GeomAbs_CurveType (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::GetType),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (ChFiDS_ElSpine::*)() const) static_cast<bool (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::IsPeriodic),
             R"#()#" 
          )
        .def("SetPeriodic",
             (void (ChFiDS_ElSpine::*)(  const bool  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const bool  ) >(&ChFiDS_ElSpine::SetPeriodic),
             R"#()#"  , py::arg("I")
          )
        .def("Period",
             (double (ChFiDS_ElSpine::*)() const) static_cast<double (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Period),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (ChFiDS_ElSpine::*)(  const double  ) const) static_cast<gp_Pnt (ChFiDS_ElSpine::*)(  const double  ) const>(&ChFiDS_ElSpine::EvalD0),
             R"#(Computes the point of parameter theAbsC on the curve.)#"  , py::arg("theAbsC")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (ChFiDS_ElSpine::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (ChFiDS_ElSpine::*)(  const double  ) const>(&ChFiDS_ElSpine::EvalD1),
             R"#(Computes the point and first derivative at parameter theAbsC.)#"  , py::arg("theAbsC")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (ChFiDS_ElSpine::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (ChFiDS_ElSpine::*)(  const double  ) const>(&ChFiDS_ElSpine::EvalD2),
             R"#(Computes the point and first two derivatives at parameter theAbsC.)#"  , py::arg("theAbsC")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (ChFiDS_ElSpine::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (ChFiDS_ElSpine::*)(  const double  ) const>(&ChFiDS_ElSpine::EvalD3),
             R"#(Computes the point and first three derivatives at parameter theAbsC.)#"  , py::arg("theAbsC")
          )
        .def("FirstParameter",
             (void (ChFiDS_ElSpine::*)(  const double  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const double  ) >(&ChFiDS_ElSpine::FirstParameter),
             R"#()#"  , py::arg("P")
          )
        .def("LastParameter",
             (void (ChFiDS_ElSpine::*)(  const double  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const double  ) >(&ChFiDS_ElSpine::LastParameter),
             R"#()#"  , py::arg("P")
          )
        .def("SaveFirstParameter",
             (void (ChFiDS_ElSpine::*)() ) static_cast<void (ChFiDS_ElSpine::*)() >(&ChFiDS_ElSpine::SaveFirstParameter),
             R"#()#" 
          )
        .def("SaveLastParameter",
             (void (ChFiDS_ElSpine::*)() ) static_cast<void (ChFiDS_ElSpine::*)() >(&ChFiDS_ElSpine::SaveLastParameter),
             R"#()#" 
          )
        .def("SetOrigin",
             (void (ChFiDS_ElSpine::*)(  const double  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const double  ) >(&ChFiDS_ElSpine::SetOrigin),
             R"#()#"  , py::arg("O")
          )
        .def("FirstPointAndTgt",
             (void (ChFiDS_ElSpine::*)( gp_Pnt & ,  gp_Vec &  ) const) static_cast<void (ChFiDS_ElSpine::*)( gp_Pnt & ,  gp_Vec &  ) const>(&ChFiDS_ElSpine::FirstPointAndTgt),
             R"#()#"  , py::arg("P"),  py::arg("T")
          )
        .def("LastPointAndTgt",
             (void (ChFiDS_ElSpine::*)( gp_Pnt & ,  gp_Vec &  ) const) static_cast<void (ChFiDS_ElSpine::*)( gp_Pnt & ,  gp_Vec &  ) const>(&ChFiDS_ElSpine::LastPointAndTgt),
             R"#()#"  , py::arg("P"),  py::arg("T")
          )
        .def("NbVertices",
             (int (ChFiDS_ElSpine::*)() const) static_cast<int (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::NbVertices),
             R"#()#" 
          )
        .def("VertexWithTangent",
             ( const gp_Ax1 & (ChFiDS_ElSpine::*)(  const int  ) const) static_cast< const gp_Ax1 & (ChFiDS_ElSpine::*)(  const int  ) const>(&ChFiDS_ElSpine::VertexWithTangent),
             R"#()#"  , py::arg("Index")
          )
        .def("SetFirstPointAndTgt",
             (void (ChFiDS_ElSpine::*)(  const gp_Pnt & ,   const gp_Vec &  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const gp_Pnt & ,   const gp_Vec &  ) >(&ChFiDS_ElSpine::SetFirstPointAndTgt),
             R"#()#"  , py::arg("P"),  py::arg("T")
          )
        .def("SetLastPointAndTgt",
             (void (ChFiDS_ElSpine::*)(  const gp_Pnt & ,   const gp_Vec &  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const gp_Pnt & ,   const gp_Vec &  ) >(&ChFiDS_ElSpine::SetLastPointAndTgt),
             R"#()#"  , py::arg("P"),  py::arg("T")
          )
        .def("AddVertexWithTangent",
             (void (ChFiDS_ElSpine::*)(  const gp_Ax1 &  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const gp_Ax1 &  ) >(&ChFiDS_ElSpine::AddVertexWithTangent),
             R"#()#"  , py::arg("anAx1")
          )
        .def("SetCurve",
             (void (ChFiDS_ElSpine::*)(  const handle<Geom_Curve> &  ) ) static_cast<void (ChFiDS_ElSpine::*)(  const handle<Geom_Curve> &  ) >(&ChFiDS_ElSpine::SetCurve),
             R"#()#"  , py::arg("C")
          )
        .def("Line",
             (gp_Lin (ChFiDS_ElSpine::*)() const) static_cast<gp_Lin (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (ChFiDS_ElSpine::*)() const) static_cast<gp_Circ (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (ChFiDS_ElSpine::*)() const) static_cast<gp_Elips (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (ChFiDS_ElSpine::*)() const) static_cast<gp_Hypr (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (ChFiDS_ElSpine::*)() const) static_cast<gp_Parab (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Parabola),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (ChFiDS_ElSpine::*)() const) static_cast<handle<Geom_BezierCurve> (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (ChFiDS_ElSpine::*)() const) static_cast<handle<Geom_BSplineCurve> (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::BSpline),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_ElSpine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_ElSpine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_ElSpine::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::DynamicType),
             R"#()#"
             
         )
       .def("Previous",
             ( const handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() const) static_cast< const handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Previous),
             R"#()#"
             
         )
       .def("ChangePrevious",
             (handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() ) static_cast<handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() >(&ChFiDS_ElSpine::ChangePrevious),
             R"#()#"
             
         )
       .def("Next",
             ( const handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() const) static_cast< const handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() const>(&ChFiDS_ElSpine::Next),
             R"#()#"
             
         )
       .def("ChangeNext",
             (handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() ) static_cast<handle<ChFiDS_SurfData> & (ChFiDS_ElSpine::*)() >(&ChFiDS_ElSpine::ChangeNext),
             R"#()#"
             
         )
;

    // Class ChFiDS_FaceInterference from ./opencascade/ChFiDS_FaceInterference.hxx
    klass = m.attr("ChFiDS_FaceInterference");


    // nested enums

    static_cast<py::class_<ChFiDS_FaceInterference , shared_ptr<ChFiDS_FaceInterference>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetInterference",
             (void (ChFiDS_FaceInterference::*)(  const int ,   const TopAbs_Orientation ,   const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> &  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const int ,   const TopAbs_Orientation ,   const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> &  ) >(&ChFiDS_FaceInterference::SetInterference),
             R"#()#"  , py::arg("LineIndex"),  py::arg("Trans"),  py::arg("PCurv1"),  py::arg("PCurv2")
          )
        .def("SetTransition",
             (void (ChFiDS_FaceInterference::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const TopAbs_Orientation  ) >(&ChFiDS_FaceInterference::SetTransition),
             R"#()#"  , py::arg("Trans")
          )
        .def("SetFirstParameter",
             (void (ChFiDS_FaceInterference::*)(  const double  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const double  ) >(&ChFiDS_FaceInterference::SetFirstParameter),
             R"#()#"  , py::arg("U1")
          )
        .def("SetLastParameter",
             (void (ChFiDS_FaceInterference::*)(  const double  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const double  ) >(&ChFiDS_FaceInterference::SetLastParameter),
             R"#()#"  , py::arg("U1")
          )
        .def("SetParameter",
             (void (ChFiDS_FaceInterference::*)(  const double ,   const bool  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const double ,   const bool  ) >(&ChFiDS_FaceInterference::SetParameter),
             R"#()#"  , py::arg("U1"),  py::arg("IsFirst")
          )
        .def("LineIndex",
             (int (ChFiDS_FaceInterference::*)() const) static_cast<int (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::LineIndex),
             R"#()#" 
          )
        .def("SetLineIndex",
             (void (ChFiDS_FaceInterference::*)(  const int  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const int  ) >(&ChFiDS_FaceInterference::SetLineIndex),
             R"#()#"  , py::arg("I")
          )
        .def("Transition",
             (TopAbs_Orientation (ChFiDS_FaceInterference::*)() const) static_cast<TopAbs_Orientation (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::Transition),
             R"#()#" 
          )
        .def("FirstParameter",
             (double (ChFiDS_FaceInterference::*)() const) static_cast<double (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (ChFiDS_FaceInterference::*)() const) static_cast<double (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::LastParameter),
             R"#()#" 
          )
        .def("Parameter",
             (double (ChFiDS_FaceInterference::*)(  const bool  ) const) static_cast<double (ChFiDS_FaceInterference::*)(  const bool  ) const>(&ChFiDS_FaceInterference::Parameter),
             R"#()#"  , py::arg("IsFirst")
          )
        .def("SetInterference",
             (void (ChFiDS_FaceInterference::*)(  const int ,   const TopAbs_Orientation ,   const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> &  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const int ,   const TopAbs_Orientation ,   const handle<Geom2d_Curve> & ,   const handle<Geom2d_Curve> &  ) >(&ChFiDS_FaceInterference::SetInterference),
             R"#()#"  , py::arg("LineIndex"),  py::arg("Trans"),  py::arg("PCurv1"),  py::arg("PCurv2")
          )
        .def("SetLineIndex",
             (void (ChFiDS_FaceInterference::*)(  const int  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const int  ) >(&ChFiDS_FaceInterference::SetLineIndex),
             R"#()#"  , py::arg("I")
          )
        .def("SetFirstParameter",
             (void (ChFiDS_FaceInterference::*)(  const double  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const double  ) >(&ChFiDS_FaceInterference::SetFirstParameter),
             R"#()#"  , py::arg("U1")
          )
        .def("SetLastParameter",
             (void (ChFiDS_FaceInterference::*)(  const double  ) ) static_cast<void (ChFiDS_FaceInterference::*)(  const double  ) >(&ChFiDS_FaceInterference::SetLastParameter),
             R"#()#"  , py::arg("U1")
          )
        .def("LineIndex",
             (int (ChFiDS_FaceInterference::*)() const) static_cast<int (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::LineIndex),
             R"#()#" 
          )
        .def("Transition",
             (TopAbs_Orientation (ChFiDS_FaceInterference::*)() const) static_cast<TopAbs_Orientation (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::Transition),
             R"#()#" 
          )
        .def("FirstParameter",
             (double (ChFiDS_FaceInterference::*)() const) static_cast<double (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (ChFiDS_FaceInterference::*)() const) static_cast<double (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::LastParameter),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PCurveOnFace",
             ( const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::PCurveOnFace),
             R"#()#"
             
         )
       .def("PCurveOnSurf",
             ( const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::PCurveOnSurf),
             R"#()#"
             
         )
       .def("ChangePCurveOnFace",
             (handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() >(&ChFiDS_FaceInterference::ChangePCurveOnFace),
             R"#()#"
             
         )
       .def("ChangePCurveOnSurf",
             (handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() >(&ChFiDS_FaceInterference::ChangePCurveOnSurf),
             R"#()#"
             
         )
       .def("PCurveOnFace",
             ( const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::PCurveOnFace),
             R"#()#"
             
         )
       .def("PCurveOnSurf",
             ( const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() const>(&ChFiDS_FaceInterference::PCurveOnSurf),
             R"#()#"
             
         )
       .def("ChangePCurveOnFace",
             (handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() >(&ChFiDS_FaceInterference::ChangePCurveOnFace),
             R"#()#"
             
         )
       .def("ChangePCurveOnSurf",
             (handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_FaceInterference::*)() >(&ChFiDS_FaceInterference::ChangePCurveOnSurf),
             R"#()#"
             
         )
;

    // Class ChFiDS_Map from ./opencascade/ChFiDS_Map.hxx
    klass = m.attr("ChFiDS_Map");


    // nested enums

    static_cast<py::class_<ChFiDS_Map , shared_ptr<ChFiDS_Map>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Fill",
             (void (ChFiDS_Map::*)(  const TopoDS_Shape & ,   const TopAbs_ShapeEnum ,   const TopAbs_ShapeEnum  ) ) static_cast<void (ChFiDS_Map::*)(  const TopoDS_Shape & ,   const TopAbs_ShapeEnum ,   const TopAbs_ShapeEnum  ) >(&ChFiDS_Map::Fill),
             R"#(Fills the map with the subshapes of type T1 as keys and the list of ancestors of type T2 as items.)#"  , py::arg("S"),  py::arg("T1"),  py::arg("T2")
          )
        .def("Contains",
             (bool (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const) static_cast<bool (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const>(&ChFiDS_Map::Contains),
             R"#()#"  , py::arg("S")
          )
        .def("FindFromKey",
             ( const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const) static_cast< const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const>(&ChFiDS_Map::FindFromKey),
             R"#()#"  , py::arg("S")
          )
        .def("FindFromIndex",
             ( const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const int  ) const) static_cast< const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const int  ) const>(&ChFiDS_Map::FindFromIndex),
             R"#()#"  , py::arg("I")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             ( const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const) static_cast< const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const TopoDS_Shape &  ) const>(&ChFiDS_Map::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("S")
          )
        .def("__call__",
             ( const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const int  ) const) static_cast< const NCollection_List<TopoDS_Shape> & (ChFiDS_Map::*)(  const int  ) const>(&ChFiDS_Map::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("I")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class ChFiDS_Regul from ./opencascade/ChFiDS_Regul.hxx
    klass = m.attr("ChFiDS_Regul");


    // nested enums

    static_cast<py::class_<ChFiDS_Regul , shared_ptr<ChFiDS_Regul>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetCurve",
             (void (ChFiDS_Regul::*)(  const int  ) ) static_cast<void (ChFiDS_Regul::*)(  const int  ) >(&ChFiDS_Regul::SetCurve),
             R"#()#"  , py::arg("IC")
          )
        .def("SetS1",
             (void (ChFiDS_Regul::*)(  const int ,   const bool  ) ) static_cast<void (ChFiDS_Regul::*)(  const int ,   const bool  ) >(&ChFiDS_Regul::SetS1),
             R"#()#"  , py::arg("IS1"),  py::arg("IsFace")=static_cast< const bool>(true)
          )
        .def("SetS2",
             (void (ChFiDS_Regul::*)(  const int ,   const bool  ) ) static_cast<void (ChFiDS_Regul::*)(  const int ,   const bool  ) >(&ChFiDS_Regul::SetS2),
             R"#()#"  , py::arg("IS2"),  py::arg("IsFace")=static_cast< const bool>(true)
          )
        .def("IsSurface1",
             (bool (ChFiDS_Regul::*)() const) static_cast<bool (ChFiDS_Regul::*)() const>(&ChFiDS_Regul::IsSurface1),
             R"#()#" 
          )
        .def("IsSurface2",
             (bool (ChFiDS_Regul::*)() const) static_cast<bool (ChFiDS_Regul::*)() const>(&ChFiDS_Regul::IsSurface2),
             R"#()#" 
          )
        .def("Curve",
             (int (ChFiDS_Regul::*)() const) static_cast<int (ChFiDS_Regul::*)() const>(&ChFiDS_Regul::Curve),
             R"#()#" 
          )
        .def("S1",
             (int (ChFiDS_Regul::*)() const) static_cast<int (ChFiDS_Regul::*)() const>(&ChFiDS_Regul::S1),
             R"#()#" 
          )
        .def("S2",
             (int (ChFiDS_Regul::*)() const) static_cast<int (ChFiDS_Regul::*)() const>(&ChFiDS_Regul::S2),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class ChFiDS_Spine from ./opencascade/ChFiDS_Spine.hxx
    klass = m.attr("ChFiDS_Spine");


    // nested enums

    static_cast<py::class_<ChFiDS_Spine ,opencascade::handle<ChFiDS_Spine>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double >()  , py::arg("Tol") )
    // custom constructors
    // methods
        .def("SetEdges",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::SetEdges),
             R"#(store edges composing the guideline)#"  , py::arg("E")
          )
        .def("SetOffsetEdges",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::SetOffsetEdges),
             R"#(store offset edges composing the offset guideline)#"  , py::arg("E")
          )
        .def("PutInFirst",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::PutInFirst),
             R"#(store the edge at the first position before all others)#"  , py::arg("E")
          )
        .def("PutInFirstOffset",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::PutInFirstOffset),
             R"#(store the offset edge at the first position before all others)#"  , py::arg("E")
          )
        .def("NbEdges",
             (int (ChFiDS_Spine::*)() const) static_cast<int (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::NbEdges),
             R"#()#" 
          )
        .def("Edges",
             ( const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const) static_cast< const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::Edges),
             R"#()#"  , py::arg("I")
          )
        .def("OffsetEdges",
             ( const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const) static_cast< const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::OffsetEdges),
             R"#()#"  , py::arg("I")
          )
        .def("SetFirstStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State  ) >(&ChFiDS_Spine::SetFirstStatus),
             R"#(stores if the start of a set of edges starts on a section of free border or forms a closed contour)#"  , py::arg("S")
          )
        .def("SetLastStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State  ) >(&ChFiDS_Spine::SetLastStatus),
             R"#(stores if the end of a set of edges starts on a section of free border or forms a closed contour)#"  , py::arg("S")
          )
        .def("AppendElSpine",
             (void (ChFiDS_Spine::*)(  const handle<ChFiDS_ElSpine> &  ) ) static_cast<void (ChFiDS_Spine::*)(  const handle<ChFiDS_ElSpine> &  ) >(&ChFiDS_Spine::AppendElSpine),
             R"#()#"  , py::arg("Els")
          )
        .def("AppendOffsetElSpine",
             (void (ChFiDS_Spine::*)(  const handle<ChFiDS_ElSpine> &  ) ) static_cast<void (ChFiDS_Spine::*)(  const handle<ChFiDS_ElSpine> &  ) >(&ChFiDS_Spine::AppendOffsetElSpine),
             R"#()#"  , py::arg("Els")
          )
        .def("ElSpine",
             (handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const int  ) const) static_cast<handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::ElSpine),
             R"#()#"  , py::arg("IE")
          )
        .def("ElSpine",
             (handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) const) static_cast<handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) const>(&ChFiDS_Spine::ElSpine),
             R"#()#"  , py::arg("E")
          )
        .def("ElSpine",
             (handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const double  ) const) static_cast<handle<ChFiDS_ElSpine> (ChFiDS_Spine::*)(  const double  ) const>(&ChFiDS_Spine::ElSpine),
             R"#()#"  , py::arg("W")
          )
        .def("Reset",
             (void (ChFiDS_Spine::*)(  const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const bool  ) >(&ChFiDS_Spine::Reset),
             R"#()#"  , py::arg("AllData")=static_cast< const bool>(false)
          )
        .def("SplitDone",
             (bool (ChFiDS_Spine::*)() const) static_cast<bool (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::SplitDone),
             R"#()#" 
          )
        .def("SplitDone",
             (void (ChFiDS_Spine::*)(  const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const bool  ) >(&ChFiDS_Spine::SplitDone),
             R"#()#"  , py::arg("B")
          )
        .def("Load",
             (void (ChFiDS_Spine::*)() ) static_cast<void (ChFiDS_Spine::*)() >(&ChFiDS_Spine::Load),
             R"#(prepare the guideline depending on the edges that are elementary arks (take parameters from a single curvilinear abscissa); to be able to call methods on the geometry (first,last,value,d1,d2) it is necessary to start with preparation otherwise an exception will be raised)#" 
          )
        .def("Resolution",
             (double (ChFiDS_Spine::*)(  const double  ) const) static_cast<double (ChFiDS_Spine::*)(  const double  ) const>(&ChFiDS_Spine::Resolution),
             R"#()#"  , py::arg("R3d")
          )
        .def("IsClosed",
             (bool (ChFiDS_Spine::*)() const) static_cast<bool (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::IsClosed),
             R"#()#" 
          )
        .def("FirstParameter",
             (double (ChFiDS_Spine::*)() const) static_cast<double (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (ChFiDS_Spine::*)() const) static_cast<double (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::LastParameter),
             R"#()#" 
          )
        .def("SetFirstParameter",
             (void (ChFiDS_Spine::*)(  const double  ) ) static_cast<void (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::SetFirstParameter),
             R"#()#"  , py::arg("Par")
          )
        .def("SetLastParameter",
             (void (ChFiDS_Spine::*)(  const double  ) ) static_cast<void (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::SetLastParameter),
             R"#()#"  , py::arg("Par")
          )
        .def("FirstParameter",
             (double (ChFiDS_Spine::*)(  const int  ) const) static_cast<double (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::FirstParameter),
             R"#(gives the total length of all arcs before the number IndexSp)#"  , py::arg("IndexSpine")
          )
        .def("LastParameter",
             (double (ChFiDS_Spine::*)(  const int  ) const) static_cast<double (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::LastParameter),
             R"#(gives the total length till the ark with number IndexSpine (inclus))#"  , py::arg("IndexSpine")
          )
        .def("Length",
             (double (ChFiDS_Spine::*)(  const int  ) const) static_cast<double (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::Length),
             R"#(gives the length of ark with number IndexSp)#"  , py::arg("IndexSpine")
          )
        .def("IsPeriodic",
             (bool (ChFiDS_Spine::*)() const) static_cast<bool (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (ChFiDS_Spine::*)() const) static_cast<double (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::Period),
             R"#()#" 
          )
        .def("Absc",
             (double (ChFiDS_Spine::*)(  const double  ) ) static_cast<double (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::Absc),
             R"#()#"  , py::arg("U")
          )
        .def("Absc",
             (double (ChFiDS_Spine::*)(  const double ,   const int  ) ) static_cast<double (ChFiDS_Spine::*)(  const double ,   const int  ) >(&ChFiDS_Spine::Absc),
             R"#()#"  , py::arg("U"),  py::arg("I")
          )
        .def("Value",
             (gp_Pnt (ChFiDS_Spine::*)(  const double  ) ) static_cast<gp_Pnt (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::Value),
             R"#()#"  , py::arg("AbsC")
          )
        .def("D0",
             (void (ChFiDS_Spine::*)(  const double ,  gp_Pnt &  ) ) static_cast<void (ChFiDS_Spine::*)(  const double ,  gp_Pnt &  ) >(&ChFiDS_Spine::D0),
             R"#()#"  , py::arg("AbsC"),  py::arg("P")
          )
        .def("D1",
             (void (ChFiDS_Spine::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) ) static_cast<void (ChFiDS_Spine::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) >(&ChFiDS_Spine::D1),
             R"#()#"  , py::arg("AbsC"),  py::arg("P"),  py::arg("V1")
          )
        .def("D2",
             (void (ChFiDS_Spine::*)(  const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (ChFiDS_Spine::*)(  const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&ChFiDS_Spine::D2),
             R"#()#"  , py::arg("AbsC"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def("SetCurrent",
             (void (ChFiDS_Spine::*)(  const int  ) ) static_cast<void (ChFiDS_Spine::*)(  const int  ) >(&ChFiDS_Spine::SetCurrent),
             R"#()#"  , py::arg("Index")
          )
        .def("CurrentElementarySpine",
             ( const BRepAdaptor_Curve & (ChFiDS_Spine::*)(  const int  ) ) static_cast< const BRepAdaptor_Curve & (ChFiDS_Spine::*)(  const int  ) >(&ChFiDS_Spine::CurrentElementarySpine),
             R"#(sets the current curve and returns it)#"  , py::arg("Index")
          )
        .def("CurrentIndexOfElementarySpine",
             (int (ChFiDS_Spine::*)() const) static_cast<int (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::CurrentIndexOfElementarySpine),
             R"#()#" 
          )
        .def("GetType",
             (GeomAbs_CurveType (ChFiDS_Spine::*)() const) static_cast<GeomAbs_CurveType (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::GetType),
             R"#()#" 
          )
        .def("Line",
             (gp_Lin (ChFiDS_Spine::*)() const) static_cast<gp_Lin (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (ChFiDS_Spine::*)() const) static_cast<gp_Circ (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::Circle),
             R"#()#" 
          )
        .def("FirstStatus",
             (ChFiDS_State (ChFiDS_Spine::*)() const) static_cast<ChFiDS_State (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::FirstStatus),
             R"#(returns if the set of edges starts on a free boundary or if the first vertex is a breakpoint or if the set is closed)#" 
          )
        .def("LastStatus",
             (ChFiDS_State (ChFiDS_Spine::*)() const) static_cast<ChFiDS_State (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::LastStatus),
             R"#(returns the state at the end of the set)#" 
          )
        .def("Status",
             (ChFiDS_State (ChFiDS_Spine::*)(  const bool  ) const) static_cast<ChFiDS_State (ChFiDS_Spine::*)(  const bool  ) const>(&ChFiDS_Spine::Status),
             R"#()#"  , py::arg("IsFirst")
          )
        .def("GetTypeOfConcavity",
             (ChFiDS_TypeOfConcavity (ChFiDS_Spine::*)() const) static_cast<ChFiDS_TypeOfConcavity (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::GetTypeOfConcavity),
             R"#(returns the type of concavity in the connection)#" 
          )
        .def("SetStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State ,   const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State ,   const bool  ) >(&ChFiDS_Spine::SetStatus),
             R"#()#"  , py::arg("S"),  py::arg("IsFirst")
          )
        .def("SetTypeOfConcavity",
             (void (ChFiDS_Spine::*)(  const ChFiDS_TypeOfConcavity  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_TypeOfConcavity  ) >(&ChFiDS_Spine::SetTypeOfConcavity),
             R"#(sets the type of concavity in the connection)#"  , py::arg("theType")
          )
        .def("IsTangencyExtremity",
             (bool (ChFiDS_Spine::*)(  const bool  ) const) static_cast<bool (ChFiDS_Spine::*)(  const bool  ) const>(&ChFiDS_Spine::IsTangencyExtremity),
             R"#(returns if the set of edges starts (or end) on Tangency point.)#"  , py::arg("IsFirst")
          )
        .def("SetTangencyExtremity",
             (void (ChFiDS_Spine::*)(  const bool ,   const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const bool ,   const bool  ) >(&ChFiDS_Spine::SetTangencyExtremity),
             R"#()#"  , py::arg("IsTangency"),  py::arg("IsFirst")
          )
        .def("Absc",
             (double (ChFiDS_Spine::*)(  const TopoDS_Vertex &  ) const) static_cast<double (ChFiDS_Spine::*)(  const TopoDS_Vertex &  ) const>(&ChFiDS_Spine::Absc),
             R"#()#"  , py::arg("V")
          )
        .def("FirstVertex",
             (TopoDS_Vertex (ChFiDS_Spine::*)() const) static_cast<TopoDS_Vertex (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::FirstVertex),
             R"#()#" 
          )
        .def("LastVertex",
             (TopoDS_Vertex (ChFiDS_Spine::*)() const) static_cast<TopoDS_Vertex (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::LastVertex),
             R"#()#" 
          )
        .def("SetFirstTgt",
             (void (ChFiDS_Spine::*)(  const double  ) ) static_cast<void (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::SetFirstTgt),
             R"#()#"  , py::arg("W")
          )
        .def("SetLastTgt",
             (void (ChFiDS_Spine::*)(  const double  ) ) static_cast<void (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::SetLastTgt),
             R"#()#"  , py::arg("W")
          )
        .def("HasFirstTgt",
             (bool (ChFiDS_Spine::*)() const) static_cast<bool (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::HasFirstTgt),
             R"#()#" 
          )
        .def("HasLastTgt",
             (bool (ChFiDS_Spine::*)() const) static_cast<bool (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::HasLastTgt),
             R"#()#" 
          )
        .def("SetReference",
             (void (ChFiDS_Spine::*)(  const double  ) ) static_cast<void (ChFiDS_Spine::*)(  const double  ) >(&ChFiDS_Spine::SetReference),
             R"#(set a parameter reference for the approx.)#"  , py::arg("W")
          )
        .def("SetReference",
             (void (ChFiDS_Spine::*)(  const int  ) ) static_cast<void (ChFiDS_Spine::*)(  const int  ) >(&ChFiDS_Spine::SetReference),
             R"#(set a parameter reference for the approx, at the middle of edge I.)#"  , py::arg("I")
          )
        .def("Index",
             (int (ChFiDS_Spine::*)(  const double ,   const bool  ) const) static_cast<int (ChFiDS_Spine::*)(  const double ,   const bool  ) const>(&ChFiDS_Spine::Index),
             R"#()#"  , py::arg("W"),  py::arg("Forward")=static_cast< const bool>(true)
          )
        .def("Index",
             (int (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) const) static_cast<int (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) const>(&ChFiDS_Spine::Index),
             R"#()#"  , py::arg("E")
          )
        .def("UnsetReference",
             (void (ChFiDS_Spine::*)() ) static_cast<void (ChFiDS_Spine::*)() >(&ChFiDS_Spine::UnsetReference),
             R"#()#" 
          )
        .def("SetErrorStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_ErrorStatus  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_ErrorStatus  ) >(&ChFiDS_Spine::SetErrorStatus),
             R"#()#"  , py::arg("state")
          )
        .def("ErrorStatus",
             (ChFiDS_ErrorStatus (ChFiDS_Spine::*)() const) static_cast<ChFiDS_ErrorStatus (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::ErrorStatus),
             R"#()#" 
          )
        .def("Mode",
             (ChFiDS_ChamfMode (ChFiDS_Spine::*)() const) static_cast<ChFiDS_ChamfMode (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::Mode),
             R"#(Return the mode of chamfers used)#" 
          )
        .def("GetTolesp",
             (double (ChFiDS_Spine::*)() const) static_cast<double (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::GetTolesp),
             R"#(Return tolesp parameter)#" 
          )
        .def("SetTypeOfConcavity",
             (void (ChFiDS_Spine::*)(  const ChFiDS_TypeOfConcavity  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_TypeOfConcavity  ) >(&ChFiDS_Spine::SetTypeOfConcavity),
             R"#(sets the type of concavity in the connection)#"  , py::arg("theType")
          )
        .def("SetFirstStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State  ) >(&ChFiDS_Spine::SetFirstStatus),
             R"#(stores if the start of a set of edges starts on a section of free border or forms a closed contour)#"  , py::arg("S")
          )
        .def("SetLastStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State  ) >(&ChFiDS_Spine::SetLastStatus),
             R"#(stores if the end of a set of edges starts on a section of free border or forms a closed contour)#"  , py::arg("S")
          )
        .def("GetTypeOfConcavity",
             (ChFiDS_TypeOfConcavity (ChFiDS_Spine::*)() const) static_cast<ChFiDS_TypeOfConcavity (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::GetTypeOfConcavity),
             R"#(returns the type of concavity in the connection)#" 
          )
        .def("FirstStatus",
             (ChFiDS_State (ChFiDS_Spine::*)() const) static_cast<ChFiDS_State (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::FirstStatus),
             R"#(returns if the set of edges starts on a free boundary or if the first vertex is a breakpoint or if the set is closed)#" 
          )
        .def("LastStatus",
             (ChFiDS_State (ChFiDS_Spine::*)() const) static_cast<ChFiDS_State (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::LastStatus),
             R"#(returns the state at the end of the set)#" 
          )
        .def("SetStatus",
             (void (ChFiDS_Spine::*)(  const ChFiDS_State ,   const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const ChFiDS_State ,   const bool  ) >(&ChFiDS_Spine::SetStatus),
             R"#()#"  , py::arg("S"),  py::arg("IsFirst")
          )
        .def("Status",
             (ChFiDS_State (ChFiDS_Spine::*)(  const bool  ) const) static_cast<ChFiDS_State (ChFiDS_Spine::*)(  const bool  ) const>(&ChFiDS_Spine::Status),
             R"#()#"  , py::arg("IsFirst")
          )
        .def("SetTangencyExtremity",
             (void (ChFiDS_Spine::*)(  const bool ,   const bool  ) ) static_cast<void (ChFiDS_Spine::*)(  const bool ,   const bool  ) >(&ChFiDS_Spine::SetTangencyExtremity),
             R"#()#"  , py::arg("IsTangency"),  py::arg("IsFirst")
          )
        .def("IsTangencyExtremity",
             (bool (ChFiDS_Spine::*)(  const bool  ) const) static_cast<bool (ChFiDS_Spine::*)(  const bool  ) const>(&ChFiDS_Spine::IsTangencyExtremity),
             R"#(returns if the set of edges starts (or end) on Tangency point.)#"  , py::arg("IsFirst")
          )
        .def("NbEdges",
             (int (ChFiDS_Spine::*)() const) static_cast<int (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::NbEdges),
             R"#()#" 
          )
        .def("Edges",
             ( const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const) static_cast< const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::Edges),
             R"#()#"  , py::arg("I")
          )
        .def("OffsetEdges",
             ( const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const) static_cast< const TopoDS_Edge & (ChFiDS_Spine::*)(  const int  ) const>(&ChFiDS_Spine::OffsetEdges),
             R"#()#"  , py::arg("I")
          )
        .def("SetEdges",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::SetEdges),
             R"#(store edges composing the guideline)#"  , py::arg("E")
          )
        .def("SetOffsetEdges",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::SetOffsetEdges),
             R"#(store offset edges composing the offset guideline)#"  , py::arg("E")
          )
        .def("PutInFirst",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::PutInFirst),
             R"#(store the edge at the first position before all others)#"  , py::arg("E")
          )
        .def("PutInFirstOffset",
             (void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_Spine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_Spine::PutInFirstOffset),
             R"#(store the offset edge at the first position before all others)#"  , py::arg("E")
          )
        .def("CurrentIndexOfElementarySpine",
             (int (ChFiDS_Spine::*)() const) static_cast<int (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::CurrentIndexOfElementarySpine),
             R"#()#" 
          )
        .def("Mode",
             (ChFiDS_ChamfMode (ChFiDS_Spine::*)() const) static_cast<ChFiDS_ChamfMode (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::Mode),
             R"#(Return the mode of chamfers used)#" 
          )
        .def("GetTolesp",
             (double (ChFiDS_Spine::*)() const) static_cast<double (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::GetTolesp),
             R"#(Return tolesp parameter)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Parameter",
             []( ChFiDS_Spine &self ,  const double AbsC, const bool Oriented ){
                 double  U;

                 self.Parameter(AbsC,U,Oriented);
                 return std::make_tuple(U); },
             R"#()#"  , py::arg("AbsC"),  py::arg("Oriented")=static_cast< const bool>(true)
          )
        .def("Parameter",
             []( ChFiDS_Spine &self ,  const int Index, const double AbsC, const bool Oriented ){
                 double  U;

                 self.Parameter(Index,AbsC,U,Oriented);
                 return std::make_tuple(U); },
             R"#()#"  , py::arg("Index"),  py::arg("AbsC"),  py::arg("Oriented")=static_cast< const bool>(true)
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_Spine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_Spine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ChangeElSpines",
             (NCollection_List<handle<ChFiDS_ElSpine>> & (ChFiDS_Spine::*)() ) static_cast<NCollection_List<handle<ChFiDS_ElSpine>> & (ChFiDS_Spine::*)() >(&ChFiDS_Spine::ChangeElSpines),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeOffsetElSpines",
             (NCollection_List<handle<ChFiDS_ElSpine>> & (ChFiDS_Spine::*)() ) static_cast<NCollection_List<handle<ChFiDS_ElSpine>> & (ChFiDS_Spine::*)() >(&ChFiDS_Spine::ChangeOffsetElSpines),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_Spine::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_Spine::*)() const>(&ChFiDS_Spine::DynamicType),
             R"#()#"
             
         )
;

    // Class ChFiDS_Stripe from ./opencascade/ChFiDS_Stripe.hxx
    klass = m.attr("ChFiDS_Stripe");


    // nested enums

    static_cast<py::class_<ChFiDS_Stripe ,opencascade::handle<ChFiDS_Stripe>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Reset",
             (void (ChFiDS_Stripe::*)() ) static_cast<void (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::Reset),
             R"#(Reset everything except Spine.)#" 
          )
        .def("OrientationOnFace1",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::OrientationOnFace1),
             R"#()#" 
          )
        .def("OrientationOnFace2",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::OrientationOnFace2),
             R"#()#" 
          )
        .def("Choix",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::Choix),
             R"#()#" 
          )
        .def("OrientationOnFace1",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::OrientationOnFace1),
             R"#()#"  , py::arg("Or1")
          )
        .def("OrientationOnFace2",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::OrientationOnFace2),
             R"#()#"  , py::arg("Or2")
          )
        .def("Choix",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::Choix),
             R"#()#"  , py::arg("C")
          )
        .def("ChangeFirstParameters",
             (void (ChFiDS_Stripe::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_Stripe::*)(  const double ,   const double  ) >(&ChFiDS_Stripe::ChangeFirstParameters),
             R"#()#"  , py::arg("Pdeb"),  py::arg("Pfin")
          )
        .def("ChangeLastParameters",
             (void (ChFiDS_Stripe::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_Stripe::*)(  const double ,   const double  ) >(&ChFiDS_Stripe::ChangeLastParameters),
             R"#()#"  , py::arg("Pdeb"),  py::arg("Pfin")
          )
        .def("FirstCurve",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstCurve),
             R"#()#" 
          )
        .def("LastCurve",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastCurve),
             R"#()#" 
          )
        .def("ChangeFirstCurve",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeFirstCurve),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeLastCurve",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeLastCurve),
             R"#()#"  , py::arg("Index")
          )
        .def("FirstPCurveOrientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstPCurveOrientation),
             R"#()#" 
          )
        .def("LastPCurveOrientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastPCurveOrientation),
             R"#()#" 
          )
        .def("FirstPCurveOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::FirstPCurveOrientation),
             R"#()#"  , py::arg("O")
          )
        .def("LastPCurveOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::LastPCurveOrientation),
             R"#()#"  , py::arg("O")
          )
        .def("IndexFirstPointOnS1",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexFirstPointOnS1),
             R"#()#" 
          )
        .def("IndexFirstPointOnS2",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexFirstPointOnS2),
             R"#()#" 
          )
        .def("IndexLastPointOnS1",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexLastPointOnS1),
             R"#()#" 
          )
        .def("IndexLastPointOnS2",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexLastPointOnS2),
             R"#()#" 
          )
        .def("ChangeIndexFirstPointOnS1",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexFirstPointOnS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexFirstPointOnS2",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexFirstPointOnS2),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexLastPointOnS1",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexLastPointOnS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexLastPointOnS2",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexLastPointOnS2),
             R"#()#"  , py::arg("Index")
          )
        .def("SetParameters",
             (void (ChFiDS_Stripe::*)(  const bool ,   const double ,   const double  ) ) static_cast<void (ChFiDS_Stripe::*)(  const bool ,   const double ,   const double  ) >(&ChFiDS_Stripe::SetParameters),
             R"#()#"  , py::arg("First"),  py::arg("Pdeb"),  py::arg("Pfin")
          )
        .def("Curve",
             (int (ChFiDS_Stripe::*)(  const bool  ) const) static_cast<int (ChFiDS_Stripe::*)(  const bool  ) const>(&ChFiDS_Stripe::Curve),
             R"#()#"  , py::arg("First")
          )
        .def("SetCurve",
             (void (ChFiDS_Stripe::*)(  const int ,   const bool  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int ,   const bool  ) >(&ChFiDS_Stripe::SetCurve),
             R"#()#"  , py::arg("Index"),  py::arg("First")
          )
        .def("PCurve",
             ( const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)(  const bool  ) const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)(  const bool  ) const>(&ChFiDS_Stripe::PCurve),
             R"#()#"  , py::arg("First")
          )
        .def("ChangePCurve",
             (handle<Geom2d_Curve> & (ChFiDS_Stripe::*)(  const bool  ) ) static_cast<handle<Geom2d_Curve> & (ChFiDS_Stripe::*)(  const bool  ) >(&ChFiDS_Stripe::ChangePCurve),
             R"#()#"  , py::arg("First")
          )
        .def("Orientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)(  const int  ) const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)(  const int  ) const>(&ChFiDS_Stripe::Orientation),
             R"#()#"  , py::arg("OnS")
          )
        .def("SetOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation ,   const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation ,   const int  ) >(&ChFiDS_Stripe::SetOrientation),
             R"#()#"  , py::arg("Or"),  py::arg("OnS")
          )
        .def("Orientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)(  const bool  ) const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)(  const bool  ) const>(&ChFiDS_Stripe::Orientation),
             R"#()#"  , py::arg("First")
          )
        .def("SetOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation ,   const bool  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation ,   const bool  ) >(&ChFiDS_Stripe::SetOrientation),
             R"#()#"  , py::arg("Or"),  py::arg("First")
          )
        .def("IndexPoint",
             (int (ChFiDS_Stripe::*)(  const bool ,   const int  ) const) static_cast<int (ChFiDS_Stripe::*)(  const bool ,   const int  ) const>(&ChFiDS_Stripe::IndexPoint),
             R"#()#"  , py::arg("First"),  py::arg("OnS")
          )
        .def("SetIndexPoint",
             (void (ChFiDS_Stripe::*)(  const int ,   const bool ,   const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int ,   const bool ,   const int  ) >(&ChFiDS_Stripe::SetIndexPoint),
             R"#()#"  , py::arg("Index"),  py::arg("First"),  py::arg("OnS")
          )
        .def("SolidIndex",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::SolidIndex),
             R"#()#" 
          )
        .def("SetSolidIndex",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::SetSolidIndex),
             R"#()#"  , py::arg("Index")
          )
        .def("InDS",
             (void (ChFiDS_Stripe::*)(  const bool ,   const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const bool ,   const int  ) >(&ChFiDS_Stripe::InDS),
             R"#(Set nb of SurfData's at end put in DS)#"  , py::arg("First"),  py::arg("Nb")=static_cast< const int>(1)
          )
        .def("IsInDS",
             (int (ChFiDS_Stripe::*)(  const bool  ) const) static_cast<int (ChFiDS_Stripe::*)(  const bool  ) const>(&ChFiDS_Stripe::IsInDS),
             R"#(Returns nb of SurfData's at end being in DS)#"  , py::arg("First")
          )
        .def("OrientationOnFace1",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::OrientationOnFace1),
             R"#()#" 
          )
        .def("OrientationOnFace2",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::OrientationOnFace2),
             R"#()#" 
          )
        .def("Choix",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::Choix),
             R"#()#" 
          )
        .def("OrientationOnFace1",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::OrientationOnFace1),
             R"#()#"  , py::arg("Or1")
          )
        .def("OrientationOnFace2",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::OrientationOnFace2),
             R"#()#"  , py::arg("Or2")
          )
        .def("Choix",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::Choix),
             R"#()#"  , py::arg("C")
          )
        .def("ChangeFirstParameters",
             (void (ChFiDS_Stripe::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_Stripe::*)(  const double ,   const double  ) >(&ChFiDS_Stripe::ChangeFirstParameters),
             R"#()#"  , py::arg("Pdeb"),  py::arg("Pfin")
          )
        .def("ChangeLastParameters",
             (void (ChFiDS_Stripe::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_Stripe::*)(  const double ,   const double  ) >(&ChFiDS_Stripe::ChangeLastParameters),
             R"#()#"  , py::arg("Pdeb"),  py::arg("Pfin")
          )
        .def("FirstCurve",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstCurve),
             R"#()#" 
          )
        .def("LastCurve",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastCurve),
             R"#()#" 
          )
        .def("ChangeFirstCurve",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeFirstCurve),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeLastCurve",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeLastCurve),
             R"#()#"  , py::arg("Index")
          )
        .def("IndexFirstPointOnS1",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexFirstPointOnS1),
             R"#()#" 
          )
        .def("IndexLastPointOnS1",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexLastPointOnS1),
             R"#()#" 
          )
        .def("IndexFirstPointOnS2",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexFirstPointOnS2),
             R"#()#" 
          )
        .def("IndexLastPointOnS2",
             (int (ChFiDS_Stripe::*)() const) static_cast<int (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::IndexLastPointOnS2),
             R"#()#" 
          )
        .def("ChangeIndexFirstPointOnS1",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexFirstPointOnS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexLastPointOnS1",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexLastPointOnS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexFirstPointOnS2",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexFirstPointOnS2),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexLastPointOnS2",
             (void (ChFiDS_Stripe::*)(  const int  ) ) static_cast<void (ChFiDS_Stripe::*)(  const int  ) >(&ChFiDS_Stripe::ChangeIndexLastPointOnS2),
             R"#()#"  , py::arg("Index")
          )
        .def("FirstPCurveOrientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstPCurveOrientation),
             R"#()#" 
          )
        .def("LastPCurveOrientation",
             (TopAbs_Orientation (ChFiDS_Stripe::*)() const) static_cast<TopAbs_Orientation (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastPCurveOrientation),
             R"#()#" 
          )
        .def("FirstPCurveOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::FirstPCurveOrientation),
             R"#()#"  , py::arg("O")
          )
        .def("LastPCurveOrientation",
             (void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) ) static_cast<void (ChFiDS_Stripe::*)(  const TopAbs_Orientation  ) >(&ChFiDS_Stripe::LastPCurveOrientation),
             R"#()#"  , py::arg("O")
          )
    // methods using call by reference i.s.o. return
        .def("FirstParameters",
             []( ChFiDS_Stripe &self   ){
                 double  Pdeb;
                double  Pfin;

                 self.FirstParameters(Pdeb,Pfin);
                 return std::make_tuple(Pdeb,Pfin); },
             R"#()#" 
          )
        .def("LastParameters",
             []( ChFiDS_Stripe &self   ){
                 double  Pdeb;
                double  Pfin;

                 self.LastParameters(Pdeb,Pfin);
                 return std::make_tuple(Pdeb,Pfin); },
             R"#()#" 
          )
        .def("Parameters",
             []( ChFiDS_Stripe &self ,  const bool First ){
                 double  Pdeb;
                double  Pfin;

                 self.Parameters(First,Pdeb,Pfin);
                 return std::make_tuple(Pdeb,Pfin); },
             R"#()#"  , py::arg("First")
          )
        .def("FirstParameters",
             []( ChFiDS_Stripe &self   ){
                 double  Pdeb;
                double  Pfin;

                 self.FirstParameters(Pdeb,Pfin);
                 return std::make_tuple(Pdeb,Pfin); },
             R"#()#" 
          )
        .def("LastParameters",
             []( ChFiDS_Stripe &self   ){
                 double  Pdeb;
                double  Pfin;

                 self.LastParameters(Pdeb,Pfin);
                 return std::make_tuple(Pdeb,Pfin); },
             R"#()#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_Stripe::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_Stripe::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SetOfSurfData",
             ( const handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() const) static_cast< const handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::SetOfSurfData),
             R"#()#"
             
         )
       .def("Spine",
             ( const handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() const) static_cast< const handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::Spine),
             R"#()#"
             
         )
       .def("ChangeSetOfSurfData",
             (handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() ) static_cast<handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeSetOfSurfData),
             R"#()#"
             
         )
       .def("ChangeSpine",
             (handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() ) static_cast<handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeSpine),
             R"#()#"
             
         )
       .def("FirstPCurve",
             ( const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstPCurve),
             R"#()#"
             
         )
       .def("LastPCurve",
             ( const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastPCurve),
             R"#()#"
             
         )
       .def("ChangeFirstPCurve",
             (handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeFirstPCurve),
             R"#()#"
             
         )
       .def("ChangeLastPCurve",
             (handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeLastPCurve),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_Stripe::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::DynamicType),
             R"#()#"
             
         )
       .def("SetOfSurfData",
             ( const handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() const) static_cast< const handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::SetOfSurfData),
             R"#()#"
             
         )
       .def("Spine",
             ( const handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() const) static_cast< const handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::Spine),
             R"#()#"
             
         )
       .def("ChangeSetOfSurfData",
             (handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() ) static_cast<handle<NCollection_HSequence<handle<ChFiDS_SurfData>>> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeSetOfSurfData),
             R"#()#"
             
         )
       .def("ChangeSpine",
             (handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() ) static_cast<handle<ChFiDS_Spine> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeSpine),
             R"#()#"
             
         )
       .def("FirstPCurve",
             ( const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::FirstPCurve),
             R"#()#"
             
         )
       .def("LastPCurve",
             ( const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const) static_cast< const handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() const>(&ChFiDS_Stripe::LastPCurve),
             R"#()#"
             
         )
       .def("ChangeFirstPCurve",
             (handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeFirstPCurve),
             R"#()#"
             
         )
       .def("ChangeLastPCurve",
             (handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() ) static_cast<handle<Geom2d_Curve> & (ChFiDS_Stripe::*)() >(&ChFiDS_Stripe::ChangeLastPCurve),
             R"#()#"
             
         )
;

    // Class ChFiDS_StripeMap from ./opencascade/ChFiDS_StripeMap.hxx
    klass = m.attr("ChFiDS_StripeMap");


    // nested enums

    static_cast<py::class_<ChFiDS_StripeMap , shared_ptr<ChFiDS_StripeMap>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Add",
             (void (ChFiDS_StripeMap::*)(  const TopoDS_Vertex & ,   const handle<ChFiDS_Stripe> &  ) ) static_cast<void (ChFiDS_StripeMap::*)(  const TopoDS_Vertex & ,   const handle<ChFiDS_Stripe> &  ) >(&ChFiDS_StripeMap::Add),
             R"#()#"  , py::arg("V"),  py::arg("F")
          )
        .def("Extent",
             (int (ChFiDS_StripeMap::*)() const) static_cast<int (ChFiDS_StripeMap::*)() const>(&ChFiDS_StripeMap::Extent),
             R"#()#" 
          )
        .def("FindFromKey",
             ( const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const TopoDS_Vertex &  ) const) static_cast< const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const TopoDS_Vertex &  ) const>(&ChFiDS_StripeMap::FindFromKey),
             R"#()#"  , py::arg("V")
          )
        .def("FindFromIndex",
             ( const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const int  ) const) static_cast< const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const int  ) const>(&ChFiDS_StripeMap::FindFromIndex),
             R"#()#"  , py::arg("I")
          )
        .def("FindKey",
             ( const TopoDS_Vertex & (ChFiDS_StripeMap::*)(  const int  ) const) static_cast< const TopoDS_Vertex & (ChFiDS_StripeMap::*)(  const int  ) const>(&ChFiDS_StripeMap::FindKey),
             R"#()#"  , py::arg("I")
          )
        .def("Clear",
             (void (ChFiDS_StripeMap::*)() ) static_cast<void (ChFiDS_StripeMap::*)() >(&ChFiDS_StripeMap::Clear),
             R"#()#" 
          )
        .def("Extent",
             (int (ChFiDS_StripeMap::*)() const) static_cast<int (ChFiDS_StripeMap::*)() const>(&ChFiDS_StripeMap::Extent),
             R"#()#" 
          )
        .def("FindKey",
             ( const TopoDS_Vertex & (ChFiDS_StripeMap::*)(  const int  ) const) static_cast< const TopoDS_Vertex & (ChFiDS_StripeMap::*)(  const int  ) const>(&ChFiDS_StripeMap::FindKey),
             R"#()#"  , py::arg("I")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             ( const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const TopoDS_Vertex &  ) const) static_cast< const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const TopoDS_Vertex &  ) const>(&ChFiDS_StripeMap::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("V")
          )
        .def("__call__",
             ( const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const int  ) const) static_cast< const NCollection_List<handle<ChFiDS_Stripe>> & (ChFiDS_StripeMap::*)(  const int  ) const>(&ChFiDS_StripeMap::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("I")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class ChFiDS_SurfData from ./opencascade/ChFiDS_SurfData.hxx
    klass = m.attr("ChFiDS_SurfData");


    // nested enums

    static_cast<py::class_<ChFiDS_SurfData ,opencascade::handle<ChFiDS_SurfData>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Copy",
             (void (ChFiDS_SurfData::*)(  const handle<ChFiDS_SurfData> &  ) ) static_cast<void (ChFiDS_SurfData::*)(  const handle<ChFiDS_SurfData> &  ) >(&ChFiDS_SurfData::Copy),
             R"#()#"  , py::arg("Other")
          )
        .def("IndexOfS1",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfS1),
             R"#()#" 
          )
        .def("IndexOfS2",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfS2),
             R"#()#" 
          )
        .def("IsOnCurve1",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IsOnCurve1),
             R"#()#" 
          )
        .def("IsOnCurve2",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IsOnCurve2),
             R"#()#" 
          )
        .def("IndexOfC1",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfC1),
             R"#()#" 
          )
        .def("IndexOfC2",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfC2),
             R"#()#" 
          )
        .def("Surf",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::Surf),
             R"#()#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (ChFiDS_SurfData::*)() const) static_cast<TopAbs_Orientation (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::Orientation),
             R"#()#" 
          )
        .def("ChangeIndexOfS1",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeIndexOfS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexOfS2",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeIndexOfS2),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeSurf",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeSurf),
             R"#()#"  , py::arg("Index")
          )
        .def("SetIndexOfC1",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::SetIndexOfC1),
             R"#()#"  , py::arg("Index")
          )
        .def("SetIndexOfC2",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::SetIndexOfC2),
             R"#()#"  , py::arg("Index")
          )
        .def("Interference",
             ( const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)(  const int  ) const) static_cast< const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::Interference),
             R"#()#"  , py::arg("OnS")
          )
        .def("ChangeInterference",
             (ChFiDS_FaceInterference & (ChFiDS_SurfData::*)(  const int  ) ) static_cast<ChFiDS_FaceInterference & (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeInterference),
             R"#()#"  , py::arg("OnS")
          )
        .def("Index",
             (int (ChFiDS_SurfData::*)(  const int  ) const) static_cast<int (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::Index),
             R"#()#"  , py::arg("OfS")
          )
        .def("Vertex",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)(  const bool ,   const int  ) const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)(  const bool ,   const int  ) const>(&ChFiDS_SurfData::Vertex),
             R"#(returns one of the four vertices whether First is true or wrong and OnS equals 1 or 2.)#"  , py::arg("First"),  py::arg("OnS")
          )
        .def("ChangeVertex",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)(  const bool ,   const int  ) ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)(  const bool ,   const int  ) >(&ChFiDS_SurfData::ChangeVertex),
             R"#(returns one of the four vertices whether First is true or wrong and OnS equals 1 or 2.)#"  , py::arg("First"),  py::arg("OnS")
          )
        .def("IsOnCurve",
             (bool (ChFiDS_SurfData::*)(  const int  ) const) static_cast<bool (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::IsOnCurve),
             R"#()#"  , py::arg("OnS")
          )
        .def("IndexOfC",
             (int (ChFiDS_SurfData::*)(  const int  ) const) static_cast<int (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::IndexOfC),
             R"#()#"  , py::arg("OnS")
          )
        .def("FirstSpineParam",
             (double (ChFiDS_SurfData::*)() const) static_cast<double (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::FirstSpineParam),
             R"#()#" 
          )
        .def("LastSpineParam",
             (double (ChFiDS_SurfData::*)() const) static_cast<double (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::LastSpineParam),
             R"#()#" 
          )
        .def("FirstSpineParam",
             (void (ChFiDS_SurfData::*)(  const double  ) ) static_cast<void (ChFiDS_SurfData::*)(  const double  ) >(&ChFiDS_SurfData::FirstSpineParam),
             R"#()#"  , py::arg("Par")
          )
        .def("LastSpineParam",
             (void (ChFiDS_SurfData::*)(  const double  ) ) static_cast<void (ChFiDS_SurfData::*)(  const double  ) >(&ChFiDS_SurfData::LastSpineParam),
             R"#()#"  , py::arg("Par")
          )
        .def("FirstExtensionValue",
             (double (ChFiDS_SurfData::*)() const) static_cast<double (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::FirstExtensionValue),
             R"#()#" 
          )
        .def("LastExtensionValue",
             (double (ChFiDS_SurfData::*)() const) static_cast<double (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::LastExtensionValue),
             R"#()#" 
          )
        .def("FirstExtensionValue",
             (void (ChFiDS_SurfData::*)(  const double  ) ) static_cast<void (ChFiDS_SurfData::*)(  const double  ) >(&ChFiDS_SurfData::FirstExtensionValue),
             R"#()#"  , py::arg("Extend")
          )
        .def("LastExtensionValue",
             (void (ChFiDS_SurfData::*)(  const double  ) ) static_cast<void (ChFiDS_SurfData::*)(  const double  ) >(&ChFiDS_SurfData::LastExtensionValue),
             R"#()#"  , py::arg("Extend")
          )
        .def("Simul",
             (handle<Standard_Transient> (ChFiDS_SurfData::*)() const) static_cast<handle<Standard_Transient> (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::Simul),
             R"#()#" 
          )
        .def("SetSimul",
             (void (ChFiDS_SurfData::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (ChFiDS_SurfData::*)(  const handle<Standard_Transient> &  ) >(&ChFiDS_SurfData::SetSimul),
             R"#()#"  , py::arg("S")
          )
        .def("ResetSimul",
             (void (ChFiDS_SurfData::*)() ) static_cast<void (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ResetSimul),
             R"#()#" 
          )
        .def("Get2dPoints",
             (gp_Pnt2d (ChFiDS_SurfData::*)(  const bool ,   const int  ) const) static_cast<gp_Pnt2d (ChFiDS_SurfData::*)(  const bool ,   const int  ) const>(&ChFiDS_SurfData::Get2dPoints),
             R"#()#"  , py::arg("First"),  py::arg("OnS")
          )
        .def("Get2dPoints",
             (void (ChFiDS_SurfData::*)( gp_Pnt2d & ,  gp_Pnt2d & ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const) static_cast<void (ChFiDS_SurfData::*)( gp_Pnt2d & ,  gp_Pnt2d & ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const>(&ChFiDS_SurfData::Get2dPoints),
             R"#()#"  , py::arg("P2df1"),  py::arg("P2dl1"),  py::arg("P2df2"),  py::arg("P2dl2")
          )
        .def("Set2dPoints",
             (void (ChFiDS_SurfData::*)(  const gp_Pnt2d & ,   const gp_Pnt2d & ,   const gp_Pnt2d & ,   const gp_Pnt2d &  ) ) static_cast<void (ChFiDS_SurfData::*)(  const gp_Pnt2d & ,   const gp_Pnt2d & ,   const gp_Pnt2d & ,   const gp_Pnt2d &  ) >(&ChFiDS_SurfData::Set2dPoints),
             R"#()#"  , py::arg("P2df1"),  py::arg("P2dl1"),  py::arg("P2df2"),  py::arg("P2dl2")
          )
        .def("TwistOnS1",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::TwistOnS1),
             R"#()#" 
          )
        .def("TwistOnS2",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::TwistOnS2),
             R"#()#" 
          )
        .def("TwistOnS1",
             (void (ChFiDS_SurfData::*)(  const bool  ) ) static_cast<void (ChFiDS_SurfData::*)(  const bool  ) >(&ChFiDS_SurfData::TwistOnS1),
             R"#()#"  , py::arg("T")
          )
        .def("TwistOnS2",
             (void (ChFiDS_SurfData::*)(  const bool  ) ) static_cast<void (ChFiDS_SurfData::*)(  const bool  ) >(&ChFiDS_SurfData::TwistOnS2),
             R"#()#"  , py::arg("T")
          )
        .def("IndexOfS1",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfS1),
             R"#()#" 
          )
        .def("IsOnCurve1",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IsOnCurve1),
             R"#()#" 
          )
        .def("IndexOfC1",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfC1),
             R"#()#" 
          )
        .def("SetIndexOfC1",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::SetIndexOfC1),
             R"#()#"  , py::arg("theIndex")
          )
        .def("IndexOfS2",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfS2),
             R"#()#" 
          )
        .def("IsOnCurve2",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IsOnCurve2),
             R"#()#" 
          )
        .def("IndexOfC2",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::IndexOfC2),
             R"#()#" 
          )
        .def("SetIndexOfC2",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::SetIndexOfC2),
             R"#()#"  , py::arg("theIndex")
          )
        .def("Surf",
             (int (ChFiDS_SurfData::*)() const) static_cast<int (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::Surf),
             R"#()#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (ChFiDS_SurfData::*)() const) static_cast<TopAbs_Orientation (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::Orientation),
             R"#()#" 
          )
        .def("ChangeIndexOfS1",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeIndexOfS1),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeIndexOfS2",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeIndexOfS2),
             R"#()#"  , py::arg("Index")
          )
        .def("ChangeSurf",
             (void (ChFiDS_SurfData::*)(  const int  ) ) static_cast<void (ChFiDS_SurfData::*)(  const int  ) >(&ChFiDS_SurfData::ChangeSurf),
             R"#()#"  , py::arg("Index")
          )
        .def("IsOnCurve",
             (bool (ChFiDS_SurfData::*)(  const int  ) const) static_cast<bool (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::IsOnCurve),
             R"#()#"  , py::arg("OnS")
          )
        .def("IndexOfC",
             (int (ChFiDS_SurfData::*)(  const int  ) const) static_cast<int (ChFiDS_SurfData::*)(  const int  ) const>(&ChFiDS_SurfData::IndexOfC),
             R"#()#"  , py::arg("OnS")
          )
        .def("TwistOnS1",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::TwistOnS1),
             R"#()#" 
          )
        .def("TwistOnS2",
             (bool (ChFiDS_SurfData::*)() const) static_cast<bool (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::TwistOnS2),
             R"#()#" 
          )
        .def("TwistOnS1",
             (void (ChFiDS_SurfData::*)(  const bool  ) ) static_cast<void (ChFiDS_SurfData::*)(  const bool  ) >(&ChFiDS_SurfData::TwistOnS1),
             R"#()#"  , py::arg("T")
          )
        .def("TwistOnS2",
             (void (ChFiDS_SurfData::*)(  const bool  ) ) static_cast<void (ChFiDS_SurfData::*)(  const bool  ) >(&ChFiDS_SurfData::TwistOnS2),
             R"#()#"  , py::arg("T")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_SurfData::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_SurfData::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("InterferenceOnS1",
             ( const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::InterferenceOnS1),
             R"#()#"
             
         )
       .def("InterferenceOnS2",
             ( const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::InterferenceOnS2),
             R"#()#"
             
         )
       .def("VertexFirstOnS1",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexFirstOnS1),
             R"#()#"
             
         )
       .def("VertexFirstOnS2",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexFirstOnS2),
             R"#()#"
             
         )
       .def("VertexLastOnS1",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexLastOnS1),
             R"#()#"
             
         )
       .def("VertexLastOnS2",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexLastOnS2),
             R"#()#"
             
         )
       .def("ChangeOrientation",
             (TopAbs_Orientation & (ChFiDS_SurfData::*)() ) static_cast<TopAbs_Orientation & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeOrientation),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeInterferenceOnS1",
             (ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeInterferenceOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeInterferenceOnS2",
             (ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeInterferenceOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexFirstOnS1",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexFirstOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexFirstOnS2",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexFirstOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexLastOnS1",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexLastOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexLastOnS2",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexLastOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_SurfData::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::DynamicType),
             R"#()#"
             
         )
       .def("InterferenceOnS1",
             ( const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::InterferenceOnS1),
             R"#()#"
             
         )
       .def("InterferenceOnS2",
             ( const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::InterferenceOnS2),
             R"#()#"
             
         )
       .def("VertexFirstOnS1",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexFirstOnS1),
             R"#()#"
             
         )
       .def("VertexLastOnS1",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexLastOnS1),
             R"#()#"
             
         )
       .def("VertexFirstOnS2",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexFirstOnS2),
             R"#()#"
             
         )
       .def("VertexLastOnS2",
             ( const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const) static_cast< const ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() const>(&ChFiDS_SurfData::VertexLastOnS2),
             R"#()#"
             
         )
       .def("ChangeOrientation",
             (TopAbs_Orientation & (ChFiDS_SurfData::*)() ) static_cast<TopAbs_Orientation & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeOrientation),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeInterferenceOnS1",
             (ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeInterferenceOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeInterferenceOnS2",
             (ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_FaceInterference & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeInterferenceOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexFirstOnS1",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexFirstOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexLastOnS1",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexLastOnS1),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexFirstOnS2",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexFirstOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeVertexLastOnS2",
             (ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() ) static_cast<ChFiDS_CommonPoint & (ChFiDS_SurfData::*)() >(&ChFiDS_SurfData::ChangeVertexLastOnS2),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class ChFiDS_ChamfSpine from ./opencascade/ChFiDS_ChamfSpine.hxx
    klass = m.attr("ChFiDS_ChamfSpine");


    // nested enums

    static_cast<py::class_<ChFiDS_ChamfSpine ,opencascade::handle<ChFiDS_ChamfSpine>  , ChFiDS_Spine >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double >()  , py::arg("Tol") )
    // custom constructors
    // methods
        .def("SetDist",
             (void (ChFiDS_ChamfSpine::*)(  const double  ) ) static_cast<void (ChFiDS_ChamfSpine::*)(  const double  ) >(&ChFiDS_ChamfSpine::SetDist),
             R"#()#"  , py::arg("Dis")
          )
        .def("SetDists",
             (void (ChFiDS_ChamfSpine::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_ChamfSpine::*)(  const double ,   const double  ) >(&ChFiDS_ChamfSpine::SetDists),
             R"#()#"  , py::arg("Dis1"),  py::arg("Dis2")
          )
        .def("SetDistAngle",
             (void (ChFiDS_ChamfSpine::*)(  const double ,   const double  ) ) static_cast<void (ChFiDS_ChamfSpine::*)(  const double ,   const double  ) >(&ChFiDS_ChamfSpine::SetDistAngle),
             R"#()#"  , py::arg("Dis"),  py::arg("Angle")
          )
        .def("SetMode",
             (void (ChFiDS_ChamfSpine::*)(  const ChFiDS_ChamfMode  ) ) static_cast<void (ChFiDS_ChamfSpine::*)(  const ChFiDS_ChamfMode  ) >(&ChFiDS_ChamfSpine::SetMode),
             R"#()#"  , py::arg("theMode")
          )
        .def("IsChamfer",
             (ChFiDS_ChamfMethod (ChFiDS_ChamfSpine::*)() const) static_cast<ChFiDS_ChamfMethod (ChFiDS_ChamfSpine::*)() const>(&ChFiDS_ChamfSpine::IsChamfer),
             R"#(Return the method of chamfers used)#" 
          )
    // methods using call by reference i.s.o. return
        .def("GetDist",
             []( ChFiDS_ChamfSpine &self   ){
                 double  Dis;

                 self.GetDist(Dis);
                 return std::make_tuple(Dis); },
             R"#()#" 
          )
        .def("Dists",
             []( ChFiDS_ChamfSpine &self   ){
                 double  Dis1;
                double  Dis2;

                 self.Dists(Dis1,Dis2);
                 return std::make_tuple(Dis1,Dis2); },
             R"#()#" 
          )
        .def("GetDistAngle",
             []( ChFiDS_ChamfSpine &self   ){
                 double  Dis;
                double  Angle;

                 self.GetDistAngle(Dis,Angle);
                 return std::make_tuple(Dis,Angle); },
             R"#()#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_ChamfSpine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_ChamfSpine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_ChamfSpine::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_ChamfSpine::*)() const>(&ChFiDS_ChamfSpine::DynamicType),
             R"#()#"
             
         )
;

    // Class ChFiDS_FilSpine from ./opencascade/ChFiDS_FilSpine.hxx
    klass = m.attr("ChFiDS_FilSpine");


    // nested enums

    static_cast<py::class_<ChFiDS_FilSpine ,opencascade::handle<ChFiDS_FilSpine>  , ChFiDS_Spine >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double >()  , py::arg("Tol") )
    // custom constructors
    // methods
        .def("Reset",
             (void (ChFiDS_FilSpine::*)(  const bool  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const bool  ) >(&ChFiDS_FilSpine::Reset),
             R"#()#"  , py::arg("AllData")=static_cast< const bool>(false)
          )
        .def("SetRadius",
             (void (ChFiDS_FilSpine::*)(  const double ,   const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const double ,   const TopoDS_Edge &  ) >(&ChFiDS_FilSpine::SetRadius),
             R"#(initializes the constant vector on edge E.)#"  , py::arg("Radius"),  py::arg("E")
          )
        .def("UnSetRadius",
             (void (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_FilSpine::UnSetRadius),
             R"#(resets the constant vector on edge E.)#"  , py::arg("E")
          )
        .def("SetRadius",
             (void (ChFiDS_FilSpine::*)(  const double ,   const TopoDS_Vertex &  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const double ,   const TopoDS_Vertex &  ) >(&ChFiDS_FilSpine::SetRadius),
             R"#(initializes the vector on Vertex V.)#"  , py::arg("Radius"),  py::arg("V")
          )
        .def("UnSetRadius",
             (void (ChFiDS_FilSpine::*)(  const TopoDS_Vertex &  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const TopoDS_Vertex &  ) >(&ChFiDS_FilSpine::UnSetRadius),
             R"#(resets the vector on Vertex V.)#"  , py::arg("V")
          )
        .def("SetRadius",
             (void (ChFiDS_FilSpine::*)(  const gp_XY & ,   const int  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const gp_XY & ,   const int  ) >(&ChFiDS_FilSpine::SetRadius),
             R"#(initializes the vector on the point of parameter W.)#"  , py::arg("UandR"),  py::arg("IinC")
          )
        .def("SetRadius",
             (void (ChFiDS_FilSpine::*)(  const double  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const double  ) >(&ChFiDS_FilSpine::SetRadius),
             R"#(initializes the constant vector on all spine.)#"  , py::arg("Radius")
          )
        .def("SetRadius",
             (void (ChFiDS_FilSpine::*)(  const handle<Law_Function> & ,   const int  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const handle<Law_Function> & ,   const int  ) >(&ChFiDS_FilSpine::SetRadius),
             R"#(initializes the rule of evolution on all spine.)#"  , py::arg("C"),  py::arg("IinC")
          )
        .def("IsConstant",
             (bool (ChFiDS_FilSpine::*)() const) static_cast<bool (ChFiDS_FilSpine::*)() const>(&ChFiDS_FilSpine::IsConstant),
             R"#(returns true if the radius is constant all along the spine.)#" 
          )
        .def("IsConstant",
             (bool (ChFiDS_FilSpine::*)(  const int  ) const) static_cast<bool (ChFiDS_FilSpine::*)(  const int  ) const>(&ChFiDS_FilSpine::IsConstant),
             R"#(returns true if the radius is constant all along the edge E.)#"  , py::arg("IE")
          )
        .def("Radius",
             (double (ChFiDS_FilSpine::*)() const) static_cast<double (ChFiDS_FilSpine::*)() const>(&ChFiDS_FilSpine::Radius),
             R"#(returns the radius if the fillet is constant all along the spine.)#" 
          )
        .def("Radius",
             (double (ChFiDS_FilSpine::*)(  const int  ) const) static_cast<double (ChFiDS_FilSpine::*)(  const int  ) const>(&ChFiDS_FilSpine::Radius),
             R"#(returns the radius if the fillet is constant all along the edge E.)#"  , py::arg("IE")
          )
        .def("Radius",
             (double (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) const) static_cast<double (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) const>(&ChFiDS_FilSpine::Radius),
             R"#(returns the radius if the fillet is constant all along the edge E.)#"  , py::arg("E")
          )
        .def("AppendElSpine",
             (void (ChFiDS_FilSpine::*)(  const handle<ChFiDS_ElSpine> &  ) ) static_cast<void (ChFiDS_FilSpine::*)(  const handle<ChFiDS_ElSpine> &  ) >(&ChFiDS_FilSpine::AppendElSpine),
             R"#()#"  , py::arg("Els")
          )
        .def("Law",
             (handle<Law_Composite> (ChFiDS_FilSpine::*)(  const handle<ChFiDS_ElSpine> &  ) const) static_cast<handle<Law_Composite> (ChFiDS_FilSpine::*)(  const handle<ChFiDS_ElSpine> &  ) const>(&ChFiDS_FilSpine::Law),
             R"#()#"  , py::arg("Els")
          )
        .def("ChangeLaw",
             (handle<Law_Function> & (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) ) static_cast<handle<Law_Function> & (ChFiDS_FilSpine::*)(  const TopoDS_Edge &  ) >(&ChFiDS_FilSpine::ChangeLaw),
             R"#(returns the elementary law)#"  , py::arg("E")
          )
        .def("MaxRadFromSeqAndLaws",
             (double (ChFiDS_FilSpine::*)() const) static_cast<double (ChFiDS_FilSpine::*)() const>(&ChFiDS_FilSpine::MaxRadFromSeqAndLaws),
             R"#(returns the maximum radius if the fillet is non-constant)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&ChFiDS_FilSpine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&ChFiDS_FilSpine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (ChFiDS_FilSpine::*)() const) static_cast< const handle<Standard_Type> & (ChFiDS_FilSpine::*)() const>(&ChFiDS_FilSpine::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/ChFiDS_ChamfMethod.hxx
// ./opencascade/ChFiDS_ChamfMode.hxx
// ./opencascade/ChFiDS_ChamfSpine.hxx
// ./opencascade/ChFiDS_CircSection.hxx
// ./opencascade/ChFiDS_CommonPoint.hxx
// ./opencascade/ChFiDS_ElSpine.hxx
// ./opencascade/ChFiDS_ErrorStatus.hxx
// ./opencascade/ChFiDS_FaceInterference.hxx
// ./opencascade/ChFiDS_FilSpine.hxx
// ./opencascade/ChFiDS_Map.hxx
// ./opencascade/ChFiDS_Regul.hxx
// ./opencascade/ChFiDS_Spine.hxx
// ./opencascade/ChFiDS_State.hxx
// ./opencascade/ChFiDS_Stripe.hxx
// ./opencascade/ChFiDS_StripeMap.hxx
// ./opencascade/ChFiDS_SurfData.hxx
// ./opencascade/ChFiDS_TypeOfConcavity.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
