
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Sphere.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <Adaptor3d_TopolTool.hxx>
#include <Adaptor3d_HVertex.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_HVertex.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <IntSurf_PathPointTool.hxx>
#include <IntSurf_InteriorPointTool.hxx>
#include <Adaptor3d_HSurfaceTool.hxx>
#include <Contap_SurfFunction.hxx>
#include <math_FunctionSetRoot.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_HVertex.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_HVertex.hxx>
#include <Contap_HCurve2dTool.hxx>
#include <Contap_HContTool.hxx>
#include <Adaptor3d_TopolTool.hxx>
#include <Contap_ArcFunction.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_HSurfaceTool.hxx>
#include <Adaptor3d_TopolTool.hxx>
#include <Contap_HContTool.hxx>
#include <Contap_SurfFunction.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_HVertex.hxx>

// module includes
#include <Contap_ArcFunction.hxx>
#include <Contap_ContAna.hxx>
#include <Contap_Contour.hxx>
#include <Contap_HContTool.hxx>
#include <Contap_HCurve2dTool.hxx>
#include <Contap_IType.hxx>
#include <Contap_Line.hxx>
#include <Contap_Point.hxx>
#include <Contap_SurfFunction.hxx>
#include <Contap_SurfProps.hxx>
#include <Contap_TFunction.hxx>
#include <Contap_TheIWalking.hxx>
#include <Contap_TheIWLineOfTheIWalking.hxx>
#include <Contap_ThePathPointOfTheSearch.hxx>
#include <Contap_TheSearch.hxx>
#include <Contap_TheSearchInside.hxx>
#include <Contap_TheSegmentOfTheSearch.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Contap(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Contap"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class Contap_ArcFunction from ./opencascade/Contap_ArcFunction.hxx
    klass = m.attr("Contap_ArcFunction");


    // nested enums

    static_cast<py::class_<Contap_ArcFunction , shared_ptr<Contap_ArcFunction>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (Contap_ArcFunction::*)(  const handle<Adaptor3d_Surface> &  ) ) static_cast<void (Contap_ArcFunction::*)(  const handle<Adaptor3d_Surface> &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("S")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Dir &  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Dir &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Direction")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Dir & ,   const double  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Direction"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Pnt &  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Pnt &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Eye")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Pnt & ,   const double  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Pnt & ,   const double  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Eye"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (Contap_ArcFunction::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("A")
          )
        .def("Value",
             (bool (Contap_ArcFunction::*)(  const double ,  double &  ) ) static_cast<bool (Contap_ArcFunction::*)(  const double ,  double &  ) >(&Contap_ArcFunction::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivative",
             (bool (Contap_ArcFunction::*)(  const double ,  double &  ) ) static_cast<bool (Contap_ArcFunction::*)(  const double ,  double &  ) >(&Contap_ArcFunction::Derivative),
             R"#()#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (Contap_ArcFunction::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (Contap_ArcFunction::*)(  const double ,  double & ,  double &  ) >(&Contap_ArcFunction::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
        .def("NbSamples",
             (int (Contap_ArcFunction::*)() const) static_cast<int (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::NbSamples),
             R"#()#" 
          )
        .def("GetStateNumber",
             (int (Contap_ArcFunction::*)() ) static_cast<int (Contap_ArcFunction::*)() >(&Contap_ArcFunction::GetStateNumber),
             R"#()#" 
          )
        .def("Valpoint",
             ( const gp_Pnt & (Contap_ArcFunction::*)(  const int  ) const) static_cast< const gp_Pnt & (Contap_ArcFunction::*)(  const int  ) const>(&Contap_ArcFunction::Valpoint),
             R"#()#"  , py::arg("Index")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Dir & ,   const double  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Direction"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Pnt & ,   const double  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Pnt & ,   const double  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Eye"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Dir &  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Dir &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Direction")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const gp_Pnt &  ) ) static_cast<void (Contap_ArcFunction::*)(  const gp_Pnt &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("Eye")
          )
        .def("Set",
             (void (Contap_ArcFunction::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (Contap_ArcFunction::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_ArcFunction::Set),
             R"#()#"  , py::arg("A")
          )
        .def("Valpoint",
             ( const gp_Pnt & (Contap_ArcFunction::*)(  const int  ) const) static_cast< const gp_Pnt & (Contap_ArcFunction::*)(  const int  ) const>(&Contap_ArcFunction::Valpoint),
             R"#()#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Quadric",
             ( const IntSurf_Quadric & (Contap_ArcFunction::*)() const) static_cast< const IntSurf_Quadric & (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::Quadric),
             R"#()#"
             
         )
       .def("Surface",
             ( const handle<Adaptor3d_Surface> & (Contap_ArcFunction::*)() const) static_cast< const handle<Adaptor3d_Surface> & (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::Surface),
             R"#(Returns mySurf field)#"
             
         )
       .def("LastComputedPoint",
             ( const gp_Pnt & (Contap_ArcFunction::*)() const) static_cast< const gp_Pnt & (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::LastComputedPoint),
             R"#(Returns the point, which has been computed while the last calling Value() method)#"
             
         )
       .def("Surface",
             ( const handle<Adaptor3d_Surface> & (Contap_ArcFunction::*)() const) static_cast< const handle<Adaptor3d_Surface> & (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::Surface),
             R"#(Returns mySurf field)#"
             
         )
       .def("LastComputedPoint",
             ( const gp_Pnt & (Contap_ArcFunction::*)() const) static_cast< const gp_Pnt & (Contap_ArcFunction::*)() const>(&Contap_ArcFunction::LastComputedPoint),
             R"#(Returns the point, which has been computed while the last calling Value() method)#"
             
         )
;

    // Class Contap_ContAna from ./opencascade/Contap_ContAna.hxx
    klass = m.attr("Contap_ContAna");


    // nested enums

    static_cast<py::class_<Contap_ContAna , shared_ptr<Contap_ContAna>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Dir &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Dir &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("S"),  py::arg("D")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Dir & ,   const double  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Dir & ,   const double  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("S"),  py::arg("D"),  py::arg("Ang")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Pnt &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Sphere & ,   const gp_Pnt &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Eye")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Dir &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Dir &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("D")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Dir & ,   const double  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Dir & ,   const double  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("D"),  py::arg("Ang")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Pnt &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cylinder & ,   const gp_Pnt &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("Eye")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Dir &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Dir &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("D")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Dir & ,   const double  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Dir & ,   const double  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("D"),  py::arg("Ang")
          )
        .def("Perform",
             (void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Pnt &  ) ) static_cast<void (Contap_ContAna::*)(  const gp_Cone & ,   const gp_Pnt &  ) >(&Contap_ContAna::Perform),
             R"#()#"  , py::arg("C"),  py::arg("Eye")
          )
        .def("IsDone",
             (bool (Contap_ContAna::*)() const) static_cast<bool (Contap_ContAna::*)() const>(&Contap_ContAna::IsDone),
             R"#()#" 
          )
        .def("NbContours",
             (int (Contap_ContAna::*)() const) static_cast<int (Contap_ContAna::*)() const>(&Contap_ContAna::NbContours),
             R"#()#" 
          )
        .def("TypeContour",
             (GeomAbs_CurveType (Contap_ContAna::*)() const) static_cast<GeomAbs_CurveType (Contap_ContAna::*)() const>(&Contap_ContAna::TypeContour),
             R"#(Returns GeomAbs_Line or GeomAbs_Circle, when IsDone() returns True.)#" 
          )
        .def("Circle",
             (gp_Circ (Contap_ContAna::*)() const) static_cast<gp_Circ (Contap_ContAna::*)() const>(&Contap_ContAna::Circle),
             R"#()#" 
          )
        .def("Line",
             (gp_Lin (Contap_ContAna::*)(  const int  ) const) static_cast<gp_Lin (Contap_ContAna::*)(  const int  ) const>(&Contap_ContAna::Line),
             R"#()#"  , py::arg("Index")
          )
        .def("IsDone",
             (bool (Contap_ContAna::*)() const) static_cast<bool (Contap_ContAna::*)() const>(&Contap_ContAna::IsDone),
             R"#()#" 
          )
        .def("NbContours",
             (int (Contap_ContAna::*)() const) static_cast<int (Contap_ContAna::*)() const>(&Contap_ContAna::NbContours),
             R"#()#" 
          )
        .def("TypeContour",
             (GeomAbs_CurveType (Contap_ContAna::*)() const) static_cast<GeomAbs_CurveType (Contap_ContAna::*)() const>(&Contap_ContAna::TypeContour),
             R"#(Returns GeomAbs_Line or GeomAbs_Circle, when IsDone() returns True.)#" 
          )
        .def("Circle",
             (gp_Circ (Contap_ContAna::*)() const) static_cast<gp_Circ (Contap_ContAna::*)() const>(&Contap_ContAna::Circle),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_Contour from ./opencascade/Contap_Contour.hxx
    klass = m.attr("Contap_Contour");


    // nested enums

    static_cast<py::class_<Contap_Contour , shared_ptr<Contap_Contour>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt & >()  , py::arg("Eye") )
        .def(py::init<  const gp_Vec & >()  , py::arg("Direction") )
        .def(py::init<  const gp_Vec &, const double >()  , py::arg("Direction"),  py::arg("Angle") )
        .def(py::init<  const handle<Adaptor3d_Surface> &, const handle<Adaptor3d_TopolTool> &, const gp_Pnt & >()  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Eye") )
        .def(py::init<  const handle<Adaptor3d_Surface> &, const handle<Adaptor3d_TopolTool> &, const gp_Vec & >()  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Direction") )
        .def(py::init<  const handle<Adaptor3d_Surface> &, const handle<Adaptor3d_TopolTool> &, const gp_Vec &, const double >()  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Direction"),  py::arg("Angle") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> &  ) ) static_cast<void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> &  ) >(&Contap_Contour::Perform),
             R"#(Creates the contour in a given direction.)#"  , py::arg("Surf"),  py::arg("Domain")
          )
        .def("Perform",
             (void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Vec &  ) ) static_cast<void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Vec &  ) >(&Contap_Contour::Perform),
             R"#(Creates the contour in a given direction.)#"  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Direction")
          )
        .def("Perform",
             (void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Vec & ,   const double  ) ) static_cast<void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Vec & ,   const double  ) >(&Contap_Contour::Perform),
             R"#(Creates the contour in a given direction.)#"  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Direction"),  py::arg("Angle")
          )
        .def("Perform",
             (void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Pnt &  ) ) static_cast<void (Contap_Contour::*)(  const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const gp_Pnt &  ) >(&Contap_Contour::Perform),
             R"#(Creates the contour for a perspective view.)#"  , py::arg("Surf"),  py::arg("Domain"),  py::arg("Eye")
          )
        .def("Init",
             (void (Contap_Contour::*)(  const gp_Vec &  ) ) static_cast<void (Contap_Contour::*)(  const gp_Vec &  ) >(&Contap_Contour::Init),
             R"#()#"  , py::arg("Direction")
          )
        .def("Init",
             (void (Contap_Contour::*)(  const gp_Vec & ,   const double  ) ) static_cast<void (Contap_Contour::*)(  const gp_Vec & ,   const double  ) >(&Contap_Contour::Init),
             R"#()#"  , py::arg("Direction"),  py::arg("Angle")
          )
        .def("Init",
             (void (Contap_Contour::*)(  const gp_Pnt &  ) ) static_cast<void (Contap_Contour::*)(  const gp_Pnt &  ) >(&Contap_Contour::Init),
             R"#()#"  , py::arg("Eye")
          )
        .def("IsDone",
             (bool (Contap_Contour::*)() const) static_cast<bool (Contap_Contour::*)() const>(&Contap_Contour::IsDone),
             R"#()#" 
          )
        .def("IsEmpty",
             (bool (Contap_Contour::*)() const) static_cast<bool (Contap_Contour::*)() const>(&Contap_Contour::IsEmpty),
             R"#(Returns true if the is no line.)#" 
          )
        .def("NbLines",
             (int (Contap_Contour::*)() const) static_cast<int (Contap_Contour::*)() const>(&Contap_Contour::NbLines),
             R"#()#" 
          )
        .def("Line",
             ( const Contap_Line & (Contap_Contour::*)(  const int  ) const) static_cast< const Contap_Line & (Contap_Contour::*)(  const int  ) const>(&Contap_Contour::Line),
             R"#()#"  , py::arg("Index")
          )
        .def("IsDone",
             (bool (Contap_Contour::*)() const) static_cast<bool (Contap_Contour::*)() const>(&Contap_Contour::IsDone),
             R"#()#" 
          )
        .def("IsEmpty",
             (bool (Contap_Contour::*)() const) static_cast<bool (Contap_Contour::*)() const>(&Contap_Contour::IsEmpty),
             R"#(Returns true if the is no line.)#" 
          )
        .def("NbLines",
             (int (Contap_Contour::*)() const) static_cast<int (Contap_Contour::*)() const>(&Contap_Contour::NbLines),
             R"#()#" 
          )
        .def("Line",
             ( const Contap_Line & (Contap_Contour::*)(  const int  ) const) static_cast< const Contap_Line & (Contap_Contour::*)(  const int  ) const>(&Contap_Contour::Line),
             R"#()#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SurfaceFunction",
             (Contap_SurfFunction & (Contap_Contour::*)() ) static_cast<Contap_SurfFunction & (Contap_Contour::*)() >(&Contap_Contour::SurfaceFunction),
             R"#(Returns a reference on the internal SurfaceFunction. This is used to compute tangents on the lines.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("SurfaceFunction",
             (Contap_SurfFunction & (Contap_Contour::*)() ) static_cast<Contap_SurfFunction & (Contap_Contour::*)() >(&Contap_Contour::SurfaceFunction),
             R"#(Returns a reference on the internal SurfaceFunction. This is used to compute tangents on the lines.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class Contap_HContTool from ./opencascade/Contap_HContTool.hxx
    klass = m.attr("Contap_HContTool");

    // default constructor
    register_default_constructor<Contap_HContTool , shared_ptr<Contap_HContTool>>(m,"Contap_HContTool");

    // nested enums

    static_cast<py::class_<Contap_HContTool , shared_ptr<Contap_HContTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("NbSamplesU_s",
                    (int (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) ) static_cast<int (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) >(&Contap_HContTool::NbSamplesU),
                    R"#()#"  , py::arg("S"),  py::arg("u1"),  py::arg("u2")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) ) static_cast<int (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) >(&Contap_HContTool::NbSamplesV),
                    R"#()#"  , py::arg("S"),  py::arg("v1"),  py::arg("v2")
          )
        .def_static("NbSamplePoints_s",
                    (int (*)(  const handle<Adaptor3d_Surface> &  ) ) static_cast<int (*)(  const handle<Adaptor3d_Surface> &  ) >(&Contap_HContTool::NbSamplePoints),
                    R"#()#"  , py::arg("S")
          )
        .def_static("HasBeenSeen_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::HasBeenSeen),
                    R"#(Returns True if all the intersection point and edges are known on the Arc. The intersection point are given as vertices. The intersection edges are given as intervals between two vertices.)#"  , py::arg("C")
          )
        .def_static("NbSamplesOnArc_s",
                    (int (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<int (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::NbSamplesOnArc),
                    R"#(returns the number of points which is used to make a sample on the arc. this number is a function of the Surface and the CurveOnSurface complexity.)#"  , py::arg("A")
          )
        .def_static("Project_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const gp_Pnt2d & ,  double & ,  gp_Pnt2d &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const gp_Pnt2d & ,  double & ,  gp_Pnt2d &  ) >(&Contap_HContTool::Project),
                    R"#(Projects the point P on the arc C. If the methods returns true, the projection is successful, and Paramproj is the parameter on the arc of the projected point, Ptproj is the projected Point. If the method returns false, Param proj and Ptproj are not significant.)#"  , py::arg("C"),  py::arg("P"),  py::arg("Paramproj"),  py::arg("Ptproj")
          )
        .def_static("Tolerance_s",
                    (double (*)(  const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (*)(  const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::Tolerance),
                    R"#(Returns the parametric tolerance used to consider that the vertex and another point meet, i-e if std::abs(parameter(Vertex) - parameter(OtherPnt))<= Tolerance, the points are "merged".)#"  , py::arg("V"),  py::arg("C")
          )
        .def_static("Parameter_s",
                    (double (*)(  const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (*)(  const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::Parameter),
                    R"#(Returns the parameter of the vertex V on the arc A.)#"  , py::arg("V"),  py::arg("C")
          )
        .def_static("NbPoints_s",
                    (int (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<int (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::NbPoints),
                    R"#(Returns the number of intersection points on the arc A.)#"  , py::arg("C")
          )
        .def_static("IsVertex_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int  ) >(&Contap_HContTool::IsVertex),
                    R"#(Returns True if the intersection point of range Index corresponds with a vertex on the arc A.)#"  , py::arg("C"),  py::arg("Index")
          )
        .def_static("NbSegments_s",
                    (int (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<int (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::NbSegments),
                    R"#(returns the number of part of A solution of the of intersection problem.)#"  , py::arg("C")
          )
        .def_static("HasFirstPoint_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int ,  int &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int ,  int &  ) >(&Contap_HContTool::HasFirstPoint),
                    R"#(Returns True when the segment of range Index is not open at the left side. In that case, IndFirst is the range in the list intersection points (see NbPoints) of the one which defines the left bound of the segment. Otherwise, the method has to return False, and IndFirst has no meaning.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("IndFirst")
          )
        .def_static("HasLastPoint_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int ,  int &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> & ,   const int ,  int &  ) >(&Contap_HContTool::HasLastPoint),
                    R"#(Returns True when the segment of range Index is not open at the right side. In that case, IndLast is the range in the list intersection points (see NbPoints) of the one which defines the right bound of the segment. Otherwise, the method has to return False, and IndLast has no meaning.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("IndLast")
          )
        .def_static("IsAllSolution_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HContTool::IsAllSolution),
                    R"#(Returns True when the whole restriction is solution of the intersection problem.)#"  , py::arg("C")
          )
    // static methods using call by reference i.s.o. return
        .def_static("SamplePoint_s",
            []( const handle<Adaptor3d_Surface> & S, const int Index ){
                double  U;
                double  V;

                Contap_HContTool::SamplePoint(S,Index,U,V);
                
return std::make_tuple(U,V); },
            R"#()#"  , py::arg("S"),  py::arg("Index")
          )
        .def_static("Bounds_s",
            []( const handle<Adaptor2d_Curve2d> & C ){
                double  Ufirst;
                double  Ulast;

                Contap_HContTool::Bounds(C,Ufirst,Ulast);
                
return std::make_tuple(Ufirst,Ulast); },
            R"#(Returns the parametric limits on the arc C. These limits must be finite : they are either the real limits of the arc, for a finite arc, or a bounding box for an infinite arc.)#"  , py::arg("C")
          )
        .def_static("Value_s",
            []( const handle<Adaptor2d_Curve2d> & C, const int Index,gp_Pnt & Pt ){
                double  Tol;
                double  U;

                Contap_HContTool::Value(C,Index,Pt,Tol,U);
                
return std::make_tuple(Tol,U); },
            R"#(Returns the value (Pt), the tolerance (Tol), and the parameter (U) on the arc A , of the intersection point of range Index.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("Pt")
          )
        .def_static("Vertex_s",
            []( const handle<Adaptor2d_Curve2d> & C, const int Index,Adaptor3d_HVertex& V ){
                handle<Adaptor3d_HVertex>  V_ptr; V_ptr = &V;

                Contap_HContTool::Vertex(C,Index,V_ptr);
                if ( V_ptr.get() != &V ) copy_if_assignable(V, *V_ptr);

 },
            R"#(When IsVertex returns True, this method returns the vertex on the arc A.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("V")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_HCurve2dTool from ./opencascade/Contap_HCurve2dTool.hxx
    klass = m.attr("Contap_HCurve2dTool");

    // default constructor
    register_default_constructor<Contap_HCurve2dTool , shared_ptr<Contap_HCurve2dTool>>(m,"Contap_HCurve2dTool");

    // nested enums

    static_cast<py::class_<Contap_HCurve2dTool , shared_ptr<Contap_HCurve2dTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::FirstParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::LastParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<GeomAbs_Shape (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Continuity),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const handle<Adaptor2d_Curve2d> & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const handle<Adaptor2d_Curve2d> & ,   const GeomAbs_Shape  ) >(&Contap_HCurve2dTool::NbIntervals),
                    R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(myclass) >= <S>)#"  , py::arg("C"),  py::arg("S")
          )
        .def_static("Intervals_s",
                    (void (*)(  const handle<Adaptor2d_Curve2d> & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const handle<Adaptor2d_Curve2d> & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&Contap_HCurve2dTool::Intervals),
                    R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("C"),  py::arg("T"),  py::arg("S")
          )
        .def_static("IsClosed_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::IsClosed),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<bool (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::IsPeriodic),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Period_s",
                    (double (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<double (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Period),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Value_s",
                    (gp_Pnt2d (*)(  const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<gp_Pnt2d (*)(  const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_HCurve2dTool::Value),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U")
          )
        .def_static("D0_s",
                    (void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d &  ) ) static_cast<void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d &  ) >(&Contap_HCurve2dTool::D0),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) >(&Contap_HCurve2dTool::D1),
                    R"#(Computes the point of parameter U on the curve with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def_static("D2_s",
                    (void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Contap_HCurve2dTool::D2),
                    R"#(Returns the point P of parameter U, the first and second derivatives V1 and V2. Raised if the continuity of the current interval is not C2.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def_static("D3_s",
                    (void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Contap_HCurve2dTool::D3),
                    R"#(Returns the point P of parameter U, the first, the second and the third derivative. Raised if the continuity of the current interval is not C3.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("V3")
          )
        .def_static("DN_s",
                    (gp_Vec2d (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const int  ) ) static_cast<gp_Vec2d (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const int  ) >(&Contap_HCurve2dTool::DN),
                    R"#(The returned vector gives the value of the derivative for the order of derivation N. Raised if the continuity of the current interval is not CN. Raised if N < 1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("N")
          )
        .def_static("Resolution_s",
                    (double (*)(  const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<double (*)(  const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_HCurve2dTool::Resolution),
                    R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("C"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<GeomAbs_CurveType (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::GetType),
                    R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("C")
          )
        .def_static("Line_s",
                    (gp_Lin2d (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<gp_Lin2d (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Line),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Circle_s",
                    (gp_Circ2d (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<gp_Circ2d (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Circle),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Ellipse_s",
                    (gp_Elips2d (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<gp_Elips2d (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Ellipse),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr2d (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<gp_Hypr2d (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Hyperbola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Parabola_s",
                    (gp_Parab2d (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<gp_Parab2d (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Parabola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Bezier_s",
                    (handle<Geom2d_BezierCurve> (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<handle<Geom2d_BezierCurve> (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::Bezier),
                    R"#()#"  , py::arg("C")
          )
        .def_static("BSpline_s",
                    (handle<Geom2d_BSplineCurve> (*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<handle<Geom2d_BSplineCurve> (*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_HCurve2dTool::BSpline),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const double  ) ) static_cast<int (*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const double  ) >(&Contap_HCurve2dTool::NbSamples),
                    R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_Line from ./opencascade/Contap_Line.hxx
    klass = m.attr("Contap_Line");


    // nested enums

    static_cast<py::class_<Contap_Line , shared_ptr<Contap_Line>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetLineOn2S",
             (void (Contap_Line::*)(  const handle<IntSurf_LineOn2S> &  ) ) static_cast<void (Contap_Line::*)(  const handle<IntSurf_LineOn2S> &  ) >(&Contap_Line::SetLineOn2S),
             R"#()#"  , py::arg("L")
          )
        .def("Clear",
             (void (Contap_Line::*)() ) static_cast<void (Contap_Line::*)() >(&Contap_Line::Clear),
             R"#()#" 
          )
        .def("ResetSeqOfVertex",
             (void (Contap_Line::*)() ) static_cast<void (Contap_Line::*)() >(&Contap_Line::ResetSeqOfVertex),
             R"#()#" 
          )
        .def("Add",
             (void (Contap_Line::*)(  const IntSurf_PntOn2S &  ) ) static_cast<void (Contap_Line::*)(  const IntSurf_PntOn2S &  ) >(&Contap_Line::Add),
             R"#()#"  , py::arg("P")
          )
        .def("SetValue",
             (void (Contap_Line::*)(  const gp_Lin &  ) ) static_cast<void (Contap_Line::*)(  const gp_Lin &  ) >(&Contap_Line::SetValue),
             R"#()#"  , py::arg("L")
          )
        .def("SetValue",
             (void (Contap_Line::*)(  const gp_Circ &  ) ) static_cast<void (Contap_Line::*)(  const gp_Circ &  ) >(&Contap_Line::SetValue),
             R"#()#"  , py::arg("C")
          )
        .def("SetValue",
             (void (Contap_Line::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (Contap_Line::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_Line::SetValue),
             R"#()#"  , py::arg("A")
          )
        .def("Add",
             (void (Contap_Line::*)(  const Contap_Point &  ) ) static_cast<void (Contap_Line::*)(  const Contap_Point &  ) >(&Contap_Line::Add),
             R"#()#"  , py::arg("P")
          )
        .def("NbVertex",
             (int (Contap_Line::*)() const) static_cast<int (Contap_Line::*)() const>(&Contap_Line::NbVertex),
             R"#()#" 
          )
        .def("Vertex",
             (Contap_Point & (Contap_Line::*)(  const int  ) const) static_cast<Contap_Point & (Contap_Line::*)(  const int  ) const>(&Contap_Line::Vertex),
             R"#()#"  , py::arg("Index")
          )
        .def("TypeContour",
             (Contap_IType (Contap_Line::*)() const) static_cast<Contap_IType (Contap_Line::*)() const>(&Contap_Line::TypeContour),
             R"#(Returns Contap_Lin for a line, Contap_Circle for a circle, and Contap_Walking for a Walking line, Contap_Restriction for a part of boundary.)#" 
          )
        .def("NbPnts",
             (int (Contap_Line::*)() const) static_cast<int (Contap_Line::*)() const>(&Contap_Line::NbPnts),
             R"#()#" 
          )
        .def("Point",
             ( const IntSurf_PntOn2S & (Contap_Line::*)(  const int  ) const) static_cast< const IntSurf_PntOn2S & (Contap_Line::*)(  const int  ) const>(&Contap_Line::Point),
             R"#()#"  , py::arg("Index")
          )
        .def("Line",
             (gp_Lin (Contap_Line::*)() const) static_cast<gp_Lin (Contap_Line::*)() const>(&Contap_Line::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (Contap_Line::*)() const) static_cast<gp_Circ (Contap_Line::*)() const>(&Contap_Line::Circle),
             R"#()#" 
          )
        .def("SetTransitionOnS",
             (void (Contap_Line::*)(  const IntSurf_TypeTrans  ) ) static_cast<void (Contap_Line::*)(  const IntSurf_TypeTrans  ) >(&Contap_Line::SetTransitionOnS),
             R"#(Set The Transition of the line.)#"  , py::arg("T")
          )
        .def("TransitionOnS",
             (IntSurf_TypeTrans (Contap_Line::*)() const) static_cast<IntSurf_TypeTrans (Contap_Line::*)() const>(&Contap_Line::TransitionOnS),
             R"#(returns IN if at the "left" of the line, the normale of the surface is oriented to the observator.)#" 
          )
        .def("Add",
             (void (Contap_Line::*)(  const IntSurf_PntOn2S &  ) ) static_cast<void (Contap_Line::*)(  const IntSurf_PntOn2S &  ) >(&Contap_Line::Add),
             R"#()#"  , py::arg("POn2S")
          )
        .def("NbVertex",
             (int (Contap_Line::*)() const) static_cast<int (Contap_Line::*)() const>(&Contap_Line::NbVertex),
             R"#()#" 
          )
        .def("Vertex",
             (Contap_Point & (Contap_Line::*)(  const int  ) const) static_cast<Contap_Point & (Contap_Line::*)(  const int  ) const>(&Contap_Line::Vertex),
             R"#()#"  , py::arg("Index")
          )
        .def("TypeContour",
             (Contap_IType (Contap_Line::*)() const) static_cast<Contap_IType (Contap_Line::*)() const>(&Contap_Line::TypeContour),
             R"#(Returns Contap_Lin for a line, Contap_Circle for a circle, and Contap_Walking for a Walking line, Contap_Restriction for a part of boundary.)#" 
          )
        .def("NbPnts",
             (int (Contap_Line::*)() const) static_cast<int (Contap_Line::*)() const>(&Contap_Line::NbPnts),
             R"#()#" 
          )
        .def("Point",
             ( const IntSurf_PntOn2S & (Contap_Line::*)(  const int  ) const) static_cast< const IntSurf_PntOn2S & (Contap_Line::*)(  const int  ) const>(&Contap_Line::Point),
             R"#()#"  , py::arg("Index")
          )
        .def("Line",
             (gp_Lin (Contap_Line::*)() const) static_cast<gp_Lin (Contap_Line::*)() const>(&Contap_Line::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (Contap_Line::*)() const) static_cast<gp_Circ (Contap_Line::*)() const>(&Contap_Line::Circle),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("LineOn2S",
             ( const handle<IntSurf_LineOn2S> & (Contap_Line::*)() const) static_cast< const handle<IntSurf_LineOn2S> & (Contap_Line::*)() const>(&Contap_Line::LineOn2S),
             R"#()#"
             
         )
       .def("Arc",
             ( const handle<Adaptor2d_Curve2d> & (Contap_Line::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_Line::*)() const>(&Contap_Line::Arc),
             R"#()#"
             
         )
       .def("LineOn2S",
             ( const handle<IntSurf_LineOn2S> & (Contap_Line::*)() const) static_cast< const handle<IntSurf_LineOn2S> & (Contap_Line::*)() const>(&Contap_Line::LineOn2S),
             R"#()#"
             
         )
;

    // Class Contap_Point from ./opencascade/Contap_Point.hxx
    klass = m.attr("Contap_Point");


    // nested enums

    static_cast<py::class_<Contap_Point , shared_ptr<Contap_Point>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const double, const double >()  , py::arg("Pt"),  py::arg("U"),  py::arg("V") )
    // custom constructors
    // methods
        .def("SetValue",
             (void (Contap_Point::*)(  const gp_Pnt & ,   const double ,   const double  ) ) static_cast<void (Contap_Point::*)(  const gp_Pnt & ,   const double ,   const double  ) >(&Contap_Point::SetValue),
             R"#(Sets the values for a point.)#"  , py::arg("Pt"),  py::arg("U"),  py::arg("V")
          )
        .def("SetParameter",
             (void (Contap_Point::*)(  const double  ) ) static_cast<void (Contap_Point::*)(  const double  ) >(&Contap_Point::SetParameter),
             R"#(Set the value of the parameter on the intersection line.)#"  , py::arg("Para")
          )
        .def("SetVertex",
             (void (Contap_Point::*)(  const handle<Adaptor3d_HVertex> &  ) ) static_cast<void (Contap_Point::*)(  const handle<Adaptor3d_HVertex> &  ) >(&Contap_Point::SetVertex),
             R"#(Sets the values of a point which is a vertex on the initial facet of restriction of one of the surface.)#"  , py::arg("V")
          )
        .def("SetArc",
             (void (Contap_Point::*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const IntSurf_Transition & ,   const IntSurf_Transition &  ) ) static_cast<void (Contap_Point::*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const IntSurf_Transition & ,   const IntSurf_Transition &  ) >(&Contap_Point::SetArc),
             R"#(Sets the value of the arc and of the parameter on this arc of the point.)#"  , py::arg("A"),  py::arg("Param"),  py::arg("TLine"),  py::arg("TArc")
          )
        .def("SetMultiple",
             (void (Contap_Point::*)() ) static_cast<void (Contap_Point::*)() >(&Contap_Point::SetMultiple),
             R"#()#" 
          )
        .def("SetInternal",
             (void (Contap_Point::*)() ) static_cast<void (Contap_Point::*)() >(&Contap_Point::SetInternal),
             R"#()#" 
          )
        .def("ParameterOnLine",
             (double (Contap_Point::*)() const) static_cast<double (Contap_Point::*)() const>(&Contap_Point::ParameterOnLine),
             R"#(This method returns the parameter of the point on the intersection line. If the points does not belong to an intersection line, the value returned does not have any sens.)#" 
          )
        .def("IsOnArc",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsOnArc),
             R"#(Returns True when the point is an intersection between the contour and a restriction.)#" 
          )
        .def("ParameterOnArc",
             (double (Contap_Point::*)() const) static_cast<double (Contap_Point::*)() const>(&Contap_Point::ParameterOnArc),
             R"#(Returns the parameter of the point on the arc returned by the method Arc().)#" 
          )
        .def("IsVertex",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsVertex),
             R"#(Returns TRUE if the point is a vertex on the initial restriction facet of the surface.)#" 
          )
        .def("IsMultiple",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsMultiple),
             R"#(Returns True if the point belongs to several lines.)#" 
          )
        .def("IsInternal",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsInternal),
             R"#(Returns True if the point is an internal one, i.e if the tangent to the line on the point and the eye direction are parallel.)#" 
          )
        .def("SetValue",
             (void (Contap_Point::*)(  const gp_Pnt & ,   const double ,   const double  ) ) static_cast<void (Contap_Point::*)(  const gp_Pnt & ,   const double ,   const double  ) >(&Contap_Point::SetValue),
             R"#(Sets the values for a point.)#"  , py::arg("Pt"),  py::arg("U"),  py::arg("V")
          )
        .def("SetParameter",
             (void (Contap_Point::*)(  const double  ) ) static_cast<void (Contap_Point::*)(  const double  ) >(&Contap_Point::SetParameter),
             R"#(Set the value of the parameter on the intersection line.)#"  , py::arg("Para")
          )
        .def("SetVertex",
             (void (Contap_Point::*)(  const handle<Adaptor3d_HVertex> &  ) ) static_cast<void (Contap_Point::*)(  const handle<Adaptor3d_HVertex> &  ) >(&Contap_Point::SetVertex),
             R"#(Sets the values of a point which is a vertex on the initial facet of restriction of one of the surface.)#"  , py::arg("V")
          )
        .def("SetArc",
             (void (Contap_Point::*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const IntSurf_Transition & ,   const IntSurf_Transition &  ) ) static_cast<void (Contap_Point::*)(  const handle<Adaptor2d_Curve2d> & ,   const double ,   const IntSurf_Transition & ,   const IntSurf_Transition &  ) >(&Contap_Point::SetArc),
             R"#(Sets the value of the arc and of the parameter on this arc of the point.)#"  , py::arg("A"),  py::arg("Param"),  py::arg("TLine"),  py::arg("TArc")
          )
        .def("SetMultiple",
             (void (Contap_Point::*)() ) static_cast<void (Contap_Point::*)() >(&Contap_Point::SetMultiple),
             R"#()#" 
          )
        .def("SetInternal",
             (void (Contap_Point::*)() ) static_cast<void (Contap_Point::*)() >(&Contap_Point::SetInternal),
             R"#()#" 
          )
        .def("IsMultiple",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsMultiple),
             R"#(Returns True if the point belongs to several lines.)#" 
          )
        .def("IsInternal",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsInternal),
             R"#(Returns True if the point is an internal one, i.e if the tangent to the line on the point and the eye direction are parallel.)#" 
          )
        .def("ParameterOnLine",
             (double (Contap_Point::*)() const) static_cast<double (Contap_Point::*)() const>(&Contap_Point::ParameterOnLine),
             R"#(This method returns the parameter of the point on the intersection line. If the points does not belong to an intersection line, the value returned does not have any sens.)#" 
          )
        .def("IsOnArc",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsOnArc),
             R"#(Returns True when the point is an intersection between the contour and a restriction.)#" 
          )
        .def("ParameterOnArc",
             (double (Contap_Point::*)() const) static_cast<double (Contap_Point::*)() const>(&Contap_Point::ParameterOnArc),
             R"#(Returns the parameter of the point on the arc returned by the method Arc().)#" 
          )
        .def("IsVertex",
             (bool (Contap_Point::*)() const) static_cast<bool (Contap_Point::*)() const>(&Contap_Point::IsVertex),
             R"#(Returns TRUE if the point is a vertex on the initial restriction facet of the surface.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Parameters",
             []( Contap_Point &self   ){
                 double  U1;
                double  V1;

                 self.Parameters(U1,V1);
                 return std::make_tuple(U1,V1); },
             R"#(Returns the parameters on the surface of the point.)#" 
          )
        .def("Parameters",
             []( Contap_Point &self   ){
                 double  U1;
                double  V1;

                 self.Parameters(U1,V1);
                 return std::make_tuple(U1,V1); },
             R"#(Returns the parameters on the surface of the point.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const gp_Pnt & (Contap_Point::*)() const) static_cast< const gp_Pnt & (Contap_Point::*)() const>(&Contap_Point::Value),
             R"#(Returns the intersection point (geometric information).)#"
             
         )
       .def("Arc",
             ( const handle<Adaptor2d_Curve2d> & (Contap_Point::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_Point::*)() const>(&Contap_Point::Arc),
             R"#(Returns the arc of restriction containing the vertex.)#"
             
         )
       .def("TransitionOnLine",
             ( const IntSurf_Transition & (Contap_Point::*)() const) static_cast< const IntSurf_Transition & (Contap_Point::*)() const>(&Contap_Point::TransitionOnLine),
             R"#(Returns the transition of the point on the contour.)#"
             
         )
       .def("TransitionOnArc",
             ( const IntSurf_Transition & (Contap_Point::*)() const) static_cast< const IntSurf_Transition & (Contap_Point::*)() const>(&Contap_Point::TransitionOnArc),
             R"#(Returns the transition of the point on the arc.)#"
             
         )
       .def("Vertex",
             ( const handle<Adaptor3d_HVertex> & (Contap_Point::*)() const) static_cast< const handle<Adaptor3d_HVertex> & (Contap_Point::*)() const>(&Contap_Point::Vertex),
             R"#(Returns the information about the point when it is on the domain of the patch, i-e when the function IsVertex returns True. Otherwise, an exception is raised.)#"
             
         )
       .def("Value",
             ( const gp_Pnt & (Contap_Point::*)() const) static_cast< const gp_Pnt & (Contap_Point::*)() const>(&Contap_Point::Value),
             R"#(Returns the intersection point (geometric information).)#"
             
         )
       .def("Arc",
             ( const handle<Adaptor2d_Curve2d> & (Contap_Point::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_Point::*)() const>(&Contap_Point::Arc),
             R"#(Returns the arc of restriction containing the vertex.)#"
             
         )
       .def("TransitionOnLine",
             ( const IntSurf_Transition & (Contap_Point::*)() const) static_cast< const IntSurf_Transition & (Contap_Point::*)() const>(&Contap_Point::TransitionOnLine),
             R"#(Returns the transition of the point on the contour.)#"
             
         )
       .def("TransitionOnArc",
             ( const IntSurf_Transition & (Contap_Point::*)() const) static_cast< const IntSurf_Transition & (Contap_Point::*)() const>(&Contap_Point::TransitionOnArc),
             R"#(Returns the transition of the point on the arc.)#"
             
         )
       .def("Vertex",
             ( const handle<Adaptor3d_HVertex> & (Contap_Point::*)() const) static_cast< const handle<Adaptor3d_HVertex> & (Contap_Point::*)() const>(&Contap_Point::Vertex),
             R"#(Returns the information about the point when it is on the domain of the patch, i-e when the function IsVertex returns True. Otherwise, an exception is raised.)#"
             
         )
;

    // Class Contap_SurfFunction from ./opencascade/Contap_SurfFunction.hxx
    klass = m.attr("Contap_SurfFunction");


    // nested enums

    static_cast<py::class_<Contap_SurfFunction , shared_ptr<Contap_SurfFunction>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (Contap_SurfFunction::*)(  const handle<Adaptor3d_Surface> &  ) ) static_cast<void (Contap_SurfFunction::*)(  const handle<Adaptor3d_Surface> &  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("S")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Pnt &  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Pnt &  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Eye")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Dir &  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Dir &  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Dir")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Dir & ,   const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Dir"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Pnt & ,   const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Pnt & ,   const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Eye"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Tolerance")
          )
        .def("NbVariables",
             (int (Contap_SurfFunction::*)() const) static_cast<int (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::NbVariables),
             R"#(This method has to return 2.)#" 
          )
        .def("NbEquations",
             (int (Contap_SurfFunction::*)() const) static_cast<int (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::NbEquations),
             R"#(This method has to return 1.)#" 
          )
        .def("Value",
             (bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Vector &  ) >(&Contap_SurfFunction::Value),
             R"#(The dimension of F is 1.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Matrix &  ) >(&Contap_SurfFunction::Derivatives),
             R"#(The dimension of D is (1,2).)#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Contap_SurfFunction::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&Contap_SurfFunction::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
        .def("Root",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Root),
             R"#(Root is the value of the function at the solution. It is a vector of dimension 1, i-e a real.)#" 
          )
        .def("Tolerance",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Tolerance),
             R"#(Returns the value Tol so that if std::abs(Func.Root())<Tol the function is considered null.)#" 
          )
        .def("IsTangent",
             (bool (Contap_SurfFunction::*)() ) static_cast<bool (Contap_SurfFunction::*)() >(&Contap_SurfFunction::IsTangent),
             R"#()#" 
          )
        .def("FunctionType",
             (Contap_TFunction (Contap_SurfFunction::*)() const) static_cast<Contap_TFunction (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::FunctionType),
             R"#()#" 
          )
        .def("Angle",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Angle),
             R"#()#" 
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Pnt &  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Pnt &  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Eye")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Dir &  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Dir &  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Direction")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Dir & ,   const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Direction"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const gp_Pnt & ,   const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const gp_Pnt & ,   const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Eye"),  py::arg("Angle")
          )
        .def("Set",
             (void (Contap_SurfFunction::*)(  const double  ) ) static_cast<void (Contap_SurfFunction::*)(  const double  ) >(&Contap_SurfFunction::Set),
             R"#()#"  , py::arg("Tolerance")
          )
        .def("Root",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Root),
             R"#(Root is the value of the function at the solution. It is a vector of dimension 1, i-e a real.)#" 
          )
        .def("Tolerance",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Tolerance),
             R"#(Returns the value Tol so that if std::abs(Func.Root())<Tol the function is considered null.)#" 
          )
        .def("Angle",
             (double (Contap_SurfFunction::*)() const) static_cast<double (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Angle),
             R"#()#" 
          )
        .def("FunctionType",
             (Contap_TFunction (Contap_SurfFunction::*)() const) static_cast<Contap_TFunction (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::FunctionType),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Point",
             ( const gp_Pnt & (Contap_SurfFunction::*)() const) static_cast< const gp_Pnt & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Point),
             R"#(Returns the value of the solution point on the surface.)#"
             
         )
       .def("Direction3d",
             ( const gp_Vec & (Contap_SurfFunction::*)() ) static_cast< const gp_Vec & (Contap_SurfFunction::*)() >(&Contap_SurfFunction::Direction3d),
             R"#()#"
             
         )
       .def("Direction2d",
             ( const gp_Dir2d & (Contap_SurfFunction::*)() ) static_cast< const gp_Dir2d & (Contap_SurfFunction::*)() >(&Contap_SurfFunction::Direction2d),
             R"#()#"
             
         )
       .def("Eye",
             ( const gp_Pnt & (Contap_SurfFunction::*)() const) static_cast< const gp_Pnt & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Eye),
             R"#()#"
             
         )
       .def("Direction",
             ( const gp_Dir & (Contap_SurfFunction::*)() const) static_cast< const gp_Dir & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Direction),
             R"#()#"
             
         )
       .def("Surface",
             ( const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const) static_cast< const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Surface),
             R"#()#"
             
         )
       .def("PSurface",
             ( const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const) static_cast< const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::PSurface),
             R"#(Method is entered for compatibility with IntPatch_TheSurfFunction.)#"
             
         )
       .def("Point",
             ( const gp_Pnt & (Contap_SurfFunction::*)() const) static_cast< const gp_Pnt & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Point),
             R"#(Returns the value of the solution point on the surface.)#"
             
         )
       .def("Direction3d",
             ( const gp_Vec & (Contap_SurfFunction::*)() ) static_cast< const gp_Vec & (Contap_SurfFunction::*)() >(&Contap_SurfFunction::Direction3d),
             R"#()#"
             
         )
       .def("Direction2d",
             ( const gp_Dir2d & (Contap_SurfFunction::*)() ) static_cast< const gp_Dir2d & (Contap_SurfFunction::*)() >(&Contap_SurfFunction::Direction2d),
             R"#()#"
             
         )
       .def("Surface",
             ( const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const) static_cast< const handle<Adaptor3d_Surface> & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Surface),
             R"#()#"
             
         )
       .def("Eye",
             ( const gp_Pnt & (Contap_SurfFunction::*)() const) static_cast< const gp_Pnt & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Eye),
             R"#()#"
             
         )
       .def("Direction",
             ( const gp_Dir & (Contap_SurfFunction::*)() const) static_cast< const gp_Dir & (Contap_SurfFunction::*)() const>(&Contap_SurfFunction::Direction),
             R"#()#"
             
         )
;

    // Class Contap_SurfProps from ./opencascade/Contap_SurfProps.hxx
    klass = m.attr("Contap_SurfProps");

    // default constructor
    register_default_constructor<Contap_SurfProps , shared_ptr<Contap_SurfProps>>(m,"Contap_SurfProps");

    // nested enums

    static_cast<py::class_<Contap_SurfProps , shared_ptr<Contap_SurfProps>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Normale_s",
                    (void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec &  ) ) static_cast<void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec &  ) >(&Contap_SurfProps::Normale),
                    R"#(Computes the point <P>, and normal vector <N> on <S> at parameters U,V.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("N")
          )
        .def_static("DerivAndNorm_s",
                    (void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&Contap_SurfProps::DerivAndNorm),
                    R"#(Computes the point <P>, and normal vector <N> on <S> at parameters U,V.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("d1u"),  py::arg("d1v"),  py::arg("N")
          )
        .def_static("NormAndDn_s",
                    (void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const handle<Adaptor3d_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&Contap_SurfProps::NormAndDn),
                    R"#(Computes the point <P>, normal vector <N>, and its derivatives <Dnu> and <Dnv> on <S> at parameters U,V.)#"  , py::arg("S"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("N"),  py::arg("Dnu"),  py::arg("Dnv")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_TheIWLineOfTheIWalking from ./opencascade/Contap_TheIWLineOfTheIWalking.hxx
    klass = m.attr("Contap_TheIWLineOfTheIWalking");


    // nested enums

    static_cast<py::class_<Contap_TheIWLineOfTheIWalking ,opencascade::handle<Contap_TheIWLineOfTheIWalking>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const IntSurf_Allocator & >()  , py::arg("theAllocator")=static_cast< const IntSurf_Allocator &>(nullptr) )
    // custom constructors
    // methods
        .def("Reverse",
             (void (Contap_TheIWLineOfTheIWalking::*)() ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)() >(&Contap_TheIWLineOfTheIWalking::Reverse),
             R"#(reverse the points in the line. Hasfirst, HasLast are kept.)#" 
          )
        .def("Cut",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) >(&Contap_TheIWLineOfTheIWalking::Cut),
             R"#(Cut the line at the point of rank Index.)#"  , py::arg("Index")
          )
        .def("AddPoint",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const IntSurf_PntOn2S &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const IntSurf_PntOn2S &  ) >(&Contap_TheIWLineOfTheIWalking::AddPoint),
             R"#(Add a point in the line.)#"  , py::arg("P")
          )
        .def("AddStatusFirst",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirst),
             R"#()#"  , py::arg("Closed"),  py::arg("HasFirst")
          )
        .def("AddStatusFirst",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const int ,   const IntSurf_PathPoint &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const int ,   const IntSurf_PathPoint &  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirst),
             R"#()#"  , py::arg("Closed"),  py::arg("HasLast"),  py::arg("Index"),  py::arg("P")
          )
        .def("AddStatusFirstLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirstLast),
             R"#()#"  , py::arg("Closed"),  py::arg("HasFirst"),  py::arg("HasLast")
          )
        .def("AddStatusLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusLast),
             R"#()#"  , py::arg("HasLast")
          )
        .def("AddStatusLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const int ,   const IntSurf_PathPoint &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const int ,   const IntSurf_PathPoint &  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusLast),
             R"#()#"  , py::arg("HasLast"),  py::arg("Index"),  py::arg("P")
          )
        .def("AddIndexPassing",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) >(&Contap_TheIWLineOfTheIWalking::AddIndexPassing),
             R"#(associate the index of the point on the line with the index of the point passing through the starting iterator)#"  , py::arg("Index")
          )
        .def("SetTangentVector",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const gp_Vec & ,   const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const gp_Vec & ,   const int  ) >(&Contap_TheIWLineOfTheIWalking::SetTangentVector),
             R"#()#"  , py::arg("V"),  py::arg("Index")
          )
        .def("SetTangencyAtBegining",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::SetTangencyAtBegining),
             R"#()#"  , py::arg("IsTangent")
          )
        .def("SetTangencyAtEnd",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::SetTangencyAtEnd),
             R"#()#"  , py::arg("IsTangent")
          )
        .def("NbPoints",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::NbPoints),
             R"#(Returns the number of points of the line (including first point and end point : see HasLastPoint and HasFirstPoint).)#" 
          )
        .def("Value",
             ( const IntSurf_PntOn2S & (Contap_TheIWLineOfTheIWalking::*)(  const int  ) const) static_cast< const IntSurf_PntOn2S & (Contap_TheIWLineOfTheIWalking::*)(  const int  ) const>(&Contap_TheIWLineOfTheIWalking::Value),
             R"#(Returns the point of range Index. If index <= 0 or Index > NbPoints, an exception is raised.)#"  , py::arg("Index")
          )
        .def("IsClosed",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsClosed),
             R"#(Returns True if the line is closed.)#" 
          )
        .def("HasFirstPoint",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::HasFirstPoint),
             R"#(Returns True if the first point of the line is a marching point. when is HasFirstPoint==False ,the line begins on the natural bound of the surface. The line can be too long)#" 
          )
        .def("HasLastPoint",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::HasLastPoint),
             R"#(Returns True if the end point of the line is a marching point (Point from IntWS). when is HasFirstPoint==False the line ends on the natural bound of the surface. The line can be too long.)#" 
          )
        .def("FirstPointIndex",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::FirstPointIndex),
             R"#(Returns the Index of first point of the line when it is a marching point. This index is the index in the PointStartIterator. An exception is raised if HasFirstPoint returns False.)#" 
          )
        .def("LastPointIndex",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::LastPointIndex),
             R"#(Returns the index of last point of the line when it is a marching point. This index is the index in the PointStartIterator. An exception is raised if HasLastPoint returns False.)#" 
          )
        .def("NbPassingPoint",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::NbPassingPoint),
             R"#(returns the number of points belonging to Pnts1 which are passing point.)#" 
          )
        .def("TangentVector",
             ( const gp_Vec & (Contap_TheIWLineOfTheIWalking::*)( int &  ) const) static_cast< const gp_Vec & (Contap_TheIWLineOfTheIWalking::*)( int &  ) const>(&Contap_TheIWLineOfTheIWalking::TangentVector),
             R"#()#"  , py::arg("Index")
          )
        .def("IsTangentAtBegining",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsTangentAtBegining),
             R"#()#" 
          )
        .def("IsTangentAtEnd",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsTangentAtEnd),
             R"#()#" 
          )
        .def("Cut",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) >(&Contap_TheIWLineOfTheIWalking::Cut),
             R"#(Cut the line at the point of rank Index.)#"  , py::arg("Index")
          )
        .def("AddPoint",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const IntSurf_PntOn2S &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const IntSurf_PntOn2S &  ) >(&Contap_TheIWLineOfTheIWalking::AddPoint),
             R"#(Add a point in the line.)#"  , py::arg("P")
          )
        .def("AddStatusFirst",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirst),
             R"#()#"  , py::arg("Closed"),  py::arg("HasFirst")
          )
        .def("AddStatusLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusLast),
             R"#()#"  , py::arg("HasLast")
          )
        .def("AddStatusFirst",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const int ,   const IntSurf_PathPoint &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const int ,   const IntSurf_PathPoint &  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirst),
             R"#()#"  , py::arg("Closed"),  py::arg("HasFirst"),  py::arg("Index"),  py::arg("P")
          )
        .def("AddStatusLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const int ,   const IntSurf_PathPoint &  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const int ,   const IntSurf_PathPoint &  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusLast),
             R"#()#"  , py::arg("HasLast"),  py::arg("Index"),  py::arg("P")
          )
        .def("AddStatusFirstLast",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool ,   const bool ,   const bool  ) >(&Contap_TheIWLineOfTheIWalking::AddStatusFirstLast),
             R"#()#"  , py::arg("Closed"),  py::arg("HasFirst"),  py::arg("HasLast")
          )
        .def("AddIndexPassing",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const int  ) >(&Contap_TheIWLineOfTheIWalking::AddIndexPassing),
             R"#(associate the index of the point on the line with the index of the point passing through the starting iterator)#"  , py::arg("Index")
          )
        .def("NbPoints",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::NbPoints),
             R"#(Returns the number of points of the line (including first point and end point : see HasLastPoint and HasFirstPoint).)#" 
          )
        .def("Value",
             ( const IntSurf_PntOn2S & (Contap_TheIWLineOfTheIWalking::*)(  const int  ) const) static_cast< const IntSurf_PntOn2S & (Contap_TheIWLineOfTheIWalking::*)(  const int  ) const>(&Contap_TheIWLineOfTheIWalking::Value),
             R"#(Returns the point of range Index. If index <= 0 or Index > NbPoints, an exception is raised.)#"  , py::arg("Index")
          )
        .def("IsClosed",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsClosed),
             R"#(Returns True if the line is closed.)#" 
          )
        .def("HasFirstPoint",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::HasFirstPoint),
             R"#(Returns True if the first point of the line is a marching point. when is HasFirstPoint==False ,the line begins on the natural bound of the surface. The line can be too long)#" 
          )
        .def("FirstPointIndex",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::FirstPointIndex),
             R"#(Returns the Index of first point of the line when it is a marching point. This index is the index in the PointStartIterator. An exception is raised if HasFirstPoint returns False.)#" 
          )
        .def("HasLastPoint",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::HasLastPoint),
             R"#(Returns True if the end point of the line is a marching point (Point from IntWS). when is HasFirstPoint==False the line ends on the natural bound of the surface. The line can be too long.)#" 
          )
        .def("LastPointIndex",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::LastPointIndex),
             R"#(Returns the index of last point of the line when it is a marching point. This index is the index in the PointStartIterator. An exception is raised if HasLastPoint returns False.)#" 
          )
        .def("NbPassingPoint",
             (int (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<int (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::NbPassingPoint),
             R"#(returns the number of points belonging to Pnts1 which are passing point.)#" 
          )
        .def("SetTangentVector",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const gp_Vec & ,   const int  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const gp_Vec & ,   const int  ) >(&Contap_TheIWLineOfTheIWalking::SetTangentVector),
             R"#()#"  , py::arg("V"),  py::arg("Index")
          )
        .def("SetTangencyAtBegining",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::SetTangencyAtBegining),
             R"#()#"  , py::arg("IsTangent")
          )
        .def("SetTangencyAtEnd",
             (void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) ) static_cast<void (Contap_TheIWLineOfTheIWalking::*)(  const bool  ) >(&Contap_TheIWLineOfTheIWalking::SetTangencyAtEnd),
             R"#()#"  , py::arg("IsTangent")
          )
        .def("TangentVector",
             ( const gp_Vec & (Contap_TheIWLineOfTheIWalking::*)( int &  ) const) static_cast< const gp_Vec & (Contap_TheIWLineOfTheIWalking::*)( int &  ) const>(&Contap_TheIWLineOfTheIWalking::TangentVector),
             R"#()#"  , py::arg("Index")
          )
        .def("IsTangentAtBegining",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsTangentAtBegining),
             R"#()#" 
          )
        .def("IsTangentAtEnd",
             (bool (Contap_TheIWLineOfTheIWalking::*)() const) static_cast<bool (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::IsTangentAtEnd),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("PassingPoint",
             []( Contap_TheIWLineOfTheIWalking &self ,  const int Index ){
                 int  IndexLine;
                int  IndexPnts;

                 self.PassingPoint(Index,IndexLine,IndexPnts);
                 return std::make_tuple(IndexLine,IndexPnts); },
             R"#(returns the index of the point belonging to the line which is associated to the passing point belonging to Pnts1 an exception is raised if Index > NbPassingPoint())#"  , py::arg("Index")
          )
        .def("PassingPoint",
             []( Contap_TheIWLineOfTheIWalking &self ,  const int Index ){
                 int  IndexLine;
                int  IndexPnts;

                 self.PassingPoint(Index,IndexLine,IndexPnts);
                 return std::make_tuple(IndexLine,IndexPnts); },
             R"#(returns the index of the point belonging to the line which is associated to the passing point belonging to Pnts1 an exception is raised if Index > NbPassingPoint())#"  , py::arg("Index")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Contap_TheIWLineOfTheIWalking::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Contap_TheIWLineOfTheIWalking::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Line",
             ( const handle<IntSurf_LineOn2S> & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const handle<IntSurf_LineOn2S> & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::Line),
             R"#(Returns the LineOn2S contained in the walking line.)#"
             
         )
       .def("FirstPoint",
             ( const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::FirstPoint),
             R"#(Returns the first point of the line when it is a marching point. An exception is raised if HasFirstPoint returns False.)#"
             
         )
       .def("LastPoint",
             ( const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::LastPoint),
             R"#(Returns the last point of the line when it is a marching point. An exception is raised if HasLastPoint returns False.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const handle<Standard_Type> & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::DynamicType),
             R"#()#"
             
         )
       .def("Line",
             ( const handle<IntSurf_LineOn2S> & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const handle<IntSurf_LineOn2S> & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::Line),
             R"#(Returns the LineOn2S contained in the walking line.)#"
             
         )
       .def("FirstPoint",
             ( const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::FirstPoint),
             R"#(Returns the first point of the line when it is a marching point. An exception is raised if HasFirstPoint returns False.)#"
             
         )
       .def("LastPoint",
             ( const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const) static_cast< const IntSurf_PathPoint & (Contap_TheIWLineOfTheIWalking::*)() const>(&Contap_TheIWLineOfTheIWalking::LastPoint),
             R"#(Returns the last point of the line when it is a marching point. An exception is raised if HasLastPoint returns False.)#"
             
         )
;

    // Class Contap_TheIWalking from ./opencascade/Contap_TheIWalking.hxx
    klass = m.attr("Contap_TheIWalking");


    // nested enums

    static_cast<py::class_<Contap_TheIWalking , shared_ptr<Contap_TheIWalking>  >>(klass)
    // constructors
        .def(py::init<  const double, const double, const double, const bool >()  , py::arg("Epsilon"),  py::arg("Deflection"),  py::arg("Step"),  py::arg("theToFillHoles")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("SetTolerance",
             (void (Contap_TheIWalking::*)(  const double ,   const double ,   const double  ) ) static_cast<void (Contap_TheIWalking::*)(  const double ,   const double ,   const double  ) >(&Contap_TheIWalking::SetTolerance),
             R"#(Deflection is the maximum deflection admitted between two consecutive points on a resulting polyline. Step is the maximum increment admitted between two consecutive points (in 2d space). Epsilon is the tolerance beyond which 2 points are confused)#"  , py::arg("Epsilon"),  py::arg("Deflection"),  py::arg("Step")
          )
        .def("Perform",
             (void (Contap_TheIWalking::*)(  const NCollection_Sequence<IntSurf_PathPoint> & ,   const NCollection_Sequence<IntSurf_InteriorPoint> & ,  Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const bool  ) ) static_cast<void (Contap_TheIWalking::*)(  const NCollection_Sequence<IntSurf_PathPoint> & ,   const NCollection_Sequence<IntSurf_InteriorPoint> & ,  Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const bool  ) >(&Contap_TheIWalking::Perform),
             R"#(Searches a set of polylines starting on a point of Pnts1 or Pnts2. Each point on a resulting polyline verifies F(u,v)=0)#"  , py::arg("Pnts1"),  py::arg("Pnts2"),  py::arg("Func"),  py::arg("S"),  py::arg("Reversed")=static_cast< const bool>(false)
          )
        .def("Perform",
             (void (Contap_TheIWalking::*)(  const NCollection_Sequence<IntSurf_PathPoint> & ,  Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const bool  ) ) static_cast<void (Contap_TheIWalking::*)(  const NCollection_Sequence<IntSurf_PathPoint> & ,  Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const bool  ) >(&Contap_TheIWalking::Perform),
             R"#(Searches a set of polylines starting on a point of Pnts1. Each point on a resulting polyline verifies F(u,v)=0)#"  , py::arg("Pnts1"),  py::arg("Func"),  py::arg("S"),  py::arg("Reversed")=static_cast< const bool>(false)
          )
        .def("IsDone",
             (bool (Contap_TheIWalking::*)() const) static_cast<bool (Contap_TheIWalking::*)() const>(&Contap_TheIWalking::IsDone),
             R"#(Returns true if the calculus was successful.)#" 
          )
        .def("NbLines",
             (int (Contap_TheIWalking::*)() const) static_cast<int (Contap_TheIWalking::*)() const>(&Contap_TheIWalking::NbLines),
             R"#(Returns the number of resulting polylines. An exception is raised if IsDone returns False.)#" 
          )
        .def("Value",
             ( const handle<Contap_TheIWLineOfTheIWalking> & (Contap_TheIWalking::*)(  const int  ) const) static_cast< const handle<Contap_TheIWLineOfTheIWalking> & (Contap_TheIWalking::*)(  const int  ) const>(&Contap_TheIWalking::Value),
             R"#(Returns the polyline of range Index. An exception is raised if IsDone is False. An exception is raised if Index<=0 or Index>NbLines.)#"  , py::arg("Index")
          )
        .def("NbSinglePnts",
             (int (Contap_TheIWalking::*)() const) static_cast<int (Contap_TheIWalking::*)() const>(&Contap_TheIWalking::NbSinglePnts),
             R"#(Returns the number of points belonging to Pnts on which no line starts or ends. An exception is raised if IsDone returns False.)#" 
          )
        .def("SinglePnt",
             ( const IntSurf_PathPoint & (Contap_TheIWalking::*)(  const int  ) const) static_cast< const IntSurf_PathPoint & (Contap_TheIWalking::*)(  const int  ) const>(&Contap_TheIWalking::SinglePnt),
             R"#(Returns the point of range Index . An exception is raised if IsDone returns False. An exception is raised if Index<=0 or Index > NbSinglePnts.)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_ThePathPointOfTheSearch from ./opencascade/Contap_ThePathPointOfTheSearch.hxx
    klass = m.attr("Contap_ThePathPointOfTheSearch");


    // nested enums

    static_cast<py::class_<Contap_ThePathPointOfTheSearch , shared_ptr<Contap_ThePathPointOfTheSearch>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const double, const handle<Adaptor2d_Curve2d> &, const double >()  , py::arg("P"),  py::arg("Tol"),  py::arg("A"),  py::arg("Parameter") )
        .def(py::init<  const gp_Pnt &, const double, const handle<Adaptor3d_HVertex> &, const handle<Adaptor2d_Curve2d> &, const double >()  , py::arg("P"),  py::arg("Tol"),  py::arg("V"),  py::arg("A"),  py::arg("Parameter") )
    // custom constructors
    // methods
        .def("SetValue",
             (void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_ThePathPointOfTheSearch::SetValue),
             R"#()#"  , py::arg("P"),  py::arg("Tol"),  py::arg("V"),  py::arg("A"),  py::arg("Parameter")
          )
        .def("SetValue",
             (void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_ThePathPointOfTheSearch::SetValue),
             R"#()#"  , py::arg("P"),  py::arg("Tol"),  py::arg("A"),  py::arg("Parameter")
          )
        .def("Tolerance",
             (double (Contap_ThePathPointOfTheSearch::*)() const) static_cast<double (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Tolerance),
             R"#()#" 
          )
        .def("IsNew",
             (bool (Contap_ThePathPointOfTheSearch::*)() const) static_cast<bool (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::IsNew),
             R"#()#" 
          )
        .def("Parameter",
             (double (Contap_ThePathPointOfTheSearch::*)() const) static_cast<double (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Parameter),
             R"#()#" 
          )
        .def("SetValue",
             (void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor3d_HVertex> & ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_ThePathPointOfTheSearch::SetValue),
             R"#()#"  , py::arg("P"),  py::arg("Tol"),  py::arg("V"),  py::arg("A"),  py::arg("Parameter")
          )
        .def("SetValue",
             (void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) ) static_cast<void (Contap_ThePathPointOfTheSearch::*)(  const gp_Pnt & ,   const double ,   const handle<Adaptor2d_Curve2d> & ,   const double  ) >(&Contap_ThePathPointOfTheSearch::SetValue),
             R"#()#"  , py::arg("P"),  py::arg("Tol"),  py::arg("A"),  py::arg("Parameter")
          )
        .def("Tolerance",
             (double (Contap_ThePathPointOfTheSearch::*)() const) static_cast<double (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Tolerance),
             R"#()#" 
          )
        .def("IsNew",
             (bool (Contap_ThePathPointOfTheSearch::*)() const) static_cast<bool (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::IsNew),
             R"#()#" 
          )
        .def("Parameter",
             (double (Contap_ThePathPointOfTheSearch::*)() const) static_cast<double (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Parameter),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const gp_Pnt & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const gp_Pnt & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Value),
             R"#()#"
             
         )
       .def("Vertex",
             ( const handle<Adaptor3d_HVertex> & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const handle<Adaptor3d_HVertex> & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Vertex),
             R"#()#"
             
         )
       .def("Arc",
             ( const handle<Adaptor2d_Curve2d> & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Arc),
             R"#()#"
             
         )
       .def("Value",
             ( const gp_Pnt & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const gp_Pnt & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Value),
             R"#()#"
             
         )
       .def("Vertex",
             ( const handle<Adaptor3d_HVertex> & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const handle<Adaptor3d_HVertex> & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Vertex),
             R"#()#"
             
         )
       .def("Arc",
             ( const handle<Adaptor2d_Curve2d> & (Contap_ThePathPointOfTheSearch::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_ThePathPointOfTheSearch::*)() const>(&Contap_ThePathPointOfTheSearch::Arc),
             R"#()#"
             
         )
;

    // Class Contap_TheSearch from ./opencascade/Contap_TheSearch.hxx
    klass = m.attr("Contap_TheSearch");


    // nested enums

    static_cast<py::class_<Contap_TheSearch , shared_ptr<Contap_TheSearch>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (Contap_TheSearch::*)( Contap_ArcFunction & ,   const handle<Adaptor3d_TopolTool> & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Contap_TheSearch::*)( Contap_ArcFunction & ,   const handle<Adaptor3d_TopolTool> & ,   const double ,   const double ,   const bool  ) >(&Contap_TheSearch::Perform),
             R"#(Algorithm to find the points and parts of curves of Domain (domain of of restriction of a surface) which verify F = 0. TolBoundary defines if a curve is on Q. TolTangency defines if a point is on Q.)#"  , py::arg("F"),  py::arg("Domain"),  py::arg("TolBoundary"),  py::arg("TolTangency"),  py::arg("RecheckOnRegularity")=static_cast< const bool>(false)
          )
        .def("IsDone",
             (bool (Contap_TheSearch::*)() const) static_cast<bool (Contap_TheSearch::*)() const>(&Contap_TheSearch::IsDone),
             R"#(Returns True if the calculus was successful.)#" 
          )
        .def("AllArcSolution",
             (bool (Contap_TheSearch::*)() const) static_cast<bool (Contap_TheSearch::*)() const>(&Contap_TheSearch::AllArcSolution),
             R"#(Returns true if all arc of the Arcs are solution (inside the surface). An exception is raised if IsDone returns False.)#" 
          )
        .def("NbPoints",
             (int (Contap_TheSearch::*)() const) static_cast<int (Contap_TheSearch::*)() const>(&Contap_TheSearch::NbPoints),
             R"#(Returns the number of resulting points. An exception is raised if IsDone returns False (NotDone).)#" 
          )
        .def("Point",
             ( const Contap_ThePathPointOfTheSearch & (Contap_TheSearch::*)(  const int  ) const) static_cast< const Contap_ThePathPointOfTheSearch & (Contap_TheSearch::*)(  const int  ) const>(&Contap_TheSearch::Point),
             R"#(Returns the resulting point of range Index. The exception NotDone is raised if IsDone() returns False. The exception OutOfRange is raised if Index <= 0 or Index > NbPoints.)#"  , py::arg("Index")
          )
        .def("NbSegments",
             (int (Contap_TheSearch::*)() const) static_cast<int (Contap_TheSearch::*)() const>(&Contap_TheSearch::NbSegments),
             R"#(Returns the number of the resulting segments. An exception is raised if IsDone returns False (NotDone).)#" 
          )
        .def("Segment",
             ( const Contap_TheSegmentOfTheSearch & (Contap_TheSearch::*)(  const int  ) const) static_cast< const Contap_TheSegmentOfTheSearch & (Contap_TheSearch::*)(  const int  ) const>(&Contap_TheSearch::Segment),
             R"#(Returns the resulting segment of range Index. The exception NotDone is raised if IsDone() returns False. The exception OutOfRange is raised if Index <= 0 or Index > NbPoints.)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_TheSearchInside from ./opencascade/Contap_TheSearchInside.hxx
    klass = m.attr("Contap_TheSearchInside");


    // nested enums

    static_cast<py::class_<Contap_TheSearchInside , shared_ptr<Contap_TheSearchInside>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init< Contap_SurfFunction &, const handle<Adaptor3d_Surface> &, const handle<Adaptor3d_TopolTool> &, const double >()  , py::arg("F"),  py::arg("Surf"),  py::arg("T"),  py::arg("Epsilon") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Contap_TheSearchInside::*)( Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const double  ) ) static_cast<void (Contap_TheSearchInside::*)( Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const handle<Adaptor3d_TopolTool> & ,   const double  ) >(&Contap_TheSearchInside::Perform),
             R"#()#"  , py::arg("F"),  py::arg("Surf"),  py::arg("T"),  py::arg("Epsilon")
          )
        .def("Perform",
             (void (Contap_TheSearchInside::*)( Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) ) static_cast<void (Contap_TheSearchInside::*)( Contap_SurfFunction & ,   const handle<Adaptor3d_Surface> & ,   const double ,   const double  ) >(&Contap_TheSearchInside::Perform),
             R"#()#"  , py::arg("F"),  py::arg("Surf"),  py::arg("UStart"),  py::arg("VStart")
          )
        .def("IsDone",
             (bool (Contap_TheSearchInside::*)() const) static_cast<bool (Contap_TheSearchInside::*)() const>(&Contap_TheSearchInside::IsDone),
             R"#()#" 
          )
        .def("NbPoints",
             (int (Contap_TheSearchInside::*)() const) static_cast<int (Contap_TheSearchInside::*)() const>(&Contap_TheSearchInside::NbPoints),
             R"#(Returns the number of points. The exception NotDone if raised if IsDone returns False.)#" 
          )
        .def("Value",
             ( const IntSurf_InteriorPoint & (Contap_TheSearchInside::*)(  const int  ) const) static_cast< const IntSurf_InteriorPoint & (Contap_TheSearchInside::*)(  const int  ) const>(&Contap_TheSearchInside::Value),
             R"#(Returns the point of range Index. The exception NotDone if raised if IsDone returns False. The exception OutOfRange if raised if Index <= 0 or Index > NbPoints.)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Contap_TheSegmentOfTheSearch from ./opencascade/Contap_TheSegmentOfTheSearch.hxx
    klass = m.attr("Contap_TheSegmentOfTheSearch");


    // nested enums

    static_cast<py::class_<Contap_TheSegmentOfTheSearch , shared_ptr<Contap_TheSegmentOfTheSearch>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetValue",
             (void (Contap_TheSegmentOfTheSearch::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (Contap_TheSegmentOfTheSearch::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_TheSegmentOfTheSearch::SetValue),
             R"#(Defines the concerned arc.)#"  , py::arg("A")
          )
        .def("SetLimitPoint",
             (void (Contap_TheSegmentOfTheSearch::*)(  const Contap_ThePathPointOfTheSearch & ,   const bool  ) ) static_cast<void (Contap_TheSegmentOfTheSearch::*)(  const Contap_ThePathPointOfTheSearch & ,   const bool  ) >(&Contap_TheSegmentOfTheSearch::SetLimitPoint),
             R"#(Defines the first point or the last point, depending on the value of the boolean First.)#"  , py::arg("V"),  py::arg("First")
          )
        .def("HasFirstPoint",
             (bool (Contap_TheSegmentOfTheSearch::*)() const) static_cast<bool (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::HasFirstPoint),
             R"#(Returns True if there is a vertex (ThePathPoint) defining the lowest valid parameter on the arc.)#" 
          )
        .def("HasLastPoint",
             (bool (Contap_TheSegmentOfTheSearch::*)() const) static_cast<bool (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::HasLastPoint),
             R"#(Returns True if there is a vertex (ThePathPoint) defining the greatest valid parameter on the arc.)#" 
          )
        .def("SetValue",
             (void (Contap_TheSegmentOfTheSearch::*)(  const handle<Adaptor2d_Curve2d> &  ) ) static_cast<void (Contap_TheSegmentOfTheSearch::*)(  const handle<Adaptor2d_Curve2d> &  ) >(&Contap_TheSegmentOfTheSearch::SetValue),
             R"#(Defines the concerned arc.)#"  , py::arg("A")
          )
        .def("HasFirstPoint",
             (bool (Contap_TheSegmentOfTheSearch::*)() const) static_cast<bool (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::HasFirstPoint),
             R"#(Returns True if there is a vertex (ThePathPoint) defining the lowest valid parameter on the arc.)#" 
          )
        .def("HasLastPoint",
             (bool (Contap_TheSegmentOfTheSearch::*)() const) static_cast<bool (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::HasLastPoint),
             R"#(Returns True if there is a vertex (ThePathPoint) defining the greatest valid parameter on the arc.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Curve",
             ( const handle<Adaptor2d_Curve2d> & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::Curve),
             R"#(Returns the geometric curve on the surface 's domain which is solution.)#"
             
         )
       .def("FirstPoint",
             ( const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::FirstPoint),
             R"#(Returns the first point.)#"
             
         )
       .def("LastPoint",
             ( const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::LastPoint),
             R"#(Returns the last point.)#"
             
         )
       .def("Curve",
             ( const handle<Adaptor2d_Curve2d> & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const handle<Adaptor2d_Curve2d> & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::Curve),
             R"#(Returns the geometric curve on the surface 's domain which is solution.)#"
             
         )
       .def("FirstPoint",
             ( const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::FirstPoint),
             R"#(Returns the first point.)#"
             
         )
       .def("LastPoint",
             ( const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const) static_cast< const Contap_ThePathPointOfTheSearch & (Contap_TheSegmentOfTheSearch::*)() const>(&Contap_TheSegmentOfTheSearch::LastPoint),
             R"#(Returns the last point.)#"
             
         )
;

// functions

// ./opencascade/Contap_ArcFunction.hxx
// ./opencascade/Contap_ContAna.hxx
// ./opencascade/Contap_Contour.hxx
// ./opencascade/Contap_HContTool.hxx
// ./opencascade/Contap_HCurve2dTool.hxx
// ./opencascade/Contap_IType.hxx
// ./opencascade/Contap_Line.hxx
// ./opencascade/Contap_Point.hxx
// ./opencascade/Contap_SurfFunction.hxx
// ./opencascade/Contap_SurfProps.hxx
// ./opencascade/Contap_TFunction.hxx
// ./opencascade/Contap_TheIWLineOfTheIWalking.hxx
// ./opencascade/Contap_TheIWalking.hxx
// ./opencascade/Contap_ThePathPointOfTheSearch.hxx
// ./opencascade/Contap_TheSearch.hxx
// ./opencascade/Contap_TheSearchInside.hxx
// ./opencascade/Contap_TheSegmentOfTheSearch.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
