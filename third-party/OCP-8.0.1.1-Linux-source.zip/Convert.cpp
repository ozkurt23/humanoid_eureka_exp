
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cone.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Sphere.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Torus.hxx>

// module includes
#include <Convert_CircleToBSplineCurve.hxx>
#include <Convert_CompBezierCurves2dToBSplineCurve2d.hxx>
#include <Convert_CompBezierCurvesToBSplineCurve.hxx>
#include <Convert_CompBezierCurvesToBSplineCurveBase.hxx>
#include <Convert_CompPolynomialToPoles.hxx>
#include <Convert_ConeToBSplineSurface.hxx>
#include <Convert_ConicToBSplineCurve.hxx>
#include <Convert_CosAndSinEvalFunction.hxx>
#include <Convert_CylinderToBSplineSurface.hxx>
#include <Convert_ElementarySurfaceToBSplineSurface.hxx>
#include <Convert_EllipseToBSplineCurve.hxx>
#include <Convert_GridPolynomialToPoles.hxx>
#include <Convert_HyperbolaToBSplineCurve.hxx>
#include <Convert_ParabolaToBSplineCurve.hxx>
#include <Convert_ParameterisationType.hxx>
#include <Convert_PolynomialCosAndSin.hxx>
#include <Convert_SphereToBSplineSurface.hxx>
#include <Convert_TorusToBSplineSurface.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Convert(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Convert"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class Convert_CompBezierCurves2dToBSplineCurve2d from ./opencascade/Convert_CompBezierCurves2dToBSplineCurve2d.hxx
    klass = m.attr("Convert_CompBezierCurves2dToBSplineCurve2d");


    // nested enums

    static_cast<py::class_<Convert_CompBezierCurves2dToBSplineCurve2d , shared_ptr<Convert_CompBezierCurves2dToBSplineCurve2d>  >>(klass)
    // constructors
        .def(py::init<  const double >()  , py::arg("theAngularTolerance")=static_cast< const double>(1.0e-4) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_CompBezierCurvesToBSplineCurve from ./opencascade/Convert_CompBezierCurvesToBSplineCurve.hxx
    klass = m.attr("Convert_CompBezierCurvesToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_CompBezierCurvesToBSplineCurve , shared_ptr<Convert_CompBezierCurvesToBSplineCurve>  >>(klass)
    // constructors
        .def(py::init<  const double >()  , py::arg("theAngularTolerance")=static_cast< const double>(1.0e-4) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_CompPolynomialToPoles from ./opencascade/Convert_CompPolynomialToPoles.hxx
    klass = m.attr("Convert_CompPolynomialToPoles");


    // nested enums

    static_cast<py::class_<Convert_CompPolynomialToPoles , shared_ptr<Convert_CompPolynomialToPoles>  >>(klass)
    // constructors
        .def(py::init<  const int, const int, const int, const NCollection_Array1<double> &, const NCollection_Array1<double> &, const NCollection_Array1<double> & >()  , py::arg("Dimension"),  py::arg("MaxDegree"),  py::arg("Degree"),  py::arg("Coefficients"),  py::arg("PolynomialIntervals"),  py::arg("TrueIntervals") )
        .def(py::init<  const int, const int, const int, const NCollection_Array1<int> &, const NCollection_Array1<int> &, const NCollection_Array1<double> &, const NCollection_Array2<double> &, const NCollection_Array1<double> & >()  , py::arg("NumCurves"),  py::arg("Dimension"),  py::arg("MaxDegree"),  py::arg("Continuity"),  py::arg("NumCoeffPerCurve"),  py::arg("Coefficients"),  py::arg("PolynomialIntervals"),  py::arg("TrueIntervals") )
        .def(py::init<  const int, const int, const int, const int, const handle<NCollection_HArray1<int>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray2<double>> &, const handle<NCollection_HArray1<double>> & >()  , py::arg("NumCurves"),  py::arg("Continuity"),  py::arg("Dimension"),  py::arg("MaxDegree"),  py::arg("NumCoeffPerCurve"),  py::arg("Coefficients"),  py::arg("PolynomialIntervals"),  py::arg("TrueIntervals") )
    // custom constructors
    // methods
        .def("NbPoles",
             (int (Convert_CompPolynomialToPoles::*)() const) static_cast<int (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::NbPoles),
             R"#(Returns the number of poles of the n-dimensional BSpline.)#" 
          )
        .def("Degree",
             (int (Convert_CompPolynomialToPoles::*)() const) static_cast<int (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::Degree),
             R"#(Returns the degree of the n-dimensional BSpline.)#" 
          )
        .def("NbKnots",
             (int (Convert_CompPolynomialToPoles::*)() const) static_cast<int (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::NbKnots),
             R"#(Returns the number of knots of the n-dimensional BSpline.)#" 
          )
        .def("IsDone",
             (bool (Convert_CompPolynomialToPoles::*)() const) static_cast<bool (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::IsDone),
             R"#(Returns true if the conversion was successful.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Poles",
             []( Convert_CompPolynomialToPoles &self , NCollection_HArray2<double>& thePoles ){
                 handle<NCollection_HArray2<double>>  thePoles_ptr; thePoles_ptr = &thePoles;

                 self.Poles(thePoles_ptr);
                 return std::make_tuple(thePoles_ptr); },
             R"#(Returns the poles of the n-dimensional BSpline via output parameter.)#"  , py::arg("thePoles")
          )
        .def("Knots",
             []( Convert_CompPolynomialToPoles &self , NCollection_HArray1<double>& theKnots ){
                 handle<NCollection_HArray1<double>>  theKnots_ptr; theKnots_ptr = &theKnots;

                 self.Knots(theKnots_ptr);
                 return std::make_tuple(theKnots_ptr); },
             R"#(Returns the knots of the n-dimensional BSpline via output parameter.)#"  , py::arg("theKnots")
          )
        .def("Multiplicities",
             []( Convert_CompPolynomialToPoles &self , NCollection_HArray1<int>& theMults ){
                 handle<NCollection_HArray1<int>>  theMults_ptr; theMults_ptr = &theMults;

                 self.Multiplicities(theMults_ptr);
                 return std::make_tuple(theMults_ptr); },
             R"#(Returns the multiplicities of the knots via output parameter.)#"  , py::arg("theMults")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Poles",
             ( const NCollection_Array2<double> & (Convert_CompPolynomialToPoles::*)() const) static_cast< const NCollection_Array2<double> & (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::Poles),
             R"#(Returns the poles of the n-dimensional BSpline in the following format: [1..NumPoles][1..Dimension])#"
             
         )
       .def("Knots",
             ( const NCollection_Array1<double> & (Convert_CompPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<double> & (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::Knots),
             R"#(Returns the knots of the n-dimensional BSpline.)#"
             
         )
       .def("Multiplicities",
             ( const NCollection_Array1<int> & (Convert_CompPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<int> & (Convert_CompPolynomialToPoles::*)() const>(&Convert_CompPolynomialToPoles::Multiplicities),
             R"#(Returns the multiplicities of the knots in the BSpline.)#"
             
         )
;

    // Class Convert_ConicToBSplineCurve from ./opencascade/Convert_ConicToBSplineCurve.hxx
    klass = m.attr("Convert_ConicToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_ConicToBSplineCurve , shared_ptr<Convert_ConicToBSplineCurve>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Degree",
             (int (Convert_ConicToBSplineCurve::*)() const) static_cast<int (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::Degree),
             R"#(Returns the degree of the BSpline curve whose data is computed in this framework.)#" 
          )
        .def("NbPoles",
             (int (Convert_ConicToBSplineCurve::*)() const) static_cast<int (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::NbPoles),
             R"#(Returns the number of poles of the BSpline curve whose data is computed in this framework.)#" 
          )
        .def("NbKnots",
             (int (Convert_ConicToBSplineCurve::*)() const) static_cast<int (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::NbKnots),
             R"#(Returns the number of knots of the BSpline curve whose data is computed in this framework.)#" 
          )
        .def("IsPeriodic",
             (bool (Convert_ConicToBSplineCurve::*)() const) static_cast<bool (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::IsPeriodic),
             R"#(Returns true if the BSpline curve whose data is computed in this framework is periodic.)#" 
          )
        .def("Pole",
             (gp_Pnt2d (Convert_ConicToBSplineCurve::*)(  const int  ) const) static_cast<gp_Pnt2d (Convert_ConicToBSplineCurve::*)(  const int  ) const>(&Convert_ConicToBSplineCurve::Pole),
             R"#(Returns the pole of index Index to the poles table of the BSpline curve whose data is computed in this framework.)#"  , py::arg("theIndex")
          )
        .def("Weight",
             (double (Convert_ConicToBSplineCurve::*)(  const int  ) const) static_cast<double (Convert_ConicToBSplineCurve::*)(  const int  ) const>(&Convert_ConicToBSplineCurve::Weight),
             R"#(Returns the weight of the pole of index Index to the poles table of the BSpline curve whose data is computed in this framework.)#"  , py::arg("theIndex")
          )
        .def("Knot",
             (double (Convert_ConicToBSplineCurve::*)(  const int  ) const) static_cast<double (Convert_ConicToBSplineCurve::*)(  const int  ) const>(&Convert_ConicToBSplineCurve::Knot),
             R"#(Returns the knot of index Index to the knots table of the BSpline curve whose data is computed in this framework.)#"  , py::arg("theIndex")
          )
        .def("Multiplicity",
             (int (Convert_ConicToBSplineCurve::*)(  const int  ) const) static_cast<int (Convert_ConicToBSplineCurve::*)(  const int  ) const>(&Convert_ConicToBSplineCurve::Multiplicity),
             R"#(Returns the multiplicity of the knot of index Index to the knots table of the BSpline curve whose data is computed in this framework.)#"  , py::arg("theIndex")
          )
    // methods using call by reference i.s.o. return
        .def("BuildCosAndSin",
             []( Convert_ConicToBSplineCurve &self ,  const Convert_ParameterisationType theParametrisation,NCollection_HArray1<double>& theCosNumerator,NCollection_HArray1<double>& theSinNumerator,NCollection_HArray1<double>& theDenominator,NCollection_HArray1<double>& theKnots,NCollection_HArray1<int>& theMults ){
                 int  theDegree;
                handle<NCollection_HArray1<double>>  theCosNumerator_ptr; theCosNumerator_ptr = &theCosNumerator;
                handle<NCollection_HArray1<double>>  theSinNumerator_ptr; theSinNumerator_ptr = &theSinNumerator;
                handle<NCollection_HArray1<double>>  theDenominator_ptr; theDenominator_ptr = &theDenominator;
                handle<NCollection_HArray1<double>>  theKnots_ptr; theKnots_ptr = &theKnots;
                handle<NCollection_HArray1<int>>  theMults_ptr; theMults_ptr = &theMults;

                 self.BuildCosAndSin(theParametrisation,theCosNumerator_ptr,theSinNumerator_ptr,theDenominator_ptr,theDegree,theKnots_ptr,theMults_ptr);
                 return std::make_tuple(theCosNumerator_ptr,theSinNumerator_ptr,theDenominator_ptr,theDegree,theKnots_ptr,theMults_ptr); },
             R"#(Legacy API returning handle arrays for compatibility.)#"  , py::arg("theParametrisation"),  py::arg("theCosNumerator"),  py::arg("theSinNumerator"),  py::arg("theDenominator"),  py::arg("theKnots"),  py::arg("theMults")
          )
        .def("BuildCosAndSin",
             []( Convert_ConicToBSplineCurve &self ,  const Convert_ParameterisationType theParametrisation, const double theUFirst, const double theULast,NCollection_HArray1<double>& theCosNumerator,NCollection_HArray1<double>& theSinNumerator,NCollection_HArray1<double>& theDenominator,NCollection_HArray1<double>& theKnots,NCollection_HArray1<int>& theMults ){
                 int  theDegree;
                handle<NCollection_HArray1<double>>  theCosNumerator_ptr; theCosNumerator_ptr = &theCosNumerator;
                handle<NCollection_HArray1<double>>  theSinNumerator_ptr; theSinNumerator_ptr = &theSinNumerator;
                handle<NCollection_HArray1<double>>  theDenominator_ptr; theDenominator_ptr = &theDenominator;
                handle<NCollection_HArray1<double>>  theKnots_ptr; theKnots_ptr = &theKnots;
                handle<NCollection_HArray1<int>>  theMults_ptr; theMults_ptr = &theMults;

                 self.BuildCosAndSin(theParametrisation,theUFirst,theULast,theCosNumerator_ptr,theSinNumerator_ptr,theDenominator_ptr,theDegree,theKnots_ptr,theMults_ptr);
                 return std::make_tuple(theCosNumerator_ptr,theSinNumerator_ptr,theDenominator_ptr,theDegree,theKnots_ptr,theMults_ptr); },
             R"#(Legacy API returning handle arrays for compatibility.)#"  , py::arg("theParametrisation"),  py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theCosNumerator"),  py::arg("theSinNumerator"),  py::arg("theDenominator"),  py::arg("theKnots"),  py::arg("theMults")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Poles",
             ( const NCollection_Array1<gp_Pnt2d> & (Convert_ConicToBSplineCurve::*)() const) static_cast< const NCollection_Array1<gp_Pnt2d> & (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::Poles),
             R"#(Returns the poles of the BSpline curve.)#"
             
         )
       .def("Weights",
             ( const NCollection_Array1<double> & (Convert_ConicToBSplineCurve::*)() const) static_cast< const NCollection_Array1<double> & (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::Weights),
             R"#(Returns the weights of the BSpline curve.)#"
             
         )
       .def("Knots",
             ( const NCollection_Array1<double> & (Convert_ConicToBSplineCurve::*)() const) static_cast< const NCollection_Array1<double> & (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::Knots),
             R"#(Returns the knots of the BSpline curve.)#"
             
         )
       .def("Multiplicities",
             ( const NCollection_Array1<int> & (Convert_ConicToBSplineCurve::*)() const) static_cast< const NCollection_Array1<int> & (Convert_ConicToBSplineCurve::*)() const>(&Convert_ConicToBSplineCurve::Multiplicities),
             R"#(Returns the multiplicities of the BSpline curve.)#"
             
         )
;

    // Class Convert_ElementarySurfaceToBSplineSurface from ./opencascade/Convert_ElementarySurfaceToBSplineSurface.hxx
    klass = m.attr("Convert_ElementarySurfaceToBSplineSurface");


    // nested enums

    static_cast<py::class_<Convert_ElementarySurfaceToBSplineSurface , shared_ptr<Convert_ElementarySurfaceToBSplineSurface>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("UDegree",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::UDegree),
             R"#(Returns the degree in the U parametric direction.)#" 
          )
        .def("VDegree",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::VDegree),
             R"#(Returns the degree in the V parametric direction.)#" 
          )
        .def("NbUPoles",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::NbUPoles),
             R"#(Returns the number of poles in the U parametric direction.)#" 
          )
        .def("NbVPoles",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::NbVPoles),
             R"#(Returns the number of poles in the V parametric direction.)#" 
          )
        .def("NbUKnots",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::NbUKnots),
             R"#(Returns the number of knots in the U parametric direction.)#" 
          )
        .def("NbVKnots",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::NbVKnots),
             R"#(Returns the number of knots in the V parametric direction.)#" 
          )
        .def("IsUPeriodic",
             (bool (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<bool (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::IsUPeriodic),
             R"#(Returns true if the surface is periodic in the U parametric direction.)#" 
          )
        .def("IsVPeriodic",
             (bool (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast<bool (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::IsVPeriodic),
             R"#(Returns true if the surface is periodic in the V parametric direction.)#" 
          )
        .def("Pole",
             (gp_Pnt (Convert_ElementarySurfaceToBSplineSurface::*)(  const int ,   const int  ) const) static_cast<gp_Pnt (Convert_ElementarySurfaceToBSplineSurface::*)(  const int ,   const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::Pole),
             R"#(Returns the pole of index (UIndex, VIndex).)#"  , py::arg("UIndex"),  py::arg("VIndex")
          )
        .def("Weight",
             (double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int ,   const int  ) const) static_cast<double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int ,   const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::Weight),
             R"#(Returns the weight of the pole of index (UIndex, VIndex).)#"  , py::arg("UIndex"),  py::arg("VIndex")
          )
        .def("UKnot",
             (double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const) static_cast<double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::UKnot),
             R"#(Returns the U-knot of range UIndex.)#"  , py::arg("UIndex")
          )
        .def("VKnot",
             (double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const) static_cast<double (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::VKnot),
             R"#(Returns the V-knot of range VIndex.)#"  , py::arg("VIndex")
          )
        .def("UMultiplicity",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::UMultiplicity),
             R"#(Returns the multiplicity of the U-knot of range UIndex.)#"  , py::arg("UIndex")
          )
        .def("VMultiplicity",
             (int (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const) static_cast<int (Convert_ElementarySurfaceToBSplineSurface::*)(  const int  ) const>(&Convert_ElementarySurfaceToBSplineSurface::VMultiplicity),
             R"#(Returns the multiplicity of the V-knot of range VIndex.)#"  , py::arg("VIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Poles",
             ( const NCollection_Array2<gp_Pnt> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array2<gp_Pnt> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::Poles),
             R"#(Returns the poles of the BSpline surface.)#"
             
         )
       .def("Weights",
             ( const NCollection_Array2<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array2<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::Weights),
             R"#(Returns the weights of the BSpline surface.)#"
             
         )
       .def("UKnots",
             ( const NCollection_Array1<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array1<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::UKnots),
             R"#(Returns the U-knots of the BSpline surface.)#"
             
         )
       .def("VKnots",
             ( const NCollection_Array1<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array1<double> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::VKnots),
             R"#(Returns the V-knots of the BSpline surface.)#"
             
         )
       .def("UMultiplicities",
             ( const NCollection_Array1<int> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array1<int> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::UMultiplicities),
             R"#(Returns the U-multiplicities of the BSpline surface.)#"
             
         )
       .def("VMultiplicities",
             ( const NCollection_Array1<int> & (Convert_ElementarySurfaceToBSplineSurface::*)() const) static_cast< const NCollection_Array1<int> & (Convert_ElementarySurfaceToBSplineSurface::*)() const>(&Convert_ElementarySurfaceToBSplineSurface::VMultiplicities),
             R"#(Returns the V-multiplicities of the BSpline surface.)#"
             
         )
;

    // Class Convert_GridPolynomialToPoles from ./opencascade/Convert_GridPolynomialToPoles.hxx
    klass = m.attr("Convert_GridPolynomialToPoles");


    // nested enums

    static_cast<py::class_<Convert_GridPolynomialToPoles , shared_ptr<Convert_GridPolynomialToPoles>  >>(klass)
    // constructors
        .def(py::init<  const int, const int, const NCollection_Array1<int> &, const NCollection_Array1<double> &, const NCollection_Array1<double> &, const NCollection_Array1<double> & >()  , py::arg("theMaxUDegree"),  py::arg("theMaxVDegree"),  py::arg("theNumCoeff"),  py::arg("theCoefficients"),  py::arg("thePolynomialUIntervals"),  py::arg("thePolynomialVIntervals") )
        .def(py::init<  const int, const int, const int, const int, const int, const int, const NCollection_Array2<int> &, const NCollection_Array1<double> &, const NCollection_Array1<double> &, const NCollection_Array1<double> &, const NCollection_Array1<double> &, const NCollection_Array1<double> & >()  , py::arg("theNbUSurfaces"),  py::arg("theNbVSurfaces"),  py::arg("theUContinuity"),  py::arg("theVContinuity"),  py::arg("theMaxUDegree"),  py::arg("theMaxVDegree"),  py::arg("theNumCoeffPerSurface"),  py::arg("theCoefficients"),  py::arg("thePolynomialUIntervals"),  py::arg("thePolynomialVIntervals"),  py::arg("theTrueUIntervals"),  py::arg("theTrueVIntervals") )
        .def(py::init<  const int, const int, const int, const int, const int, const int, const handle<NCollection_HArray2<int>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> & >()  , py::arg("theNbUSurfaces"),  py::arg("theNbVSurfaces"),  py::arg("theUContinuity"),  py::arg("theVContinuity"),  py::arg("theMaxUDegree"),  py::arg("theMaxVDegree"),  py::arg("theNumCoeffPerSurface"),  py::arg("theCoefficients"),  py::arg("thePolynomialUIntervals"),  py::arg("thePolynomialVIntervals"),  py::arg("theTrueUIntervals"),  py::arg("theTrueVIntervals") )
        .def(py::init<  const int, const int, const handle<NCollection_HArray1<int>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> &, const handle<NCollection_HArray1<double>> & >()  , py::arg("theMaxUDegree"),  py::arg("theMaxVDegree"),  py::arg("theNumCoeff"),  py::arg("theCoefficients"),  py::arg("thePolynomialUIntervals"),  py::arg("thePolynomialVIntervals") )
    // custom constructors
    // methods
        .def("NbUPoles",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::NbUPoles),
             R"#(Returns the number of poles in the U parametric direction.)#" 
          )
        .def("NbVPoles",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::NbVPoles),
             R"#(Returns the number of poles in the V parametric direction.)#" 
          )
        .def("UDegree",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::UDegree),
             R"#(Returns the degree in the U parametric direction.)#" 
          )
        .def("VDegree",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::VDegree),
             R"#(Returns the degree in the V parametric direction.)#" 
          )
        .def("NbUKnots",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::NbUKnots),
             R"#(Returns the number of knots in the U parametric direction.)#" 
          )
        .def("NbVKnots",
             (int (Convert_GridPolynomialToPoles::*)() const) static_cast<int (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::NbVKnots),
             R"#(Returns the number of knots in the V parametric direction.)#" 
          )
        .def("IsDone",
             (bool (Convert_GridPolynomialToPoles::*)() const) static_cast<bool (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::IsDone),
             R"#(Returns true if the conversion was successful.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Poles",
             ( const NCollection_Array2<gp_Pnt> & (Convert_GridPolynomialToPoles::*)() const) static_cast< const NCollection_Array2<gp_Pnt> & (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::Poles),
             R"#(Returns the poles of the BSpline Surface.)#"
             
         )
       .def("UKnots",
             ( const NCollection_Array1<double> & (Convert_GridPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<double> & (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::UKnots),
             R"#(Returns the knots in the U direction.)#"
             
         )
       .def("VKnots",
             ( const NCollection_Array1<double> & (Convert_GridPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<double> & (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::VKnots),
             R"#(Returns the knots in the V direction.)#"
             
         )
       .def("UMultiplicities",
             ( const NCollection_Array1<int> & (Convert_GridPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<int> & (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::UMultiplicities),
             R"#(Returns the multiplicities of the knots in the U direction.)#"
             
         )
       .def("VMultiplicities",
             ( const NCollection_Array1<int> & (Convert_GridPolynomialToPoles::*)() const) static_cast< const NCollection_Array1<int> & (Convert_GridPolynomialToPoles::*)() const>(&Convert_GridPolynomialToPoles::VMultiplicities),
             R"#(Returns the multiplicities of the knots in the V direction.)#"
             
         )
;

    // Class Convert_CircleToBSplineCurve from ./opencascade/Convert_CircleToBSplineCurve.hxx
    klass = m.attr("Convert_CircleToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_CircleToBSplineCurve , shared_ptr<Convert_CircleToBSplineCurve>  , Convert_ConicToBSplineCurve >>(klass)
    // constructors
        .def(py::init<  const gp_Circ2d &, const Convert_ParameterisationType >()  , py::arg("C"),  py::arg("Parameterisation")=static_cast< const Convert_ParameterisationType>(Convert_TgtThetaOver2) )
        .def(py::init<  const gp_Circ2d &, const double, const double, const Convert_ParameterisationType >()  , py::arg("C"),  py::arg("U1"),  py::arg("U2"),  py::arg("Parameterisation")=static_cast< const Convert_ParameterisationType>(Convert_TgtThetaOver2) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_ConeToBSplineSurface from ./opencascade/Convert_ConeToBSplineSurface.hxx
    klass = m.attr("Convert_ConeToBSplineSurface");


    // nested enums

    static_cast<py::class_<Convert_ConeToBSplineSurface , shared_ptr<Convert_ConeToBSplineSurface>  , Convert_ElementarySurfaceToBSplineSurface >>(klass)
    // constructors
        .def(py::init<  const gp_Cone &, const double, const double >()  , py::arg("C"),  py::arg("V1"),  py::arg("V2") )
        .def(py::init<  const gp_Cone &, const double, const double, const double, const double >()  , py::arg("C"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_CylinderToBSplineSurface from ./opencascade/Convert_CylinderToBSplineSurface.hxx
    klass = m.attr("Convert_CylinderToBSplineSurface");


    // nested enums

    static_cast<py::class_<Convert_CylinderToBSplineSurface , shared_ptr<Convert_CylinderToBSplineSurface>  , Convert_ElementarySurfaceToBSplineSurface >>(klass)
    // constructors
        .def(py::init<  const gp_Cylinder &, const double, const double >()  , py::arg("Cyl"),  py::arg("V1"),  py::arg("V2") )
        .def(py::init<  const gp_Cylinder &, const double, const double, const double, const double >()  , py::arg("Cyl"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_EllipseToBSplineCurve from ./opencascade/Convert_EllipseToBSplineCurve.hxx
    klass = m.attr("Convert_EllipseToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_EllipseToBSplineCurve , shared_ptr<Convert_EllipseToBSplineCurve>  , Convert_ConicToBSplineCurve >>(klass)
    // constructors
        .def(py::init<  const gp_Elips2d &, const Convert_ParameterisationType >()  , py::arg("E"),  py::arg("Parameterisation")=static_cast< const Convert_ParameterisationType>(Convert_TgtThetaOver2) )
        .def(py::init<  const gp_Elips2d &, const double, const double, const Convert_ParameterisationType >()  , py::arg("E"),  py::arg("U1"),  py::arg("U2"),  py::arg("Parameterisation")=static_cast< const Convert_ParameterisationType>(Convert_TgtThetaOver2) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_HyperbolaToBSplineCurve from ./opencascade/Convert_HyperbolaToBSplineCurve.hxx
    klass = m.attr("Convert_HyperbolaToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_HyperbolaToBSplineCurve , shared_ptr<Convert_HyperbolaToBSplineCurve>  , Convert_ConicToBSplineCurve >>(klass)
    // constructors
        .def(py::init<  const gp_Hypr2d &, const double, const double >()  , py::arg("H"),  py::arg("U1"),  py::arg("U2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_ParabolaToBSplineCurve from ./opencascade/Convert_ParabolaToBSplineCurve.hxx
    klass = m.attr("Convert_ParabolaToBSplineCurve");


    // nested enums

    static_cast<py::class_<Convert_ParabolaToBSplineCurve , shared_ptr<Convert_ParabolaToBSplineCurve>  , Convert_ConicToBSplineCurve >>(klass)
    // constructors
        .def(py::init<  const gp_Parab2d &, const double, const double >()  , py::arg("Prb"),  py::arg("U1"),  py::arg("U2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_SphereToBSplineSurface from ./opencascade/Convert_SphereToBSplineSurface.hxx
    klass = m.attr("Convert_SphereToBSplineSurface");


    // nested enums

    static_cast<py::class_<Convert_SphereToBSplineSurface , shared_ptr<Convert_SphereToBSplineSurface>  , Convert_ElementarySurfaceToBSplineSurface >>(klass)
    // constructors
        .def(py::init<  const gp_Sphere & >()  , py::arg("Sph") )
        .def(py::init<  const gp_Sphere &, const double, const double, const bool >()  , py::arg("Sph"),  py::arg("Param1"),  py::arg("Param2"),  py::arg("UTrim")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Sphere &, const double, const double, const double, const double >()  , py::arg("Sph"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Convert_TorusToBSplineSurface from ./opencascade/Convert_TorusToBSplineSurface.hxx
    klass = m.attr("Convert_TorusToBSplineSurface");


    // nested enums

    static_cast<py::class_<Convert_TorusToBSplineSurface , shared_ptr<Convert_TorusToBSplineSurface>  , Convert_ElementarySurfaceToBSplineSurface >>(klass)
    // constructors
        .def(py::init<  const gp_Torus & >()  , py::arg("T") )
        .def(py::init<  const gp_Torus &, const double, const double, const bool >()  , py::arg("T"),  py::arg("Param1"),  py::arg("Param2"),  py::arg("UTrim")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Torus &, const double, const double, const double, const double >()  , py::arg("T"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/Convert_CircleToBSplineCurve.hxx
// ./opencascade/Convert_CompBezierCurves2dToBSplineCurve2d.hxx
// ./opencascade/Convert_CompBezierCurvesToBSplineCurve.hxx
// ./opencascade/Convert_CompBezierCurvesToBSplineCurveBase.hxx
// ./opencascade/Convert_CompPolynomialToPoles.hxx
// ./opencascade/Convert_ConeToBSplineSurface.hxx
// ./opencascade/Convert_ConicToBSplineCurve.hxx
// ./opencascade/Convert_CosAndSinEvalFunction.hxx
// ./opencascade/Convert_CylinderToBSplineSurface.hxx
// ./opencascade/Convert_ElementarySurfaceToBSplineSurface.hxx
// ./opencascade/Convert_EllipseToBSplineCurve.hxx
// ./opencascade/Convert_GridPolynomialToPoles.hxx
// ./opencascade/Convert_HyperbolaToBSplineCurve.hxx
// ./opencascade/Convert_ParabolaToBSplineCurve.hxx
// ./opencascade/Convert_ParameterisationType.hxx
// ./opencascade/Convert_PolynomialCosAndSin.hxx
    m.def("BuildPolynomialCosAndSin",
          (void (*)(  const double ,   const double ,   const int ,  NCollection_Array1<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<double> &  ))  static_cast<void (*)(  const double ,   const double ,   const int ,  NCollection_Array1<double> & ,  NCollection_Array1<double> & ,  NCollection_Array1<double> &  )>(&BuildPolynomialCosAndSin),
          R"#()#"  , py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theNumPoles"),  py::arg("theCosNumerator"),  py::arg("theSinNumerator"),  py::arg("theDenominator")
          );
// ./opencascade/Convert_SphereToBSplineSurface.hxx
// ./opencascade/Convert_TorusToBSplineSurface.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
