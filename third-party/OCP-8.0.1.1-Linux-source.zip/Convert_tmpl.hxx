#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cone.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Sphere.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Torus.hxx>

// module includes
#include <Convert_CircleToBSplineCurve.hxx>
#include <Convert_CompBezierCurves2dToBSplineCurve2d.hxx>
#include <Convert_CompBezierCurvesToBSplineCurve.hxx>
#include <Convert_CompBezierCurvesToBSplineCurveBase.hxx>
#include <Convert_CompPolynomialToPoles.hxx>
#include <Convert_ConeToBSplineSurface.hxx>
#include <Convert_ConicToBSplineCurve.hxx>
#include <Convert_CosAndSinEvalFunction.hxx>
#include <Convert_CylinderToBSplineSurface.hxx>
#include <Convert_ElementarySurfaceToBSplineSurface.hxx>
#include <Convert_EllipseToBSplineCurve.hxx>
#include <Convert_GridPolynomialToPoles.hxx>
#include <Convert_HyperbolaToBSplineCurve.hxx>
#include <Convert_ParabolaToBSplineCurve.hxx>
#include <Convert_ParameterisationType.hxx>
#include <Convert_PolynomialCosAndSin.hxx>
#include <Convert_SphereToBSplineSurface.hxx>
#include <Convert_TorusToBSplineSurface.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename PointType,typename VecType>
void preregister_template_Convert_CompBezierCurvesToBSplineCurveBase(py::object &m, const char *name){
    py::class_<Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType> , shared_ptr<Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>> >(m,name,R"#(Template base class for converting a sequence of adjacent non-rational Bezier curves into a BSpline curve. PointType is gp_Pnt or gp_Pnt2d; VecType is gp_Vec or gp_Vec2d.)#");
}

template <typename PointType,typename VecType>
void register_template_Convert_CompBezierCurvesToBSplineCurveBase(py::object &m, const char *name){
    static_cast<py::class_<Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType> , shared_ptr<Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>> >>(m.attr(name))
        .def(py::init<  const double >() ,py::arg("theAngularTolerance")=static_cast< const double>(1.0e-4) )
        .def("AddCurve",
             (void (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)(  const NCollection_Array1<PointType> &  ) ) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::AddCurve,
             R"#(Adds the Bezier curve defined by the table of poles to the sequence of adjacent Bezier curves to be converted.)#" ,py::arg("thePoles"))
        .def("Perform",
             (void (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)() ) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::Perform,
             R"#(Computes all the data needed to build a BSpline curve equivalent to the adjacent Bezier curve sequence.)#" )
        .def("Degree",
             (int (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)() const) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::Degree,
             R"#(Returns the degree of the BSpline curve.)#" )
        .def("NbPoles",
             (int (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)() const) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::NbPoles,
             R"#(Returns the number of poles of the BSpline curve.)#" )
        .def("Poles",
             (void (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)( NCollection_Array1<PointType> &  ) const) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::Poles,
             R"#(Loads the Poles table with the poles of the BSpline curve.)#" ,py::arg("thePoles"))
        .def("NbKnots",
             (int (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)() const) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::NbKnots,
             R"#(Returns the number of knots of the BSpline curve.)#" )
        .def("KnotsAndMults",
             (void (Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::*)( NCollection_Array1<double> & ,  NCollection_Array1<int> &  ) const) &Convert_CompBezierCurvesToBSplineCurveBase<PointType,VecType>::KnotsAndMults,
             R"#(Loads the Knots and Mults tables with the knots and corresponding multiplicities of the BSpline curve.)#" ,py::arg("theKnots"), py::arg("theMults"))
    ;
};


// user-defined post

