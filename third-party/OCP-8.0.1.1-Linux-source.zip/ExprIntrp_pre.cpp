
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <ExprIntrp_Generator.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <ExprIntrp_Generator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Expr_GeneralRelation.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <ExprIntrp.hxx>
#include <ExprIntrp_Analysis.hxx>
#include <ExprIntrp_Generator.hxx>
#include <ExprIntrp_GenExp.hxx>
#include <ExprIntrp_GenFct.hxx>
#include <ExprIntrp_GenRel.hxx>
#include <ExprIntrp_SyntaxError.hxx>
#include <ExprIntrp_yaccanal.hxx>
#include <ExprIntrp_yaccintrf.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_ExprIntrp_enums(py::module &main_module) {


py::module m = main_module.def_submodule("ExprIntrp", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<ExprIntrp , shared_ptr<ExprIntrp>  >(
      m,
      "ExprIntrp",R"#(Describes an interpreter for GeneralExpressions, GeneralFunctions, and GeneralRelations defined in package Expr.)#"
    );
    py::class_<ExprIntrp_Analysis , shared_ptr<ExprIntrp_Analysis>  >(
      m,
      "ExprIntrp_Analysis",R"#()#"
    );
    py::class_<ExprIntrp_Generator ,opencascade::handle<ExprIntrp_Generator>  , Standard_Transient >(
      m,
      "ExprIntrp_Generator",R"#(Implements general services for interpretation of expressions.)#"
    );
    py::class_<ExprIntrp_GenExp ,opencascade::handle<ExprIntrp_GenExp>  , ExprIntrp_Generator >(
      m,
      "ExprIntrp_GenExp",R"#(This class permits, from a string, to create any kind of expression of package Expr by using built-in functions such as Sin,Cos, etc, and by creating variables.)#"
    );
    py::class_<ExprIntrp_GenFct ,opencascade::handle<ExprIntrp_GenFct>  , ExprIntrp_Generator >(
      m,
      "ExprIntrp_GenFct",R"#(Implements an interpreter for defining functions. All its functionalities can be found in class GenExp.)#"
    );
    py::class_<ExprIntrp_GenRel ,opencascade::handle<ExprIntrp_GenRel>  , ExprIntrp_Generator >(
      m,
      "ExprIntrp_GenRel",R"#(Implements an interpreter for equations or system of equations made of expressions of package Expr.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
