
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <FEmTool_ProfileMatrix.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <FEmTool_Assembly.hxx>
#include <FEmTool_Curve.hxx>
#include <FEmTool_ElementaryCriterion.hxx>
#include <FEmTool_ElementsOfRefMatrix.hxx>
#include <FEmTool_LinearFlexion.hxx>
#include <FEmTool_LinearJerk.hxx>
#include <FEmTool_LinearTension.hxx>
#include <FEmTool_ProfileMatrix.hxx>
#include <FEmTool_SparseMatrix.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_FEmTool(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("FEmTool"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_FEmTool_ElementaryCriterion : public FEmTool_ElementaryCriterion{
    public:
        using FEmTool_ElementaryCriterion::FEmTool_ElementaryCriterion;


        // public pure virtual
        handle<NCollection_HArray2<int>> DependenceTable() const  override { using return_type = handle<NCollection_HArray2<int>>;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,DependenceTable,) };
        double Value() override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Value,) };
        void Hessian( const int Dim1, const int Dim2,math_Matrix & H) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Hessian,Dim1,Dim2,H) };
        void Gradient( const int Dim,math_Vector & G) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Gradient,Dim,G) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_FEmTool_SparseMatrix : public FEmTool_SparseMatrix{
    public:
        using FEmTool_SparseMatrix::FEmTool_SparseMatrix;


        // public pure virtual
        void Init( const double Value) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Init,Value) };
        double & ChangeValue( const int I, const int J) override { using return_type = double &;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,ChangeValue,I,J) };
        bool Decompose() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Decompose,) };
        void Solve( const math_Vector & B,math_Vector & X) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Solve,B,X) };
        bool Prepare() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Prepare,) };
        void Solve( const math_Vector & B, const math_Vector & Init,math_Vector & X,math_Vector & Residual, const double Tolerance, const int NbIterations) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Solve,B,Init,X,Residual,Tolerance,NbIterations) };
        void Multiplied( const math_Vector & X,math_Vector & MX) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Multiplied,X,MX) };
        int RowNumber() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,RowNumber,) };
        int ColNumber() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,ColNumber,) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class FEmTool_Assembly from ./opencascade/FEmTool_Assembly.hxx
    klass = m.attr("FEmTool_Assembly");


    // nested enums

    static_cast<py::class_<FEmTool_Assembly , shared_ptr<FEmTool_Assembly>  >>(klass)
    // constructors
        .def(py::init<  const NCollection_Array2<int> &, const handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>> & >()  , py::arg("Dependence"),  py::arg("Table") )
    // custom constructors
    // methods
        .def("NullifyMatrix",
             (void (FEmTool_Assembly::*)() ) static_cast<void (FEmTool_Assembly::*)() >(&FEmTool_Assembly::NullifyMatrix),
             R"#(Nullify all Matrix's Coefficient)#" 
          )
        .def("AddMatrix",
             (void (FEmTool_Assembly::*)(  const int ,   const int ,   const int ,   const math_Matrix &  ) ) static_cast<void (FEmTool_Assembly::*)(  const int ,   const int ,   const int ,   const math_Matrix &  ) >(&FEmTool_Assembly::AddMatrix),
             R"#(Add an elementary Matrix in the assembly Matrix if Dependence(Dimension1,Dimension2) is False)#"  , py::arg("Element"),  py::arg("Dimension1"),  py::arg("Dimension2"),  py::arg("Mat")
          )
        .def("NullifyVector",
             (void (FEmTool_Assembly::*)() ) static_cast<void (FEmTool_Assembly::*)() >(&FEmTool_Assembly::NullifyVector),
             R"#(Nullify all Coordinate of assembly Vector (second member))#" 
          )
        .def("AddVector",
             (void (FEmTool_Assembly::*)(  const int ,   const int ,   const math_Vector &  ) ) static_cast<void (FEmTool_Assembly::*)(  const int ,   const int ,   const math_Vector &  ) >(&FEmTool_Assembly::AddVector),
             R"#(Add an elementary Vector in the assembly Vector (second member))#"  , py::arg("Element"),  py::arg("Dimension"),  py::arg("Vec")
          )
        .def("ResetConstraint",
             (void (FEmTool_Assembly::*)() ) static_cast<void (FEmTool_Assembly::*)() >(&FEmTool_Assembly::ResetConstraint),
             R"#(Delete all Constraints.)#" 
          )
        .def("NullifyConstraint",
             (void (FEmTool_Assembly::*)() ) static_cast<void (FEmTool_Assembly::*)() >(&FEmTool_Assembly::NullifyConstraint),
             R"#(Nullify all Constraints.)#" 
          )
        .def("AddConstraint",
             (void (FEmTool_Assembly::*)(  const int ,   const int ,   const int ,   const math_Vector & ,   const double  ) ) static_cast<void (FEmTool_Assembly::*)(  const int ,   const int ,   const int ,   const math_Vector & ,   const double  ) >(&FEmTool_Assembly::AddConstraint),
             R"#()#"  , py::arg("IndexofConstraint"),  py::arg("Element"),  py::arg("Dimension"),  py::arg("LinearForm"),  py::arg("Value")
          )
        .def("Solve",
             (bool (FEmTool_Assembly::*)() ) static_cast<bool (FEmTool_Assembly::*)() >(&FEmTool_Assembly::Solve),
             R"#(Solve the assembly system Returns false if the computation failed.)#" 
          )
        .def("Solution",
             (void (FEmTool_Assembly::*)( math_Vector &  ) const) static_cast<void (FEmTool_Assembly::*)( math_Vector &  ) const>(&FEmTool_Assembly::Solution),
             R"#()#"  , py::arg("Solution")
          )
        .def("NbGlobVar",
             (int (FEmTool_Assembly::*)() const) static_cast<int (FEmTool_Assembly::*)() const>(&FEmTool_Assembly::NbGlobVar),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("GetAssemblyTable",
             []( FEmTool_Assembly &self , NCollection_HArray2<handle<NCollection_HArray1<int>>>& AssTable ){
                 handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>>  AssTable_ptr; AssTable_ptr = &AssTable;

                 self.GetAssemblyTable(AssTable_ptr);
                 return std::make_tuple(AssTable_ptr); },
             R"#(Returns the assembly table via output parameter.)#"  , py::arg("AssTable")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("AssemblyTable",
             ( const handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>> & (FEmTool_Assembly::*)() const) static_cast< const handle<NCollection_HArray2<handle<NCollection_HArray1<int>>>> & (FEmTool_Assembly::*)() const>(&FEmTool_Assembly::AssemblyTable),
             R"#(Returns the assembly table mapping element-local indices to global indices.)#"
             
         )
;

    // Class FEmTool_Curve from ./opencascade/FEmTool_Curve.hxx
    klass = m.attr("FEmTool_Curve");


    // nested enums

    static_cast<py::class_<FEmTool_Curve ,opencascade::handle<FEmTool_Curve>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int, const PLib_HermitJacobi &, const double >()  , py::arg("Dimension"),  py::arg("NbElements"),  py::arg("TheBase"),  py::arg("Tolerance") )
    // custom constructors
    // methods
        .def("SetElement",
             (void (FEmTool_Curve::*)(  const int ,   const NCollection_Array2<double> &  ) ) static_cast<void (FEmTool_Curve::*)(  const int ,   const NCollection_Array2<double> &  ) >(&FEmTool_Curve::SetElement),
             R"#()#"  , py::arg("IndexOfElement"),  py::arg("Coeffs")
          )
        .def("D0",
             (void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) ) static_cast<void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) >(&FEmTool_Curve::D0),
             R"#()#"  , py::arg("U"),  py::arg("Pnt")
          )
        .def("D1",
             (void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) ) static_cast<void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) >(&FEmTool_Curve::D1),
             R"#()#"  , py::arg("U"),  py::arg("Vec")
          )
        .def("D2",
             (void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) ) static_cast<void (FEmTool_Curve::*)(  const double ,  NCollection_Array1<double> &  ) >(&FEmTool_Curve::D2),
             R"#()#"  , py::arg("U"),  py::arg("Vec")
          )
        .def("GetElement",
             (void (FEmTool_Curve::*)(  const int ,  NCollection_Array2<double> &  ) ) static_cast<void (FEmTool_Curve::*)(  const int ,  NCollection_Array2<double> &  ) >(&FEmTool_Curve::GetElement),
             R"#()#"  , py::arg("IndexOfElement"),  py::arg("Coeffs")
          )
        .def("GetPolynom",
             (void (FEmTool_Curve::*)( NCollection_Array1<double> &  ) ) static_cast<void (FEmTool_Curve::*)( NCollection_Array1<double> &  ) >(&FEmTool_Curve::GetPolynom),
             R"#(returns coefficients of all elements in canonical base.)#"  , py::arg("Coeffs")
          )
        .def("NbElements",
             (int (FEmTool_Curve::*)() const) static_cast<int (FEmTool_Curve::*)() const>(&FEmTool_Curve::NbElements),
             R"#()#" 
          )
        .def("Dimension",
             (int (FEmTool_Curve::*)() const) static_cast<int (FEmTool_Curve::*)() const>(&FEmTool_Curve::Dimension),
             R"#()#" 
          )
        .def("Degree",
             (int (FEmTool_Curve::*)(  const int  ) const) static_cast<int (FEmTool_Curve::*)(  const int  ) const>(&FEmTool_Curve::Degree),
             R"#()#"  , py::arg("IndexOfElement")
          )
        .def("SetDegree",
             (void (FEmTool_Curve::*)(  const int ,   const int  ) ) static_cast<void (FEmTool_Curve::*)(  const int ,   const int  ) >(&FEmTool_Curve::SetDegree),
             R"#()#"  , py::arg("IndexOfElement"),  py::arg("Degree")
          )
    // methods using call by reference i.s.o. return
        .def("Length",
             []( FEmTool_Curve &self ,  const double FirstU, const double LastU ){
                 double  Length;

                 self.Length(FirstU,LastU,Length);
                 return std::make_tuple(Length); },
             R"#()#"  , py::arg("FirstU"),  py::arg("LastU")
          )
        .def("ReduceDegree",
             []( FEmTool_Curve &self ,  const int IndexOfElement, const double Tol ){
                 int  NewDegree;
                double  MaxError;

                 self.ReduceDegree(IndexOfElement,Tol,NewDegree,MaxError);
                 return std::make_tuple(NewDegree,MaxError); },
             R"#()#"  , py::arg("IndexOfElement"),  py::arg("Tol")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_Curve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_Curve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Knots",
             (NCollection_Array1<double> & (FEmTool_Curve::*)() const) static_cast<NCollection_Array1<double> & (FEmTool_Curve::*)() const>(&FEmTool_Curve::Knots),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Base",
             ( const PLib_HermitJacobi & (FEmTool_Curve::*)() const) static_cast< const PLib_HermitJacobi & (FEmTool_Curve::*)() const>(&FEmTool_Curve::Base),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_Curve::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_Curve::*)() const>(&FEmTool_Curve::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_ElementaryCriterion from ./opencascade/FEmTool_ElementaryCriterion.hxx
    klass = m.attr("FEmTool_ElementaryCriterion");


    // nested enums

    static_cast<py::class_<FEmTool_ElementaryCriterion ,opencascade::handle<FEmTool_ElementaryCriterion> ,Py_FEmTool_ElementaryCriterion , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (FEmTool_ElementaryCriterion::*)(  const handle<NCollection_HArray2<double>> &  ) ) static_cast<void (FEmTool_ElementaryCriterion::*)(  const handle<NCollection_HArray2<double>> &  ) >(&FEmTool_ElementaryCriterion::Set),
             R"#(Set the coefficient of the Element (the Curve))#"  , py::arg("Coeff")
          )
        .def("Set",
             (void (FEmTool_ElementaryCriterion::*)(  const double ,   const double  ) ) static_cast<void (FEmTool_ElementaryCriterion::*)(  const double ,   const double  ) >(&FEmTool_ElementaryCriterion::Set),
             R"#(Set the definition interval of the Element)#"  , py::arg("FirstKnot"),  py::arg("LastKnot")
          )
        .def("DependenceTable",
             (handle<NCollection_HArray2<int>> (FEmTool_ElementaryCriterion::*)() const) static_cast<handle<NCollection_HArray2<int>> (FEmTool_ElementaryCriterion::*)() const>(&FEmTool_ElementaryCriterion::DependenceTable),
             R"#(To know if two dimension are independent.)#" 
          )
        .def("Value",
             (double (FEmTool_ElementaryCriterion::*)() ) static_cast<double (FEmTool_ElementaryCriterion::*)() >(&FEmTool_ElementaryCriterion::Value),
             R"#(To Compute J(E) where E is the current Element)#" 
          )
        .def("Hessian",
             (void (FEmTool_ElementaryCriterion::*)(  const int ,   const int ,  math_Matrix &  ) ) static_cast<void (FEmTool_ElementaryCriterion::*)(  const int ,   const int ,  math_Matrix &  ) >(&FEmTool_ElementaryCriterion::Hessian),
             R"#(To Compute J(E) the coefficients of Hessian matrix of J(E) which are crossed derivatives in dimensions <Dim1> and <Dim2>. If DependenceTable(Dimension1,Dimension2) is False)#"  , py::arg("Dim1"),  py::arg("Dim2"),  py::arg("H")
          )
        .def("Gradient",
             (void (FEmTool_ElementaryCriterion::*)(  const int ,  math_Vector &  ) ) static_cast<void (FEmTool_ElementaryCriterion::*)(  const int ,  math_Vector &  ) >(&FEmTool_ElementaryCriterion::Gradient),
             R"#(To Compute the coefficients in the dimension <dim> of the J(E)'s Gradient where E is the current Element)#"  , py::arg("Dim"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_ElementaryCriterion::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_ElementaryCriterion::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_ElementaryCriterion::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_ElementaryCriterion::*)() const>(&FEmTool_ElementaryCriterion::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_ElementsOfRefMatrix from ./opencascade/FEmTool_ElementsOfRefMatrix.hxx
    klass = m.attr("FEmTool_ElementsOfRefMatrix");


    // nested enums

    static_cast<py::class_<FEmTool_ElementsOfRefMatrix , shared_ptr<FEmTool_ElementsOfRefMatrix>  , math_FunctionSet >>(klass)
    // constructors
        .def(py::init<  const PLib_HermitJacobi &, const int >()  , py::arg("TheBase"),  py::arg("DerOrder") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (FEmTool_ElementsOfRefMatrix::*)() const) static_cast<int (FEmTool_ElementsOfRefMatrix::*)() const>(&FEmTool_ElementsOfRefMatrix::NbVariables),
             R"#(returns the number of variables of the function. It is supposed that NbVariables = 1.)#" 
          )
        .def("NbEquations",
             (int (FEmTool_ElementsOfRefMatrix::*)() const) static_cast<int (FEmTool_ElementsOfRefMatrix::*)() const>(&FEmTool_ElementsOfRefMatrix::NbEquations),
             R"#(returns the number of equations of the function.)#" 
          )
        .def("Value",
             (bool (FEmTool_ElementsOfRefMatrix::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (FEmTool_ElementsOfRefMatrix::*)(  const math_Vector & ,  math_Vector &  ) >(&FEmTool_ElementsOfRefMatrix::Value),
             R"#(computes the values <F> of the functions for the variable <X>. returns True if the computation was done successfully, False otherwise. F contains results only for i<=j in following order: P0*P0, P0*P1, P0*P2... P1*P1, P1*P2,... (upper triangle of matrix {PiPj}))#"  , py::arg("X"),  py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class FEmTool_SparseMatrix from ./opencascade/FEmTool_SparseMatrix.hxx
    klass = m.attr("FEmTool_SparseMatrix");


    // nested enums

    static_cast<py::class_<FEmTool_SparseMatrix ,opencascade::handle<FEmTool_SparseMatrix> ,Py_FEmTool_SparseMatrix , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Init",
             (void (FEmTool_SparseMatrix::*)(  const double  ) ) static_cast<void (FEmTool_SparseMatrix::*)(  const double  ) >(&FEmTool_SparseMatrix::Init),
             R"#()#"  , py::arg("Value")
          )
        .def("ChangeValue",
             (double & (FEmTool_SparseMatrix::*)(  const int ,   const int  ) ) static_cast<double & (FEmTool_SparseMatrix::*)(  const int ,   const int  ) >(&FEmTool_SparseMatrix::ChangeValue),
             R"#()#"  , py::arg("I"),  py::arg("J")
          )
        .def("Decompose",
             (bool (FEmTool_SparseMatrix::*)() ) static_cast<bool (FEmTool_SparseMatrix::*)() >(&FEmTool_SparseMatrix::Decompose),
             R"#(To make a Factorization of <me>)#" 
          )
        .def("Solve",
             (void (FEmTool_SparseMatrix::*)(  const math_Vector & ,  math_Vector &  ) const) static_cast<void (FEmTool_SparseMatrix::*)(  const math_Vector & ,  math_Vector &  ) const>(&FEmTool_SparseMatrix::Solve),
             R"#(Direct Solve of AX = B)#"  , py::arg("B"),  py::arg("X")
          )
        .def("Prepare",
             (bool (FEmTool_SparseMatrix::*)() ) static_cast<bool (FEmTool_SparseMatrix::*)() >(&FEmTool_SparseMatrix::Prepare),
             R"#(Make Preparation to iterative solve)#" 
          )
        .def("Solve",
             (void (FEmTool_SparseMatrix::*)(  const math_Vector & ,   const math_Vector & ,  math_Vector & ,  math_Vector & ,   const double ,   const int  ) const) static_cast<void (FEmTool_SparseMatrix::*)(  const math_Vector & ,   const math_Vector & ,  math_Vector & ,  math_Vector & ,   const double ,   const int  ) const>(&FEmTool_SparseMatrix::Solve),
             R"#(Iterative solve of AX = B)#"  , py::arg("B"),  py::arg("Init"),  py::arg("X"),  py::arg("Residual"),  py::arg("Tolerance")=static_cast< const double>(1.0e-8),  py::arg("NbIterations")=static_cast< const int>(50)
          )
        .def("Multiplied",
             (void (FEmTool_SparseMatrix::*)(  const math_Vector & ,  math_Vector &  ) const) static_cast<void (FEmTool_SparseMatrix::*)(  const math_Vector & ,  math_Vector &  ) const>(&FEmTool_SparseMatrix::Multiplied),
             R"#(returns the product of a SparseMatrix by a vector. An exception is raised if the dimensions are different)#"  , py::arg("X"),  py::arg("MX")
          )
        .def("RowNumber",
             (int (FEmTool_SparseMatrix::*)() const) static_cast<int (FEmTool_SparseMatrix::*)() const>(&FEmTool_SparseMatrix::RowNumber),
             R"#(returns the row range of a matrix.)#" 
          )
        .def("ColNumber",
             (int (FEmTool_SparseMatrix::*)() const) static_cast<int (FEmTool_SparseMatrix::*)() const>(&FEmTool_SparseMatrix::ColNumber),
             R"#(returns the column range of the matrix.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_SparseMatrix::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_SparseMatrix::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_SparseMatrix::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_SparseMatrix::*)() const>(&FEmTool_SparseMatrix::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_LinearFlexion from ./opencascade/FEmTool_LinearFlexion.hxx
    klass = m.attr("FEmTool_LinearFlexion");


    // nested enums

    static_cast<py::class_<FEmTool_LinearFlexion ,opencascade::handle<FEmTool_LinearFlexion>  , FEmTool_ElementaryCriterion >>(klass)
    // constructors
        .def(py::init<  const int, const GeomAbs_Shape >()  , py::arg("WorkDegree"),  py::arg("ConstraintOrder") )
    // custom constructors
    // methods
        .def("DependenceTable",
             (handle<NCollection_HArray2<int>> (FEmTool_LinearFlexion::*)() const) static_cast<handle<NCollection_HArray2<int>> (FEmTool_LinearFlexion::*)() const>(&FEmTool_LinearFlexion::DependenceTable),
             R"#()#" 
          )
        .def("Value",
             (double (FEmTool_LinearFlexion::*)() ) static_cast<double (FEmTool_LinearFlexion::*)() >(&FEmTool_LinearFlexion::Value),
             R"#()#" 
          )
        .def("Hessian",
             (void (FEmTool_LinearFlexion::*)(  const int ,   const int ,  math_Matrix &  ) ) static_cast<void (FEmTool_LinearFlexion::*)(  const int ,   const int ,  math_Matrix &  ) >(&FEmTool_LinearFlexion::Hessian),
             R"#()#"  , py::arg("Dimension1"),  py::arg("Dimension2"),  py::arg("H")
          )
        .def("Gradient",
             (void (FEmTool_LinearFlexion::*)(  const int ,  math_Vector &  ) ) static_cast<void (FEmTool_LinearFlexion::*)(  const int ,  math_Vector &  ) >(&FEmTool_LinearFlexion::Gradient),
             R"#()#"  , py::arg("Dimension"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_LinearFlexion::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_LinearFlexion::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_LinearFlexion::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_LinearFlexion::*)() const>(&FEmTool_LinearFlexion::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_LinearJerk from ./opencascade/FEmTool_LinearJerk.hxx
    klass = m.attr("FEmTool_LinearJerk");


    // nested enums

    static_cast<py::class_<FEmTool_LinearJerk ,opencascade::handle<FEmTool_LinearJerk>  , FEmTool_ElementaryCriterion >>(klass)
    // constructors
        .def(py::init<  const int, const GeomAbs_Shape >()  , py::arg("WorkDegree"),  py::arg("ConstraintOrder") )
    // custom constructors
    // methods
        .def("DependenceTable",
             (handle<NCollection_HArray2<int>> (FEmTool_LinearJerk::*)() const) static_cast<handle<NCollection_HArray2<int>> (FEmTool_LinearJerk::*)() const>(&FEmTool_LinearJerk::DependenceTable),
             R"#()#" 
          )
        .def("Value",
             (double (FEmTool_LinearJerk::*)() ) static_cast<double (FEmTool_LinearJerk::*)() >(&FEmTool_LinearJerk::Value),
             R"#()#" 
          )
        .def("Hessian",
             (void (FEmTool_LinearJerk::*)(  const int ,   const int ,  math_Matrix &  ) ) static_cast<void (FEmTool_LinearJerk::*)(  const int ,   const int ,  math_Matrix &  ) >(&FEmTool_LinearJerk::Hessian),
             R"#()#"  , py::arg("Dimension1"),  py::arg("Dimension2"),  py::arg("H")
          )
        .def("Gradient",
             (void (FEmTool_LinearJerk::*)(  const int ,  math_Vector &  ) ) static_cast<void (FEmTool_LinearJerk::*)(  const int ,  math_Vector &  ) >(&FEmTool_LinearJerk::Gradient),
             R"#()#"  , py::arg("Dimension"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_LinearJerk::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_LinearJerk::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_LinearJerk::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_LinearJerk::*)() const>(&FEmTool_LinearJerk::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_LinearTension from ./opencascade/FEmTool_LinearTension.hxx
    klass = m.attr("FEmTool_LinearTension");


    // nested enums

    static_cast<py::class_<FEmTool_LinearTension ,opencascade::handle<FEmTool_LinearTension>  , FEmTool_ElementaryCriterion >>(klass)
    // constructors
        .def(py::init<  const int, const GeomAbs_Shape >()  , py::arg("WorkDegree"),  py::arg("ConstraintOrder") )
    // custom constructors
    // methods
        .def("DependenceTable",
             (handle<NCollection_HArray2<int>> (FEmTool_LinearTension::*)() const) static_cast<handle<NCollection_HArray2<int>> (FEmTool_LinearTension::*)() const>(&FEmTool_LinearTension::DependenceTable),
             R"#()#" 
          )
        .def("Value",
             (double (FEmTool_LinearTension::*)() ) static_cast<double (FEmTool_LinearTension::*)() >(&FEmTool_LinearTension::Value),
             R"#()#" 
          )
        .def("Hessian",
             (void (FEmTool_LinearTension::*)(  const int ,   const int ,  math_Matrix &  ) ) static_cast<void (FEmTool_LinearTension::*)(  const int ,   const int ,  math_Matrix &  ) >(&FEmTool_LinearTension::Hessian),
             R"#()#"  , py::arg("Dimension1"),  py::arg("Dimension2"),  py::arg("H")
          )
        .def("Gradient",
             (void (FEmTool_LinearTension::*)(  const int ,  math_Vector &  ) ) static_cast<void (FEmTool_LinearTension::*)(  const int ,  math_Vector &  ) >(&FEmTool_LinearTension::Gradient),
             R"#()#"  , py::arg("Dimension"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_LinearTension::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_LinearTension::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_LinearTension::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_LinearTension::*)() const>(&FEmTool_LinearTension::DynamicType),
             R"#()#"
             
         )
;

    // Class FEmTool_ProfileMatrix from ./opencascade/FEmTool_ProfileMatrix.hxx
    klass = m.attr("FEmTool_ProfileMatrix");


    // nested enums

    static_cast<py::class_<FEmTool_ProfileMatrix ,opencascade::handle<FEmTool_ProfileMatrix>  , FEmTool_SparseMatrix >>(klass)
    // constructors
        .def(py::init<  const NCollection_Array1<int> & >()  , py::arg("FirstIndexes") )
    // custom constructors
    // methods
        .def("Init",
             (void (FEmTool_ProfileMatrix::*)(  const double  ) ) static_cast<void (FEmTool_ProfileMatrix::*)(  const double  ) >(&FEmTool_ProfileMatrix::Init),
             R"#()#"  , py::arg("Value")
          )
        .def("ChangeValue",
             (double & (FEmTool_ProfileMatrix::*)(  const int ,   const int  ) ) static_cast<double & (FEmTool_ProfileMatrix::*)(  const int ,   const int  ) >(&FEmTool_ProfileMatrix::ChangeValue),
             R"#()#"  , py::arg("I"),  py::arg("J")
          )
        .def("Decompose",
             (bool (FEmTool_ProfileMatrix::*)() ) static_cast<bool (FEmTool_ProfileMatrix::*)() >(&FEmTool_ProfileMatrix::Decompose),
             R"#(To make a Factorization of <me>)#" 
          )
        .def("Solve",
             (void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,  math_Vector &  ) const) static_cast<void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,  math_Vector &  ) const>(&FEmTool_ProfileMatrix::Solve),
             R"#(Direct Solve of AX = B)#"  , py::arg("B"),  py::arg("X")
          )
        .def("Prepare",
             (bool (FEmTool_ProfileMatrix::*)() ) static_cast<bool (FEmTool_ProfileMatrix::*)() >(&FEmTool_ProfileMatrix::Prepare),
             R"#(Make Preparation to iterative solve)#" 
          )
        .def("Solve",
             (void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,   const math_Vector & ,  math_Vector & ,  math_Vector & ,   const double ,   const int  ) const) static_cast<void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,   const math_Vector & ,  math_Vector & ,  math_Vector & ,   const double ,   const int  ) const>(&FEmTool_ProfileMatrix::Solve),
             R"#(Iterative solve of AX = B)#"  , py::arg("B"),  py::arg("Init"),  py::arg("X"),  py::arg("Residual"),  py::arg("Tolerance")=static_cast< const double>(1.0e-8),  py::arg("NbIterations")=static_cast< const int>(50)
          )
        .def("Multiplied",
             (void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,  math_Vector &  ) const) static_cast<void (FEmTool_ProfileMatrix::*)(  const math_Vector & ,  math_Vector &  ) const>(&FEmTool_ProfileMatrix::Multiplied),
             R"#(returns the product of a SparseMatrix by a vector. An exception is raised if the dimensions are different)#"  , py::arg("X"),  py::arg("MX")
          )
        .def("RowNumber",
             (int (FEmTool_ProfileMatrix::*)() const) static_cast<int (FEmTool_ProfileMatrix::*)() const>(&FEmTool_ProfileMatrix::RowNumber),
             R"#(returns the row range of a matrix.)#" 
          )
        .def("ColNumber",
             (int (FEmTool_ProfileMatrix::*)() const) static_cast<int (FEmTool_ProfileMatrix::*)() const>(&FEmTool_ProfileMatrix::ColNumber),
             R"#(returns the column range of the matrix.)#" 
          )
        .def("IsInProfile",
             (bool (FEmTool_ProfileMatrix::*)(  const int ,   const int  ) const) static_cast<bool (FEmTool_ProfileMatrix::*)(  const int ,   const int  ) const>(&FEmTool_ProfileMatrix::IsInProfile),
             R"#()#"  , py::arg("i"),  py::arg("j")
          )
        .def("OutM",
             (void (FEmTool_ProfileMatrix::*)() const) static_cast<void (FEmTool_ProfileMatrix::*)() const>(&FEmTool_ProfileMatrix::OutM),
             R"#()#" 
          )
        .def("OutS",
             (void (FEmTool_ProfileMatrix::*)() const) static_cast<void (FEmTool_ProfileMatrix::*)() const>(&FEmTool_ProfileMatrix::OutS),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&FEmTool_ProfileMatrix::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&FEmTool_ProfileMatrix::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (FEmTool_ProfileMatrix::*)() const) static_cast< const handle<Standard_Type> & (FEmTool_ProfileMatrix::*)() const>(&FEmTool_ProfileMatrix::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/FEmTool_Assembly.hxx
// ./opencascade/FEmTool_Curve.hxx
// ./opencascade/FEmTool_ElementaryCriterion.hxx
// ./opencascade/FEmTool_ElementsOfRefMatrix.hxx
// ./opencascade/FEmTool_LinearFlexion.hxx
// ./opencascade/FEmTool_LinearJerk.hxx
// ./opencascade/FEmTool_LinearTension.hxx
// ./opencascade/FEmTool_ProfileMatrix.hxx
// ./opencascade/FEmTool_SparseMatrix.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
