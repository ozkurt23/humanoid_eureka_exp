
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <FEmTool_ProfileMatrix.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <FEmTool_Assembly.hxx>
#include <FEmTool_Curve.hxx>
#include <FEmTool_ElementaryCriterion.hxx>
#include <FEmTool_ElementsOfRefMatrix.hxx>
#include <FEmTool_LinearFlexion.hxx>
#include <FEmTool_LinearJerk.hxx>
#include <FEmTool_LinearTension.hxx>
#include <FEmTool_ProfileMatrix.hxx>
#include <FEmTool_SparseMatrix.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_FEmTool_enums(py::module &main_module) {


py::module m = main_module.def_submodule("FEmTool", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes
    class Py_FEmTool_ElementaryCriterion : public FEmTool_ElementaryCriterion{
    public:
        using FEmTool_ElementaryCriterion::FEmTool_ElementaryCriterion;


        // public pure virtual
        handle<NCollection_HArray2<int>> DependenceTable() const  override { using return_type = handle<NCollection_HArray2<int>>;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,DependenceTable,) };
        double Value() override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Value,) };
        void Hessian( const int Dim1, const int Dim2,math_Matrix & H) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Hessian,Dim1,Dim2,H) };
        void Gradient( const int Dim,math_Vector & G) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_ElementaryCriterion,Gradient,Dim,G) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_FEmTool_SparseMatrix : public FEmTool_SparseMatrix{
    public:
        using FEmTool_SparseMatrix::FEmTool_SparseMatrix;


        // public pure virtual
        void Init( const double Value) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Init,Value) };
        double & ChangeValue( const int I, const int J) override { using return_type = double &;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,ChangeValue,I,J) };
        bool Decompose() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Decompose,) };
        void Solve( const math_Vector & B,math_Vector & X) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Solve,B,X) };
        bool Prepare() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Prepare,) };
        void Solve( const math_Vector & B, const math_Vector & Init,math_Vector & X,math_Vector & Residual, const double Tolerance, const int NbIterations) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Solve,B,Init,X,Residual,Tolerance,NbIterations) };
        void Multiplied( const math_Vector & X,math_Vector & MX) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,Multiplied,X,MX) };
        int RowNumber() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,RowNumber,) };
        int ColNumber() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,FEmTool_SparseMatrix,ColNumber,) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<FEmTool_Assembly , shared_ptr<FEmTool_Assembly>  >(
      m,
      "FEmTool_Assembly",R"#(Assemble and solve system from (one dimensional) Finite Elements)#"
    );
    py::class_<FEmTool_Curve ,opencascade::handle<FEmTool_Curve>  , Standard_Transient >(
      m,
      "FEmTool_Curve",R"#(Curve defined by Polynomial Elements.)#"
    );
    py::class_<FEmTool_ElementaryCriterion ,opencascade::handle<FEmTool_ElementaryCriterion> ,Py_FEmTool_ElementaryCriterion , Standard_Transient >(
      m,
      "FEmTool_ElementaryCriterion",R"#(defined J Criteria to used in minimisation)#"
    );
    py::class_<FEmTool_ElementsOfRefMatrix , shared_ptr<FEmTool_ElementsOfRefMatrix>  , math_FunctionSet >(
      m,
      "FEmTool_ElementsOfRefMatrix",R"#(this class describes the functions needed for calculating matrix elements of RefMatrix for linear criteriums (Tension, Flexion and Jerk) by Gauss integration. Each function from set gives value Pi(u)'*Pj(u)' or Pi(u)''*Pj(u)'' or Pi(u)'''*Pj(u)''' for each i and j, where Pi(u) is i-th basis function of expansion and (') means derivative.)#"
    );
    py::class_<FEmTool_SparseMatrix ,opencascade::handle<FEmTool_SparseMatrix> ,Py_FEmTool_SparseMatrix , Standard_Transient >(
      m,
      "FEmTool_SparseMatrix",R"#(Sparse Matrix definition)#"
    );
    py::class_<FEmTool_LinearFlexion ,opencascade::handle<FEmTool_LinearFlexion>  , FEmTool_ElementaryCriterion >(
      m,
      "FEmTool_LinearFlexion",R"#(Criterium of LinearFlexion To Hermit-Jacobi elements)#"
    );
    py::class_<FEmTool_LinearJerk ,opencascade::handle<FEmTool_LinearJerk>  , FEmTool_ElementaryCriterion >(
      m,
      "FEmTool_LinearJerk",R"#(Criterion of LinearJerk To Hermit-Jacobi elements)#"
    );
    py::class_<FEmTool_LinearTension ,opencascade::handle<FEmTool_LinearTension>  , FEmTool_ElementaryCriterion >(
      m,
      "FEmTool_LinearTension",R"#(Criterium of LinearTension To Hermit-Jacobi elements)#"
    );
    py::class_<FEmTool_ProfileMatrix ,opencascade::handle<FEmTool_ProfileMatrix>  , FEmTool_SparseMatrix >(
      m,
      "FEmTool_ProfileMatrix",R"#(Symmetric Sparse ProfileMatrix useful for 1D Finite Element methods)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
