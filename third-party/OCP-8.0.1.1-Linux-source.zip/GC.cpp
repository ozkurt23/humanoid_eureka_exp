
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cone.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Pnt.hxx>
#include <gp_Ax1.hxx>
#include <gp_Lin.hxx>
#include <gp_Dir.hxx>
#include <gp_Pln.hxx>
#include <gp_Ax2.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_Ax2d.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Dir2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Lin.hxx>
#include <gp_Ax1.hxx>
#include <gp_Pnt.hxx>
#include <gp_Dir.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Vec.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Vec2d.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <gp_Ax1.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <GC_MakeArcOfCircle.hxx>
#include <GC_MakeArcOfCircle2d.hxx>
#include <GC_MakeArcOfEllipse.hxx>
#include <GC_MakeArcOfEllipse2d.hxx>
#include <GC_MakeArcOfHyperbola.hxx>
#include <GC_MakeArcOfHyperbola2d.hxx>
#include <GC_MakeArcOfParabola.hxx>
#include <GC_MakeArcOfParabola2d.hxx>
#include <GC_MakeCircle.hxx>
#include <GC_MakeCircle2d.hxx>
#include <GC_MakeConicalSurface.hxx>
#include <GC_MakeCylindricalSurface.hxx>
#include <GC_MakeEllipse.hxx>
#include <GC_MakeEllipse2d.hxx>
#include <GC_MakeHyperbola.hxx>
#include <GC_MakeHyperbola2d.hxx>
#include <GC_MakeLine.hxx>
#include <GC_MakeLine2d.hxx>
#include <GC_MakeMirror.hxx>
#include <GC_MakeMirror2d.hxx>
#include <GC_MakeParabola2d.hxx>
#include <GC_MakePlane.hxx>
#include <GC_MakeRotation.hxx>
#include <GC_MakeRotation2d.hxx>
#include <GC_MakeScale.hxx>
#include <GC_MakeScale2d.hxx>
#include <GC_MakeSegment.hxx>
#include <GC_MakeSegment2d.hxx>
#include <GC_MakeTranslation.hxx>
#include <GC_MakeTranslation2d.hxx>
#include <GC_MakeTrimmedCone.hxx>
#include <GC_MakeTrimmedCylinder.hxx>
#include <GC_Root.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GC(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("GC"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class GC_MakeMirror from ./opencascade/GC_MakeMirror.hxx
    klass = m.attr("GC_MakeMirror");


    // nested enums

    static_cast<py::class_<GC_MakeMirror , shared_ptr<GC_MakeMirror>  >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 & >()  , py::arg("theAxis") )
        .def(py::init<  const gp_Ax2 & >()  , py::arg("thePlane") )
        .def(py::init<  const gp_Lin & >()  , py::arg("theLine") )
        .def(py::init<  const gp_Pln & >()  , py::arg("thePlane") )
        .def(py::init<  const gp_Pnt & >()  , py::arg("thePoint") )
        .def(py::init<  const gp_Pnt &, const gp_Dir & >()  , py::arg("thePoint"),  py::arg("theDirec") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Transformation> & (GC_MakeMirror::*)() const) static_cast< const handle<Geom_Transformation> & (GC_MakeMirror::*)() const>(&GC_MakeMirror::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeMirror2d from ./opencascade/GC_MakeMirror2d.hxx
    klass = m.attr("GC_MakeMirror2d");


    // nested enums

    static_cast<py::class_<GC_MakeMirror2d , shared_ptr<GC_MakeMirror2d>  >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2d & >()  , py::arg("theAxis") )
        .def(py::init<  const gp_Lin2d & >()  , py::arg("theLine") )
        .def(py::init<  const gp_Pnt2d & >()  , py::arg("thePoint") )
        .def(py::init<  const gp_Pnt2d &, const gp_Dir2d & >()  , py::arg("thePoint"),  py::arg("theDirec") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Transformation> & (GC_MakeMirror2d::*)() const) static_cast< const handle<Geom2d_Transformation> & (GC_MakeMirror2d::*)() const>(&GC_MakeMirror2d::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeRotation from ./opencascade/GC_MakeRotation.hxx
    klass = m.attr("GC_MakeRotation");


    // nested enums

    static_cast<py::class_<GC_MakeRotation , shared_ptr<GC_MakeRotation>  >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 &, const double >()  , py::arg("theAxis"),  py::arg("theAngle") )
        .def(py::init<  const gp_Lin &, const double >()  , py::arg("theLine"),  py::arg("theAngle") )
        .def(py::init<  const gp_Pnt &, const gp_Dir &, const double >()  , py::arg("thePoint"),  py::arg("theDirec"),  py::arg("theAngle") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Transformation> & (GC_MakeRotation::*)() const) static_cast< const handle<Geom_Transformation> & (GC_MakeRotation::*)() const>(&GC_MakeRotation::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeRotation2d from ./opencascade/GC_MakeRotation2d.hxx
    klass = m.attr("GC_MakeRotation2d");


    // nested enums

    static_cast<py::class_<GC_MakeRotation2d , shared_ptr<GC_MakeRotation2d>  >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt2d &, const double >()  , py::arg("thePoint"),  py::arg("theAngle") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Transformation> & (GC_MakeRotation2d::*)() const) static_cast< const handle<Geom2d_Transformation> & (GC_MakeRotation2d::*)() const>(&GC_MakeRotation2d::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeScale from ./opencascade/GC_MakeScale.hxx
    klass = m.attr("GC_MakeScale");


    // nested enums

    static_cast<py::class_<GC_MakeScale , shared_ptr<GC_MakeScale>  >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt &, const double >()  , py::arg("thePoint"),  py::arg("theScale") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Transformation> & (GC_MakeScale::*)() const) static_cast< const handle<Geom_Transformation> & (GC_MakeScale::*)() const>(&GC_MakeScale::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeScale2d from ./opencascade/GC_MakeScale2d.hxx
    klass = m.attr("GC_MakeScale2d");


    // nested enums

    static_cast<py::class_<GC_MakeScale2d , shared_ptr<GC_MakeScale2d>  >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt2d &, const double >()  , py::arg("thePoint"),  py::arg("theScale") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Transformation> & (GC_MakeScale2d::*)() const) static_cast< const handle<Geom2d_Transformation> & (GC_MakeScale2d::*)() const>(&GC_MakeScale2d::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeTranslation from ./opencascade/GC_MakeTranslation.hxx
    klass = m.attr("GC_MakeTranslation");


    // nested enums

    static_cast<py::class_<GC_MakeTranslation , shared_ptr<GC_MakeTranslation>  >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt &, const gp_Pnt & >()  , py::arg("thePoint1"),  py::arg("thePoint2") )
        .def(py::init<  const gp_Vec & >()  , py::arg("theVect") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Transformation> & (GC_MakeTranslation::*)() const) static_cast< const handle<Geom_Transformation> & (GC_MakeTranslation::*)() const>(&GC_MakeTranslation::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_MakeTranslation2d from ./opencascade/GC_MakeTranslation2d.hxx
    klass = m.attr("GC_MakeTranslation2d");


    // nested enums

    static_cast<py::class_<GC_MakeTranslation2d , shared_ptr<GC_MakeTranslation2d>  >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("thePoint1"),  py::arg("thePoint2") )
        .def(py::init<  const gp_Vec2d & >()  , py::arg("theVect") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Transformation> & (GC_MakeTranslation2d::*)() const) static_cast< const handle<Geom2d_Transformation> & (GC_MakeTranslation2d::*)() const>(&GC_MakeTranslation2d::Value),
             R"#(Returns the constructed transformation.)#"
             
         )
;

    // Class GC_Root from ./opencascade/GC_Root.hxx
    klass = m.attr("GC_Root");

    // default constructor
    register_default_constructor<GC_Root , shared_ptr<GC_Root>>(m,"GC_Root");

    // nested enums

    static_cast<py::class_<GC_Root , shared_ptr<GC_Root>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsDone",
             (bool (GC_Root::*)() const) static_cast<bool (GC_Root::*)() const>(&GC_Root::IsDone),
             R"#(Returns true if the construction is successful.)#" 
          )
        .def("IsError",
             (bool (GC_Root::*)() const) static_cast<bool (GC_Root::*)() const>(&GC_Root::IsError),
             R"#(Returns true if the construction has failed.)#" 
          )
        .def("Status",
             (gce_ErrorType (GC_Root::*)() const) static_cast<gce_ErrorType (GC_Root::*)() const>(&GC_Root::Status),
             R"#(Returns the status of the construction: - gce_Done, if the construction is successful, or - another value of the gce_ErrorType enumeration indicating why the construction failed.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GC_MakeArcOfCircle from ./opencascade/GC_MakeArcOfCircle.hxx
    klass = m.attr("GC_MakeArcOfCircle");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfCircle , shared_ptr<GC_MakeArcOfCircle>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Circ &, const double, const double, const bool >()  , py::arg("theCirc"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense") )
        .def(py::init<  const gp_Circ &, const gp_Pnt &, const double, const bool >()  , py::arg("theCirc"),  py::arg("theP"),  py::arg("theAlpha"),  py::arg("theSense") )
        .def(py::init<  const gp_Circ &, const gp_Pnt &, const gp_Pnt &, const bool >()  , py::arg("theCirc"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
        .def(py::init<  const gp_Pnt &, const gp_Vec &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theV"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_TrimmedCurve> & (GC_MakeArcOfCircle::*)() const) static_cast< const handle<Geom_TrimmedCurve> & (GC_MakeArcOfCircle::*)() const>(&GC_MakeArcOfCircle::Value),
             R"#(Returns the constructed arc of circle. Exceptions StdFail_NotDone if no arc of circle is constructed.)#"
             
         )
;

    // Class GC_MakeArcOfCircle2d from ./opencascade/GC_MakeArcOfCircle2d.hxx
    klass = m.attr("GC_MakeArcOfCircle2d");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfCircle2d , shared_ptr<GC_MakeArcOfCircle2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Circ2d &, const double, const double, const bool >()  , py::arg("theCircle"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Circ2d &, const gp_Pnt2d &, const double, const bool >()  , py::arg("theCircle"),  py::arg("thePoint"),  py::arg("theAlpha"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Circ2d &, const gp_Pnt2d &, const gp_Pnt2d &, const bool >()  , py::arg("theCircle"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
        .def(py::init<  const gp_Pnt2d &, const gp_Vec2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theV"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfCircle2d::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfCircle2d::*)() const>(&GC_MakeArcOfCircle2d::Value),
             R"#(Returns the constructed arc of circle. Exceptions StdFail_NotDone if no arc of circle is constructed.)#"
             
         )
;

    // Class GC_MakeArcOfEllipse from ./opencascade/GC_MakeArcOfEllipse.hxx
    klass = m.attr("GC_MakeArcOfEllipse");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfEllipse , shared_ptr<GC_MakeArcOfEllipse>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Elips &, const double, const double, const bool >()  , py::arg("theElips"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense") )
        .def(py::init<  const gp_Elips &, const gp_Pnt &, const double, const bool >()  , py::arg("theElips"),  py::arg("theP"),  py::arg("theAlpha"),  py::arg("theSense") )
        .def(py::init<  const gp_Elips &, const gp_Pnt &, const gp_Pnt &, const bool >()  , py::arg("theElips"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_TrimmedCurve> & (GC_MakeArcOfEllipse::*)() const) static_cast< const handle<Geom_TrimmedCurve> & (GC_MakeArcOfEllipse::*)() const>(&GC_MakeArcOfEllipse::Value),
             R"#(Returns the constructed arc of ellipse.)#"
             
         )
;

    // Class GC_MakeArcOfEllipse2d from ./opencascade/GC_MakeArcOfEllipse2d.hxx
    klass = m.attr("GC_MakeArcOfEllipse2d");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfEllipse2d , shared_ptr<GC_MakeArcOfEllipse2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Elips2d &, const double, const double, const bool >()  , py::arg("theEllipse"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Elips2d &, const gp_Pnt2d &, const double, const bool >()  , py::arg("theEllipse"),  py::arg("thePoint"),  py::arg("theAlpha"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Elips2d &, const gp_Pnt2d &, const gp_Pnt2d &, const bool >()  , py::arg("theEllipse"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense")=static_cast< const bool>(true) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfEllipse2d::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfEllipse2d::*)() const>(&GC_MakeArcOfEllipse2d::Value),
             R"#(Returns the constructed arc of ellipse.)#"
             
         )
;

    // Class GC_MakeArcOfHyperbola from ./opencascade/GC_MakeArcOfHyperbola.hxx
    klass = m.attr("GC_MakeArcOfHyperbola");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfHyperbola , shared_ptr<GC_MakeArcOfHyperbola>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Hypr &, const double, const double, const bool >()  , py::arg("theHypr"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense") )
        .def(py::init<  const gp_Hypr &, const gp_Pnt &, const double, const bool >()  , py::arg("theHypr"),  py::arg("theP"),  py::arg("theAlpha"),  py::arg("theSense") )
        .def(py::init<  const gp_Hypr &, const gp_Pnt &, const gp_Pnt &, const bool >()  , py::arg("theHypr"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_TrimmedCurve> & (GC_MakeArcOfHyperbola::*)() const) static_cast< const handle<Geom_TrimmedCurve> & (GC_MakeArcOfHyperbola::*)() const>(&GC_MakeArcOfHyperbola::Value),
             R"#(Returns the constructed arc of hyperbola.)#"
             
         )
;

    // Class GC_MakeArcOfHyperbola2d from ./opencascade/GC_MakeArcOfHyperbola2d.hxx
    klass = m.attr("GC_MakeArcOfHyperbola2d");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfHyperbola2d , shared_ptr<GC_MakeArcOfHyperbola2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Hypr2d &, const double, const double, const bool >()  , py::arg("theHyperbola"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Hypr2d &, const gp_Pnt2d &, const double, const bool >()  , py::arg("theHyperbola"),  py::arg("thePoint"),  py::arg("theAlpha"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Hypr2d &, const gp_Pnt2d &, const gp_Pnt2d &, const bool >()  , py::arg("theHyperbola"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense")=static_cast< const bool>(true) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfHyperbola2d::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfHyperbola2d::*)() const>(&GC_MakeArcOfHyperbola2d::Value),
             R"#(Returns the constructed arc of hyperbola.)#"
             
         )
;

    // Class GC_MakeArcOfParabola from ./opencascade/GC_MakeArcOfParabola.hxx
    klass = m.attr("GC_MakeArcOfParabola");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfParabola , shared_ptr<GC_MakeArcOfParabola>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Parab &, const double, const double, const bool >()  , py::arg("theParab"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense") )
        .def(py::init<  const gp_Parab &, const gp_Pnt &, const double, const bool >()  , py::arg("theParab"),  py::arg("theP"),  py::arg("theAlpha"),  py::arg("theSense") )
        .def(py::init<  const gp_Parab &, const gp_Pnt &, const gp_Pnt &, const bool >()  , py::arg("theParab"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_TrimmedCurve> & (GC_MakeArcOfParabola::*)() const) static_cast< const handle<Geom_TrimmedCurve> & (GC_MakeArcOfParabola::*)() const>(&GC_MakeArcOfParabola::Value),
             R"#(Returns the constructed arc of parabola.)#"
             
         )
;

    // Class GC_MakeArcOfParabola2d from ./opencascade/GC_MakeArcOfParabola2d.hxx
    klass = m.attr("GC_MakeArcOfParabola2d");


    // nested enums

    static_cast<py::class_<GC_MakeArcOfParabola2d , shared_ptr<GC_MakeArcOfParabola2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Parab2d &, const double, const double, const bool >()  , py::arg("theParabola"),  py::arg("theAlpha1"),  py::arg("theAlpha2"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Parab2d &, const gp_Pnt2d &, const double, const bool >()  , py::arg("theParabola"),  py::arg("thePoint"),  py::arg("theAlpha"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Parab2d &, const gp_Pnt2d &, const gp_Pnt2d &, const bool >()  , py::arg("theParabola"),  py::arg("theP1"),  py::arg("theP2"),  py::arg("theSense")=static_cast< const bool>(true) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfParabola2d::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (GC_MakeArcOfParabola2d::*)() const>(&GC_MakeArcOfParabola2d::Value),
             R"#(Returns the constructed arc of parabola.)#"
             
         )
;

    // Class GC_MakeCircle from ./opencascade/GC_MakeCircle.hxx
    klass = m.attr("GC_MakeCircle");


    // nested enums

    static_cast<py::class_<GC_MakeCircle , shared_ptr<GC_MakeCircle>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 &, const double >()  , py::arg("theAxis"),  py::arg("theRadius") )
        .def(py::init<  const gp_Ax2 &, const double >()  , py::arg("theA2"),  py::arg("theRadius") )
        .def(py::init<  const gp_Circ & >()  , py::arg("theC") )
        .def(py::init<  const gp_Circ &, const double >()  , py::arg("theCirc"),  py::arg("theDist") )
        .def(py::init<  const gp_Circ &, const gp_Pnt & >()  , py::arg("theCirc"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt &, const gp_Dir &, const double >()  , py::arg("theCenter"),  py::arg("theNorm"),  py::arg("theRadius") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const double >()  , py::arg("theCenter"),  py::arg("thePtAxis"),  py::arg("theRadius") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Circle> & (GC_MakeCircle::*)() const) static_cast< const handle<Geom_Circle> & (GC_MakeCircle::*)() const>(&GC_MakeCircle::Value),
             R"#(Returns the constructed circle. Exceptions StdFail_NotDone if no circle is constructed.)#"
             
         )
;

    // Class GC_MakeCircle2d from ./opencascade/GC_MakeCircle2d.hxx
    klass = m.attr("GC_MakeCircle2d");


    // nested enums

    static_cast<py::class_<GC_MakeCircle2d , shared_ptr<GC_MakeCircle2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax22d &, const double >()  , py::arg("theAxis"),  py::arg("theRadius") )
        .def(py::init<  const gp_Ax2d &, const double, const bool >()  , py::arg("theAxis"),  py::arg("theRadius"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Circ2d & >()  , py::arg("theCircle") )
        .def(py::init<  const gp_Circ2d &, const double >()  , py::arg("theCircle"),  py::arg("theDist") )
        .def(py::init<  const gp_Circ2d &, const gp_Pnt2d & >()  , py::arg("theCircle"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt2d &, const double, const bool >()  , py::arg("theCenter"),  py::arg("theRadius"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d &, const bool >()  , py::arg("theCenter"),  py::arg("thePoint"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Circle> & (GC_MakeCircle2d::*)() const) static_cast< const handle<Geom2d_Circle> & (GC_MakeCircle2d::*)() const>(&GC_MakeCircle2d::Value),
             R"#(Returns the constructed circle. Exceptions StdFail_NotDone if no circle is constructed.)#"
             
         )
;

    // Class GC_MakeConicalSurface from ./opencascade/GC_MakeConicalSurface.hxx
    klass = m.attr("GC_MakeConicalSurface");


    // nested enums

    static_cast<py::class_<GC_MakeConicalSurface , shared_ptr<GC_MakeConicalSurface>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2 &, const double, const double >()  , py::arg("theA2"),  py::arg("theAng"),  py::arg("theRadius") )
        .def(py::init<  const gp_Cone & >()  , py::arg("theC") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const double, const double >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theR1"),  py::arg("theR2") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3"),  py::arg("theP4") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_ConicalSurface> & (GC_MakeConicalSurface::*)() const) static_cast< const handle<Geom_ConicalSurface> & (GC_MakeConicalSurface::*)() const>(&GC_MakeConicalSurface::Value),
             R"#(Returns the constructed cone. Exceptions StdFail_NotDone if no cone is constructed.)#"
             
         )
;

    // Class GC_MakeCylindricalSurface from ./opencascade/GC_MakeCylindricalSurface.hxx
    klass = m.attr("GC_MakeCylindricalSurface");


    // nested enums

    static_cast<py::class_<GC_MakeCylindricalSurface , shared_ptr<GC_MakeCylindricalSurface>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 &, const double >()  , py::arg("theAxis"),  py::arg("theRadius") )
        .def(py::init<  const gp_Ax2 &, const double >()  , py::arg("theA2"),  py::arg("theRadius") )
        .def(py::init<  const gp_Circ & >()  , py::arg("theCirc") )
        .def(py::init<  const gp_Cylinder & >()  , py::arg("theC") )
        .def(py::init<  const gp_Cylinder &, const double >()  , py::arg("theCyl"),  py::arg("theDist") )
        .def(py::init<  const gp_Cylinder &, const gp_Pnt & >()  , py::arg("theCyl"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_CylindricalSurface> & (GC_MakeCylindricalSurface::*)() const) static_cast< const handle<Geom_CylindricalSurface> & (GC_MakeCylindricalSurface::*)() const>(&GC_MakeCylindricalSurface::Value),
             R"#(Returns the constructed cylinder. Exceptions StdFail_NotDone if no cylinder is constructed.)#"
             
         )
;

    // Class GC_MakeEllipse from ./opencascade/GC_MakeEllipse.hxx
    klass = m.attr("GC_MakeEllipse");


    // nested enums

    static_cast<py::class_<GC_MakeEllipse , shared_ptr<GC_MakeEllipse>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2 &, const double, const double >()  , py::arg("theA2"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius") )
        .def(py::init<  const gp_Elips & >()  , py::arg("theE") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theS1"),  py::arg("theS2"),  py::arg("theCenter") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Ellipse> & (GC_MakeEllipse::*)() const) static_cast< const handle<Geom_Ellipse> & (GC_MakeEllipse::*)() const>(&GC_MakeEllipse::Value),
             R"#(Returns the constructed ellipse. Exceptions StdFail_NotDone if no ellipse is constructed.)#"
             
         )
;

    // Class GC_MakeEllipse2d from ./opencascade/GC_MakeEllipse2d.hxx
    klass = m.attr("GC_MakeEllipse2d");


    // nested enums

    static_cast<py::class_<GC_MakeEllipse2d , shared_ptr<GC_MakeEllipse2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax22d &, const double, const double >()  , py::arg("theAxis"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius") )
        .def(py::init<  const gp_Ax2d &, const double, const double, const bool >()  , py::arg("theMajorAxis"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Elips2d & >()  , py::arg("theEllipse") )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theS1"),  py::arg("theS2"),  py::arg("theCenter") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Ellipse> & (GC_MakeEllipse2d::*)() const) static_cast< const handle<Geom2d_Ellipse> & (GC_MakeEllipse2d::*)() const>(&GC_MakeEllipse2d::Value),
             R"#(Returns the constructed ellipse. Exceptions StdFail_NotDone if no ellipse is constructed.)#"
             
         )
;

    // Class GC_MakeHyperbola from ./opencascade/GC_MakeHyperbola.hxx
    klass = m.attr("GC_MakeHyperbola");


    // nested enums

    static_cast<py::class_<GC_MakeHyperbola , shared_ptr<GC_MakeHyperbola>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2 &, const double, const double >()  , py::arg("theA2"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius") )
        .def(py::init<  const gp_Hypr & >()  , py::arg("theH") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theS1"),  py::arg("theS2"),  py::arg("theCenter") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Hyperbola> & (GC_MakeHyperbola::*)() const) static_cast< const handle<Geom_Hyperbola> & (GC_MakeHyperbola::*)() const>(&GC_MakeHyperbola::Value),
             R"#(Returns the constructed hyperbola. Exceptions StdFail_NotDone if no hyperbola is constructed.)#"
             
         )
;

    // Class GC_MakeHyperbola2d from ./opencascade/GC_MakeHyperbola2d.hxx
    klass = m.attr("GC_MakeHyperbola2d");


    // nested enums

    static_cast<py::class_<GC_MakeHyperbola2d , shared_ptr<GC_MakeHyperbola2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax22d &, const double, const double >()  , py::arg("theAxis"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius") )
        .def(py::init<  const gp_Ax2d &, const double, const double, const bool >()  , py::arg("theMajorAxis"),  py::arg("theMajorRadius"),  py::arg("theMinorRadius"),  py::arg("theSense") )
        .def(py::init<  const gp_Hypr2d & >()  , py::arg("theHyperbola") )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theS1"),  py::arg("theS2"),  py::arg("theCenter") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Hyperbola> & (GC_MakeHyperbola2d::*)() const) static_cast< const handle<Geom2d_Hyperbola> & (GC_MakeHyperbola2d::*)() const>(&GC_MakeHyperbola2d::Value),
             R"#(Returns the constructed hyperbola. Exceptions: StdFail_NotDone if no hyperbola is constructed.)#"
             
         )
;

    // Class GC_MakeLine from ./opencascade/GC_MakeLine.hxx
    klass = m.attr("GC_MakeLine");


    // nested enums

    static_cast<py::class_<GC_MakeLine , shared_ptr<GC_MakeLine>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 & >()  , py::arg("theA1") )
        .def(py::init<  const gp_Lin & >()  , py::arg("theL") )
        .def(py::init<  const gp_Lin &, const gp_Pnt & >()  , py::arg("theLin"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt &, const gp_Dir & >()  , py::arg("theP"),  py::arg("theV") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Line> & (GC_MakeLine::*)() const) static_cast< const handle<Geom_Line> & (GC_MakeLine::*)() const>(&GC_MakeLine::Value),
             R"#(Returns the constructed line. Exceptions StdFail_NotDone if no line is constructed.)#"
             
         )
;

    // Class GC_MakeLine2d from ./opencascade/GC_MakeLine2d.hxx
    klass = m.attr("GC_MakeLine2d");


    // nested enums

    static_cast<py::class_<GC_MakeLine2d , shared_ptr<GC_MakeLine2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2d & >()  , py::arg("theAxis") )
        .def(py::init<  const gp_Lin2d & >()  , py::arg("theLine") )
        .def(py::init<  const gp_Lin2d &, const double >()  , py::arg("theLine"),  py::arg("theDist") )
        .def(py::init<  const gp_Lin2d &, const gp_Pnt2d & >()  , py::arg("theLine"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt2d &, const gp_Dir2d & >()  , py::arg("thePoint"),  py::arg("theDir") )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Line> & (GC_MakeLine2d::*)() const) static_cast< const handle<Geom2d_Line> & (GC_MakeLine2d::*)() const>(&GC_MakeLine2d::Value),
             R"#(Returns the constructed line. Exceptions StdFail_NotDone if no line is constructed.)#"
             
         )
;

    // Class GC_MakeParabola2d from ./opencascade/GC_MakeParabola2d.hxx
    klass = m.attr("GC_MakeParabola2d");


    // nested enums

    static_cast<py::class_<GC_MakeParabola2d , shared_ptr<GC_MakeParabola2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax22d &, const double >()  , py::arg("theAxis"),  py::arg("theFocal") )
        .def(py::init<  const gp_Ax2d &, const double, const bool >()  , py::arg("theMirrorAxis"),  py::arg("theFocal"),  py::arg("theSense") )
        .def(py::init<  const gp_Ax2d &, const gp_Pnt2d &, const bool >()  , py::arg("theDirectrix"),  py::arg("theFocus"),  py::arg("theSense")=static_cast< const bool>(true) )
        .def(py::init<  const gp_Parab2d & >()  , py::arg("theParabola") )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theFocus"),  py::arg("theVertex") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_Parabola> & (GC_MakeParabola2d::*)() const) static_cast< const handle<Geom2d_Parabola> & (GC_MakeParabola2d::*)() const>(&GC_MakeParabola2d::Value),
             R"#(Returns the constructed parabola. Exceptions StdFail_NotDone if no parabola is constructed.)#"
             
         )
;

    // Class GC_MakePlane from ./opencascade/GC_MakePlane.hxx
    klass = m.attr("GC_MakePlane");


    // nested enums

    static_cast<py::class_<GC_MakePlane , shared_ptr<GC_MakePlane>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const double, const double, const double, const double >()  , py::arg("theA"),  py::arg("theB"),  py::arg("theC"),  py::arg("theD") )
        .def(py::init<  const gp_Ax1 & >()  , py::arg("theAxis") )
        .def(py::init<  const gp_Pln & >()  , py::arg("thePl") )
        .def(py::init<  const gp_Pln &, const double >()  , py::arg("thePln"),  py::arg("theDist") )
        .def(py::init<  const gp_Pln &, const gp_Pnt & >()  , py::arg("thePln"),  py::arg("thePoint") )
        .def(py::init<  const gp_Pnt &, const gp_Dir & >()  , py::arg("theP"),  py::arg("theV") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_Plane> & (GC_MakePlane::*)() const) static_cast< const handle<Geom_Plane> & (GC_MakePlane::*)() const>(&GC_MakePlane::Value),
             R"#(Returns the constructed plane. Exceptions StdFail_NotDone if no plane is constructed.)#"
             
         )
;

    // Class GC_MakeSegment from ./opencascade/GC_MakeSegment.hxx
    klass = m.attr("GC_MakeSegment");


    // nested enums

    static_cast<py::class_<GC_MakeSegment , shared_ptr<GC_MakeSegment>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Lin &, const double, const double >()  , py::arg("theLine"),  py::arg("theU1"),  py::arg("theU2") )
        .def(py::init<  const gp_Lin &, const gp_Pnt &, const double >()  , py::arg("theLine"),  py::arg("thePoint"),  py::arg("theUlast") )
        .def(py::init<  const gp_Lin &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theLine"),  py::arg("theP1"),  py::arg("theP2") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_TrimmedCurve> & (GC_MakeSegment::*)() const) static_cast< const handle<Geom_TrimmedCurve> & (GC_MakeSegment::*)() const>(&GC_MakeSegment::Value),
             R"#(Returns the constructed line segment.)#"
             
         )
;

    // Class GC_MakeSegment2d from ./opencascade/GC_MakeSegment2d.hxx
    klass = m.attr("GC_MakeSegment2d");


    // nested enums

    static_cast<py::class_<GC_MakeSegment2d , shared_ptr<GC_MakeSegment2d>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Lin2d &, const double, const double >()  , py::arg("theLine"),  py::arg("theU1"),  py::arg("theU2") )
        .def(py::init<  const gp_Lin2d &, const gp_Pnt2d &, const double >()  , py::arg("theLine"),  py::arg("thePoint"),  py::arg("theUlast") )
        .def(py::init<  const gp_Lin2d &, const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theLine"),  py::arg("theP1"),  py::arg("theP2") )
        .def(py::init<  const gp_Pnt2d &, const gp_Dir2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theV"),  py::arg("theP2") )
        .def(py::init<  const gp_Pnt2d &, const gp_Pnt2d & >()  , py::arg("theP1"),  py::arg("theP2") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom2d_TrimmedCurve> & (GC_MakeSegment2d::*)() const) static_cast< const handle<Geom2d_TrimmedCurve> & (GC_MakeSegment2d::*)() const>(&GC_MakeSegment2d::Value),
             R"#(Returns the constructed line segment. Exceptions StdFail_NotDone if no line segment is constructed.)#"
             
         )
;

    // Class GC_MakeTrimmedCone from ./opencascade/GC_MakeTrimmedCone.hxx
    klass = m.attr("GC_MakeTrimmedCone");


    // nested enums

    static_cast<py::class_<GC_MakeTrimmedCone , shared_ptr<GC_MakeTrimmedCone>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const double, const double >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theR1"),  py::arg("theR2") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3"),  py::arg("theP4") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_RectangularTrimmedSurface> & (GC_MakeTrimmedCone::*)() const) static_cast< const handle<Geom_RectangularTrimmedSurface> & (GC_MakeTrimmedCone::*)() const>(&GC_MakeTrimmedCone::Value),
             R"#(Returns the constructed trimmed cone. StdFail_NotDone if no trimmed cone is constructed.)#"
             
         )
;

    // Class GC_MakeTrimmedCylinder from ./opencascade/GC_MakeTrimmedCylinder.hxx
    klass = m.attr("GC_MakeTrimmedCylinder");


    // nested enums

    static_cast<py::class_<GC_MakeTrimmedCylinder , shared_ptr<GC_MakeTrimmedCylinder>  , GC_Root >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 &, const double, const double >()  , py::arg("theA1"),  py::arg("theRadius"),  py::arg("theHeight") )
        .def(py::init<  const gp_Circ &, const double >()  , py::arg("theCirc"),  py::arg("theHeight") )
        .def(py::init<  const gp_Pnt &, const gp_Pnt &, const gp_Pnt & >()  , py::arg("theP1"),  py::arg("theP2"),  py::arg("theP3") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Geom_RectangularTrimmedSurface> & (GC_MakeTrimmedCylinder::*)() const) static_cast< const handle<Geom_RectangularTrimmedSurface> & (GC_MakeTrimmedCylinder::*)() const>(&GC_MakeTrimmedCylinder::Value),
             R"#(Returns the constructed trimmed cylinder. Exceptions StdFail_NotDone if no trimmed cylinder is constructed.)#"
             
         )
;

// functions

// ./opencascade/GC_MakeArcOfCircle.hxx
// ./opencascade/GC_MakeArcOfCircle2d.hxx
// ./opencascade/GC_MakeArcOfEllipse.hxx
// ./opencascade/GC_MakeArcOfEllipse2d.hxx
// ./opencascade/GC_MakeArcOfHyperbola.hxx
// ./opencascade/GC_MakeArcOfHyperbola2d.hxx
// ./opencascade/GC_MakeArcOfParabola.hxx
// ./opencascade/GC_MakeArcOfParabola2d.hxx
// ./opencascade/GC_MakeCircle.hxx
// ./opencascade/GC_MakeCircle2d.hxx
// ./opencascade/GC_MakeConicalSurface.hxx
// ./opencascade/GC_MakeCylindricalSurface.hxx
// ./opencascade/GC_MakeEllipse.hxx
// ./opencascade/GC_MakeEllipse2d.hxx
// ./opencascade/GC_MakeHyperbola.hxx
// ./opencascade/GC_MakeHyperbola2d.hxx
// ./opencascade/GC_MakeLine.hxx
// ./opencascade/GC_MakeLine2d.hxx
// ./opencascade/GC_MakeMirror.hxx
// ./opencascade/GC_MakeMirror2d.hxx
// ./opencascade/GC_MakeParabola2d.hxx
// ./opencascade/GC_MakePlane.hxx
// ./opencascade/GC_MakeRotation.hxx
// ./opencascade/GC_MakeRotation2d.hxx
// ./opencascade/GC_MakeScale.hxx
// ./opencascade/GC_MakeScale2d.hxx
// ./opencascade/GC_MakeSegment.hxx
// ./opencascade/GC_MakeSegment2d.hxx
// ./opencascade/GC_MakeTranslation.hxx
// ./opencascade/GC_MakeTranslation2d.hxx
// ./opencascade/GC_MakeTrimmedCone.hxx
// ./opencascade/GC_MakeTrimmedCylinder.hxx
// ./opencascade/GC_Root.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
