
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cone.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Circ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Pnt.hxx>
#include <gp_Ax1.hxx>
#include <gp_Lin.hxx>
#include <gp_Dir.hxx>
#include <gp_Pln.hxx>
#include <gp_Ax2.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_Ax2d.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Dir2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Lin.hxx>
#include <gp_Ax1.hxx>
#include <gp_Pnt.hxx>
#include <gp_Dir.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Transformation.hxx>
#include <gp_Vec.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Transformation.hxx>
#include <gp_Vec2d.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <gp_Ax1.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <GC_MakeArcOfCircle.hxx>
#include <GC_MakeArcOfCircle2d.hxx>
#include <GC_MakeArcOfEllipse.hxx>
#include <GC_MakeArcOfEllipse2d.hxx>
#include <GC_MakeArcOfHyperbola.hxx>
#include <GC_MakeArcOfHyperbola2d.hxx>
#include <GC_MakeArcOfParabola.hxx>
#include <GC_MakeArcOfParabola2d.hxx>
#include <GC_MakeCircle.hxx>
#include <GC_MakeCircle2d.hxx>
#include <GC_MakeConicalSurface.hxx>
#include <GC_MakeCylindricalSurface.hxx>
#include <GC_MakeEllipse.hxx>
#include <GC_MakeEllipse2d.hxx>
#include <GC_MakeHyperbola.hxx>
#include <GC_MakeHyperbola2d.hxx>
#include <GC_MakeLine.hxx>
#include <GC_MakeLine2d.hxx>
#include <GC_MakeMirror.hxx>
#include <GC_MakeMirror2d.hxx>
#include <GC_MakeParabola2d.hxx>
#include <GC_MakePlane.hxx>
#include <GC_MakeRotation.hxx>
#include <GC_MakeRotation2d.hxx>
#include <GC_MakeScale.hxx>
#include <GC_MakeScale2d.hxx>
#include <GC_MakeSegment.hxx>
#include <GC_MakeSegment2d.hxx>
#include <GC_MakeTranslation.hxx>
#include <GC_MakeTranslation2d.hxx>
#include <GC_MakeTrimmedCone.hxx>
#include <GC_MakeTrimmedCylinder.hxx>
#include <GC_Root.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GC_enums(py::module &main_module) {


py::module m = main_module.def_submodule("GC", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<GC_MakeMirror , shared_ptr<GC_MakeMirror>  >(
      m,
      "GC_MakeMirror",R"#(This class implements elementary construction algorithms for a symmetrical transformation in 3D space about a point, axis or plane. The result is a Geom_Transformation transformation. A MakeMirror object provides a framework for: - defining the construction of the transformation, - implementing the construction algorithm, and - consulting the result.)#"
    );
    py::class_<GC_MakeMirror2d , shared_ptr<GC_MakeMirror2d>  >(
      m,
      "GC_MakeMirror2d",R"#(This class implements elementary construction algorithms for symmetric transformations in 2D space about a point, axis, or line. The result is a `Geom2d_Transformation`. A `GC_MakeMirror2d` object provides a framework for: - defining the transformation parameters; - running the construction algorithm; - querying the resulting transformation via `Value()`.)#"
    );
    py::class_<GC_MakeRotation , shared_ptr<GC_MakeRotation>  >(
      m,
      "GC_MakeRotation",R"#(This class implements elementary construction algorithms for a rotation in 3D space. The result is a Geom_Transformation transformation. A MakeRotation object provides a framework for: - defining the construction of the transformation, - implementing the construction algorithm, and - consulting the result.)#"
    );
    py::class_<GC_MakeRotation2d , shared_ptr<GC_MakeRotation2d>  >(
      m,
      "GC_MakeRotation2d",R"#(This class implements elementary construction algorithms for rotations in 2D space. The result is a `Geom2d_Transformation`. A `GC_MakeRotation2d` object provides a framework for: - defining the transformation parameters; - running the construction algorithm; - querying the resulting transformation via `Value()`.)#"
    );
    py::class_<GC_MakeScale , shared_ptr<GC_MakeScale>  >(
      m,
      "GC_MakeScale",R"#(Implements construction of a scaling transformation in 3D space. The result is a `Geom_Transformation` centered at `Point` with scale factor `Scale`. A MakeScale object provides a framework for: - defining the construction of the transformation, - implementing the construction algorithm, and - consulting the result.)#"
    );
    py::class_<GC_MakeScale2d , shared_ptr<GC_MakeScale2d>  >(
      m,
      "GC_MakeScale2d",R"#(This class implements elementary construction algorithms for scaling transformations in 2D space. The result is a `Geom2d_Transformation`. A `GC_MakeScale2d` object provides a framework for: - defining the transformation parameters; - running the construction algorithm; - querying the resulting transformation via `Value()`.)#"
    );
    py::class_<GC_MakeTranslation , shared_ptr<GC_MakeTranslation>  >(
      m,
      "GC_MakeTranslation",R"#(This class implements elementary construction algorithms for a translation in 3D space. The result is a Geom_Transformation transformation. A MakeTranslation object provides a framework for: - defining the construction of the transformation, - implementing the construction algorithm, and - consulting the result.)#"
    );
    py::class_<GC_MakeTranslation2d , shared_ptr<GC_MakeTranslation2d>  >(
      m,
      "GC_MakeTranslation2d",R"#(This class implements elementary construction algorithms for translations in 2D space. The result is a `Geom2d_Transformation`. A `GC_MakeTranslation2d` object provides a framework for: - defining the transformation parameters; - running the construction algorithm; - querying the resulting transformation via `Value()`.)#"
    );
    py::class_<GC_Root , shared_ptr<GC_Root>  >(
      m,
      "GC_Root",R"#(Provides common status services for GC builders reporting construction errors.)#"
    );
    py::class_<GC_MakeArcOfCircle , shared_ptr<GC_MakeArcOfCircle>  , GC_Root >(
      m,
      "GC_MakeArcOfCircle",R"#(Implements construction algorithms for an arc of circle in 3D space. The result is a Geom_TrimmedCurve curve. A MakeArcOfCircle object provides a framework for: - defining the construction of the arc of circle, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed arc of circle.)#"
    );
    py::class_<GC_MakeArcOfCircle2d , shared_ptr<GC_MakeArcOfCircle2d>  , GC_Root >(
      m,
      "GC_MakeArcOfCircle2d",R"#(This class implements construction algorithms for arcs of circles in the plane. The result is a `Geom2d_TrimmedCurve`. A `GC_MakeArcOfCircle2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting arc via `Value()`.)#"
    );
    py::class_<GC_MakeArcOfEllipse , shared_ptr<GC_MakeArcOfEllipse>  , GC_Root >(
      m,
      "GC_MakeArcOfEllipse",R"#(Implements construction algorithms for ellipse arcs in 3D space. The result is a `Geom_TrimmedCurve`. A MakeArcOfEllipse object provides a framework for: - defining the construction of the arc of ellipse, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed arc of ellipse.)#"
    );
    py::class_<GC_MakeArcOfEllipse2d , shared_ptr<GC_MakeArcOfEllipse2d>  , GC_Root >(
      m,
      "GC_MakeArcOfEllipse2d",R"#(This class implements construction algorithms for arcs of ellipses in the plane. The result is a `Geom2d_TrimmedCurve`. A `GC_MakeArcOfEllipse2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting arc via `Value()`.)#"
    );
    py::class_<GC_MakeArcOfHyperbola , shared_ptr<GC_MakeArcOfHyperbola>  , GC_Root >(
      m,
      "GC_MakeArcOfHyperbola",R"#(Implements construction algorithms for hyperbola arcs in 3D space. The result is a `Geom_TrimmedCurve`. A MakeArcOfHyperbola object provides a framework for: - defining the construction of the arc of hyperbola, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed arc of hyperbola.)#"
    );
    py::class_<GC_MakeArcOfHyperbola2d , shared_ptr<GC_MakeArcOfHyperbola2d>  , GC_Root >(
      m,
      "GC_MakeArcOfHyperbola2d",R"#(This class implements construction algorithms for arcs of hyperbolas in the plane. The result is a `Geom2d_TrimmedCurve`. A `GC_MakeArcOfHyperbola2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting arc via `Value()`.)#"
    );
    py::class_<GC_MakeArcOfParabola , shared_ptr<GC_MakeArcOfParabola>  , GC_Root >(
      m,
      "GC_MakeArcOfParabola",R"#(Implements construction algorithms for parabola arcs in 3D space. The result is a `Geom_TrimmedCurve`. A MakeArcOfParabola object provides a framework for: - defining the construction of the arc of parabola, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed arc of parabola.)#"
    );
    py::class_<GC_MakeArcOfParabola2d , shared_ptr<GC_MakeArcOfParabola2d>  , GC_Root >(
      m,
      "GC_MakeArcOfParabola2d",R"#(This class implements construction algorithms for arcs of parabolas in the plane. The result is a `Geom2d_TrimmedCurve`. A `GC_MakeArcOfParabola2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting arc via `Value()`.)#"
    );
    py::class_<GC_MakeCircle , shared_ptr<GC_MakeCircle>  , GC_Root >(
      m,
      "GC_MakeCircle",R"#(Implements construction algorithms for circles in 3D space.)#"
    );
    py::class_<GC_MakeCircle2d , shared_ptr<GC_MakeCircle2d>  , GC_Root >(
      m,
      "GC_MakeCircle2d",R"#(This class implements construction algorithms for circles in the plane. The result is a `Geom2d_Circle`. A `GC_MakeCircle2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting circle via `Value()`.)#"
    );
    py::class_<GC_MakeConicalSurface , shared_ptr<GC_MakeConicalSurface>  , GC_Root >(
      m,
      "GC_MakeConicalSurface",R"#(Implements construction algorithms for conical surfaces. Supported constructions include: - a conical surface from axis placement and angle/radius; - conversion from `gp_Cone`; - a conical surface through four points; - a conical surface from two points and two radii. The local coordinate system of the ConicalSurface is defined with an axis placement (see class ElementarySurface).)#"
    );
    py::class_<GC_MakeCylindricalSurface , shared_ptr<GC_MakeCylindricalSurface>  , GC_Root >(
      m,
      "GC_MakeCylindricalSurface",R"#(Implements construction algorithms for cylindrical surfaces. Supported constructions include: - a cylindrical surface from axis placement and radius; - conversion from `gp_Cylinder`; - an offset/parallel cylindrical surface; - a cylindrical surface through three points; - a cylindrical surface from axis and radius; - a cylindrical surface from circular base. The local coordinate system of the CylindricalSurface is defined with an axis placement (see class ElementarySurface).)#"
    );
    py::class_<GC_MakeEllipse , shared_ptr<GC_MakeEllipse>  , GC_Root >(
      m,
      "GC_MakeEllipse",R"#(Implements construction algorithms for ellipses in 3D space. The result is a `Geom_Ellipse`. A MakeEllipse object provides a framework for: - defining the construction of the ellipse, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed ellipse.)#"
    );
    py::class_<GC_MakeEllipse2d , shared_ptr<GC_MakeEllipse2d>  , GC_Root >(
      m,
      "GC_MakeEllipse2d",R"#(This class implements construction algorithms for ellipses in the plane. The result is a `Geom2d_Ellipse`. A `GC_MakeEllipse2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting ellipse via `Value()`.)#"
    );
    py::class_<GC_MakeHyperbola , shared_ptr<GC_MakeHyperbola>  , GC_Root >(
      m,
      "GC_MakeHyperbola",R"#(Implements construction algorithms for hyperbolas in 3D space. The result is a `Geom_Hyperbola`. A MakeHyperbola object provides a framework for: - defining the construction of the hyperbola, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed hyperbola. To define the main branch of a hyperbola. The parameterization range is ]-infinite,+infinite[ It is possible to get the other branch and the two conjugate branches of the main branch.)#"
    );
    py::class_<GC_MakeHyperbola2d , shared_ptr<GC_MakeHyperbola2d>  , GC_Root >(
      m,
      "GC_MakeHyperbola2d",R"#(This class implements construction algorithms for hyperbolas in the plane. The result is a `Geom2d_Hyperbola` (main branch). A `GC_MakeHyperbola2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting hyperbola via `Value()`.)#"
    );
    py::class_<GC_MakeLine , shared_ptr<GC_MakeLine>  , GC_Root >(
      m,
      "GC_MakeLine",R"#(This class implements the following algorithms used to create a Line from Geom. * Create a Line parallel to another and passing through a point. * Create a Line passing through 2 points. A MakeLine object provides a framework for: - defining the construction of the line, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed line.)#"
    );
    py::class_<GC_MakeLine2d , shared_ptr<GC_MakeLine2d>  , GC_Root >(
      m,
      "GC_MakeLine2d",R"#(This class implements construction algorithms for lines in the plane. The result is a `Geom2d_Line`. A `GC_MakeLine2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting line via `Value()`. Supported constructions include: - line from axis placement; - line from existing `gp_Lin2d`; - line from point and direction; - line parallel to input line through a point; - line parallel to input line at signed distance; - line through two points.)#"
    );
    py::class_<GC_MakeParabola2d , shared_ptr<GC_MakeParabola2d>  , GC_Root >(
      m,
      "GC_MakeParabola2d",R"#(This class implements construction algorithms for parabolas in the plane. The result is a `Geom2d_Parabola`. A `GC_MakeParabola2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting parabola via `Value()`.)#"
    );
    py::class_<GC_MakePlane , shared_ptr<GC_MakePlane>  , GC_Root >(
      m,
      "GC_MakePlane",R"#(Implements construction algorithms for planes in 3D space. Supported constructions include: - a plane parallel to another plane and passing through a point; - a plane passing through three points; - a plane defined by a point and normal direction. A MakePlane object provides a framework for: - defining the construction of the plane, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed plane.)#"
    );
    py::class_<GC_MakeSegment , shared_ptr<GC_MakeSegment>  , GC_Root >(
      m,
      "GC_MakeSegment",R"#(Implements construction algorithms for line segments in 3D space. The result is a `Geom_TrimmedCurve`. A `GC_MakeSegment` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and resulting segment via `Value()`.)#"
    );
    py::class_<GC_MakeSegment2d , shared_ptr<GC_MakeSegment2d>  , GC_Root >(
      m,
      "GC_MakeSegment2d",R"#(This class implements construction algorithms for line segments in the plane. The result is a `Geom2d_TrimmedCurve`. A `GC_MakeSegment2d` object provides a framework for: - defining the construction parameters; - running the construction algorithm; - querying the construction status and the resulting segment via `Value()`.)#"
    );
    py::class_<GC_MakeTrimmedCone , shared_ptr<GC_MakeTrimmedCone>  , GC_Root >(
      m,
      "GC_MakeTrimmedCone",R"#(Implements construction algorithms for trimmed cones. The result is a `Geom_RectangularTrimmedSurface`. A MakeTrimmedCone provides a framework for: - defining the construction of the trimmed cone, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed trimmed cone.)#"
    );
    py::class_<GC_MakeTrimmedCylinder , shared_ptr<GC_MakeTrimmedCylinder>  , GC_Root >(
      m,
      "GC_MakeTrimmedCylinder",R"#(Implements construction algorithms for trimmed cylinders. The result is a `Geom_RectangularTrimmedSurface`. A MakeTrimmedCylinder provides a framework for: - defining the construction of the trimmed cylinder, - implementing the construction algorithm, and - consulting the results. In particular, the Value function returns the constructed trimmed cylinder.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
