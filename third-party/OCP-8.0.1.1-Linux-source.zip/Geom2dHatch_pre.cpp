
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2dHatch_Elements.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Geom2dHatch_Classifier.hxx>
#include <Geom2dHatch_Element.hxx>
#include <Geom2dHatch_Elements.hxx>
#include <Geom2dHatch_FClass2dOfClassifier.hxx>
#include <Geom2dHatch_Hatcher.hxx>
#include <Geom2dHatch_Hatching.hxx>
#include <Geom2dHatch_Intersector.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Geom2dHatch_enums(py::module &main_module) {


py::module m = main_module.def_submodule("Geom2dHatch", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<Geom2dHatch_Classifier , shared_ptr<Geom2dHatch_Classifier>  >(
      m,
      "Geom2dHatch_Classifier",R"#()#"
    );
    py::class_<Geom2dHatch_Element , shared_ptr<Geom2dHatch_Element>  >(
      m,
      "Geom2dHatch_Element",R"#()#"
    );
    py::class_<Geom2dHatch_Elements , shared_ptr<Geom2dHatch_Elements>  >(
      m,
      "Geom2dHatch_Elements",R"#()#"
    );
    py::class_<Geom2dHatch_FClass2dOfClassifier , shared_ptr<Geom2dHatch_FClass2dOfClassifier>  >(
      m,
      "Geom2dHatch_FClass2dOfClassifier",R"#()#"
    );
    py::class_<Geom2dHatch_Hatcher , shared_ptr<Geom2dHatch_Hatcher>  >(
      m,
      "Geom2dHatch_Hatcher",R"#()#"
    );
    py::class_<Geom2dHatch_Hatching , shared_ptr<Geom2dHatch_Hatching>  >(
      m,
      "Geom2dHatch_Hatching",R"#()#"
    );
    py::class_<Geom2dHatch_Intersector , shared_ptr<Geom2dHatch_Intersector>  , Geom2dInt_GInter >(
      m,
      "Geom2dHatch_Intersector",R"#()#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
