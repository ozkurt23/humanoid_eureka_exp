
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>
#include <Geom2dInt_TheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>
#include <Geom2dInt_IntConicCurveOfGInter.hxx>
#include <Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>
#include <Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>
#include <Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IntCurve_IConicTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>
#include <Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter.hxx>
#include <IntRes2d_Domain.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <IntRes2d_Domain.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_Geom2dCurveTool.hxx>
#include <Geom2dInt_GInter.hxx>
#include <Geom2dInt_IntConicCurveOfGInter.hxx>
#include <Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter.hxx>
#include <Geom2dInt_PCLocFOfTheLocateExtPCOfTheProjPCurOfGInter.hxx>
#include <Geom2dInt_TheCurveLocatorOfTheProjPCurOfGInter.hxx>
#include <Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_TheIntConicCurveOfGInter.hxx>
#include <Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter.hxx>
#include <Geom2dInt_TheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_TheLocateExtPCOfTheProjPCurOfGInter.hxx>
#include <Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx>
#include <Geom2dInt_TheProjPCurOfGInter.hxx>

// template related includes

// ./opencascade/Geom2dInt_PCLocFOfTheLocateExtPCOfTheProjPCurOfGInter.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Geom2dInt_TheCurveLocatorOfTheProjPCurOfGInter.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Geom2dInt_TheLocateExtPCOfTheProjPCurOfGInter.hxx
#include "Extrema_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Geom2dInt(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Geom2dInt"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter from ./opencascade/Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter , shared_ptr<Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter>  >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::Perform),
             R"#()#"  , py::arg("Uo"),  py::arg("Vo"),  py::arg("UInf"),  py::arg("VInf"),  py::arg("USup"),  py::arg("VSup")
          )
        .def("NbRoots",
             (int (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<int (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::NbRoots),
             R"#()#" 
          )
        .def("AnErrorOccurred",
             (bool (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<bool (Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter::AnErrorOccurred),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Perform",
             []( Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter &self ,  const Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter & Poly1, const Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter & Poly2 ){
                 int  NumSegOn1;
                int  NumSegOn2;
                double  ParamOnSeg1;
                double  ParamOnSeg2;

                 self.Perform(Poly1,Poly2,NumSegOn1,NumSegOn2,ParamOnSeg1,ParamOnSeg2);
                 return std::make_tuple(NumSegOn1,NumSegOn2,ParamOnSeg1,ParamOnSeg2); },
             R"#()#"  , py::arg("Poly1"),  py::arg("Poly2")
          )
        .def("Roots",
             []( Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter &self   ){
                 double  U;
                double  V;

                 self.Roots(U,V);
                 return std::make_tuple(U,V); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_GInter from ./opencascade/Geom2dInt_GInter.hxx
    klass = m.attr("Geom2dInt_GInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_GInter , shared_ptr<Geom2dInt_GInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const double, const double >()  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("C"),  py::arg("D"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const Adaptor2d_Curve2d &, const double, const double >()  , py::arg("C"),  py::arg("TolConf"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const Adaptor2d_Curve2d & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const Adaptor2d_Curve2d & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("D1"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("D1"),  py::arg("C2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_GInter::Perform),
             R"#(Intersection between 2 curves.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("ComputeDomain",
             (IntRes2d_Domain (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const double  ) const) static_cast<IntRes2d_Domain (Geom2dInt_GInter::*)(  const Adaptor2d_Curve2d & ,   const double  ) const>(&Geom2dInt_GInter::ComputeDomain),
             R"#(Create a domain from a curve)#"  , py::arg("C1"),  py::arg("TolDomain")
          )
        .def("SetMinNbSamples",
             (void (Geom2dInt_GInter::*)(  const int  ) ) static_cast<void (Geom2dInt_GInter::*)(  const int  ) >(&Geom2dInt_GInter::SetMinNbSamples),
             R"#(Set / get minimum number of points in polygon intersection.)#"  , py::arg("theMinNbSamples")
          )
        .def("GetMinNbSamples",
             (int (Geom2dInt_GInter::*)() const) static_cast<int (Geom2dInt_GInter::*)() const>(&Geom2dInt_GInter::GetMinNbSamples),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_Geom2dCurveTool from ./opencascade/Geom2dInt_Geom2dCurveTool.hxx
    klass = m.attr("Geom2dInt_Geom2dCurveTool");

    // default constructor
    register_default_constructor<Geom2dInt_Geom2dCurveTool , shared_ptr<Geom2dInt_Geom2dCurveTool>>(m,"Geom2dInt_Geom2dCurveTool");

    // nested enums

    static_cast<py::class_<Geom2dInt_Geom2dCurveTool , shared_ptr<Geom2dInt_Geom2dCurveTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<GeomAbs_CurveType (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::GetType),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Line_s",
                    (gp_Lin2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Lin2d (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Line),
                    R"#(Returns the Lin2d from gp corresponding to the curve C. This method is called only when TheType returns GeomAbs_Line.)#"  , py::arg("C")
          )
        .def_static("Circle_s",
                    (gp_Circ2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Circ2d (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Circle),
                    R"#(Returns the Circ2d from gp corresponding to the curve C. This method is called only when TheType returns GeomAbs_Circle.)#"  , py::arg("C")
          )
        .def_static("Ellipse_s",
                    (gp_Elips2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Elips2d (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Ellipse),
                    R"#(Returns the Elips2d from gp corresponding to the curve C. This method is called only when TheType returns GeomAbs_Ellipse.)#"  , py::arg("C")
          )
        .def_static("Parabola_s",
                    (gp_Parab2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Parab2d (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Parabola),
                    R"#(Returns the Parab2d from gp corresponding to the curve C. This method is called only when TheType returns GeomAbs_Parabola.)#"  , py::arg("C")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Hypr2d (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Hyperbola),
                    R"#(Returns the Hypr2d from gp corresponding to the curve C. This method is called only when TheType returns GeomAbs_Hyperbola.)#"  , py::arg("C")
          )
        .def_static("EpsX_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::EpsX),
                    R"#()#"  , py::arg("C")
          )
        .def_static("EpsX_s",
                    (double (*)(  const Adaptor2d_Curve2d & ,   const double  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d & ,   const double  ) >(&Geom2dInt_Geom2dCurveTool::EpsX),
                    R"#()#"  , py::arg("C"),  py::arg("Eps_XYZ")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::NbSamples),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) >(&Geom2dInt_Geom2dCurveTool::NbSamples),
                    R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1")
          )
        .def_static("FirstParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::FirstParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::LastParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Value_s",
                    (gp_Pnt2d (*)(  const Adaptor2d_Curve2d & ,   const double  ) ) static_cast<gp_Pnt2d (*)(  const Adaptor2d_Curve2d & ,   const double  ) >(&Geom2dInt_Geom2dCurveTool::Value),
                    R"#()#"  , py::arg("C"),  py::arg("X")
          )
        .def_static("D0_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d &  ) >(&Geom2dInt_Geom2dCurveTool::D0),
                    R"#()#"  , py::arg("C"),  py::arg("U"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) >(&Geom2dInt_Geom2dCurveTool::D1),
                    R"#()#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("T")
          )
        .def_static("D2_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Geom2dInt_Geom2dCurveTool::D2),
                    R"#()#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("T"),  py::arg("N")
          )
        .def_static("D3_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Geom2dInt_Geom2dCurveTool::D3),
                    R"#()#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("T"),  py::arg("N"),  py::arg("V")
          )
        .def_static("DN_s",
                    (gp_Vec2d (*)(  const Adaptor2d_Curve2d & ,   const double ,   const int  ) ) static_cast<gp_Vec2d (*)(  const Adaptor2d_Curve2d & ,   const double ,   const int  ) >(&Geom2dInt_Geom2dCurveTool::DN),
                    R"#()#"  , py::arg("C"),  py::arg("U"),  py::arg("N")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::NbIntervals),
                    R"#(output the number of interval of continuity C2 of the curve)#"  , py::arg("C")
          )
        .def_static("Intervals_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,  NCollection_Array1<double> &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,  NCollection_Array1<double> &  ) >(&Geom2dInt_Geom2dCurveTool::Intervals),
                    R"#(compute Tab.)#"  , py::arg("C"),  py::arg("Tab")
          )
        .def_static("Degree_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Geom2dInt_Geom2dCurveTool::Degree),
                    R"#()#"  , py::arg("C")
          )
    // static methods using call by reference i.s.o. return
        .def_static("GetInterval_s",
            []( const Adaptor2d_Curve2d & C, const int Index, const NCollection_Array1<double> & Tab ){
                double  U1;
                double  U2;

                Geom2dInt_Geom2dCurveTool::GetInterval(C,Index,Tab,U1,U2);
                
return std::make_tuple(U1,U2); },
            R"#(output the bounds of interval of index <Index> used if Type == Composite.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("Tab")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_IntConicCurveOfGInter from ./opencascade/Geom2dInt_IntConicCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_IntConicCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_IntConicCurveOfGInter , shared_ptr<Geom2dInt_IntConicCurveOfGInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("C"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Elips2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("E"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Hypr2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("H"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Lin2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("L"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Parab2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("Prb"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Lin2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Lin2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_IntConicCurveOfGInter::Perform),
             R"#(Intersection between a line and a parametric curve.)#"  , py::arg("L"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Circ2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Circ2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_IntConicCurveOfGInter::Perform),
             R"#(Intersection between a line and a parametric curve.)#"  , py::arg("C"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Elips2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Elips2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_IntConicCurveOfGInter::Perform),
             R"#(Intersection between an ellipse and a parametric curve.)#"  , py::arg("E"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Parab2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Parab2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_IntConicCurveOfGInter::Perform),
             R"#(Intersection between a parabola and a parametric curve.)#"  , py::arg("Prb"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Hypr2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_IntConicCurveOfGInter::*)(  const gp_Hypr2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_IntConicCurveOfGInter::Perform),
             R"#(Intersection between the main branch of an hyperbola and a parametric curve.)#"  , py::arg("H"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter from ./opencascade/Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter , shared_ptr<Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init<  const IntCurve_IConicTool &, const Adaptor2d_Curve2d & >()  , py::arg("IT"),  py::arg("PC") )
    // custom constructors
    // methods
        .def("Value",
             (bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double &  ) ) static_cast<bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double &  ) >(&Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::Value),
             R"#(Computes the value of the signed distance between the implicit curve and the point at parameter Param on the parametrised curve.)#"  , py::arg("Param"),  py::arg("F")
          )
        .def("Derivative",
             (bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double &  ) ) static_cast<bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double &  ) >(&Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::Derivative),
             R"#(Computes the derivative of the previous function at parameter Param.)#"  , py::arg("Param"),  py::arg("D")
          )
        .def("Values",
             (bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  double & ,  double &  ) >(&Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter::Values),
             R"#(Computes the value and the derivative of the function.)#"  , py::arg("Param"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter from ./opencascade/Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter , shared_ptr<Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d & >()  , py::arg("curve1"),  py::arg("curve2") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<int (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::NbVariables),
             R"#(returns 2.)#" 
          )
        .def("NbEquations",
             (int (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<int (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::NbEquations),
             R"#(returns 2.)#" 
          )
        .def("Value",
             (bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Vector &  ) >(&Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::Value),
             R"#(computes the values <F> of the Functions for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Matrix &  ) >(&Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::Derivatives),
             R"#(returns the values <D> of the derivatives for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter::Values),
             R"#(returns the values <F> of the functions and the derivatives <D> for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_TheIntConicCurveOfGInter from ./opencascade/Geom2dInt_TheIntConicCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_TheIntConicCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_TheIntConicCurveOfGInter , shared_ptr<Geom2dInt_TheIntConicCurveOfGInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("C"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Elips2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("E"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Hypr2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("H"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Lin2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("L"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
        .def(py::init<  const gp_Parab2d &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("Prb"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Lin2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Lin2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntConicCurveOfGInter::Perform),
             R"#(Intersection between a line and a parametric curve.)#"  , py::arg("L"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Circ2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Circ2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntConicCurveOfGInter::Perform),
             R"#(Intersection between a line and a parametric curve.)#"  , py::arg("C"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Elips2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Elips2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntConicCurveOfGInter::Perform),
             R"#(Intersection between an ellipse and a parametric curve.)#"  , py::arg("E"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Parab2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Parab2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntConicCurveOfGInter::Perform),
             R"#(Intersection between a parabola and a parametric curve.)#"  , py::arg("Prb"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Hypr2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntConicCurveOfGInter::*)(  const gp_Hypr2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntConicCurveOfGInter::Perform),
             R"#(Intersection between the main branch of an hyperbola and a parametric curve.)#"  , py::arg("H"),  py::arg("D1"),  py::arg("PCurve"),  py::arg("D2"),  py::arg("TolConf"),  py::arg("Tol")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_TheIntPCurvePCurveOfGInter from ./opencascade/Geom2dInt_TheIntPCurvePCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_TheIntPCurvePCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_TheIntPCurvePCurveOfGInter , shared_ptr<Geom2dInt_TheIntPCurvePCurveOfGInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntPCurvePCurveOfGInter::Perform),
             R"#()#"  , py::arg("Curve1"),  py::arg("Domain1"),  py::arg("Curve2"),  py::arg("Domain2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntPCurvePCurveOfGInter::Perform),
             R"#()#"  , py::arg("Curve1"),  py::arg("Domain1"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("SetMinNbSamples",
             (void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const int  ) ) static_cast<void (Geom2dInt_TheIntPCurvePCurveOfGInter::*)(  const int  ) >(&Geom2dInt_TheIntPCurvePCurveOfGInter::SetMinNbSamples),
             R"#(Set / get minimum number of points in polygon for intersection.)#"  , py::arg("theMinNbSamples")
          )
        .def("GetMinNbSamples",
             (int (Geom2dInt_TheIntPCurvePCurveOfGInter::*)() const) static_cast<int (Geom2dInt_TheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_TheIntPCurvePCurveOfGInter::GetMinNbSamples),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter from ./opencascade/Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter , shared_ptr<Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const IntCurve_IConicTool &, const IntRes2d_Domain &, const Adaptor2d_Curve2d &, const IntRes2d_Domain &, const double, const double >()  , py::arg("ITool"),  py::arg("Dom1"),  py::arg("PCurve"),  py::arg("Dom2"),  py::arg("TolConf"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const IntCurve_IConicTool & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) ) static_cast<void (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const IntCurve_IConicTool & ,   const IntRes2d_Domain & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double  ) >(&Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::Perform),
             R"#(Intersection between an implicit curve and a parametrised curve. The exception ConstructionError is raised if the domain of the parametrised curve does not verify HasFirstPoint and HasLastPoint return True.)#"  , py::arg("ITool"),  py::arg("Dom1"),  py::arg("PCurve"),  py::arg("Dom2"),  py::arg("TolConf"),  py::arg("Tol")
          )
        .def("FindU",
             (double (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  gp_Pnt2d & ,   const Adaptor2d_Curve2d & ,   const IntCurve_IConicTool &  ) const) static_cast<double (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  gp_Pnt2d & ,   const Adaptor2d_Curve2d & ,   const IntCurve_IConicTool &  ) const>(&Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::FindU),
             R"#()#"  , py::arg("parameter"),  py::arg("point"),  py::arg("TheParCurev"),  py::arg("TheImpTool")
          )
        .def("FindV",
             (double (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  gp_Pnt2d & ,   const IntCurve_IConicTool & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double ,   const double  ) const) static_cast<double (Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::*)(  const double ,  gp_Pnt2d & ,   const IntCurve_IConicTool & ,   const Adaptor2d_Curve2d & ,   const IntRes2d_Domain & ,   const double ,   const double ,   const double  ) const>(&Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter::FindV),
             R"#()#"  , py::arg("parameter"),  py::arg("point"),  py::arg("TheImpTool"),  py::arg("ParCurve"),  py::arg("TheParCurveDomain"),  py::arg("V0"),  py::arg("V1"),  py::arg("Tolerance")
          )
    // methods using call by reference i.s.o. return
        .def("And_Domaine_Objet1_Intersections",
             []( Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter &self ,  const IntCurve_IConicTool & TheImpTool, const Adaptor2d_Curve2d & TheParCurve, const IntRes2d_Domain & TheImpCurveDomain, const IntRes2d_Domain & TheParCurveDomain,NCollection_Array1<double> & Inter2_And_Domain2,NCollection_Array1<double> & Inter1,NCollection_Array1<double> & Resultat1,NCollection_Array1<double> & Resultat2, const double EpsNul ){
                 int  NbResultats;

                 self.And_Domaine_Objet1_Intersections(TheImpTool,TheParCurve,TheImpCurveDomain,TheParCurveDomain,NbResultats,Inter2_And_Domain2,Inter1,Resultat1,Resultat2,EpsNul);
                 return std::make_tuple(NbResultats); },
             R"#()#"  , py::arg("TheImpTool"),  py::arg("TheParCurve"),  py::arg("TheImpCurveDomain"),  py::arg("TheParCurveDomain"),  py::arg("Inter2_And_Domain2"),  py::arg("Inter1"),  py::arg("Resultat1"),  py::arg("Resultat2"),  py::arg("EpsNul")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter from ./opencascade/Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx
    klass = m.attr("Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter");


    // nested enums

    static_cast<py::class_<Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter , shared_ptr<Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter>  , Intf_Polygon2d >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const int, const IntRes2d_Domain &, const double >()  , py::arg("Curve"),  py::arg("NbPnt"),  py::arg("Domain"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("ComputeWithBox",
             (void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const Bnd_Box2d &  ) ) static_cast<void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const Adaptor2d_Curve2d & ,   const Bnd_Box2d &  ) >(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::ComputeWithBox),
             R"#(The current polygon is modified if most of the points of the polygon are outside the box <OtherBox>. In this situation, bounds are computed to build a polygon inside or near the OtherBox.)#"  , py::arg("Curve"),  py::arg("OtherBox")
          )
        .def("DeflectionOverEstimation",
             (double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::DeflectionOverEstimation),
             R"#()#" 
          )
        .def("SetDeflectionOverEstimation",
             (void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const double  ) ) static_cast<void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const double  ) >(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::SetDeflectionOverEstimation),
             R"#()#"  , py::arg("x")
          )
        .def("Closed",
             (void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const bool  ) ) static_cast<void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const bool  ) >(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::Closed),
             R"#()#"  , py::arg("clos")
          )
        .def("Closed",
             (bool (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<bool (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::Closed),
             R"#(Returns True if the polyline is closed.)#" 
          )
        .def("NbSegments",
             (int (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<int (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::NbSegments),
             R"#(Give the number of Segments in the polyline.)#" 
          )
        .def("Segment",
             (void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const) static_cast<void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::Segment),
             R"#(Returns the points of the segment <Index> in the Polygon.)#"  , py::arg("theIndex"),  py::arg("theBegin"),  py::arg("theEnd")
          )
        .def("InfParameter",
             (double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::InfParameter),
             R"#(Returns the parameter (On the curve) of the first point of the Polygon)#" 
          )
        .def("SupParameter",
             (double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::SupParameter),
             R"#(Returns the parameter (On the curve) of the last point of the Polygon)#" 
          )
        .def("AutoIntersectionIsPossible",
             (bool (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<bool (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::AutoIntersectionIsPossible),
             R"#()#" 
          )
        .def("ApproxParamOnCurve",
             (double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const int ,   const double  ) const) static_cast<double (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const int ,   const double  ) const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::ApproxParamOnCurve),
             R"#(Give an approximation of the parameter on the curve according to the discretization of the Curve.)#"  , py::arg("Index"),  py::arg("ParamOnLine")
          )
        .def("CalculRegion",
             (int (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) const) static_cast<int (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::CalculRegion),
             R"#()#"  , py::arg("x"),  py::arg("y"),  py::arg("x1"),  py::arg("x2"),  py::arg("y1"),  py::arg("y2")
          )
        .def("Dump",
             (void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const) static_cast<void (Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::*)() const>(&Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter::Dump),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Geom2dInt_TheProjPCurOfGInter from ./opencascade/Geom2dInt_TheProjPCurOfGInter.hxx
    klass = m.attr("Geom2dInt_TheProjPCurOfGInter");

    // default constructor
    register_default_constructor<Geom2dInt_TheProjPCurOfGInter , shared_ptr<Geom2dInt_TheProjPCurOfGInter>>(m,"Geom2dInt_TheProjPCurOfGInter");

    // nested enums

    static_cast<py::class_<Geom2dInt_TheProjPCurOfGInter , shared_ptr<Geom2dInt_TheProjPCurOfGInter>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FindParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d & ,   const gp_Pnt2d & ,   const double  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d & ,   const gp_Pnt2d & ,   const double  ) >(&Geom2dInt_TheProjPCurOfGInter::FindParameter),
                    R"#(Returns the parameter V of the point on the parametric curve corresponding to the Point Pnt. The Correspondence between Pnt and the point P(V) on the parametric curve must be coherent with the way of determination of the signed distance between a point and the implicit curve. Tol is the tolerance on the distance between a point and the parametrised curve. In that case, no bounds are given. The research of the right parameter has to be made on the natural parametric domain of the curve.)#"  , py::arg("C"),  py::arg("Pnt"),  py::arg("Tol")
          )
        .def_static("FindParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d & ,   const gp_Pnt2d & ,   const double ,   const double ,   const double  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d & ,   const gp_Pnt2d & ,   const double ,   const double ,   const double  ) >(&Geom2dInt_TheProjPCurOfGInter::FindParameter),
                    R"#(Returns the parameter V of the point on the parametric curve corresponding to the Point Pnt. The Correspondence between Pnt and the point P(V) on the parametric curve must be coherent with the way of determination of the signed distance between a point and the implicit curve. Tol is the tolerance on the distance between a point and the parametrised curve. LowParameter and HighParameter give the boundaries of the interval in which the parameter certainly lies. These parameters are given to implement a more efficient algorithm. So, it is not necessary to check that the returned value verifies LowParameter <= Value <= HighParameter.)#"  , py::arg("C"),  py::arg("Pnt"),  py::arg("LowParameter"),  py::arg("HighParameter"),  py::arg("Tol")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/Geom2dInt_ExactIntersectionPointOfTheIntPCurvePCurveOfGInter.hxx
// ./opencascade/Geom2dInt_GInter.hxx
// ./opencascade/Geom2dInt_Geom2dCurveTool.hxx
// ./opencascade/Geom2dInt_IntConicCurveOfGInter.hxx
// ./opencascade/Geom2dInt_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfGInter.hxx
// ./opencascade/Geom2dInt_PCLocFOfTheLocateExtPCOfTheProjPCurOfGInter.hxx
// ./opencascade/Geom2dInt_TheCurveLocatorOfTheProjPCurOfGInter.hxx
// ./opencascade/Geom2dInt_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfGInter.hxx
// ./opencascade/Geom2dInt_TheIntConicCurveOfGInter.hxx
// ./opencascade/Geom2dInt_TheIntPCurvePCurveOfGInter.hxx
// ./opencascade/Geom2dInt_TheIntersectorOfTheIntConicCurveOfGInter.hxx
// ./opencascade/Geom2dInt_TheLocateExtPCOfTheProjPCurOfGInter.hxx
// ./opencascade/Geom2dInt_ThePolygon2dOfTheIntPCurvePCurveOfGInter.hxx
// ./opencascade/Geom2dInt_TheProjPCurOfGInter.hxx

// Additional functions


// operators

// register typdefs
    register_template_Extrema_GFuncExtPC<Adaptor2d_Curve2d, Geom2dInt_Geom2dCurveTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"Geom2dInt_PCLocFOfTheLocateExtPCOfTheProjPCurOfGInter");
    register_template_Extrema_GCurveLocator<Adaptor2d_Curve2d, Geom2dInt_Geom2dCurveTool, Extrema_POnCurv2d, gp_Pnt2d>(m,"Geom2dInt_TheCurveLocatorOfTheProjPCurOfGInter");
    register_template_Extrema_GenLocateExtPC<Adaptor2d_Curve2d, Geom2dInt_Geom2dCurveTool, Extrema_POnCurv2d, gp_Pnt2d, Geom2dInt_PCLocFOfTheLocateExtPCOfTheProjPCurOfGInter>(m,"Geom2dInt_TheLocateExtPCOfTheProjPCurOfGInter");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
