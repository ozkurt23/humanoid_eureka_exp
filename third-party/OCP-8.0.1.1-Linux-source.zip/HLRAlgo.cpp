
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRAlgo_EdgeStatus.hxx>
#include <HLRAlgo_PolyShellData.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRAlgo_EdgeStatus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax2.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <HLRAlgo.hxx>
#include <HLRAlgo_BiPoint.hxx>
#include <HLRAlgo_Coincidence.hxx>
#include <HLRAlgo_EdgeIterator.hxx>
#include <HLRAlgo_EdgesBlock.hxx>
#include <HLRAlgo_EdgeStatus.hxx>
#include <HLRAlgo_Interference.hxx>
#include <HLRAlgo_Intersection.hxx>
#include <HLRAlgo_PolyAlgo.hxx>
#include <HLRAlgo_PolyData.hxx>
#include <HLRAlgo_PolyHidingData.hxx>
#include <HLRAlgo_PolyInternalData.hxx>
#include <HLRAlgo_PolyInternalNode.hxx>
#include <HLRAlgo_PolyInternalSegment.hxx>
#include <HLRAlgo_PolyMask.hxx>
#include <HLRAlgo_PolyShellData.hxx>
#include <HLRAlgo_Projector.hxx>
#include <HLRAlgo_TriangleData.hxx>
#include <HLRAlgo_WiresBlock.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_HLRAlgo(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("HLRAlgo"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class HLRAlgo from ./opencascade/HLRAlgo.hxx
    klass = m.attr("HLRAlgo");

    // default constructor
    register_default_constructor<HLRAlgo , shared_ptr<HLRAlgo>>(m,"HLRAlgo");

    // nested enums

    static_cast<py::class_<HLRAlgo , shared_ptr<HLRAlgo>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("UpdateMinMax_s",
                    (void (*)(  const double ,   const double ,   const double ,  double[16] ,  double[16]  ) ) static_cast<void (*)(  const double ,   const double ,   const double ,  double[16] ,  double[16]  ) >(&HLRAlgo::UpdateMinMax),
                    R"#(Iterator on the visible or hidden parts of an EdgeStatus.)#"  , py::arg("x"),  py::arg("y"),  py::arg("z"),  py::arg("Min"),  py::arg("Max")
          )
        .def_static("EnlargeMinMax_s",
                    (void (*)(  const double ,  double[16] ,  double[16]  ) ) static_cast<void (*)(  const double ,  double[16] ,  double[16]  ) >(&HLRAlgo::EnlargeMinMax),
                    R"#()#"  , py::arg("tol"),  py::arg("Min"),  py::arg("Max")
          )
        .def_static("InitMinMax_s",
                    (void (*)(  const double ,  double[16] ,  double[16]  ) ) static_cast<void (*)(  const double ,  double[16] ,  double[16]  ) >(&HLRAlgo::InitMinMax),
                    R"#()#"  , py::arg("Big"),  py::arg("Min"),  py::arg("Max")
          )
        .def_static("EncodeMinMax_s",
                    (void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo::EncodeMinMax),
                    R"#()#"  , py::arg("Min"),  py::arg("Max"),  py::arg("MinMax")
          )
        .def_static("SizeBox_s",
                    (double (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<double (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo::SizeBox),
                    R"#()#"  , py::arg("Min"),  py::arg("Max")
          )
        .def_static("DecodeMinMax_s",
                    (void (*)(  const HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (*)(  const HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo::DecodeMinMax),
                    R"#()#"  , py::arg("MinMax"),  py::arg("Min"),  py::arg("Max")
          )
        .def_static("CopyMinMax_s",
                    (void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo::CopyMinMax),
                    R"#()#"  , py::arg("IMin"),  py::arg("IMax"),  py::arg("OMin"),  py::arg("OMax")
          )
        .def_static("AddMinMax_s",
                    (void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (*)( HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices & ,  HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo::AddMinMax),
                    R"#()#"  , py::arg("IMin"),  py::arg("IMax"),  py::arg("OMin"),  py::arg("OMax")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_BiPoint from ./opencascade/HLRAlgo_BiPoint.hxx
    klass = m.attr("HLRAlgo_BiPoint");


    // nested enums

    static_cast<py::class_<HLRAlgo_BiPoint , shared_ptr<HLRAlgo_BiPoint>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const bool, const bool, const bool, const bool >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const int >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("flag") )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const int, const int, const int, const bool, const bool, const bool, const bool >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("i1"),  py::arg("i1p1"),  py::arg("i1p2"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const int, const int, const int, const int >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("i1"),  py::arg("i1p1"),  py::arg("i1p2"),  py::arg("flag") )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const int, const int, const int, const int, const int, const int, const bool, const bool, const bool, const bool >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("i1"),  py::arg("i1p1"),  py::arg("i1p2"),  py::arg("i2"),  py::arg("i2p1"),  py::arg("i2p2"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double, const int, const int, const int, const int, const int, const int, const int, const int >()  , py::arg("X1"),  py::arg("Y1"),  py::arg("Z1"),  py::arg("X2"),  py::arg("Y2"),  py::arg("Z2"),  py::arg("XT1"),  py::arg("YT1"),  py::arg("ZT1"),  py::arg("XT2"),  py::arg("YT2"),  py::arg("ZT2"),  py::arg("Index"),  py::arg("i1"),  py::arg("i1p1"),  py::arg("i1p2"),  py::arg("i2"),  py::arg("i2p1"),  py::arg("i2p2"),  py::arg("flag") )
    // custom constructors
    // methods
        .def("Rg1Line",
             (bool (HLRAlgo_BiPoint::*)() const) static_cast<bool (HLRAlgo_BiPoint::*)() const>(&HLRAlgo_BiPoint::Rg1Line),
             R"#()#" 
          )
        .def("Rg1Line",
             (void (HLRAlgo_BiPoint::*)(  const bool  ) ) static_cast<void (HLRAlgo_BiPoint::*)(  const bool  ) >(&HLRAlgo_BiPoint::Rg1Line),
             R"#()#"  , py::arg("B")
          )
        .def("RgNLine",
             (bool (HLRAlgo_BiPoint::*)() const) static_cast<bool (HLRAlgo_BiPoint::*)() const>(&HLRAlgo_BiPoint::RgNLine),
             R"#()#" 
          )
        .def("RgNLine",
             (void (HLRAlgo_BiPoint::*)(  const bool  ) ) static_cast<void (HLRAlgo_BiPoint::*)(  const bool  ) >(&HLRAlgo_BiPoint::RgNLine),
             R"#()#"  , py::arg("B")
          )
        .def("OutLine",
             (bool (HLRAlgo_BiPoint::*)() const) static_cast<bool (HLRAlgo_BiPoint::*)() const>(&HLRAlgo_BiPoint::OutLine),
             R"#()#" 
          )
        .def("OutLine",
             (void (HLRAlgo_BiPoint::*)(  const bool  ) ) static_cast<void (HLRAlgo_BiPoint::*)(  const bool  ) >(&HLRAlgo_BiPoint::OutLine),
             R"#()#"  , py::arg("B")
          )
        .def("IntLine",
             (bool (HLRAlgo_BiPoint::*)() const) static_cast<bool (HLRAlgo_BiPoint::*)() const>(&HLRAlgo_BiPoint::IntLine),
             R"#()#" 
          )
        .def("IntLine",
             (void (HLRAlgo_BiPoint::*)(  const bool  ) ) static_cast<void (HLRAlgo_BiPoint::*)(  const bool  ) >(&HLRAlgo_BiPoint::IntLine),
             R"#()#"  , py::arg("B")
          )
        .def("Hidden",
             (bool (HLRAlgo_BiPoint::*)() const) static_cast<bool (HLRAlgo_BiPoint::*)() const>(&HLRAlgo_BiPoint::Hidden),
             R"#()#" 
          )
        .def("Hidden",
             (void (HLRAlgo_BiPoint::*)(  const bool  ) ) static_cast<void (HLRAlgo_BiPoint::*)(  const bool  ) >(&HLRAlgo_BiPoint::Hidden),
             R"#()#"  , py::arg("B")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Indices",
             (HLRAlgo_BiPoint::IndicesT & (HLRAlgo_BiPoint::*)() ) static_cast<HLRAlgo_BiPoint::IndicesT & (HLRAlgo_BiPoint::*)() >(&HLRAlgo_BiPoint::Indices),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Points",
             (HLRAlgo_BiPoint::PointsT & (HLRAlgo_BiPoint::*)() ) static_cast<HLRAlgo_BiPoint::PointsT & (HLRAlgo_BiPoint::*)() >(&HLRAlgo_BiPoint::Points),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRAlgo_Coincidence from ./opencascade/HLRAlgo_Coincidence.hxx
    klass = m.attr("HLRAlgo_Coincidence");


    // nested enums

    static_cast<py::class_<HLRAlgo_Coincidence , shared_ptr<HLRAlgo_Coincidence>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set2D",
             (void (HLRAlgo_Coincidence::*)(  const int ,   const double  ) ) static_cast<void (HLRAlgo_Coincidence::*)(  const int ,   const double  ) >(&HLRAlgo_Coincidence::Set2D),
             R"#()#"  , py::arg("FE"),  py::arg("Param")
          )
        .def("SetState3D",
             (void (HLRAlgo_Coincidence::*)(  const TopAbs_State ,   const TopAbs_State  ) ) static_cast<void (HLRAlgo_Coincidence::*)(  const TopAbs_State ,   const TopAbs_State  ) >(&HLRAlgo_Coincidence::SetState3D),
             R"#()#"  , py::arg("stbef"),  py::arg("staft")
          )
        .def("State3D",
             (void (HLRAlgo_Coincidence::*)( TopAbs_State & ,  TopAbs_State &  ) const) static_cast<void (HLRAlgo_Coincidence::*)( TopAbs_State & ,  TopAbs_State &  ) const>(&HLRAlgo_Coincidence::State3D),
             R"#()#"  , py::arg("stbef"),  py::arg("staft")
          )
    // methods using call by reference i.s.o. return
        .def("Value2D",
             []( HLRAlgo_Coincidence &self   ){
                 int  FE;
                double  Param;

                 self.Value2D(FE,Param);
                 return std::make_tuple(FE,Param); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_EdgeIterator from ./opencascade/HLRAlgo_EdgeIterator.hxx
    klass = m.attr("HLRAlgo_EdgeIterator");


    // nested enums

    static_cast<py::class_<HLRAlgo_EdgeIterator , shared_ptr<HLRAlgo_EdgeIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("InitHidden",
             (void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) ) static_cast<void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) >(&HLRAlgo_EdgeIterator::InitHidden),
             R"#()#"  , py::arg("status")
          )
        .def("MoreHidden",
             (bool (HLRAlgo_EdgeIterator::*)() const) static_cast<bool (HLRAlgo_EdgeIterator::*)() const>(&HLRAlgo_EdgeIterator::MoreHidden),
             R"#()#" 
          )
        .def("NextHidden",
             (void (HLRAlgo_EdgeIterator::*)() ) static_cast<void (HLRAlgo_EdgeIterator::*)() >(&HLRAlgo_EdgeIterator::NextHidden),
             R"#()#" 
          )
        .def("InitVisible",
             (void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) ) static_cast<void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) >(&HLRAlgo_EdgeIterator::InitVisible),
             R"#()#"  , py::arg("status")
          )
        .def("MoreVisible",
             (bool (HLRAlgo_EdgeIterator::*)() const) static_cast<bool (HLRAlgo_EdgeIterator::*)() const>(&HLRAlgo_EdgeIterator::MoreVisible),
             R"#()#" 
          )
        .def("NextVisible",
             (void (HLRAlgo_EdgeIterator::*)() ) static_cast<void (HLRAlgo_EdgeIterator::*)() >(&HLRAlgo_EdgeIterator::NextVisible),
             R"#()#" 
          )
        .def("MoreHidden",
             (bool (HLRAlgo_EdgeIterator::*)() const) static_cast<bool (HLRAlgo_EdgeIterator::*)() const>(&HLRAlgo_EdgeIterator::MoreHidden),
             R"#()#" 
          )
        .def("InitVisible",
             (void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) ) static_cast<void (HLRAlgo_EdgeIterator::*)( HLRAlgo_EdgeStatus &  ) >(&HLRAlgo_EdgeIterator::InitVisible),
             R"#()#"  , py::arg("status")
          )
        .def("MoreVisible",
             (bool (HLRAlgo_EdgeIterator::*)() const) static_cast<bool (HLRAlgo_EdgeIterator::*)() const>(&HLRAlgo_EdgeIterator::MoreVisible),
             R"#()#" 
          )
        .def("NextVisible",
             (void (HLRAlgo_EdgeIterator::*)() ) static_cast<void (HLRAlgo_EdgeIterator::*)() >(&HLRAlgo_EdgeIterator::NextVisible),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Hidden",
             []( HLRAlgo_EdgeIterator &self   ){
                 double  Start;
                float  TolStart;
                double  End;
                float  TolEnd;

                 self.Hidden(Start,TolStart,End,TolEnd);
                 return std::make_tuple(Start,TolStart,End,TolEnd); },
             R"#(Returns the bounds and the tolerances of the current Hidden Interval)#" 
          )
        .def("Visible",
             []( HLRAlgo_EdgeIterator &self   ){
                 double  Start;
                float  TolStart;
                double  End;
                float  TolEnd;

                 self.Visible(Start,TolStart,End,TolEnd);
                 return std::make_tuple(Start,TolStart,End,TolEnd); },
             R"#(Returns the bounds and the tolerances of the current Visible Interval)#" 
          )
        .def("Hidden",
             []( HLRAlgo_EdgeIterator &self   ){
                 double  Start;
                float  TolStart;
                double  End;
                float  TolEnd;

                 self.Hidden(Start,TolStart,End,TolEnd);
                 return std::make_tuple(Start,TolStart,End,TolEnd); },
             R"#(Returns the bounds and the tolerances of the current Hidden Interval)#" 
          )
        .def("Visible",
             []( HLRAlgo_EdgeIterator &self   ){
                 double  Start;
                float  TolStart;
                double  End;
                float  TolEnd;

                 self.Visible(Start,TolStart,End,TolEnd);
                 return std::make_tuple(Start,TolStart,End,TolEnd); },
             R"#(Returns the bounds and the tolerances of the current Visible Interval)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_EdgeStatus from ./opencascade/HLRAlgo_EdgeStatus.hxx
    klass = m.attr("HLRAlgo_EdgeStatus");


    // nested enums

    static_cast<py::class_<HLRAlgo_EdgeStatus , shared_ptr<HLRAlgo_EdgeStatus>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const float, const double, const float >()  , py::arg("Start"),  py::arg("TolStart"),  py::arg("End"),  py::arg("TolEnd") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (HLRAlgo_EdgeStatus::*)(  const double ,   const float ,   const double ,   const float  ) ) static_cast<void (HLRAlgo_EdgeStatus::*)(  const double ,   const float ,   const double ,   const float  ) >(&HLRAlgo_EdgeStatus::Initialize),
             R"#(Initialize an EdgeStatus. Default visible. The Edge is bounded by the interval <Start>, <End> with the tolerances <TolStart>, <TolEnd>.)#"  , py::arg("Start"),  py::arg("TolStart"),  py::arg("End"),  py::arg("TolEnd")
          )
        .def("NbVisiblePart",
             (int (HLRAlgo_EdgeStatus::*)() const) static_cast<int (HLRAlgo_EdgeStatus::*)() const>(&HLRAlgo_EdgeStatus::NbVisiblePart),
             R"#()#" 
          )
        .def("Hide",
             (void (HLRAlgo_EdgeStatus::*)(  const double ,   const float ,   const double ,   const float ,   const bool ,   const bool  ) ) static_cast<void (HLRAlgo_EdgeStatus::*)(  const double ,   const float ,   const double ,   const float ,   const bool ,   const bool  ) >(&HLRAlgo_EdgeStatus::Hide),
             R"#(Hides the interval <Start>, <End> with the tolerances <TolStart>, <TolEnd>. This interval is subtracted from the visible parts. If the hidden part is on (or under) the face the flag <OnFace> is True (or False). If the hidden part is on (or inside) the boundary of the face the flag <OnBoundary> is True (or False).)#"  , py::arg("Start"),  py::arg("TolStart"),  py::arg("End"),  py::arg("TolEnd"),  py::arg("OnFace"),  py::arg("OnBoundary")
          )
        .def("HideAll",
             (void (HLRAlgo_EdgeStatus::*)() ) static_cast<void (HLRAlgo_EdgeStatus::*)() >(&HLRAlgo_EdgeStatus::HideAll),
             R"#(Hide the whole Edge.)#" 
          )
        .def("ShowAll",
             (void (HLRAlgo_EdgeStatus::*)() ) static_cast<void (HLRAlgo_EdgeStatus::*)() >(&HLRAlgo_EdgeStatus::ShowAll),
             R"#(Show the whole Edge.)#" 
          )
        .def("AllHidden",
             (bool (HLRAlgo_EdgeStatus::*)() const) static_cast<bool (HLRAlgo_EdgeStatus::*)() const>(&HLRAlgo_EdgeStatus::AllHidden),
             R"#()#" 
          )
        .def("AllHidden",
             (void (HLRAlgo_EdgeStatus::*)(  const bool  ) ) static_cast<void (HLRAlgo_EdgeStatus::*)(  const bool  ) >(&HLRAlgo_EdgeStatus::AllHidden),
             R"#()#"  , py::arg("B")
          )
        .def("AllVisible",
             (bool (HLRAlgo_EdgeStatus::*)() const) static_cast<bool (HLRAlgo_EdgeStatus::*)() const>(&HLRAlgo_EdgeStatus::AllVisible),
             R"#()#" 
          )
        .def("AllVisible",
             (void (HLRAlgo_EdgeStatus::*)(  const bool  ) ) static_cast<void (HLRAlgo_EdgeStatus::*)(  const bool  ) >(&HLRAlgo_EdgeStatus::AllVisible),
             R"#()#"  , py::arg("B")
          )
    // methods using call by reference i.s.o. return
        .def("Bounds",
             []( HLRAlgo_EdgeStatus &self   ){
                 double  theStart;
                float  theTolStart;
                double  theEnd;
                float  theTolEnd;

                 self.Bounds(theStart,theTolStart,theEnd,theTolEnd);
                 return std::make_tuple(theStart,theTolStart,theEnd,theTolEnd); },
             R"#()#" 
          )
        .def("VisiblePart",
             []( HLRAlgo_EdgeStatus &self ,  const int Index ){
                 double  Start;
                float  TolStart;
                double  End;
                float  TolEnd;

                 self.VisiblePart(Index,Start,TolStart,End,TolEnd);
                 return std::make_tuple(Start,TolStart,End,TolEnd); },
             R"#()#"  , py::arg("Index")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_EdgesBlock from ./opencascade/HLRAlgo_EdgesBlock.hxx
    klass = m.attr("HLRAlgo_EdgesBlock");


    // nested enums

    static_cast<py::class_<HLRAlgo_EdgesBlock ,opencascade::handle<HLRAlgo_EdgesBlock>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int >()  , py::arg("NbEdges") )
    // custom constructors
    // methods
        .def("NbEdges",
             (int (HLRAlgo_EdgesBlock::*)() const) static_cast<int (HLRAlgo_EdgesBlock::*)() const>(&HLRAlgo_EdgesBlock::NbEdges),
             R"#()#" 
          )
        .def("Edge",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const int  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const int  ) >(&HLRAlgo_EdgesBlock::Edge),
             R"#()#"  , py::arg("I"),  py::arg("EI")
          )
        .def("Edge",
             (int (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<int (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::Edge),
             R"#()#"  , py::arg("I")
          )
        .def("Orientation",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const TopAbs_Orientation  ) >(&HLRAlgo_EdgesBlock::Orientation),
             R"#()#"  , py::arg("I"),  py::arg("Or")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<TopAbs_Orientation (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::Orientation),
             R"#()#"  , py::arg("I")
          )
        .def("OutLine",
             (bool (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<bool (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::OutLine),
             R"#()#"  , py::arg("I")
          )
        .def("OutLine",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) >(&HLRAlgo_EdgesBlock::OutLine),
             R"#()#"  , py::arg("I"),  py::arg("B")
          )
        .def("Internal",
             (bool (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<bool (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::Internal),
             R"#()#"  , py::arg("I")
          )
        .def("Internal",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) >(&HLRAlgo_EdgesBlock::Internal),
             R"#()#"  , py::arg("I"),  py::arg("B")
          )
        .def("Double",
             (bool (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<bool (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::Double),
             R"#()#"  , py::arg("I")
          )
        .def("Double",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) >(&HLRAlgo_EdgesBlock::Double),
             R"#()#"  , py::arg("I"),  py::arg("B")
          )
        .def("IsoLine",
             (bool (HLRAlgo_EdgesBlock::*)(  const int  ) const) static_cast<bool (HLRAlgo_EdgesBlock::*)(  const int  ) const>(&HLRAlgo_EdgesBlock::IsoLine),
             R"#()#"  , py::arg("I")
          )
        .def("IsoLine",
             (void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const int ,   const bool  ) >(&HLRAlgo_EdgesBlock::IsoLine),
             R"#()#"  , py::arg("I"),  py::arg("B")
          )
        .def("UpdateMinMax",
             (void (HLRAlgo_EdgesBlock::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (HLRAlgo_EdgesBlock::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo_EdgesBlock::UpdateMinMax),
             R"#()#"  , py::arg("TotMinMax")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_EdgesBlock::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_EdgesBlock::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("MinMax",
             (HLRAlgo_EdgesBlock::MinMaxIndices & (HLRAlgo_EdgesBlock::*)() ) static_cast<HLRAlgo_EdgesBlock::MinMaxIndices & (HLRAlgo_EdgesBlock::*)() >(&HLRAlgo_EdgesBlock::MinMax),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_EdgesBlock::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_EdgesBlock::*)() const>(&HLRAlgo_EdgesBlock::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRAlgo_Interference from ./opencascade/HLRAlgo_Interference.hxx
    klass = m.attr("HLRAlgo_Interference");


    // nested enums

    static_cast<py::class_<HLRAlgo_Interference , shared_ptr<HLRAlgo_Interference>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const HLRAlgo_Intersection &, const HLRAlgo_Coincidence &, const TopAbs_Orientation, const TopAbs_Orientation, const TopAbs_Orientation >()  , py::arg("Inters"),  py::arg("Bound"),  py::arg("Orient"),  py::arg("Trans"),  py::arg("BTrans") )
    // custom constructors
    // methods
        .def("Intersection",
             (void (HLRAlgo_Interference::*)(  const HLRAlgo_Intersection &  ) ) static_cast<void (HLRAlgo_Interference::*)(  const HLRAlgo_Intersection &  ) >(&HLRAlgo_Interference::Intersection),
             R"#()#"  , py::arg("I")
          )
        .def("Boundary",
             (void (HLRAlgo_Interference::*)(  const HLRAlgo_Coincidence &  ) ) static_cast<void (HLRAlgo_Interference::*)(  const HLRAlgo_Coincidence &  ) >(&HLRAlgo_Interference::Boundary),
             R"#()#"  , py::arg("B")
          )
        .def("Orientation",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::Orientation),
             R"#()#"  , py::arg("O")
          )
        .def("Transition",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::Transition),
             R"#()#"  , py::arg("Tr")
          )
        .def("BoundaryTransition",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::BoundaryTransition),
             R"#()#"  , py::arg("BTr")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Orientation),
             R"#()#" 
          )
        .def("Transition",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Transition),
             R"#()#" 
          )
        .def("BoundaryTransition",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::BoundaryTransition),
             R"#()#" 
          )
        .def("Intersection",
             (void (HLRAlgo_Interference::*)(  const HLRAlgo_Intersection &  ) ) static_cast<void (HLRAlgo_Interference::*)(  const HLRAlgo_Intersection &  ) >(&HLRAlgo_Interference::Intersection),
             R"#()#"  , py::arg("I")
          )
        .def("Boundary",
             (void (HLRAlgo_Interference::*)(  const HLRAlgo_Coincidence &  ) ) static_cast<void (HLRAlgo_Interference::*)(  const HLRAlgo_Coincidence &  ) >(&HLRAlgo_Interference::Boundary),
             R"#()#"  , py::arg("B")
          )
        .def("Orientation",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::Orientation),
             R"#()#"  , py::arg("Or")
          )
        .def("Transition",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::Transition),
             R"#()#"  , py::arg("Or")
          )
        .def("BoundaryTransition",
             (void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Interference::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Interference::BoundaryTransition),
             R"#()#"  , py::arg("Or")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Orientation),
             R"#()#" 
          )
        .def("Transition",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Transition),
             R"#()#" 
          )
        .def("BoundaryTransition",
             (TopAbs_Orientation (HLRAlgo_Interference::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::BoundaryTransition),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Intersection",
             ( const HLRAlgo_Intersection & (HLRAlgo_Interference::*)() const) static_cast< const HLRAlgo_Intersection & (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Intersection),
             R"#()#"
             
         )
       .def("ChangeIntersection",
             (HLRAlgo_Intersection & (HLRAlgo_Interference::*)() ) static_cast<HLRAlgo_Intersection & (HLRAlgo_Interference::*)() >(&HLRAlgo_Interference::ChangeIntersection),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Boundary",
             ( const HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() const) static_cast< const HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Boundary),
             R"#()#"
             
         )
       .def("ChangeBoundary",
             (HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() ) static_cast<HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() >(&HLRAlgo_Interference::ChangeBoundary),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Intersection",
             ( const HLRAlgo_Intersection & (HLRAlgo_Interference::*)() const) static_cast< const HLRAlgo_Intersection & (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Intersection),
             R"#()#"
             
         )
       .def("ChangeIntersection",
             (HLRAlgo_Intersection & (HLRAlgo_Interference::*)() ) static_cast<HLRAlgo_Intersection & (HLRAlgo_Interference::*)() >(&HLRAlgo_Interference::ChangeIntersection),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Boundary",
             ( const HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() const) static_cast< const HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() const>(&HLRAlgo_Interference::Boundary),
             R"#()#"
             
         )
       .def("ChangeBoundary",
             (HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() ) static_cast<HLRAlgo_Coincidence & (HLRAlgo_Interference::*)() >(&HLRAlgo_Interference::ChangeBoundary),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRAlgo_Intersection from ./opencascade/HLRAlgo_Intersection.hxx
    klass = m.attr("HLRAlgo_Intersection");


    // nested enums

    static_cast<py::class_<HLRAlgo_Intersection , shared_ptr<HLRAlgo_Intersection>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopAbs_Orientation, const int, const int, const int, const double, const float, const TopAbs_State >()  , py::arg("Ori"),  py::arg("Lev"),  py::arg("SegInd"),  py::arg("Ind"),  py::arg("P"),  py::arg("Tol"),  py::arg("S") )
    // custom constructors
    // methods
        .def("Orientation",
             (void (HLRAlgo_Intersection::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Intersection::Orientation),
             R"#()#"  , py::arg("Ori")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRAlgo_Intersection::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Orientation),
             R"#()#" 
          )
        .def("Level",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::Level),
             R"#()#"  , py::arg("Lev")
          )
        .def("Level",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Level),
             R"#()#" 
          )
        .def("SegIndex",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::SegIndex),
             R"#()#"  , py::arg("SegInd")
          )
        .def("SegIndex",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::SegIndex),
             R"#()#" 
          )
        .def("Index",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::Index),
             R"#()#"  , py::arg("Ind")
          )
        .def("Index",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Index),
             R"#()#" 
          )
        .def("Parameter",
             (void (HLRAlgo_Intersection::*)(  const double  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const double  ) >(&HLRAlgo_Intersection::Parameter),
             R"#()#"  , py::arg("P")
          )
        .def("Parameter",
             (double (HLRAlgo_Intersection::*)() const) static_cast<double (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Parameter),
             R"#()#" 
          )
        .def("Tolerance",
             (void (HLRAlgo_Intersection::*)(  const float  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const float  ) >(&HLRAlgo_Intersection::Tolerance),
             R"#()#"  , py::arg("T")
          )
        .def("Tolerance",
             (float (HLRAlgo_Intersection::*)() const) static_cast<float (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Tolerance),
             R"#()#" 
          )
        .def("State",
             (void (HLRAlgo_Intersection::*)(  const TopAbs_State  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const TopAbs_State  ) >(&HLRAlgo_Intersection::State),
             R"#()#"  , py::arg("S")
          )
        .def("State",
             (TopAbs_State (HLRAlgo_Intersection::*)() const) static_cast<TopAbs_State (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::State),
             R"#()#" 
          )
        .def("Orientation",
             (void (HLRAlgo_Intersection::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const TopAbs_Orientation  ) >(&HLRAlgo_Intersection::Orientation),
             R"#()#"  , py::arg("Ori")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRAlgo_Intersection::*)() const) static_cast<TopAbs_Orientation (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Orientation),
             R"#()#" 
          )
        .def("Level",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::Level),
             R"#()#"  , py::arg("Lev")
          )
        .def("Level",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Level),
             R"#()#" 
          )
        .def("SegIndex",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::SegIndex),
             R"#()#"  , py::arg("SegInd")
          )
        .def("SegIndex",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::SegIndex),
             R"#()#" 
          )
        .def("Index",
             (void (HLRAlgo_Intersection::*)(  const int  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const int  ) >(&HLRAlgo_Intersection::Index),
             R"#()#"  , py::arg("Ind")
          )
        .def("Index",
             (int (HLRAlgo_Intersection::*)() const) static_cast<int (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Index),
             R"#()#" 
          )
        .def("Parameter",
             (void (HLRAlgo_Intersection::*)(  const double  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const double  ) >(&HLRAlgo_Intersection::Parameter),
             R"#()#"  , py::arg("P")
          )
        .def("Parameter",
             (double (HLRAlgo_Intersection::*)() const) static_cast<double (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Parameter),
             R"#()#" 
          )
        .def("Tolerance",
             (void (HLRAlgo_Intersection::*)(  const float  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const float  ) >(&HLRAlgo_Intersection::Tolerance),
             R"#()#"  , py::arg("T")
          )
        .def("Tolerance",
             (float (HLRAlgo_Intersection::*)() const) static_cast<float (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::Tolerance),
             R"#()#" 
          )
        .def("State",
             (void (HLRAlgo_Intersection::*)(  const TopAbs_State  ) ) static_cast<void (HLRAlgo_Intersection::*)(  const TopAbs_State  ) >(&HLRAlgo_Intersection::State),
             R"#()#"  , py::arg("St")
          )
        .def("State",
             (TopAbs_State (HLRAlgo_Intersection::*)() const) static_cast<TopAbs_State (HLRAlgo_Intersection::*)() const>(&HLRAlgo_Intersection::State),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_PolyAlgo from ./opencascade/HLRAlgo_PolyAlgo.hxx
    klass = m.attr("HLRAlgo_PolyAlgo");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyAlgo ,opencascade::handle<HLRAlgo_PolyAlgo>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (HLRAlgo_PolyAlgo::*)(  const int  ) ) static_cast<void (HLRAlgo_PolyAlgo::*)(  const int  ) >(&HLRAlgo_PolyAlgo::Init),
             R"#()#"  , py::arg("theNbShells")
          )
        .def("Clear",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::Clear),
             R"#()#" 
          )
        .def("Update",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::Update),
             R"#(Prepare all the data to process the algo.)#" 
          )
        .def("InitHide",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::InitHide),
             R"#()#" 
          )
        .def("MoreHide",
             (bool (HLRAlgo_PolyAlgo::*)() const) static_cast<bool (HLRAlgo_PolyAlgo::*)() const>(&HLRAlgo_PolyAlgo::MoreHide),
             R"#()#" 
          )
        .def("NextHide",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::NextHide),
             R"#()#" 
          )
        .def("Hide",
             (HLRAlgo_BiPoint::PointsT & (HLRAlgo_PolyAlgo::*)( HLRAlgo_EdgeStatus & ,  int & ,  bool & ,  bool & ,  bool & ,  bool &  ) ) static_cast<HLRAlgo_BiPoint::PointsT & (HLRAlgo_PolyAlgo::*)( HLRAlgo_EdgeStatus & ,  int & ,  bool & ,  bool & ,  bool & ,  bool &  ) >(&HLRAlgo_PolyAlgo::Hide),
             R"#(process hiding between <Pt1> and <Pt2>.)#"  , py::arg("status"),  py::arg("Index"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl")
          )
        .def("InitShow",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::InitShow),
             R"#()#" 
          )
        .def("MoreShow",
             (bool (HLRAlgo_PolyAlgo::*)() const) static_cast<bool (HLRAlgo_PolyAlgo::*)() const>(&HLRAlgo_PolyAlgo::MoreShow),
             R"#()#" 
          )
        .def("NextShow",
             (void (HLRAlgo_PolyAlgo::*)() ) static_cast<void (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::NextShow),
             R"#()#" 
          )
        .def("Show",
             (HLRAlgo_BiPoint::PointsT & (HLRAlgo_PolyAlgo::*)( int & ,  bool & ,  bool & ,  bool & ,  bool &  ) ) static_cast<HLRAlgo_BiPoint::PointsT & (HLRAlgo_PolyAlgo::*)( int & ,  bool & ,  bool & ,  bool & ,  bool &  ) >(&HLRAlgo_PolyAlgo::Show),
             R"#(process hiding between <Pt1> and <Pt2>.)#"  , py::arg("Index"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_PolyAlgo::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_PolyAlgo::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PolyShell",
             ( const NCollection_Array1<handle<HLRAlgo_PolyShellData>> & (HLRAlgo_PolyAlgo::*)() const) static_cast< const NCollection_Array1<handle<HLRAlgo_PolyShellData>> & (HLRAlgo_PolyAlgo::*)() const>(&HLRAlgo_PolyAlgo::PolyShell),
             R"#()#"
             
         )
       .def("ChangePolyShell",
             (NCollection_Array1<handle<HLRAlgo_PolyShellData>> & (HLRAlgo_PolyAlgo::*)() ) static_cast<NCollection_Array1<handle<HLRAlgo_PolyShellData>> & (HLRAlgo_PolyAlgo::*)() >(&HLRAlgo_PolyAlgo::ChangePolyShell),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_PolyAlgo::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_PolyAlgo::*)() const>(&HLRAlgo_PolyAlgo::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRAlgo_PolyData from ./opencascade/HLRAlgo_PolyData.hxx
    klass = m.attr("HLRAlgo_PolyData");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyData ,opencascade::handle<HLRAlgo_PolyData>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("HNodes",
             (void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<gp_XYZ>> &  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<gp_XYZ>> &  ) >(&HLRAlgo_PolyData::HNodes),
             R"#()#"  , py::arg("HNodes")
          )
        .def("HTData",
             (void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<HLRAlgo_TriangleData>> &  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<HLRAlgo_TriangleData>> &  ) >(&HLRAlgo_PolyData::HTData),
             R"#()#"  , py::arg("HTData")
          )
        .def("HPHDat",
             (void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<HLRAlgo_PolyHidingData>> &  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const handle<NCollection_HArray1<HLRAlgo_PolyHidingData>> &  ) >(&HLRAlgo_PolyData::HPHDat),
             R"#()#"  , py::arg("HPHDat")
          )
        .def("FaceIndex",
             (void (HLRAlgo_PolyData::*)(  const int  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const int  ) >(&HLRAlgo_PolyData::FaceIndex),
             R"#()#"  , py::arg("I")
          )
        .def("FaceIndex",
             (int (HLRAlgo_PolyData::*)() const) static_cast<int (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::FaceIndex),
             R"#()#" 
          )
        .def("UpdateGlobalMinMax",
             (void (HLRAlgo_PolyData::*)( Bnd_Box &  ) ) static_cast<void (HLRAlgo_PolyData::*)( Bnd_Box &  ) >(&HLRAlgo_PolyData::UpdateGlobalMinMax),
             R"#()#"  , py::arg("theBox")
          )
        .def("Hiding",
             (bool (HLRAlgo_PolyData::*)() const) static_cast<bool (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::Hiding),
             R"#()#" 
          )
        .def("HideByPolyData",
             (void (HLRAlgo_PolyData::*)(  const HLRAlgo_BiPoint::PointsT & ,  HLRAlgo_PolyData::Triangle & ,  HLRAlgo_BiPoint::IndicesT & ,   const bool ,  HLRAlgo_EdgeStatus &  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const HLRAlgo_BiPoint::PointsT & ,  HLRAlgo_PolyData::Triangle & ,  HLRAlgo_BiPoint::IndicesT & ,   const bool ,  HLRAlgo_EdgeStatus &  ) >(&HLRAlgo_PolyData::HideByPolyData),
             R"#(process hiding between <Pt1> and <Pt2>.)#"  , py::arg("thePoints"),  py::arg("theTriangle"),  py::arg("theIndices"),  py::arg("HidingShell"),  py::arg("status")
          )
        .def("FaceIndex",
             (void (HLRAlgo_PolyData::*)(  const int  ) ) static_cast<void (HLRAlgo_PolyData::*)(  const int  ) >(&HLRAlgo_PolyData::FaceIndex),
             R"#()#"  , py::arg("I")
          )
        .def("FaceIndex",
             (int (HLRAlgo_PolyData::*)() const) static_cast<int (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::FaceIndex),
             R"#()#" 
          )
        .def("Hiding",
             (bool (HLRAlgo_PolyData::*)() const) static_cast<bool (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::Hiding),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_PolyData::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_PolyData::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Nodes",
             (NCollection_Array1<gp_XYZ> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<gp_XYZ> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::Nodes),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("TData",
             (NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::TData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PHDat",
             (NCollection_Array1<HLRAlgo_PolyHidingData> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<HLRAlgo_PolyHidingData> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::PHDat),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Indices",
             (HLRAlgo_PolyData::FaceIndices & (HLRAlgo_PolyData::*)() ) static_cast<HLRAlgo_PolyData::FaceIndices & (HLRAlgo_PolyData::*)() >(&HLRAlgo_PolyData::Indices),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_PolyData::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::DynamicType),
             R"#()#"
             
         )
       .def("Nodes",
             (NCollection_Array1<gp_XYZ> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<gp_XYZ> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::Nodes),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("TData",
             (NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::TData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PHDat",
             (NCollection_Array1<HLRAlgo_PolyHidingData> & (HLRAlgo_PolyData::*)() const) static_cast<NCollection_Array1<HLRAlgo_PolyHidingData> & (HLRAlgo_PolyData::*)() const>(&HLRAlgo_PolyData::PHDat),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRAlgo_PolyHidingData from ./opencascade/HLRAlgo_PolyHidingData.hxx
    klass = m.attr("HLRAlgo_PolyHidingData");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyHidingData , shared_ptr<HLRAlgo_PolyHidingData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (HLRAlgo_PolyHidingData::*)(  const int ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (HLRAlgo_PolyHidingData::*)(  const int ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double  ) >(&HLRAlgo_PolyHidingData::Set),
             R"#()#"  , py::arg("Index"),  py::arg("Minim"),  py::arg("Maxim"),  py::arg("A"),  py::arg("B"),  py::arg("C"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Indices",
             (HLRAlgo_PolyHidingData::TriangleIndices & (HLRAlgo_PolyHidingData::*)() ) static_cast<HLRAlgo_PolyHidingData::TriangleIndices & (HLRAlgo_PolyHidingData::*)() >(&HLRAlgo_PolyHidingData::Indices),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Plane",
             (HLRAlgo_PolyHidingData::PlaneT & (HLRAlgo_PolyHidingData::*)() ) static_cast<HLRAlgo_PolyHidingData::PlaneT & (HLRAlgo_PolyHidingData::*)() >(&HLRAlgo_PolyHidingData::Plane),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRAlgo_PolyInternalData from ./opencascade/HLRAlgo_PolyInternalData.hxx
    klass = m.attr("HLRAlgo_PolyInternalData");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyInternalData ,opencascade::handle<HLRAlgo_PolyInternalData>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("nbNod"),  py::arg("nbTri") )
    // custom constructors
    // methods
        .def("UpdateLinks",
             (void (HLRAlgo_PolyInternalData::*)( NCollection_Array1<HLRAlgo_TriangleData> & ,  NCollection_Array1<HLRAlgo_PolyInternalSegment> & ,  NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> &  ) ) static_cast<void (HLRAlgo_PolyInternalData::*)( NCollection_Array1<HLRAlgo_TriangleData> & ,  NCollection_Array1<HLRAlgo_PolyInternalSegment> & ,  NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> &  ) >(&HLRAlgo_PolyInternalData::UpdateLinks),
             R"#()#"  , py::arg("theTData"),  py::arg("thePISeg"),  py::arg("thePINod")
          )
        .def("Dump",
             (void (HLRAlgo_PolyInternalData::*)() const) static_cast<void (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::Dump),
             R"#()#" 
          )
        .def("DecTData",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecTData),
             R"#()#" 
          )
        .def("DecPISeg",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecPISeg),
             R"#()#" 
          )
        .def("DecPINod",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecPINod),
             R"#()#" 
          )
        .def("NbTData",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbTData),
             R"#()#" 
          )
        .def("NbPISeg",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbPISeg),
             R"#()#" 
          )
        .def("NbPINod",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbPINod),
             R"#()#" 
          )
        .def("Planar",
             (bool (HLRAlgo_PolyInternalData::*)() const) static_cast<bool (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::Planar),
             R"#()#" 
          )
        .def("Planar",
             (void (HLRAlgo_PolyInternalData::*)(  const bool  ) ) static_cast<void (HLRAlgo_PolyInternalData::*)(  const bool  ) >(&HLRAlgo_PolyInternalData::Planar),
             R"#()#"  , py::arg("B")
          )
        .def("IntOutL",
             (bool (HLRAlgo_PolyInternalData::*)() const) static_cast<bool (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::IntOutL),
             R"#()#" 
          )
        .def("IntOutL",
             (void (HLRAlgo_PolyInternalData::*)(  const bool  ) ) static_cast<void (HLRAlgo_PolyInternalData::*)(  const bool  ) >(&HLRAlgo_PolyInternalData::IntOutL),
             R"#()#"  , py::arg("B")
          )
        .def("DecTData",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecTData),
             R"#()#" 
          )
        .def("DecPISeg",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecPISeg),
             R"#()#" 
          )
        .def("DecPINod",
             (void (HLRAlgo_PolyInternalData::*)() ) static_cast<void (HLRAlgo_PolyInternalData::*)() >(&HLRAlgo_PolyInternalData::DecPINod),
             R"#()#" 
          )
        .def("NbTData",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbTData),
             R"#()#" 
          )
        .def("NbPISeg",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbPISeg),
             R"#()#" 
          )
        .def("NbPINod",
             (int (HLRAlgo_PolyInternalData::*)() const) static_cast<int (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::NbPINod),
             R"#()#" 
          )
        .def("Planar",
             (bool (HLRAlgo_PolyInternalData::*)() const) static_cast<bool (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::Planar),
             R"#()#" 
          )
        .def("Planar",
             (void (HLRAlgo_PolyInternalData::*)(  const bool  ) ) static_cast<void (HLRAlgo_PolyInternalData::*)(  const bool  ) >(&HLRAlgo_PolyInternalData::Planar),
             R"#()#"  , py::arg("B")
          )
        .def("IntOutL",
             (bool (HLRAlgo_PolyInternalData::*)() const) static_cast<bool (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::IntOutL),
             R"#()#" 
          )
        .def("IntOutL",
             (void (HLRAlgo_PolyInternalData::*)(  const bool  ) ) static_cast<void (HLRAlgo_PolyInternalData::*)(  const bool  ) >(&HLRAlgo_PolyInternalData::IntOutL),
             R"#()#"  , py::arg("B")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_PolyInternalData::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_PolyInternalData::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("TData",
             (NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::TData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PISeg",
             (NCollection_Array1<HLRAlgo_PolyInternalSegment> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<HLRAlgo_PolyInternalSegment> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::PISeg),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PINod",
             (NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::PINod),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_PolyInternalData::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::DynamicType),
             R"#()#"
             
         )
       .def("TData",
             (NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<HLRAlgo_TriangleData> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::TData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PINod",
             (NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<handle<HLRAlgo_PolyInternalNode>> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::PINod),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PISeg",
             (NCollection_Array1<HLRAlgo_PolyInternalSegment> & (HLRAlgo_PolyInternalData::*)() const) static_cast<NCollection_Array1<HLRAlgo_PolyInternalSegment> & (HLRAlgo_PolyInternalData::*)() const>(&HLRAlgo_PolyInternalData::PISeg),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRAlgo_PolyInternalNode from ./opencascade/HLRAlgo_PolyInternalNode.hxx
    klass = m.attr("HLRAlgo_PolyInternalNode");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyInternalNode ,opencascade::handle<HLRAlgo_PolyInternalNode>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_PolyInternalNode::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_PolyInternalNode::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Indices",
             (HLRAlgo_PolyInternalNode::NodeIndices & (HLRAlgo_PolyInternalNode::*)() ) static_cast<HLRAlgo_PolyInternalNode::NodeIndices & (HLRAlgo_PolyInternalNode::*)() >(&HLRAlgo_PolyInternalNode::Indices),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Data",
             (HLRAlgo_PolyInternalNode::NodeData & (HLRAlgo_PolyInternalNode::*)() ) static_cast<HLRAlgo_PolyInternalNode::NodeData & (HLRAlgo_PolyInternalNode::*)() >(&HLRAlgo_PolyInternalNode::Data),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_PolyInternalNode::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_PolyInternalNode::*)() const>(&HLRAlgo_PolyInternalNode::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRAlgo_PolyInternalSegment from ./opencascade/HLRAlgo_PolyInternalSegment.hxx
    klass = m.attr("HLRAlgo_PolyInternalSegment");

    // default constructor
    register_default_constructor<HLRAlgo_PolyInternalSegment , shared_ptr<HLRAlgo_PolyInternalSegment>>(m,"HLRAlgo_PolyInternalSegment");

    // nested enums

    static_cast<py::class_<HLRAlgo_PolyInternalSegment , shared_ptr<HLRAlgo_PolyInternalSegment>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("LstSg1", &HLRAlgo_PolyInternalSegment::LstSg1)
        .def_readwrite("LstSg2", &HLRAlgo_PolyInternalSegment::LstSg2)
        .def_readwrite("NxtSg1", &HLRAlgo_PolyInternalSegment::NxtSg1)
        .def_readwrite("NxtSg2", &HLRAlgo_PolyInternalSegment::NxtSg2)
        .def_readwrite("Conex1", &HLRAlgo_PolyInternalSegment::Conex1)
        .def_readwrite("Conex2", &HLRAlgo_PolyInternalSegment::Conex2)
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_PolyShellData from ./opencascade/HLRAlgo_PolyShellData.hxx
    klass = m.attr("HLRAlgo_PolyShellData");


    // nested enums

    static_cast<py::class_<HLRAlgo_PolyShellData ,opencascade::handle<HLRAlgo_PolyShellData>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int >()  , py::arg("nbFace") )
    // custom constructors
    // methods
        .def("UpdateGlobalMinMax",
             (void (HLRAlgo_PolyShellData::*)( Bnd_Box &  ) ) static_cast<void (HLRAlgo_PolyShellData::*)( Bnd_Box &  ) >(&HLRAlgo_PolyShellData::UpdateGlobalMinMax),
             R"#()#"  , py::arg("theBox")
          )
        .def("UpdateHiding",
             (void (HLRAlgo_PolyShellData::*)(  const int  ) ) static_cast<void (HLRAlgo_PolyShellData::*)(  const int  ) >(&HLRAlgo_PolyShellData::UpdateHiding),
             R"#()#"  , py::arg("nbHiding")
          )
        .def("Hiding",
             (bool (HLRAlgo_PolyShellData::*)() const) static_cast<bool (HLRAlgo_PolyShellData::*)() const>(&HLRAlgo_PolyShellData::Hiding),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_PolyShellData::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_PolyShellData::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PolyData",
             (NCollection_Array1<handle<HLRAlgo_PolyData>> & (HLRAlgo_PolyShellData::*)() ) static_cast<NCollection_Array1<handle<HLRAlgo_PolyData>> & (HLRAlgo_PolyShellData::*)() >(&HLRAlgo_PolyShellData::PolyData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("HidingPolyData",
             (NCollection_Array1<handle<HLRAlgo_PolyData>> & (HLRAlgo_PolyShellData::*)() ) static_cast<NCollection_Array1<handle<HLRAlgo_PolyData>> & (HLRAlgo_PolyShellData::*)() >(&HLRAlgo_PolyShellData::HidingPolyData),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Edges",
             (NCollection_List<HLRAlgo_BiPoint> & (HLRAlgo_PolyShellData::*)() ) static_cast<NCollection_List<HLRAlgo_BiPoint> & (HLRAlgo_PolyShellData::*)() >(&HLRAlgo_PolyShellData::Edges),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Indices",
             (HLRAlgo_PolyShellData::ShellIndices & (HLRAlgo_PolyShellData::*)() ) static_cast<HLRAlgo_PolyShellData::ShellIndices & (HLRAlgo_PolyShellData::*)() >(&HLRAlgo_PolyShellData::Indices),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_PolyShellData::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_PolyShellData::*)() const>(&HLRAlgo_PolyShellData::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRAlgo_Projector from ./opencascade/HLRAlgo_Projector.hxx
    klass = m.attr("HLRAlgo_Projector");


    // nested enums

    static_cast<py::class_<HLRAlgo_Projector , shared_ptr<HLRAlgo_Projector>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Ax2 & >()  , py::arg("CS") )
        .def(py::init<  const gp_Ax2 &, const double >()  , py::arg("CS"),  py::arg("Focus") )
        .def(py::init<  const gp_Trsf &, const bool, const double >()  , py::arg("T"),  py::arg("Persp"),  py::arg("Focus") )
        .def(py::init<  const gp_Trsf &, const bool, const double, const gp_Vec2d &, const gp_Vec2d &, const gp_Vec2d & >()  , py::arg("T"),  py::arg("Persp"),  py::arg("Focus"),  py::arg("v1"),  py::arg("v2"),  py::arg("v3") )
    // custom constructors
    // methods
        .def("Set",
             (void (HLRAlgo_Projector::*)(  const gp_Trsf & ,   const bool ,   const double  ) ) static_cast<void (HLRAlgo_Projector::*)(  const gp_Trsf & ,   const bool ,   const double  ) >(&HLRAlgo_Projector::Set),
             R"#()#"  , py::arg("T"),  py::arg("Persp"),  py::arg("Focus")
          )
        .def("Directions",
             (void (HLRAlgo_Projector::*)( gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const>(&HLRAlgo_Projector::Directions),
             R"#()#"  , py::arg("D1"),  py::arg("D2"),  py::arg("D3")
          )
        .def("Scaled",
             (void (HLRAlgo_Projector::*)(  const bool  ) ) static_cast<void (HLRAlgo_Projector::*)(  const bool  ) >(&HLRAlgo_Projector::Scaled),
             R"#(to compute with the given scale and translation.)#"  , py::arg("On")=static_cast< const bool>(false)
          )
        .def("Perspective",
             (bool (HLRAlgo_Projector::*)() const) static_cast<bool (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::Perspective),
             R"#(Returns True if there is a perspective transformation.)#" 
          )
        .def("Focus",
             (double (HLRAlgo_Projector::*)() const) static_cast<double (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::Focus),
             R"#(Returns the focal length.)#" 
          )
        .def("Transform",
             (void (HLRAlgo_Projector::*)( gp_Vec &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Vec &  ) const>(&HLRAlgo_Projector::Transform),
             R"#()#"  , py::arg("D")
          )
        .def("Transform",
             (void (HLRAlgo_Projector::*)( gp_Pnt &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Pnt &  ) const>(&HLRAlgo_Projector::Transform),
             R"#()#"  , py::arg("Pnt")
          )
        .def("Project",
             (void (HLRAlgo_Projector::*)(  const gp_Pnt & ,  gp_Pnt2d &  ) const) static_cast<void (HLRAlgo_Projector::*)(  const gp_Pnt & ,  gp_Pnt2d &  ) const>(&HLRAlgo_Projector::Project),
             R"#(Transform and apply perspective if needed.)#"  , py::arg("P"),  py::arg("Pout")
          )
        .def("Project",
             (void (HLRAlgo_Projector::*)(  const gp_Pnt & ,   const gp_Vec & ,  gp_Pnt2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRAlgo_Projector::*)(  const gp_Pnt & ,   const gp_Vec & ,  gp_Pnt2d & ,  gp_Vec2d &  ) const>(&HLRAlgo_Projector::Project),
             R"#(Transform and apply perspective if needed.)#"  , py::arg("P"),  py::arg("D1"),  py::arg("Pout"),  py::arg("D1out")
          )
        .def("Shoot",
             (gp_Lin (HLRAlgo_Projector::*)(  const double ,   const double  ) const) static_cast<gp_Lin (HLRAlgo_Projector::*)(  const double ,   const double  ) const>(&HLRAlgo_Projector::Shoot),
             R"#(return a line going through the eye towards the 2d point <X,Y>.)#"  , py::arg("X"),  py::arg("Y")
          )
        .def("Directions",
             (void (HLRAlgo_Projector::*)( gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const>(&HLRAlgo_Projector::Directions),
             R"#()#"  , py::arg("D1"),  py::arg("D2"),  py::arg("D3")
          )
        .def("Perspective",
             (bool (HLRAlgo_Projector::*)() const) static_cast<bool (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::Perspective),
             R"#(Returns True if there is a perspective transformation.)#" 
          )
        .def("Focus",
             (double (HLRAlgo_Projector::*)() const) static_cast<double (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::Focus),
             R"#(Returns the focal length.)#" 
          )
        .def("Transform",
             (void (HLRAlgo_Projector::*)( gp_Vec &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Vec &  ) const>(&HLRAlgo_Projector::Transform),
             R"#()#"  , py::arg("D")
          )
        .def("Transform",
             (void (HLRAlgo_Projector::*)( gp_Pnt &  ) const) static_cast<void (HLRAlgo_Projector::*)( gp_Pnt &  ) const>(&HLRAlgo_Projector::Transform),
             R"#()#"  , py::arg("Pnt")
          )
    // methods using call by reference i.s.o. return
        .def("Project",
             []( HLRAlgo_Projector &self ,  const gp_Pnt & P ){
                 double  X;
                double  Y;
                double  Z;

                 self.Project(P,X,Y,Z);
                 return std::make_tuple(X,Y,Z); },
             R"#(Transform and apply perspective if needed.)#"  , py::arg("P")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Transformation",
             ( const gp_Trsf & (HLRAlgo_Projector::*)() const) static_cast< const gp_Trsf & (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::Transformation),
             R"#(Returns the active transformation.)#"
             
         )
       .def("InvertedTransformation",
             ( const gp_Trsf & (HLRAlgo_Projector::*)() const) static_cast< const gp_Trsf & (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::InvertedTransformation),
             R"#(Returns the active inverted transformation.)#"
             
         )
       .def("FullTransformation",
             ( const gp_Trsf & (HLRAlgo_Projector::*)() const) static_cast< const gp_Trsf & (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::FullTransformation),
             R"#(Returns the original transformation.)#"
             
         )
       .def("InvertedTransformation",
             ( const gp_Trsf & (HLRAlgo_Projector::*)() const) static_cast< const gp_Trsf & (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::InvertedTransformation),
             R"#(Returns the active inverted transformation.)#"
             
         )
       .def("FullTransformation",
             ( const gp_Trsf & (HLRAlgo_Projector::*)() const) static_cast< const gp_Trsf & (HLRAlgo_Projector::*)() const>(&HLRAlgo_Projector::FullTransformation),
             R"#(Returns the original transformation.)#"
             
         )
;

    // Class HLRAlgo_TriangleData from ./opencascade/HLRAlgo_TriangleData.hxx
    klass = m.attr("HLRAlgo_TriangleData");

    // default constructor
    register_default_constructor<HLRAlgo_TriangleData , shared_ptr<HLRAlgo_TriangleData>>(m,"HLRAlgo_TriangleData");

    // nested enums

    static_cast<py::class_<HLRAlgo_TriangleData , shared_ptr<HLRAlgo_TriangleData>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Node1", &HLRAlgo_TriangleData::Node1)
        .def_readwrite("Node2", &HLRAlgo_TriangleData::Node2)
        .def_readwrite("Node3", &HLRAlgo_TriangleData::Node3)
        .def_readwrite("Flags", &HLRAlgo_TriangleData::Flags)
    // methods returning by ref wrapped as properties
;

    // Class HLRAlgo_WiresBlock from ./opencascade/HLRAlgo_WiresBlock.hxx
    klass = m.attr("HLRAlgo_WiresBlock");


    // nested enums

    static_cast<py::class_<HLRAlgo_WiresBlock ,opencascade::handle<HLRAlgo_WiresBlock>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int >()  , py::arg("NbWires") )
    // custom constructors
    // methods
        .def("NbWires",
             (int (HLRAlgo_WiresBlock::*)() const) static_cast<int (HLRAlgo_WiresBlock::*)() const>(&HLRAlgo_WiresBlock::NbWires),
             R"#()#" 
          )
        .def("Set",
             (void (HLRAlgo_WiresBlock::*)(  const int ,   const handle<HLRAlgo_EdgesBlock> &  ) ) static_cast<void (HLRAlgo_WiresBlock::*)(  const int ,   const handle<HLRAlgo_EdgesBlock> &  ) >(&HLRAlgo_WiresBlock::Set),
             R"#()#"  , py::arg("I"),  py::arg("W")
          )
        .def("Wire",
             (handle<HLRAlgo_EdgesBlock> & (HLRAlgo_WiresBlock::*)(  const int  ) ) static_cast<handle<HLRAlgo_EdgesBlock> & (HLRAlgo_WiresBlock::*)(  const int  ) >(&HLRAlgo_WiresBlock::Wire),
             R"#()#"  , py::arg("I")
          )
        .def("UpdateMinMax",
             (void (HLRAlgo_WiresBlock::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (HLRAlgo_WiresBlock::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRAlgo_WiresBlock::UpdateMinMax),
             R"#()#"  , py::arg("theMinMaxes")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRAlgo_WiresBlock::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRAlgo_WiresBlock::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("MinMax",
             (HLRAlgo_EdgesBlock::MinMaxIndices & (HLRAlgo_WiresBlock::*)() ) static_cast<HLRAlgo_EdgesBlock::MinMaxIndices & (HLRAlgo_WiresBlock::*)() >(&HLRAlgo_WiresBlock::MinMax),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRAlgo_WiresBlock::*)() const) static_cast< const handle<Standard_Type> & (HLRAlgo_WiresBlock::*)() const>(&HLRAlgo_WiresBlock::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/HLRAlgo.hxx
// ./opencascade/HLRAlgo_BiPoint.hxx
// ./opencascade/HLRAlgo_Coincidence.hxx
// ./opencascade/HLRAlgo_EdgeIterator.hxx
// ./opencascade/HLRAlgo_EdgeStatus.hxx
// ./opencascade/HLRAlgo_EdgesBlock.hxx
// ./opencascade/HLRAlgo_Interference.hxx
// ./opencascade/HLRAlgo_Intersection.hxx
// ./opencascade/HLRAlgo_PolyAlgo.hxx
// ./opencascade/HLRAlgo_PolyData.hxx
// ./opencascade/HLRAlgo_PolyHidingData.hxx
// ./opencascade/HLRAlgo_PolyInternalData.hxx
// ./opencascade/HLRAlgo_PolyInternalNode.hxx
// ./opencascade/HLRAlgo_PolyInternalSegment.hxx
// ./opencascade/HLRAlgo_PolyMask.hxx
// ./opencascade/HLRAlgo_PolyShellData.hxx
// ./opencascade/HLRAlgo_Projector.hxx
// ./opencascade/HLRAlgo_TriangleData.hxx
// ./opencascade/HLRAlgo_WiresBlock.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
