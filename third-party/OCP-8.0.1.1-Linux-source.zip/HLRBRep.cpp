
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Edge.hxx>
#include <HLRBRep_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_IntConicCurveOfCInter.hxx>
#include <HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter.hxx>
#include <Geom_BSplineCurve.hxx>
#include <HLRAlgo_Projector.hxx>
#include <BRepTopAdaptor_TopolTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_AreaLimit.hxx>
#include <HLRBRep_VertexList.hxx>
#include <HLRAlgo_Intersection.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Dir.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_EdgeInterferenceTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_Data.hxx>
#include <gp_Dir.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_TheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRAlgo_WiresBlock.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_FaceData.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_Algo.hxx>
#include <HLRBRep_Data.hxx>
#include <HLRBRep_EdgeData.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <HLRBRep_Data.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Bnd_BoundSortBox.hxx>
#include <Bnd_Box.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Lin.hxx>
#include <gp_Parab.hxx>
#include <HLRBRep_LineTool.hxx>
#include <HLRBRep_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <HLRBRep_TheExactInterCSurf.hxx>
#include <HLRBRep_TheInterferenceOfInterCSurf.hxx>
#include <HLRBRep_ThePolygonOfInterCSurf.hxx>
#include <HLRBRep_ThePolygonToolOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronToolOfInterCSurf.hxx>
#include <HLRBRep_TheQuadCurvExactInterCSurf.hxx>
#include <HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf.hxx>
#include <IntAna_IntConicQuad.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <HLRBRep_Data.hxx>
#include <HLRTopoBRep_OutLiner.hxx>
#include <HLRBRep_EdgeData.hxx>
#include <HLRBRep_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRAlgo_PolyInternalData.hxx>
#include <HLRAlgo_EdgeStatus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_PolyAlgo.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRTopoBRep_OutLiner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <HLRBRep_Data.hxx>
#include <HLRTopoBRep_OutLiner.hxx>
#include <HLRAlgo_Projector.hxx>
#include <TopoDS_Face.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <HLRBRep_LineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <HLRBRep_LineTool.hxx>
#include <math_FunctionSetRoot.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_ThePolygonOfInterCSurf.hxx>
#include <HLRBRep_ThePolygonToolOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronToolOfInterCSurf.hxx>
#include <Bnd_BoundSortBox.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IntCurve_IConicTool.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter.hxx>
#include <IntRes2d_Domain.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <IntRes2d_Domain.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <HLRBRep_LineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <gp_Lin.hxx>
#include <HLRBRep_LineTool.hxx>
#include <HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <HLRBRep_LineTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <HLRBRep.hxx>
#include <HLRBRep_Algo.hxx>
#include <HLRBRep_AreaLimit.hxx>
#include <HLRBRep_BCurveTool.hxx>
#include <HLRBRep_BiPnt2D.hxx>
#include <HLRBRep_BiPoint.hxx>
#include <HLRBRep_BSurfaceTool.hxx>
#include <HLRBRep_CInter.hxx>
#include <HLRBRep_CLProps.hxx>
#include <HLRBRep_CLPropsATool.hxx>
#include <HLRBRep_Curve.hxx>
#include <HLRBRep_CurveTool.hxx>
#include <HLRBRep_Data.hxx>
#include <HLRBRep_EdgeBuilder.hxx>
#include <HLRBRep_EdgeData.hxx>
#include <HLRBRep_EdgeFaceTool.hxx>
#include <HLRBRep_EdgeIList.hxx>
#include <HLRBRep_EdgeInterferenceTool.hxx>
#include <HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_FaceData.hxx>
#include <HLRBRep_FaceIterator.hxx>
#include <HLRBRep_Hider.hxx>
#include <HLRBRep_HLRToShape.hxx>
#include <HLRBRep_IntConicCurveOfCInter.hxx>
#include <HLRBRep_InterCSurf.hxx>
#include <HLRBRep_InternalAlgo.hxx>
#include <HLRBRep_Intersector.hxx>
#include <HLRBRep_LineTool.hxx>
#include <HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter.hxx>
#include <HLRBRep_PCLocFOfTheLocateExtPCOfTheProjPCurOfCInter.hxx>
#include <HLRBRep_PolyAlgo.hxx>
#include <HLRBRep_PolyHLRToShape.hxx>
#include <HLRBRep_ShapeBounds.hxx>
#include <HLRBRep_ShapeToHLR.hxx>
#include <HLRBRep_SLProps.hxx>
#include <HLRBRep_SLPropsATool.hxx>
#include <HLRBRep_Surface.hxx>
#include <HLRBRep_SurfaceTool.hxx>
#include <HLRBRep_TheCSFunctionOfInterCSurf.hxx>
#include <HLRBRep_TheCurveLocatorOfTheProjPCurOfCInter.hxx>
#include <HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_TheExactInterCSurf.hxx>
#include <HLRBRep_TheIntConicCurveOfCInter.hxx>
#include <HLRBRep_TheInterferenceOfInterCSurf.hxx>
#include <HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter.hxx>
#include <HLRBRep_TheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_TheLocateExtPCOfTheProjPCurOfCInter.hxx>
#include <HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx>
#include <HLRBRep_ThePolygonOfInterCSurf.hxx>
#include <HLRBRep_ThePolygonToolOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronOfInterCSurf.hxx>
#include <HLRBRep_ThePolyhedronToolOfInterCSurf.hxx>
#include <HLRBRep_TheProjPCurOfCInter.hxx>
#include <HLRBRep_TheQuadCurvExactInterCSurf.hxx>
#include <HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf.hxx>
#include <HLRBRep_TypeDef.hxx>
#include <HLRBRep_TypeOfResultingEdge.hxx>
#include <HLRBRep_VertexList.hxx>

// template related includes

// ./opencascade/HLRBRep_CLProps.hxx
#include "GeomLProp_tmpl.hxx"

// ./opencascade/HLRBRep_PCLocFOfTheLocateExtPCOfTheProjPCurOfCInter.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/HLRBRep_SLProps.hxx
#include "GeomLProp_tmpl.hxx"

// ./opencascade/HLRBRep_TheCurveLocatorOfTheProjPCurOfCInter.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/HLRBRep_TheLocateExtPCOfTheProjPCurOfCInter.hxx
#include "Extrema_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_HLRBRep(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("HLRBRep"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class HLRBRep from ./opencascade/HLRBRep.hxx
    klass = m.attr("HLRBRep");

    // default constructor
    register_default_constructor<HLRBRep , shared_ptr<HLRBRep>>(m,"HLRBRep");

    // nested enums

    static_cast<py::class_<HLRBRep , shared_ptr<HLRBRep>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MakeEdge_s",
                    (TopoDS_Edge (*)(  const HLRBRep_Curve & ,   const double ,   const double  ) ) static_cast<TopoDS_Edge (*)(  const HLRBRep_Curve & ,   const double ,   const double  ) >(&HLRBRep::MakeEdge),
                    R"#()#"  , py::arg("ec"),  py::arg("U1"),  py::arg("U2")
          )
        .def_static("MakeEdge3d_s",
                    (TopoDS_Edge (*)(  const HLRBRep_Curve & ,   const double ,   const double  ) ) static_cast<TopoDS_Edge (*)(  const HLRBRep_Curve & ,   const double ,   const double  ) >(&HLRBRep::MakeEdge3d),
                    R"#()#"  , py::arg("ec"),  py::arg("U1"),  py::arg("U2")
          )
    // static methods using call by reference i.s.o. return
        .def_static("PolyHLRAngleAndDeflection_s",
            []( const double InAngl ){
                double  OutAngl;
                double  OutDefl;

                HLRBRep::PolyHLRAngleAndDeflection(InAngl,OutAngl,OutDefl);
                
return std::make_tuple(OutAngl,OutDefl); },
            R"#()#"  , py::arg("InAngl")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_AreaLimit from ./opencascade/HLRBRep_AreaLimit.hxx
    klass = m.attr("HLRBRep_AreaLimit");


    // nested enums

    static_cast<py::class_<HLRBRep_AreaLimit ,opencascade::handle<HLRBRep_AreaLimit>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const HLRAlgo_Intersection &, const bool, const bool, const TopAbs_State, const TopAbs_State, const TopAbs_State, const TopAbs_State >()  , py::arg("V"),  py::arg("Boundary"),  py::arg("Interference"),  py::arg("StateBefore"),  py::arg("StateAfter"),  py::arg("EdgeBefore"),  py::arg("EdgeAfter") )
    // custom constructors
    // methods
        .def("StateBefore",
             (void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) >(&HLRBRep_AreaLimit::StateBefore),
             R"#()#"  , py::arg("St")
          )
        .def("StateAfter",
             (void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) >(&HLRBRep_AreaLimit::StateAfter),
             R"#()#"  , py::arg("St")
          )
        .def("EdgeBefore",
             (void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) >(&HLRBRep_AreaLimit::EdgeBefore),
             R"#()#"  , py::arg("St")
          )
        .def("EdgeAfter",
             (void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const TopAbs_State  ) >(&HLRBRep_AreaLimit::EdgeAfter),
             R"#()#"  , py::arg("St")
          )
        .def("Previous",
             (void (HLRBRep_AreaLimit::*)(  const handle<HLRBRep_AreaLimit> &  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const handle<HLRBRep_AreaLimit> &  ) >(&HLRBRep_AreaLimit::Previous),
             R"#()#"  , py::arg("P")
          )
        .def("Next",
             (void (HLRBRep_AreaLimit::*)(  const handle<HLRBRep_AreaLimit> &  ) ) static_cast<void (HLRBRep_AreaLimit::*)(  const handle<HLRBRep_AreaLimit> &  ) >(&HLRBRep_AreaLimit::Next),
             R"#()#"  , py::arg("N")
          )
        .def("IsBoundary",
             (bool (HLRBRep_AreaLimit::*)() const) static_cast<bool (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::IsBoundary),
             R"#()#" 
          )
        .def("IsInterference",
             (bool (HLRBRep_AreaLimit::*)() const) static_cast<bool (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::IsInterference),
             R"#()#" 
          )
        .def("StateBefore",
             (TopAbs_State (HLRBRep_AreaLimit::*)() const) static_cast<TopAbs_State (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::StateBefore),
             R"#()#" 
          )
        .def("StateAfter",
             (TopAbs_State (HLRBRep_AreaLimit::*)() const) static_cast<TopAbs_State (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::StateAfter),
             R"#()#" 
          )
        .def("EdgeBefore",
             (TopAbs_State (HLRBRep_AreaLimit::*)() const) static_cast<TopAbs_State (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::EdgeBefore),
             R"#()#" 
          )
        .def("EdgeAfter",
             (TopAbs_State (HLRBRep_AreaLimit::*)() const) static_cast<TopAbs_State (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::EdgeAfter),
             R"#()#" 
          )
        .def("Previous",
             (handle<HLRBRep_AreaLimit> (HLRBRep_AreaLimit::*)() const) static_cast<handle<HLRBRep_AreaLimit> (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::Previous),
             R"#()#" 
          )
        .def("Next",
             (handle<HLRBRep_AreaLimit> (HLRBRep_AreaLimit::*)() const) static_cast<handle<HLRBRep_AreaLimit> (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::Next),
             R"#()#" 
          )
        .def("Clear",
             (void (HLRBRep_AreaLimit::*)() ) static_cast<void (HLRBRep_AreaLimit::*)() >(&HLRBRep_AreaLimit::Clear),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRBRep_AreaLimit::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRBRep_AreaLimit::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Vertex",
             ( const HLRAlgo_Intersection & (HLRBRep_AreaLimit::*)() const) static_cast< const HLRAlgo_Intersection & (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::Vertex),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRBRep_AreaLimit::*)() const) static_cast< const handle<Standard_Type> & (HLRBRep_AreaLimit::*)() const>(&HLRBRep_AreaLimit::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRBRep_BCurveTool from ./opencascade/HLRBRep_BCurveTool.hxx
    klass = m.attr("HLRBRep_BCurveTool");

    // default constructor
    register_default_constructor<HLRBRep_BCurveTool , shared_ptr<HLRBRep_BCurveTool>>(m,"HLRBRep_BCurveTool");

    // nested enums

    static_cast<py::class_<HLRBRep_BCurveTool , shared_ptr<HLRBRep_BCurveTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const BRepAdaptor_Curve &  ) ) static_cast<double (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::FirstParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const BRepAdaptor_Curve &  ) ) static_cast<double (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::LastParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const BRepAdaptor_Curve &  ) ) static_cast<GeomAbs_Shape (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Continuity),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const BRepAdaptor_Curve & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const BRepAdaptor_Curve & ,   const GeomAbs_Shape  ) >(&HLRBRep_BCurveTool::NbIntervals),
                    R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(myclass) >= <S>)#"  , py::arg("C"),  py::arg("S")
          )
        .def_static("Intervals_s",
                    (void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_BCurveTool::Intervals),
                    R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("C"),  py::arg("T"),  py::arg("S")
          )
        .def_static("IsClosed_s",
                    (bool (*)(  const BRepAdaptor_Curve &  ) ) static_cast<bool (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::IsClosed),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const BRepAdaptor_Curve &  ) ) static_cast<bool (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::IsPeriodic),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Period_s",
                    (double (*)(  const BRepAdaptor_Curve &  ) ) static_cast<double (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Period),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const BRepAdaptor_Curve & ,   const double  ) ) static_cast<gp_Pnt (*)(  const BRepAdaptor_Curve & ,   const double  ) >(&HLRBRep_BCurveTool::Value),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U")
          )
        .def_static("D0_s",
                    (void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt &  ) >(&HLRBRep_BCurveTool::D0),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) >(&HLRBRep_BCurveTool::D1),
                    R"#(Computes the point of parameter U on the curve with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def_static("D2_s",
                    (void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_BCurveTool::D2),
                    R"#(Returns the point P of parameter U, the first and second derivatives V1 and V2. Raised if the continuity of the current interval is not C2.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def_static("D3_s",
                    (void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_BCurveTool::D3),
                    R"#(Returns the point P of parameter U, the first, the second and the third derivative. Raised if the continuity of the current interval is not C3.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("V3")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const BRepAdaptor_Curve & ,   const double ,   const int  ) ) static_cast<gp_Vec (*)(  const BRepAdaptor_Curve & ,   const double ,   const int  ) >(&HLRBRep_BCurveTool::DN),
                    R"#(The returned vector gives the value of the derivative for the order of derivation N. Raised if the continuity of the current interval is not CN. Raised if N < 1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("N")
          )
        .def_static("Resolution_s",
                    (double (*)(  const BRepAdaptor_Curve & ,   const double  ) ) static_cast<double (*)(  const BRepAdaptor_Curve & ,   const double  ) >(&HLRBRep_BCurveTool::Resolution),
                    R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("C"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const BRepAdaptor_Curve &  ) ) static_cast<GeomAbs_CurveType (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::GetType),
                    R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("C")
          )
        .def_static("Line_s",
                    (gp_Lin (*)(  const BRepAdaptor_Curve &  ) ) static_cast<gp_Lin (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Line),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Circle_s",
                    (gp_Circ (*)(  const BRepAdaptor_Curve &  ) ) static_cast<gp_Circ (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Circle),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Ellipse_s",
                    (gp_Elips (*)(  const BRepAdaptor_Curve &  ) ) static_cast<gp_Elips (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Ellipse),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr (*)(  const BRepAdaptor_Curve &  ) ) static_cast<gp_Hypr (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Hyperbola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Parabola_s",
                    (gp_Parab (*)(  const BRepAdaptor_Curve &  ) ) static_cast<gp_Parab (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Parabola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierCurve> (*)(  const BRepAdaptor_Curve &  ) ) static_cast<handle<Geom_BezierCurve> (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Bezier),
                    R"#()#"  , py::arg("C")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineCurve> (*)(  const BRepAdaptor_Curve &  ) ) static_cast<handle<Geom_BSplineCurve> (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::BSpline),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Degree_s",
                    (int (*)(  const BRepAdaptor_Curve &  ) ) static_cast<int (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::Degree),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsRational_s",
                    (bool (*)(  const BRepAdaptor_Curve &  ) ) static_cast<bool (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::IsRational),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbPoles_s",
                    (int (*)(  const BRepAdaptor_Curve &  ) ) static_cast<int (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::NbPoles),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbKnots_s",
                    (int (*)(  const BRepAdaptor_Curve &  ) ) static_cast<int (*)(  const BRepAdaptor_Curve &  ) >(&HLRBRep_BCurveTool::NbKnots),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Poles_s",
                    (void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<gp_Pnt> &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<gp_Pnt> &  ) >(&HLRBRep_BCurveTool::Poles),
                    R"#()#"  , py::arg("C"),  py::arg("T")
          )
        .def_static("PolesAndWeights_s",
                    (void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<double> &  ) ) static_cast<void (*)(  const BRepAdaptor_Curve & ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<double> &  ) >(&HLRBRep_BCurveTool::PolesAndWeights),
                    R"#()#"  , py::arg("C"),  py::arg("T"),  py::arg("W")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const BRepAdaptor_Curve & ,   const double ,   const double  ) ) static_cast<int (*)(  const BRepAdaptor_Curve & ,   const double ,   const double  ) >(&HLRBRep_BCurveTool::NbSamples),
                    R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_BSurfaceTool from ./opencascade/HLRBRep_BSurfaceTool.hxx
    klass = m.attr("HLRBRep_BSurfaceTool");

    // default constructor
    register_default_constructor<HLRBRep_BSurfaceTool , shared_ptr<HLRBRep_BSurfaceTool>>(m,"HLRBRep_BSurfaceTool");

    // nested enums

    static_cast<py::class_<HLRBRep_BSurfaceTool , shared_ptr<HLRBRep_BSurfaceTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstUParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::FirstUParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("FirstVParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::FirstVParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("LastUParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::LastUParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("LastVParameter_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::LastVParameter),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbUIntervals_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) >(&HLRBRep_BSurfaceTool::NbUIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("Sh")
          )
        .def_static("NbVIntervals_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const GeomAbs_Shape  ) >(&HLRBRep_BSurfaceTool::NbVIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("Sh")
          )
        .def_static("UIntervals_s",
                    (void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_BSurfaceTool::UIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("T"),  py::arg("Sh")
          )
        .def_static("VIntervals_s",
                    (void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_BSurfaceTool::VIntervals),
                    R"#()#"  , py::arg("S"),  py::arg("T"),  py::arg("Sh")
          )
        .def_static("UTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) >(&HLRBRep_BSurfaceTool::UTrim),
                    R"#(If <First> >= <Last>)#"  , py::arg("S"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def_static("VTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const double  ) >(&HLRBRep_BSurfaceTool::VTrim),
                    R"#(If <First> >= <Last>)#"  , py::arg("S"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def_static("IsUClosed_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsUClosed),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsVClosed_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsVClosed),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsUPeriodic_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsUPeriodic),
                    R"#()#"  , py::arg("S")
          )
        .def_static("UPeriod_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::UPeriod),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsVPeriodic_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsVPeriodic),
                    R"#()#"  , py::arg("S")
          )
        .def_static("VPeriod_s",
                    (double (*)(  const BRepAdaptor_Surface &  ) ) static_cast<double (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::VPeriod),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<gp_Pnt (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&HLRBRep_BSurfaceTool::Value),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v")
          )
        .def_static("D0_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt &  ) >(&HLRBRep_BSurfaceTool::D0),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_BSurfaceTool::D1),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1u"),  py::arg("D1v")
          )
        .def_static("D2_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_BSurfaceTool::D2),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV")
          )
        .def_static("D3_s",
                    (void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_BSurfaceTool::D3),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV"),  py::arg("D3U"),  py::arg("D3V"),  py::arg("D3UUV"),  py::arg("D3UVV")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) ) static_cast<gp_Vec (*)(  const BRepAdaptor_Surface & ,   const double ,   const double ,   const int ,   const int  ) >(&HLRBRep_BSurfaceTool::DN),
                    R"#()#"  , py::arg("S"),  py::arg("u"),  py::arg("v"),  py::arg("Nu"),  py::arg("Nv")
          )
        .def_static("UContinuity_s",
                    (GeomAbs_Shape (*)(  const BRepAdaptor_Surface &  ) ) static_cast<GeomAbs_Shape (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::UContinuity),
                    R"#()#"  , py::arg("S")
          )
        .def_static("VContinuity_s",
                    (GeomAbs_Shape (*)(  const BRepAdaptor_Surface &  ) ) static_cast<GeomAbs_Shape (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::VContinuity),
                    R"#()#"  , py::arg("S")
          )
        .def_static("UDegree_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::UDegree),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbUPoles_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbUPoles),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbUKnots_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbUKnots),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsURational_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsURational),
                    R"#()#"  , py::arg("S")
          )
        .def_static("VDegree_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::VDegree),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbVPoles_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbVPoles),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbVKnots_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbVKnots),
                    R"#()#"  , py::arg("S")
          )
        .def_static("IsVRational_s",
                    (bool (*)(  const BRepAdaptor_Surface &  ) ) static_cast<bool (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::IsVRational),
                    R"#()#"  , py::arg("S")
          )
        .def_static("UResolution_s",
                    (double (*)(  const BRepAdaptor_Surface & ,   const double  ) ) static_cast<double (*)(  const BRepAdaptor_Surface & ,   const double  ) >(&HLRBRep_BSurfaceTool::UResolution),
                    R"#()#"  , py::arg("S"),  py::arg("R3d")
          )
        .def_static("VResolution_s",
                    (double (*)(  const BRepAdaptor_Surface & ,   const double  ) ) static_cast<double (*)(  const BRepAdaptor_Surface & ,   const double  ) >(&HLRBRep_BSurfaceTool::VResolution),
                    R"#()#"  , py::arg("S"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_SurfaceType (*)(  const BRepAdaptor_Surface &  ) ) static_cast<GeomAbs_SurfaceType (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::GetType),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Plane_s",
                    (gp_Pln (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Pln (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Plane),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Cylinder_s",
                    (gp_Cylinder (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Cylinder (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Cylinder),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Cone_s",
                    (gp_Cone (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Cone (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Cone),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Torus_s",
                    (gp_Torus (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Torus (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Torus),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Sphere_s",
                    (gp_Sphere (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Sphere (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Sphere),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierSurface> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Geom_BezierSurface> (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Bezier),
                    R"#()#"  , py::arg("S")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineSurface> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Geom_BSplineSurface> (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::BSpline),
                    R"#()#"  , py::arg("S")
          )
        .def_static("AxeOfRevolution_s",
                    (gp_Ax1 (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Ax1 (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::AxeOfRevolution),
                    R"#()#"  , py::arg("S")
          )
        .def_static("Direction_s",
                    (gp_Dir (*)(  const BRepAdaptor_Surface &  ) ) static_cast<gp_Dir (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::Direction),
                    R"#()#"  , py::arg("S")
          )
        .def_static("BasisCurve_s",
                    (handle<Adaptor3d_Curve> (*)(  const BRepAdaptor_Surface &  ) ) static_cast<handle<Adaptor3d_Curve> (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::BasisCurve),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const BRepAdaptor_Surface &  ) ) static_cast<int (*)(  const BRepAdaptor_Surface &  ) >(&HLRBRep_BSurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("S")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&HLRBRep_BSurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("S"),  py::arg("u1"),  py::arg("u2")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) ) static_cast<int (*)(  const BRepAdaptor_Surface & ,   const double ,   const double  ) >(&HLRBRep_BSurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("S"),  py::arg("v1"),  py::arg("v2")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_BiPnt2D from ./opencascade/HLRBRep_BiPnt2D.hxx
    klass = m.attr("HLRBRep_BiPnt2D");


    // nested enums

    static_cast<py::class_<HLRBRep_BiPnt2D , shared_ptr<HLRBRep_BiPnt2D>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const double, const double, const TopoDS_Shape &, const bool, const bool, const bool, const bool >()  , py::arg("x1"),  py::arg("y1"),  py::arg("x2"),  py::arg("y2"),  py::arg("S"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
        .def(py::init<  const gp_XY &, const gp_XY &, const TopoDS_Shape &, const bool, const bool, const bool, const bool >()  , py::arg("thePoint1"),  py::arg("thePoint2"),  py::arg("S"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
    // custom constructors
    // methods
        .def("Shape",
             (void (HLRBRep_BiPnt2D::*)(  const TopoDS_Shape &  ) ) static_cast<void (HLRBRep_BiPnt2D::*)(  const TopoDS_Shape &  ) >(&HLRBRep_BiPnt2D::Shape),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1Line",
             (bool (HLRBRep_BiPnt2D::*)() const) static_cast<bool (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::Rg1Line),
             R"#()#" 
          )
        .def("Rg1Line",
             (void (HLRBRep_BiPnt2D::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPnt2D::*)(  const bool  ) >(&HLRBRep_BiPnt2D::Rg1Line),
             R"#()#"  , py::arg("B")
          )
        .def("RgNLine",
             (bool (HLRBRep_BiPnt2D::*)() const) static_cast<bool (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::RgNLine),
             R"#()#" 
          )
        .def("RgNLine",
             (void (HLRBRep_BiPnt2D::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPnt2D::*)(  const bool  ) >(&HLRBRep_BiPnt2D::RgNLine),
             R"#()#"  , py::arg("B")
          )
        .def("OutLine",
             (bool (HLRBRep_BiPnt2D::*)() const) static_cast<bool (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::OutLine),
             R"#()#" 
          )
        .def("OutLine",
             (void (HLRBRep_BiPnt2D::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPnt2D::*)(  const bool  ) >(&HLRBRep_BiPnt2D::OutLine),
             R"#()#"  , py::arg("B")
          )
        .def("IntLine",
             (bool (HLRBRep_BiPnt2D::*)() const) static_cast<bool (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::IntLine),
             R"#()#" 
          )
        .def("IntLine",
             (void (HLRBRep_BiPnt2D::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPnt2D::*)(  const bool  ) >(&HLRBRep_BiPnt2D::IntLine),
             R"#()#"  , py::arg("B")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("P1",
             ( const gp_Pnt2d & (HLRBRep_BiPnt2D::*)() const) static_cast< const gp_Pnt2d & (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::P1),
             R"#()#"
             
         )
       .def("P2",
             ( const gp_Pnt2d & (HLRBRep_BiPnt2D::*)() const) static_cast< const gp_Pnt2d & (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::P2),
             R"#()#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (HLRBRep_BiPnt2D::*)() const) static_cast< const TopoDS_Shape & (HLRBRep_BiPnt2D::*)() const>(&HLRBRep_BiPnt2D::Shape),
             R"#()#"
             
         )
;

    // Class HLRBRep_BiPoint from ./opencascade/HLRBRep_BiPoint.hxx
    klass = m.attr("HLRBRep_BiPoint");


    // nested enums

    static_cast<py::class_<HLRBRep_BiPoint , shared_ptr<HLRBRep_BiPoint>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const double, const double, const double, const double, const TopoDS_Shape &, const bool, const bool, const bool, const bool >()  , py::arg("x1"),  py::arg("y1"),  py::arg("z1"),  py::arg("x2"),  py::arg("y2"),  py::arg("z2"),  py::arg("S"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl") )
    // custom constructors
    // methods
        .def("Shape",
             (void (HLRBRep_BiPoint::*)(  const TopoDS_Shape &  ) ) static_cast<void (HLRBRep_BiPoint::*)(  const TopoDS_Shape &  ) >(&HLRBRep_BiPoint::Shape),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1Line",
             (bool (HLRBRep_BiPoint::*)() const) static_cast<bool (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::Rg1Line),
             R"#()#" 
          )
        .def("Rg1Line",
             (void (HLRBRep_BiPoint::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPoint::*)(  const bool  ) >(&HLRBRep_BiPoint::Rg1Line),
             R"#()#"  , py::arg("B")
          )
        .def("RgNLine",
             (bool (HLRBRep_BiPoint::*)() const) static_cast<bool (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::RgNLine),
             R"#()#" 
          )
        .def("RgNLine",
             (void (HLRBRep_BiPoint::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPoint::*)(  const bool  ) >(&HLRBRep_BiPoint::RgNLine),
             R"#()#"  , py::arg("B")
          )
        .def("OutLine",
             (bool (HLRBRep_BiPoint::*)() const) static_cast<bool (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::OutLine),
             R"#()#" 
          )
        .def("OutLine",
             (void (HLRBRep_BiPoint::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPoint::*)(  const bool  ) >(&HLRBRep_BiPoint::OutLine),
             R"#()#"  , py::arg("B")
          )
        .def("IntLine",
             (bool (HLRBRep_BiPoint::*)() const) static_cast<bool (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::IntLine),
             R"#()#" 
          )
        .def("IntLine",
             (void (HLRBRep_BiPoint::*)(  const bool  ) ) static_cast<void (HLRBRep_BiPoint::*)(  const bool  ) >(&HLRBRep_BiPoint::IntLine),
             R"#()#"  , py::arg("B")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("P1",
             ( const gp_Pnt & (HLRBRep_BiPoint::*)() const) static_cast< const gp_Pnt & (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::P1),
             R"#()#"
             
         )
       .def("P2",
             ( const gp_Pnt & (HLRBRep_BiPoint::*)() const) static_cast< const gp_Pnt & (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::P2),
             R"#()#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (HLRBRep_BiPoint::*)() const) static_cast< const TopoDS_Shape & (HLRBRep_BiPoint::*)() const>(&HLRBRep_BiPoint::Shape),
             R"#()#"
             
         )
;

    // Class HLRBRep_CInter from ./opencascade/HLRBRep_CInter.hxx
    klass = m.attr("HLRBRep_CInter");


    // nested enums

    static_cast<py::class_<HLRBRep_CInter , shared_ptr<HLRBRep_CInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetMinNbSamples",
             (void (HLRBRep_CInter::*)(  const int  ) ) static_cast<void (HLRBRep_CInter::*)(  const int  ) >(&HLRBRep_CInter::SetMinNbSamples),
             R"#(Set / get minimum number of points in polygon intersection.)#"  , py::arg("theMinNbSamples")
          )
        .def("GetMinNbSamples",
             (int (HLRBRep_CInter::*)() const) static_cast<int (HLRBRep_CInter::*)() const>(&HLRBRep_CInter::GetMinNbSamples),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_Curve from ./opencascade/HLRBRep_Curve.hxx
    klass = m.attr("HLRBRep_Curve");


    // nested enums

    static_cast<py::class_<HLRBRep_Curve , shared_ptr<HLRBRep_Curve>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Projector",
             (void (HLRBRep_Curve::*)(  const HLRAlgo_Projector *  ) ) static_cast<void (HLRBRep_Curve::*)(  const HLRAlgo_Projector *  ) >(&HLRBRep_Curve::Projector),
             R"#()#"  , py::arg("Proj")
          )
        .def("Curve",
             (void (HLRBRep_Curve::*)(  const TopoDS_Edge &  ) ) static_cast<void (HLRBRep_Curve::*)(  const TopoDS_Edge &  ) >(&HLRBRep_Curve::Curve),
             R"#(Sets the 3D curve to be projected.)#"  , py::arg("E")
          )
        .def("Parameter2d",
             (double (HLRBRep_Curve::*)(  const double  ) const) static_cast<double (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Parameter2d),
             R"#(Returns the parameter on the 2d curve from the parameter on the 3d curve.)#"  , py::arg("P3d")
          )
        .def("Parameter3d",
             (double (HLRBRep_Curve::*)(  const double  ) const) static_cast<double (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Parameter3d),
             R"#(Returns the parameter on the 3d curve from the parameter on the 2d curve.)#"  , py::arg("P2d")
          )
        .def("Update",
             (double (HLRBRep_Curve::*)( double[16] ,  double[16]  ) ) static_cast<double (HLRBRep_Curve::*)( double[16] ,  double[16]  ) >(&HLRBRep_Curve::Update),
             R"#(Update the minmax and the internal data)#"  , py::arg("TotMin"),  py::arg("TotMax")
          )
        .def("UpdateMinMax",
             (double (HLRBRep_Curve::*)( double[16] ,  double[16]  ) ) static_cast<double (HLRBRep_Curve::*)( double[16] ,  double[16]  ) >(&HLRBRep_Curve::UpdateMinMax),
             R"#(Update the minmax returns tol for enlarge;)#"  , py::arg("TotMin"),  py::arg("TotMax")
          )
        .def("Z",
             (double (HLRBRep_Curve::*)(  const double  ) const) static_cast<double (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Z),
             R"#(Computes the Z coordinate of the point of parameter U on the curve in the viewing coordinate system)#"  , py::arg("U")
          )
        .def("Value3D",
             (gp_Pnt (HLRBRep_Curve::*)(  const double  ) const) static_cast<gp_Pnt (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Value3D),
             R"#(Computes the 3D point of parameter U on the curve.)#"  , py::arg("U")
          )
        .def("D0",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt &  ) const>(&HLRBRep_Curve::D0),
             R"#(Computes the 3D point of parameter U on the curve.)#"  , py::arg("U"),  py::arg("P")
          )
        .def("D1",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) const>(&HLRBRep_Curve::D1),
             R"#(Computes the point of parameter U on the curve with its first derivative.)#"  , py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def("Tangent",
             (void (HLRBRep_Curve::*)(  const bool ,  gp_Pnt2d & ,  gp_Dir2d &  ) const) static_cast<void (HLRBRep_Curve::*)(  const bool ,  gp_Pnt2d & ,  gp_Dir2d &  ) const>(&HLRBRep_Curve::Tangent),
             R"#(Depending on <AtStart> computes the 2D point and tangent on the curve at sart (or at end). If the first derivative is null look after at start (or before at end) with the second derivative.)#"  , py::arg("AtStart"),  py::arg("P"),  py::arg("D")
          )
        .def("FirstParameter",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (HLRBRep_Curve::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (HLRBRep_Curve::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Curve::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Curve::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (HLRBRep_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&HLRBRep_Curve::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("IsClosed",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Period),
             R"#()#" 
          )
        .def("Value",
             (gp_Pnt2d (HLRBRep_Curve::*)(  const double  ) const) static_cast<gp_Pnt2d (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Value),
             R"#(Computes the point of parameter U on the curve.)#"  , py::arg("U")
          )
        .def("D0",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d &  ) const>(&HLRBRep_Curve::D0),
             R"#(Computes the point of parameter U on the curve.)#"  , py::arg("U"),  py::arg("P")
          )
        .def("D1",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) const>(&HLRBRep_Curve::D1),
             R"#(Computes the point of parameter U on the curve with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def("D2",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const>(&HLRBRep_Curve::D2),
             R"#(Raised if the continuity of the current interval is not C2.)#"  , py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def("D3",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) const>(&HLRBRep_Curve::D3),
             R"#(Returns the point P of parameter U, the first, the second and the third derivative. Raised if the continuity of the current interval is not C3.)#"  , py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("V3")
          )
        .def("DN",
             (gp_Vec2d (HLRBRep_Curve::*)(  const double ,   const int  ) const) static_cast<gp_Vec2d (HLRBRep_Curve::*)(  const double ,   const int  ) const>(&HLRBRep_Curve::DN),
             R"#(The returned vector gives the value of the derivative for the order of derivation N. Raised if the continuity of the current interval is not CN. Raised if N < 1.)#"  , py::arg("U"),  py::arg("N")
          )
        .def("Resolution",
             (double (HLRBRep_Curve::*)(  const double  ) const) static_cast<double (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Resolution),
             R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (HLRBRep_Curve::*)() const) static_cast<GeomAbs_CurveType (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::GetType),
             R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#" 
          )
        .def("Line",
             (gp_Lin2d (HLRBRep_Curve::*)() const) static_cast<gp_Lin2d (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ2d (HLRBRep_Curve::*)() const) static_cast<gp_Circ2d (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips2d (HLRBRep_Curve::*)() const) static_cast<gp_Elips2d (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr2d (HLRBRep_Curve::*)() const) static_cast<gp_Hypr2d (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab2d (HLRBRep_Curve::*)() const) static_cast<gp_Parab2d (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Parabola),
             R"#()#" 
          )
        .def("IsRational",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsRational),
             R"#()#" 
          )
        .def("Degree",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Degree),
             R"#()#" 
          )
        .def("NbPoles",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::NbPoles),
             R"#()#" 
          )
        .def("Poles",
             (void (HLRBRep_Curve::*)( NCollection_Array1<gp_Pnt2d> &  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<gp_Pnt2d> &  ) const>(&HLRBRep_Curve::Poles),
             R"#()#"  , py::arg("TP")
          )
        .def("Poles",
             (void (HLRBRep_Curve::*)(  const handle<Geom_BSplineCurve> & ,  NCollection_Array1<gp_Pnt2d> &  ) const) static_cast<void (HLRBRep_Curve::*)(  const handle<Geom_BSplineCurve> & ,  NCollection_Array1<gp_Pnt2d> &  ) const>(&HLRBRep_Curve::Poles),
             R"#()#"  , py::arg("aCurve"),  py::arg("TP")
          )
        .def("PolesAndWeights",
             (void (HLRBRep_Curve::*)( NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> &  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> &  ) const>(&HLRBRep_Curve::PolesAndWeights),
             R"#()#"  , py::arg("TP"),  py::arg("TW")
          )
        .def("PolesAndWeights",
             (void (HLRBRep_Curve::*)(  const handle<Geom_BSplineCurve> & ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> &  ) const) static_cast<void (HLRBRep_Curve::*)(  const handle<Geom_BSplineCurve> & ,  NCollection_Array1<gp_Pnt2d> & ,  NCollection_Array1<double> &  ) const>(&HLRBRep_Curve::PolesAndWeights),
             R"#()#"  , py::arg("aCurve"),  py::arg("TP"),  py::arg("TW")
          )
        .def("NbKnots",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::NbKnots),
             R"#()#" 
          )
        .def("Knots",
             (void (HLRBRep_Curve::*)( NCollection_Array1<double> &  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<double> &  ) const>(&HLRBRep_Curve::Knots),
             R"#()#"  , py::arg("kn")
          )
        .def("Multiplicities",
             (void (HLRBRep_Curve::*)( NCollection_Array1<int> &  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<int> &  ) const>(&HLRBRep_Curve::Multiplicities),
             R"#()#"  , py::arg("mu")
          )
        .def("Value3D",
             (gp_Pnt (HLRBRep_Curve::*)(  const double  ) const) static_cast<gp_Pnt (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Value3D),
             R"#(Computes the 3D point of parameter U on the curve.)#"  , py::arg("U")
          )
        .def("D0",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt &  ) const>(&HLRBRep_Curve::D0),
             R"#(Computes the 3D point of parameter U on the curve.)#"  , py::arg("U"),  py::arg("P")
          )
        .def("D1",
             (void (HLRBRep_Curve::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Curve::*)(  const double ,  gp_Pnt & ,  gp_Vec &  ) const>(&HLRBRep_Curve::D1),
             R"#(Computes the point of parameter U on the curve with its first derivative.)#"  , py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def("FirstParameter",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (HLRBRep_Curve::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (HLRBRep_Curve::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Curve::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Curve::NbIntervals),
             R"#(If necessary, breaks the curve in intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (HLRBRep_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (HLRBRep_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&HLRBRep_Curve::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("Tab"),  py::arg("Sh")
          )
        .def("IsClosed",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (HLRBRep_Curve::*)() const) static_cast<double (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Period),
             R"#()#" 
          )
        .def("Value",
             (gp_Pnt2d (HLRBRep_Curve::*)(  const double  ) const) static_cast<gp_Pnt2d (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Value),
             R"#(Computes the point of parameter U on the curve.)#"  , py::arg("U")
          )
        .def("Resolution",
             (double (HLRBRep_Curve::*)(  const double  ) const) static_cast<double (HLRBRep_Curve::*)(  const double  ) const>(&HLRBRep_Curve::Resolution),
             R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (HLRBRep_Curve::*)() const) static_cast<GeomAbs_CurveType (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::GetType),
             R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#" 
          )
        .def("Degree",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::Degree),
             R"#()#" 
          )
        .def("NbPoles",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::NbPoles),
             R"#()#" 
          )
        .def("NbKnots",
             (int (HLRBRep_Curve::*)() const) static_cast<int (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::NbKnots),
             R"#()#" 
          )
        .def("IsRational",
             (bool (HLRBRep_Curve::*)() const) static_cast<bool (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::IsRational),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Curve",
             (BRepAdaptor_Curve & (HLRBRep_Curve::*)() ) static_cast<BRepAdaptor_Curve & (HLRBRep_Curve::*)() >(&HLRBRep_Curve::Curve),
             R"#(Returns the 3D curve.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("GetCurve",
             ( const BRepAdaptor_Curve & (HLRBRep_Curve::*)() const) static_cast< const BRepAdaptor_Curve & (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::GetCurve),
             R"#(Returns the 3D curve.)#"
             
         )
       .def("Curve",
             (BRepAdaptor_Curve & (HLRBRep_Curve::*)() ) static_cast<BRepAdaptor_Curve & (HLRBRep_Curve::*)() >(&HLRBRep_Curve::Curve),
             R"#(Returns the 3D curve.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("GetCurve",
             ( const BRepAdaptor_Curve & (HLRBRep_Curve::*)() const) static_cast< const BRepAdaptor_Curve & (HLRBRep_Curve::*)() const>(&HLRBRep_Curve::GetCurve),
             R"#(Returns the 3D curve.)#"
             
         )
;

    // Class HLRBRep_CurveTool from ./opencascade/HLRBRep_CurveTool.hxx
    klass = m.attr("HLRBRep_CurveTool");

    // default constructor
    register_default_constructor<HLRBRep_CurveTool , shared_ptr<HLRBRep_CurveTool>>(m,"HLRBRep_CurveTool");

    // nested enums

    static_cast<py::class_<HLRBRep_CurveTool , shared_ptr<HLRBRep_CurveTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const HLRBRep_CurvePtr  ) ) static_cast<double (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::FirstParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const HLRBRep_CurvePtr  ) ) static_cast<double (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::LastParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const HLRBRep_CurvePtr  ) ) static_cast<GeomAbs_Shape (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Continuity),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const HLRBRep_CurvePtr  ) ) static_cast<int (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::NbIntervals),
                    R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(myclass) >= <S>)#"  , py::arg("C")
          )
        .def_static("Intervals_s",
                    (void (*)(  const HLRBRep_CurvePtr ,  NCollection_Array1<double> &  ) ) static_cast<void (*)(  const HLRBRep_CurvePtr ,  NCollection_Array1<double> &  ) >(&HLRBRep_CurveTool::Intervals),
                    R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("C"),  py::arg("T")
          )
        .def_static("IsClosed_s",
                    (bool (*)(  const HLRBRep_CurvePtr  ) ) static_cast<bool (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::IsClosed),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const HLRBRep_CurvePtr  ) ) static_cast<bool (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::IsPeriodic),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Period_s",
                    (double (*)(  const HLRBRep_CurvePtr  ) ) static_cast<double (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Period),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Value_s",
                    (gp_Pnt2d (*)(  const HLRBRep_CurvePtr ,   const double  ) ) static_cast<gp_Pnt2d (*)(  const HLRBRep_CurvePtr ,   const double  ) >(&HLRBRep_CurveTool::Value),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U")
          )
        .def_static("D0_s",
                    (void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d &  ) ) static_cast<void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d &  ) >(&HLRBRep_CurveTool::D0),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) >(&HLRBRep_CurveTool::D1),
                    R"#(Computes the point of parameter U on the curve with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def_static("D2_s",
                    (void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&HLRBRep_CurveTool::D2),
                    R"#(Returns the point P of parameter U, the first and second derivatives V1 and V2. Raised if the continuity of the current interval is not C2.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def_static("D3_s",
                    (void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const HLRBRep_CurvePtr ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&HLRBRep_CurveTool::D3),
                    R"#(Returns the point P of parameter U, the first, the second and the third derivative. Raised if the continuity of the current interval is not C3.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("V3")
          )
        .def_static("DN_s",
                    (gp_Vec2d (*)(  const HLRBRep_CurvePtr ,   const double ,   const int  ) ) static_cast<gp_Vec2d (*)(  const HLRBRep_CurvePtr ,   const double ,   const int  ) >(&HLRBRep_CurveTool::DN),
                    R"#(The returned vector gives the value of the derivative for the order of derivation N. Raised if the continuity of the current interval is not CN. Raised if N < 1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("N")
          )
        .def_static("Resolution_s",
                    (double (*)(  const HLRBRep_CurvePtr ,   const double  ) ) static_cast<double (*)(  const HLRBRep_CurvePtr ,   const double  ) >(&HLRBRep_CurveTool::Resolution),
                    R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("C"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const HLRBRep_CurvePtr  ) ) static_cast<GeomAbs_CurveType (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::GetType),
                    R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("C")
          )
        .def_static("TheType_s",
                    (GeomAbs_CurveType (*)(  const HLRBRep_CurvePtr  ) ) static_cast<GeomAbs_CurveType (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::TheType),
                    R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("C")
          )
        .def_static("Line_s",
                    (gp_Lin2d (*)(  const HLRBRep_CurvePtr  ) ) static_cast<gp_Lin2d (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Line),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Circle_s",
                    (gp_Circ2d (*)(  const HLRBRep_CurvePtr  ) ) static_cast<gp_Circ2d (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Circle),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Ellipse_s",
                    (gp_Elips2d (*)(  const HLRBRep_CurvePtr  ) ) static_cast<gp_Elips2d (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Ellipse),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr2d (*)(  const HLRBRep_CurvePtr  ) ) static_cast<gp_Hypr2d (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Hyperbola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Parabola_s",
                    (gp_Parab2d (*)(  const HLRBRep_CurvePtr  ) ) static_cast<gp_Parab2d (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Parabola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Bezier_s",
                    (handle<Geom2d_BezierCurve> (*)(  const HLRBRep_CurvePtr  ) ) static_cast<handle<Geom2d_BezierCurve> (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Bezier),
                    R"#()#"  , py::arg("C")
          )
        .def_static("BSpline_s",
                    (handle<Geom2d_BSplineCurve> (*)(  const HLRBRep_CurvePtr  ) ) static_cast<handle<Geom2d_BSplineCurve> (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::BSpline),
                    R"#()#"  , py::arg("C")
          )
        .def_static("EpsX_s",
                    (double (*)(  const HLRBRep_CurvePtr  ) ) static_cast<double (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::EpsX),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const HLRBRep_CurvePtr ,   const double ,   const double  ) ) static_cast<int (*)(  const HLRBRep_CurvePtr ,   const double ,   const double  ) >(&HLRBRep_CurveTool::NbSamples),
                    R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const HLRBRep_CurvePtr  ) ) static_cast<int (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::NbSamples),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Degree_s",
                    (int (*)(  const HLRBRep_CurvePtr  ) ) static_cast<int (*)(  const HLRBRep_CurvePtr  ) >(&HLRBRep_CurveTool::Degree),
                    R"#()#"  , py::arg("C")
          )
    // static methods using call by reference i.s.o. return
        .def_static("GetInterval_s",
            []( const HLRBRep_CurvePtr C, const int Index, const NCollection_Array1<double> & Tab ){
                double  U1;
                double  U2;

                HLRBRep_CurveTool::GetInterval(C,Index,Tab,U1,U2);
                
return std::make_tuple(U1,U2); },
            R"#(output the bounds of interval of index <Index> used if Type == Composite.)#"  , py::arg("C"),  py::arg("Index"),  py::arg("Tab")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_Data from ./opencascade/HLRBRep_Data.hxx
    klass = m.attr("HLRBRep_Data");


    // nested enums

    static_cast<py::class_<HLRBRep_Data ,opencascade::handle<HLRBRep_Data>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int, const int >()  , py::arg("NV"),  py::arg("NE"),  py::arg("NF") )
    // custom constructors
    // methods
        .def("Write",
             (void (HLRBRep_Data::*)(  const handle<HLRBRep_Data> & ,   const int ,   const int ,   const int  ) ) static_cast<void (HLRBRep_Data::*)(  const handle<HLRBRep_Data> & ,   const int ,   const int ,   const int  ) >(&HLRBRep_Data::Write),
             R"#(Write <DS> in me with a translation of <dv>,<de>,<df>.)#"  , py::arg("DS"),  py::arg("dv"),  py::arg("de"),  py::arg("df")
          )
        .def("Tolerance",
             (void (HLRBRep_Data::*)(  const float  ) ) static_cast<void (HLRBRep_Data::*)(  const float  ) >(&HLRBRep_Data::Tolerance),
             R"#(Set the tolerance for the rejections during the exploration)#"  , py::arg("tol")
          )
        .def("Tolerance",
             (float (HLRBRep_Data::*)() const) static_cast<float (HLRBRep_Data::*)() const>(&HLRBRep_Data::Tolerance),
             R"#(returns the tolerance for the rejections during the exploration)#" 
          )
        .def("Update",
             (void (HLRBRep_Data::*)(  const HLRAlgo_Projector &  ) ) static_cast<void (HLRBRep_Data::*)(  const HLRAlgo_Projector &  ) >(&HLRBRep_Data::Update),
             R"#(end of building of the Data and updating all the information linked to the projection.)#"  , py::arg("P")
          )
        .def("NbVertices",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbVertices),
             R"#()#" 
          )
        .def("NbEdges",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbEdges),
             R"#()#" 
          )
        .def("NbFaces",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbFaces),
             R"#()#" 
          )
        .def("InitBoundSort",
             (void (HLRBRep_Data::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices & ,   const int ,   const int  ) ) static_cast<void (HLRBRep_Data::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices & ,   const int ,   const int  ) >(&HLRBRep_Data::InitBoundSort),
             R"#(to compare with only non rejected edges.)#"  , py::arg("MinMaxTot"),  py::arg("e1"),  py::arg("e2")
          )
        .def("InitEdge",
             (void (HLRBRep_Data::*)(  const int ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> &  ) ) static_cast<void (HLRBRep_Data::*)(  const int ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> &  ) >(&HLRBRep_Data::InitEdge),
             R"#(Begin an iteration only on visible Edges crossing the face number <FI>.)#"  , py::arg("FI"),  py::arg("MST")
          )
        .def("MoreEdge",
             (bool (HLRBRep_Data::*)() ) static_cast<bool (HLRBRep_Data::*)() >(&HLRBRep_Data::MoreEdge),
             R"#()#" 
          )
        .def("NextEdge",
             (void (HLRBRep_Data::*)(  const bool  ) ) static_cast<void (HLRBRep_Data::*)(  const bool  ) >(&HLRBRep_Data::NextEdge),
             R"#()#"  , py::arg("skip")=static_cast< const bool>(true)
          )
        .def("Edge",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::Edge),
             R"#(Returns the current Edge)#" 
          )
        .def("HidingTheFace",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::HidingTheFace),
             R"#(Returns true if the current edge to be hidden belongs to the hiding face.)#" 
          )
        .def("SimpleHidingFace",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::SimpleHidingFace),
             R"#(Returns true if the current hiding face is not an auto-intersected one.)#" 
          )
        .def("InitInterference",
             (void (HLRBRep_Data::*)() ) static_cast<void (HLRBRep_Data::*)() >(&HLRBRep_Data::InitInterference),
             R"#(Intersect the current Edge with the boundary of the hiding face. The interferences are given by the More, Next, and Value methods.)#" 
          )
        .def("MoreInterference",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::MoreInterference),
             R"#()#" 
          )
        .def("NextInterference",
             (void (HLRBRep_Data::*)() ) static_cast<void (HLRBRep_Data::*)() >(&HLRBRep_Data::NextInterference),
             R"#()#" 
          )
        .def("RejectedInterference",
             (bool (HLRBRep_Data::*)() ) static_cast<bool (HLRBRep_Data::*)() >(&HLRBRep_Data::RejectedInterference),
             R"#(Returns True if the interference is rejected.)#" 
          )
        .def("AboveInterference",
             (bool (HLRBRep_Data::*)() ) static_cast<bool (HLRBRep_Data::*)() >(&HLRBRep_Data::AboveInterference),
             R"#(Returns True if the rejected interference is above the face.)#" 
          )
        .def("EdgeState",
             (void (HLRBRep_Data::*)(  const double ,   const double ,  TopAbs_State & ,  TopAbs_State &  ) ) static_cast<void (HLRBRep_Data::*)(  const double ,   const double ,  TopAbs_State & ,  TopAbs_State &  ) >(&HLRBRep_Data::EdgeState),
             R"#(Returns the local 3D state of the intersection between the current edge and the current face at the <p1> and <p2> parameters.)#"  , py::arg("p1"),  py::arg("p2"),  py::arg("stbef"),  py::arg("staf")
          )
        .def("EdgeOfTheHidingFace",
             (bool (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) const) static_cast<bool (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) const>(&HLRBRep_Data::EdgeOfTheHidingFace),
             R"#(Returns the true if the Edge <ED> belongs to the Hiding Face.)#"  , py::arg("E"),  py::arg("ED")
          )
        .def("HidingStartLevel",
             (int (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const NCollection_List<HLRAlgo_Interference> &  ) ) static_cast<int (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const NCollection_List<HLRAlgo_Interference> &  ) >(&HLRBRep_Data::HidingStartLevel),
             R"#(Returns the number of levels of hiding face above the first point of the edge <ED>. The InterferenceList is given to compute far away of the Interferences and then come back.)#"  , py::arg("E"),  py::arg("ED"),  py::arg("IL")
          )
        .def("Compare",
             (TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) ) static_cast<TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) >(&HLRBRep_Data::Compare),
             R"#(Returns the state of the Edge <ED> after classification.)#"  , py::arg("E"),  py::arg("ED")
          )
        .def("SimplClassify",
             (TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const int ,   const double ,   const double  ) ) static_cast<TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const int ,   const double ,   const double  ) >(&HLRBRep_Data::SimplClassify),
             R"#(Simple classification of part of edge [p1, p2]. Returns OUT if at least 1 of Nbp points of edge is out; otherwise returns IN. It is used to check "suspicion" hidden part of edge.)#"  , py::arg("E"),  py::arg("ED"),  py::arg("Nbp"),  py::arg("p1"),  py::arg("p2")
          )
        .def("Classify",
             (TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const bool ,  int & ,   const double  ) ) static_cast<TopAbs_State (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData & ,   const bool ,  int & ,   const double  ) >(&HLRBRep_Data::Classify),
             R"#(Classification of an edge.)#"  , py::arg("E"),  py::arg("ED"),  py::arg("LevelFlag"),  py::arg("Level"),  py::arg("param")
          )
        .def("IsBadFace",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::IsBadFace),
             R"#(Returns true if the current face is bad.)#" 
          )
        .def("Destroy",
             (void (HLRBRep_Data::*)() ) static_cast<void (HLRBRep_Data::*)() >(&HLRBRep_Data::Destroy),
             R"#()#" 
          )
        .def("Tolerance",
             (void (HLRBRep_Data::*)(  const float  ) ) static_cast<void (HLRBRep_Data::*)(  const float  ) >(&HLRBRep_Data::Tolerance),
             R"#(Set the tolerance for the rejections during the exploration)#"  , py::arg("tol")
          )
        .def("Tolerance",
             (float (HLRBRep_Data::*)() const) static_cast<float (HLRBRep_Data::*)() const>(&HLRBRep_Data::Tolerance),
             R"#(returns the tolerance for the rejections during the exploration)#" 
          )
        .def("NbVertices",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbVertices),
             R"#()#" 
          )
        .def("NbEdges",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbEdges),
             R"#()#" 
          )
        .def("NbFaces",
             (int (HLRBRep_Data::*)() const) static_cast<int (HLRBRep_Data::*)() const>(&HLRBRep_Data::NbFaces),
             R"#()#" 
          )
        .def("SimpleHidingFace",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::SimpleHidingFace),
             R"#(Returns true if the current hiding face is not an auto-intersected one.)#" 
          )
        .def("HidingTheFace",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::HidingTheFace),
             R"#(Returns true if the current edge to be hidden belongs to the hiding face.)#" 
          )
        .def("MoreInterference",
             (bool (HLRBRep_Data::*)() const) static_cast<bool (HLRBRep_Data::*)() const>(&HLRBRep_Data::MoreInterference),
             R"#()#" 
          )
        .def("EdgeOfTheHidingFace",
             (bool (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) const) static_cast<bool (HLRBRep_Data::*)(  const int ,   const HLRBRep_EdgeData &  ) const>(&HLRBRep_Data::EdgeOfTheHidingFace),
             R"#(Returns the true if the Edge <ED> belongs to the Hiding Face.)#"  , py::arg("arg0"),  py::arg("ED")
          )
    // methods using call by reference i.s.o. return
        .def("LocalLEGeometry2D",
             []( HLRBRep_Data &self ,  const double Param,gp_Dir2d & Tg,gp_Dir2d & Nm ){
                 double  Cu;

                 self.LocalLEGeometry2D(Param,Tg,Nm,Cu);
                 return std::make_tuple(Cu); },
             R"#(Returns the local description of the projection of the current LEdge at parameter <Param>.)#"  , py::arg("Param"),  py::arg("Tg"),  py::arg("Nm")
          )
        .def("LocalFEGeometry2D",
             []( HLRBRep_Data &self ,  const int FE, const double Param,gp_Dir2d & Tg,gp_Dir2d & Nm ){
                 double  Cu;

                 self.LocalFEGeometry2D(FE,Param,Tg,Nm,Cu);
                 return std::make_tuple(Cu); },
             R"#(Returns the local description of the projection of the current FEdge at parameter <Param>.)#"  , py::arg("FE"),  py::arg("Param"),  py::arg("Tg"),  py::arg("Nm")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRBRep_Data::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRBRep_Data::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("EDataArray",
             (NCollection_Array1<HLRBRep_EdgeData> & (HLRBRep_Data::*)() ) static_cast<NCollection_Array1<HLRBRep_EdgeData> & (HLRBRep_Data::*)() >(&HLRBRep_Data::EDataArray),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("FDataArray",
             (NCollection_Array1<HLRBRep_FaceData> & (HLRBRep_Data::*)() ) static_cast<NCollection_Array1<HLRBRep_FaceData> & (HLRBRep_Data::*)() >(&HLRBRep_Data::FDataArray),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Projector",
             (HLRAlgo_Projector & (HLRBRep_Data::*)() ) static_cast<HLRAlgo_Projector & (HLRBRep_Data::*)() >(&HLRBRep_Data::Projector),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("EdgeMap",
             (NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() ) static_cast<NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() >(&HLRBRep_Data::EdgeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("FaceMap",
             (NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() ) static_cast<NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() >(&HLRBRep_Data::FaceMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Interference",
             (HLRAlgo_Interference & (HLRBRep_Data::*)() ) static_cast<HLRAlgo_Interference & (HLRBRep_Data::*)() >(&HLRBRep_Data::Interference),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRBRep_Data::*)() const) static_cast< const handle<Standard_Type> & (HLRBRep_Data::*)() const>(&HLRBRep_Data::DynamicType),
             R"#()#"
             
         )
       .def("EDataArray",
             (NCollection_Array1<HLRBRep_EdgeData> & (HLRBRep_Data::*)() ) static_cast<NCollection_Array1<HLRBRep_EdgeData> & (HLRBRep_Data::*)() >(&HLRBRep_Data::EDataArray),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("FDataArray",
             (NCollection_Array1<HLRBRep_FaceData> & (HLRBRep_Data::*)() ) static_cast<NCollection_Array1<HLRBRep_FaceData> & (HLRBRep_Data::*)() >(&HLRBRep_Data::FDataArray),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Projector",
             (HLRAlgo_Projector & (HLRBRep_Data::*)() ) static_cast<HLRAlgo_Projector & (HLRBRep_Data::*)() >(&HLRBRep_Data::Projector),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("EdgeMap",
             (NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() ) static_cast<NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() >(&HLRBRep_Data::EdgeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("FaceMap",
             (NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() ) static_cast<NCollection_IndexedMap<TopoDS_Shape, TopTools_ShapeMapHasher> & (HLRBRep_Data::*)() >(&HLRBRep_Data::FaceMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Interference",
             (HLRAlgo_Interference & (HLRBRep_Data::*)() ) static_cast<HLRAlgo_Interference & (HLRBRep_Data::*)() >(&HLRBRep_Data::Interference),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRBRep_EdgeBuilder from ./opencascade/HLRBRep_EdgeBuilder.hxx
    klass = m.attr("HLRBRep_EdgeBuilder");


    // nested enums

    static_cast<py::class_<HLRBRep_EdgeBuilder , shared_ptr<HLRBRep_EdgeBuilder>  >>(klass)
    // constructors
        .def(py::init< HLRBRep_VertexList & >()  , py::arg("VList") )
    // custom constructors
    // methods
        .def("InitAreas",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::InitAreas),
             R"#(Initialize an iteration on the areas.)#" 
          )
        .def("NextArea",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::NextArea),
             R"#(Set the current area to the next area.)#" 
          )
        .def("PreviousArea",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::PreviousArea),
             R"#(Set the current area to the previous area.)#" 
          )
        .def("HasArea",
             (bool (HLRBRep_EdgeBuilder::*)() const) static_cast<bool (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::HasArea),
             R"#(Returns True if there is a current area.)#" 
          )
        .def("AreaState",
             (TopAbs_State (HLRBRep_EdgeBuilder::*)() const) static_cast<TopAbs_State (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::AreaState),
             R"#(Returns the state of the current area.)#" 
          )
        .def("AreaEdgeState",
             (TopAbs_State (HLRBRep_EdgeBuilder::*)() const) static_cast<TopAbs_State (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::AreaEdgeState),
             R"#(Returns the edge state of the current area.)#" 
          )
        .def("LeftLimit",
             (handle<HLRBRep_AreaLimit> (HLRBRep_EdgeBuilder::*)() const) static_cast<handle<HLRBRep_AreaLimit> (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::LeftLimit),
             R"#(Returns the AreaLimit beginning the current area. This is a NULL handle when the area is infinite on the left.)#" 
          )
        .def("RightLimit",
             (handle<HLRBRep_AreaLimit> (HLRBRep_EdgeBuilder::*)() const) static_cast<handle<HLRBRep_AreaLimit> (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::RightLimit),
             R"#(Returns the AreaLimit ending the current area. This is a NULL handle when the area is infinite on the right.)#" 
          )
        .def("Builds",
             (void (HLRBRep_EdgeBuilder::*)(  const TopAbs_State  ) ) static_cast<void (HLRBRep_EdgeBuilder::*)(  const TopAbs_State  ) >(&HLRBRep_EdgeBuilder::Builds),
             R"#(Reinitialize the results iteration to the parts with State <ToBuild>. If this method is not called after construction the default is <ToBuild> = IN.)#"  , py::arg("ToBuild")
          )
        .def("MoreEdges",
             (bool (HLRBRep_EdgeBuilder::*)() const) static_cast<bool (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::MoreEdges),
             R"#(Returns True if there are more new edges to build.)#" 
          )
        .def("NextEdge",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::NextEdge),
             R"#(Proceeds to the next edge to build. Skip all remaining vertices on the current edge.)#" 
          )
        .def("MoreVertices",
             (bool (HLRBRep_EdgeBuilder::*)() const) static_cast<bool (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::MoreVertices),
             R"#(True if there are more vertices in the current new edge.)#" 
          )
        .def("NextVertex",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::NextVertex),
             R"#(Proceeds to the next vertex of the current edge.)#" 
          )
        .def("IsBoundary",
             (bool (HLRBRep_EdgeBuilder::*)() const) static_cast<bool (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::IsBoundary),
             R"#(Returns True if the current vertex comes from the boundary of the edge.)#" 
          )
        .def("IsInterference",
             (bool (HLRBRep_EdgeBuilder::*)() const) static_cast<bool (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::IsInterference),
             R"#(Returns True if the current vertex was an interference.)#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_EdgeBuilder::*)() const) static_cast<TopAbs_Orientation (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::Orientation),
             R"#(Returns the new orientation of the current vertex.)#" 
          )
        .def("Destroy",
             (void (HLRBRep_EdgeBuilder::*)() ) static_cast<void (HLRBRep_EdgeBuilder::*)() >(&HLRBRep_EdgeBuilder::Destroy),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Current",
             ( const HLRAlgo_Intersection & (HLRBRep_EdgeBuilder::*)() const) static_cast< const HLRAlgo_Intersection & (HLRBRep_EdgeBuilder::*)() const>(&HLRBRep_EdgeBuilder::Current),
             R"#(Returns the current vertex of the current edge.)#"
             
         )
;

    // Class HLRBRep_EdgeData from ./opencascade/HLRBRep_EdgeData.hxx
    klass = m.attr("HLRBRep_EdgeData");


    // nested enums

    static_cast<py::class_<HLRBRep_EdgeData , shared_ptr<HLRBRep_EdgeData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (HLRBRep_EdgeData::*)(  const bool ,   const bool ,   const TopoDS_Edge & ,   const int ,   const int ,   const bool ,   const bool ,   const bool ,   const bool ,   const double ,   const float ,   const double ,   const float  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool ,   const bool ,   const TopoDS_Edge & ,   const int ,   const int ,   const bool ,   const bool ,   const bool ,   const bool ,   const double ,   const float ,   const double ,   const float  ) >(&HLRBRep_EdgeData::Set),
             R"#()#"  , py::arg("Reg1"),  py::arg("RegN"),  py::arg("EG"),  py::arg("V1"),  py::arg("V2"),  py::arg("Out1"),  py::arg("Out2"),  py::arg("Cut1"),  py::arg("Cut2"),  py::arg("Start"),  py::arg("TolStart"),  py::arg("End"),  py::arg("TolEnd")
          )
        .def("Selected",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Selected),
             R"#()#" 
          )
        .def("Selected",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Selected),
             R"#()#"  , py::arg("B")
          )
        .def("Rg1Line",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Rg1Line),
             R"#()#" 
          )
        .def("Rg1Line",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Rg1Line),
             R"#()#"  , py::arg("B")
          )
        .def("RgNLine",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::RgNLine),
             R"#()#" 
          )
        .def("RgNLine",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::RgNLine),
             R"#()#"  , py::arg("B")
          )
        .def("Vertical",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Vertical),
             R"#()#" 
          )
        .def("Vertical",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Vertical),
             R"#()#"  , py::arg("B")
          )
        .def("Simple",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Simple),
             R"#()#" 
          )
        .def("Simple",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Simple),
             R"#()#"  , py::arg("B")
          )
        .def("OutLVSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::OutLVSta),
             R"#()#" 
          )
        .def("OutLVSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::OutLVSta),
             R"#()#"  , py::arg("B")
          )
        .def("OutLVEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::OutLVEnd),
             R"#()#" 
          )
        .def("OutLVEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::OutLVEnd),
             R"#()#"  , py::arg("B")
          )
        .def("CutAtSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::CutAtSta),
             R"#()#" 
          )
        .def("CutAtSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::CutAtSta),
             R"#()#"  , py::arg("B")
          )
        .def("CutAtEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::CutAtEnd),
             R"#()#" 
          )
        .def("CutAtEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::CutAtEnd),
             R"#()#"  , py::arg("B")
          )
        .def("VerAtSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VerAtSta),
             R"#()#" 
          )
        .def("VerAtSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::VerAtSta),
             R"#()#"  , py::arg("B")
          )
        .def("VerAtEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VerAtEnd),
             R"#()#" 
          )
        .def("VerAtEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::VerAtEnd),
             R"#()#"  , py::arg("B")
          )
        .def("AutoIntersectionDone",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::AutoIntersectionDone),
             R"#()#" 
          )
        .def("AutoIntersectionDone",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::AutoIntersectionDone),
             R"#()#"  , py::arg("B")
          )
        .def("Used",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Used),
             R"#()#" 
          )
        .def("Used",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Used),
             R"#()#"  , py::arg("B")
          )
        .def("HideCount",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::HideCount),
             R"#()#" 
          )
        .def("HideCount",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::HideCount),
             R"#()#"  , py::arg("I")
          )
        .def("VSta",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VSta),
             R"#()#" 
          )
        .def("VSta",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::VSta),
             R"#()#"  , py::arg("I")
          )
        .def("VEnd",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VEnd),
             R"#()#" 
          )
        .def("VEnd",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::VEnd),
             R"#()#"  , py::arg("I")
          )
        .def("UpdateMinMax",
             (void (HLRBRep_EdgeData::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRBRep_EdgeData::UpdateMinMax),
             R"#()#"  , py::arg("theTotMinMax")
          )
        .def("Curve",
             (HLRBRep_Curve * (HLRBRep_EdgeData::*)() ) static_cast<HLRBRep_Curve * (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::Curve),
             R"#()#" 
          )
        .def("Tolerance",
             (float (HLRBRep_EdgeData::*)() const) static_cast<float (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Tolerance),
             R"#()#" 
          )
        .def("Selected",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Selected),
             R"#()#" 
          )
        .def("Selected",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Selected),
             R"#()#"  , py::arg("B")
          )
        .def("Rg1Line",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Rg1Line),
             R"#()#" 
          )
        .def("Rg1Line",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Rg1Line),
             R"#()#"  , py::arg("B")
          )
        .def("RgNLine",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::RgNLine),
             R"#()#" 
          )
        .def("RgNLine",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::RgNLine),
             R"#()#"  , py::arg("B")
          )
        .def("Vertical",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Vertical),
             R"#()#" 
          )
        .def("Vertical",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Vertical),
             R"#()#"  , py::arg("B")
          )
        .def("Simple",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Simple),
             R"#()#" 
          )
        .def("Simple",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Simple),
             R"#()#"  , py::arg("B")
          )
        .def("OutLVSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::OutLVSta),
             R"#()#" 
          )
        .def("OutLVSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::OutLVSta),
             R"#()#"  , py::arg("B")
          )
        .def("OutLVEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::OutLVEnd),
             R"#()#" 
          )
        .def("OutLVEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::OutLVEnd),
             R"#()#"  , py::arg("B")
          )
        .def("CutAtSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::CutAtSta),
             R"#()#" 
          )
        .def("CutAtSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::CutAtSta),
             R"#()#"  , py::arg("B")
          )
        .def("CutAtEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::CutAtEnd),
             R"#()#" 
          )
        .def("CutAtEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::CutAtEnd),
             R"#()#"  , py::arg("B")
          )
        .def("VerAtSta",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VerAtSta),
             R"#()#" 
          )
        .def("VerAtSta",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::VerAtSta),
             R"#()#"  , py::arg("B")
          )
        .def("VerAtEnd",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VerAtEnd),
             R"#()#" 
          )
        .def("VerAtEnd",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::VerAtEnd),
             R"#()#"  , py::arg("B")
          )
        .def("AutoIntersectionDone",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::AutoIntersectionDone),
             R"#()#" 
          )
        .def("AutoIntersectionDone",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::AutoIntersectionDone),
             R"#()#"  , py::arg("B")
          )
        .def("Used",
             (bool (HLRBRep_EdgeData::*)() const) static_cast<bool (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Used),
             R"#()#" 
          )
        .def("Used",
             (void (HLRBRep_EdgeData::*)(  const bool  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const bool  ) >(&HLRBRep_EdgeData::Used),
             R"#()#"  , py::arg("B")
          )
        .def("HideCount",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::HideCount),
             R"#()#" 
          )
        .def("HideCount",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::HideCount),
             R"#()#"  , py::arg("I")
          )
        .def("VSta",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VSta),
             R"#()#" 
          )
        .def("VSta",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::VSta),
             R"#()#"  , py::arg("I")
          )
        .def("VEnd",
             (int (HLRBRep_EdgeData::*)() const) static_cast<int (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::VEnd),
             R"#()#" 
          )
        .def("VEnd",
             (void (HLRBRep_EdgeData::*)(  const int  ) ) static_cast<void (HLRBRep_EdgeData::*)(  const int  ) >(&HLRBRep_EdgeData::VEnd),
             R"#()#"  , py::arg("I")
          )
        .def("Tolerance",
             (float (HLRBRep_EdgeData::*)() const) static_cast<float (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Tolerance),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("MinMax",
             (HLRAlgo_EdgesBlock::MinMaxIndices & (HLRBRep_EdgeData::*)() ) static_cast<HLRAlgo_EdgesBlock::MinMaxIndices & (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::MinMax),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Status",
             (HLRAlgo_EdgeStatus & (HLRBRep_EdgeData::*)() ) static_cast<HLRAlgo_EdgeStatus & (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::Status),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeGeometry",
             (HLRBRep_Curve & (HLRBRep_EdgeData::*)() ) static_cast<HLRBRep_Curve & (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::ChangeGeometry),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Geometry",
             ( const HLRBRep_Curve & (HLRBRep_EdgeData::*)() const) static_cast< const HLRBRep_Curve & (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Geometry),
             R"#()#"
             
         )
       .def("Status",
             (HLRAlgo_EdgeStatus & (HLRBRep_EdgeData::*)() ) static_cast<HLRAlgo_EdgeStatus & (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::Status),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeGeometry",
             (HLRBRep_Curve & (HLRBRep_EdgeData::*)() ) static_cast<HLRBRep_Curve & (HLRBRep_EdgeData::*)() >(&HLRBRep_EdgeData::ChangeGeometry),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Geometry",
             ( const HLRBRep_Curve & (HLRBRep_EdgeData::*)() const) static_cast< const HLRBRep_Curve & (HLRBRep_EdgeData::*)() const>(&HLRBRep_EdgeData::Geometry),
             R"#()#"
             
         )
;

    // Class HLRBRep_EdgeFaceTool from ./opencascade/HLRBRep_EdgeFaceTool.hxx
    klass = m.attr("HLRBRep_EdgeFaceTool");

    // default constructor
    register_default_constructor<HLRBRep_EdgeFaceTool , shared_ptr<HLRBRep_EdgeFaceTool>>(m,"HLRBRep_EdgeFaceTool");

    // nested enums

    static_cast<py::class_<HLRBRep_EdgeFaceTool , shared_ptr<HLRBRep_EdgeFaceTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("CurvatureValue_s",
                    (double (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,   const gp_Dir &  ) ) static_cast<double (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,   const gp_Dir &  ) >(&HLRBRep_EdgeFaceTool::CurvatureValue),
                    R"#()#"  , py::arg("F"),  py::arg("U"),  py::arg("V"),  py::arg("Tg")
          )
        .def_static("UVPoint_s",
                    (bool (*)(  const double ,   const HLRBRep_CurvePtr ,   const HLRBRep_SurfacePtr ,  double & ,  double &  ) ) static_cast<bool (*)(  const double ,   const HLRBRep_CurvePtr ,   const HLRBRep_SurfacePtr ,  double & ,  double &  ) >(&HLRBRep_EdgeFaceTool::UVPoint),
                    R"#(return True if U and V are found.)#"  , py::arg("Par"),  py::arg("E"),  py::arg("F"),  py::arg("U"),  py::arg("V")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_EdgeIList from ./opencascade/HLRBRep_EdgeIList.hxx
    klass = m.attr("HLRBRep_EdgeIList");

    // default constructor
    register_default_constructor<HLRBRep_EdgeIList , shared_ptr<HLRBRep_EdgeIList>>(m,"HLRBRep_EdgeIList");

    // nested enums

    static_cast<py::class_<HLRBRep_EdgeIList , shared_ptr<HLRBRep_EdgeIList>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("AddInterference_s",
                    (void (*)( NCollection_List<HLRAlgo_Interference> & ,   const HLRAlgo_Interference & ,   const HLRBRep_EdgeInterferenceTool &  ) ) static_cast<void (*)( NCollection_List<HLRAlgo_Interference> & ,   const HLRAlgo_Interference & ,   const HLRBRep_EdgeInterferenceTool &  ) >(&HLRBRep_EdgeIList::AddInterference),
                    R"#(Add the interference <I> to the list <IL>.)#"  , py::arg("IL"),  py::arg("I"),  py::arg("T")
          )
        .def_static("ProcessComplex_s",
                    (void (*)( NCollection_List<HLRAlgo_Interference> & ,   const HLRBRep_EdgeInterferenceTool &  ) ) static_cast<void (*)( NCollection_List<HLRAlgo_Interference> & ,   const HLRBRep_EdgeInterferenceTool &  ) >(&HLRBRep_EdgeIList::ProcessComplex),
                    R"#(Process complex transitions on the list IL.)#"  , py::arg("IL"),  py::arg("T")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_EdgeInterferenceTool from ./opencascade/HLRBRep_EdgeInterferenceTool.hxx
    klass = m.attr("HLRBRep_EdgeInterferenceTool");


    // nested enums

    static_cast<py::class_<HLRBRep_EdgeInterferenceTool , shared_ptr<HLRBRep_EdgeInterferenceTool>  >>(klass)
    // constructors
        .def(py::init<  const handle<HLRBRep_Data> & >()  , py::arg("DS") )
    // custom constructors
    // methods
        .def("LoadEdge",
             (void (HLRBRep_EdgeInterferenceTool::*)() ) static_cast<void (HLRBRep_EdgeInterferenceTool::*)() >(&HLRBRep_EdgeInterferenceTool::LoadEdge),
             R"#()#" 
          )
        .def("InitVertices",
             (void (HLRBRep_EdgeInterferenceTool::*)() ) static_cast<void (HLRBRep_EdgeInterferenceTool::*)() >(&HLRBRep_EdgeInterferenceTool::InitVertices),
             R"#()#" 
          )
        .def("MoreVertices",
             (bool (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::MoreVertices),
             R"#()#" 
          )
        .def("NextVertex",
             (void (HLRBRep_EdgeInterferenceTool::*)() ) static_cast<void (HLRBRep_EdgeInterferenceTool::*)() >(&HLRBRep_EdgeInterferenceTool::NextVertex),
             R"#()#" 
          )
        .def("CurrentOrientation",
             (TopAbs_Orientation (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<TopAbs_Orientation (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentOrientation),
             R"#()#" 
          )
        .def("CurrentParameter",
             (double (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<double (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentParameter),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::IsPeriodic),
             R"#()#" 
          )
        .def("ParameterOfInterference",
             (double (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const) static_cast<double (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const>(&HLRBRep_EdgeInterferenceTool::ParameterOfInterference),
             R"#()#"  , py::arg("I")
          )
        .def("SameInterferences",
             (bool (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference & ,   const HLRAlgo_Interference &  ) const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference & ,   const HLRAlgo_Interference &  ) const>(&HLRBRep_EdgeInterferenceTool::SameInterferences),
             R"#(True if the two interferences are on the same geometric locus.)#"  , py::arg("I1"),  py::arg("I2")
          )
        .def("SameVertexAndInterference",
             (bool (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const>(&HLRBRep_EdgeInterferenceTool::SameVertexAndInterference),
             R"#(True if the Interference and the current Vertex are on the same geometric locus.)#"  , py::arg("I")
          )
        .def("InitVertices",
             (void (HLRBRep_EdgeInterferenceTool::*)() ) static_cast<void (HLRBRep_EdgeInterferenceTool::*)() >(&HLRBRep_EdgeInterferenceTool::InitVertices),
             R"#()#" 
          )
        .def("MoreVertices",
             (bool (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::MoreVertices),
             R"#()#" 
          )
        .def("NextVertex",
             (void (HLRBRep_EdgeInterferenceTool::*)() ) static_cast<void (HLRBRep_EdgeInterferenceTool::*)() >(&HLRBRep_EdgeInterferenceTool::NextVertex),
             R"#()#" 
          )
        .def("CurrentOrientation",
             (TopAbs_Orientation (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<TopAbs_Orientation (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentOrientation),
             R"#()#" 
          )
        .def("CurrentParameter",
             (double (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<double (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentParameter),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (HLRBRep_EdgeInterferenceTool::*)() const) static_cast<bool (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::IsPeriodic),
             R"#()#" 
          )
        .def("ParameterOfInterference",
             (double (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const) static_cast<double (HLRBRep_EdgeInterferenceTool::*)(  const HLRAlgo_Interference &  ) const>(&HLRBRep_EdgeInterferenceTool::ParameterOfInterference),
             R"#()#"  , py::arg("I")
          )
    // methods using call by reference i.s.o. return
        .def("EdgeGeometry",
             []( HLRBRep_EdgeInterferenceTool &self ,  const double Param,gp_Dir & Tgt,gp_Dir & Nrm ){
                 double  Curv;

                 self.EdgeGeometry(Param,Tgt,Nrm,Curv);
                 return std::make_tuple(Curv); },
             R"#(Returns local geometric description of the Edge at parameter <Para>. See method Reset of class EdgeFaceTransition from TopCnx for other arguments.)#"  , py::arg("Param"),  py::arg("Tgt"),  py::arg("Nrm")
          )
        .def("InterferenceBoundaryGeometry",
             []( HLRBRep_EdgeInterferenceTool &self ,  const HLRAlgo_Interference & I,gp_Dir & Tang,gp_Dir & Norm ){
                 double  Curv;

                 self.InterferenceBoundaryGeometry(I,Tang,Norm,Curv);
                 return std::make_tuple(Curv); },
             R"#(Returns the geometry of the boundary at the interference <I>. See the AddInterference method of the class EdgeFaceTransition from TopCnx for the other arguments.)#"  , py::arg("I"),  py::arg("Tang"),  py::arg("Norm")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CurrentVertex",
             ( const HLRAlgo_Intersection & (HLRBRep_EdgeInterferenceTool::*)() const) static_cast< const HLRAlgo_Intersection & (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentVertex),
             R"#()#"
             
         )
       .def("CurrentVertex",
             ( const HLRAlgo_Intersection & (HLRBRep_EdgeInterferenceTool::*)() const) static_cast< const HLRAlgo_Intersection & (HLRBRep_EdgeInterferenceTool::*)() const>(&HLRBRep_EdgeInterferenceTool::CurrentVertex),
             R"#()#"
             
         )
;

    // Class HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter from ./opencascade/HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter.hxx
    klass = m.attr("HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter , shared_ptr<HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Perform",
             (void (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::Perform),
             R"#()#"  , py::arg("Uo"),  py::arg("Vo"),  py::arg("UInf"),  py::arg("VInf"),  py::arg("USup"),  py::arg("VSup")
          )
        .def("NbRoots",
             (int (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<int (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::NbRoots),
             R"#()#" 
          )
        .def("AnErrorOccurred",
             (bool (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<bool (HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter::AnErrorOccurred),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Perform",
             []( HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter &self ,  const HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter & Poly1, const HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter & Poly2 ){
                 int  NumSegOn1;
                int  NumSegOn2;
                double  ParamOnSeg1;
                double  ParamOnSeg2;

                 self.Perform(Poly1,Poly2,NumSegOn1,NumSegOn2,ParamOnSeg1,ParamOnSeg2);
                 return std::make_tuple(NumSegOn1,NumSegOn2,ParamOnSeg1,ParamOnSeg2); },
             R"#()#"  , py::arg("Poly1"),  py::arg("Poly2")
          )
        .def("Roots",
             []( HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter &self   ){
                 double  U;
                double  V;

                 self.Roots(U,V);
                 return std::make_tuple(U,V); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_FaceData from ./opencascade/HLRBRep_FaceData.hxx
    klass = m.attr("HLRBRep_FaceData");


    // nested enums

    static_cast<py::class_<HLRBRep_FaceData , shared_ptr<HLRBRep_FaceData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (HLRBRep_FaceData::*)(  const TopoDS_Face & ,   const TopAbs_Orientation ,   const bool ,   const int  ) ) static_cast<void (HLRBRep_FaceData::*)(  const TopoDS_Face & ,   const TopAbs_Orientation ,   const bool ,   const int  ) >(&HLRBRep_FaceData::Set),
             R"#(<Or> is the orientation of the face. <Cl> is true if the face belongs to a closed volume. <NW> is the number of wires (or block of edges) of the face.)#"  , py::arg("FG"),  py::arg("Or"),  py::arg("Cl"),  py::arg("NW")
          )
        .def("SetWire",
             (void (HLRBRep_FaceData::*)(  const int ,   const int  ) ) static_cast<void (HLRBRep_FaceData::*)(  const int ,   const int  ) >(&HLRBRep_FaceData::SetWire),
             R"#(Set <NE> the number of edges of the wire number <WI>.)#"  , py::arg("WI"),  py::arg("NE")
          )
        .def("SetWEdge",
             (void (HLRBRep_FaceData::*)(  const int ,   const int ,   const int ,   const TopAbs_Orientation ,   const bool ,   const bool ,   const bool ,   const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const int ,   const int ,   const int ,   const TopAbs_Orientation ,   const bool ,   const bool ,   const bool ,   const bool  ) >(&HLRBRep_FaceData::SetWEdge),
             R"#(Set the edge number <EWI> of the wire <WI>.)#"  , py::arg("WI"),  py::arg("EWI"),  py::arg("EI"),  py::arg("Or"),  py::arg("OutL"),  py::arg("Inte"),  py::arg("Dble"),  py::arg("IsoL")
          )
        .def("Selected",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Selected),
             R"#()#" 
          )
        .def("Selected",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Selected),
             R"#()#"  , py::arg("B")
          )
        .def("Back",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Back),
             R"#()#" 
          )
        .def("Back",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Back),
             R"#()#"  , py::arg("B")
          )
        .def("Side",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Side),
             R"#()#" 
          )
        .def("Side",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Side),
             R"#()#"  , py::arg("B")
          )
        .def("Closed",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Closed),
             R"#()#" 
          )
        .def("Closed",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Closed),
             R"#()#"  , py::arg("B")
          )
        .def("Hiding",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Hiding),
             R"#()#" 
          )
        .def("Hiding",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Hiding),
             R"#()#"  , py::arg("B")
          )
        .def("Simple",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Simple),
             R"#()#" 
          )
        .def("Simple",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Simple),
             R"#()#"  , py::arg("B")
          )
        .def("Cut",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cut),
             R"#()#" 
          )
        .def("Cut",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cut),
             R"#()#"  , py::arg("B")
          )
        .def("WithOutL",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::WithOutL),
             R"#()#" 
          )
        .def("WithOutL",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::WithOutL),
             R"#()#"  , py::arg("B")
          )
        .def("Plane",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Plane),
             R"#()#" 
          )
        .def("Plane",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Plane),
             R"#()#"  , py::arg("B")
          )
        .def("Cylinder",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cylinder),
             R"#()#" 
          )
        .def("Cylinder",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cylinder),
             R"#()#"  , py::arg("B")
          )
        .def("Cone",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cone),
             R"#()#" 
          )
        .def("Cone",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cone),
             R"#()#"  , py::arg("B")
          )
        .def("Sphere",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Sphere),
             R"#()#" 
          )
        .def("Sphere",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Sphere),
             R"#()#"  , py::arg("B")
          )
        .def("Torus",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Torus),
             R"#()#" 
          )
        .def("Torus",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Torus),
             R"#()#"  , py::arg("B")
          )
        .def("Size",
             (double (HLRBRep_FaceData::*)() const) static_cast<double (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Size),
             R"#()#" 
          )
        .def("Size",
             (void (HLRBRep_FaceData::*)(  const double  ) ) static_cast<void (HLRBRep_FaceData::*)(  const double  ) >(&HLRBRep_FaceData::Size),
             R"#()#"  , py::arg("S")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_FaceData::*)() const) static_cast<TopAbs_Orientation (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Orientation),
             R"#()#" 
          )
        .def("Orientation",
             (void (HLRBRep_FaceData::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRBRep_FaceData::*)(  const TopAbs_Orientation  ) >(&HLRBRep_FaceData::Orientation),
             R"#()#"  , py::arg("O")
          )
        .def("Tolerance",
             (float (HLRBRep_FaceData::*)() const) static_cast<float (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Tolerance),
             R"#()#" 
          )
        .def("Selected",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Selected),
             R"#()#" 
          )
        .def("Selected",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Selected),
             R"#()#"  , py::arg("B")
          )
        .def("Back",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Back),
             R"#()#" 
          )
        .def("Back",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Back),
             R"#()#"  , py::arg("B")
          )
        .def("Side",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Side),
             R"#()#" 
          )
        .def("Side",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Side),
             R"#()#"  , py::arg("B")
          )
        .def("Closed",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Closed),
             R"#()#" 
          )
        .def("Closed",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Closed),
             R"#()#"  , py::arg("B")
          )
        .def("Hiding",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Hiding),
             R"#()#" 
          )
        .def("Hiding",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Hiding),
             R"#()#"  , py::arg("B")
          )
        .def("Simple",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Simple),
             R"#()#" 
          )
        .def("Simple",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Simple),
             R"#()#"  , py::arg("B")
          )
        .def("Cut",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cut),
             R"#()#" 
          )
        .def("Cut",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cut),
             R"#()#"  , py::arg("B")
          )
        .def("WithOutL",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::WithOutL),
             R"#()#" 
          )
        .def("WithOutL",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::WithOutL),
             R"#()#"  , py::arg("B")
          )
        .def("Plane",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Plane),
             R"#()#" 
          )
        .def("Plane",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Plane),
             R"#()#"  , py::arg("B")
          )
        .def("Cylinder",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cylinder),
             R"#()#" 
          )
        .def("Cylinder",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cylinder),
             R"#()#"  , py::arg("B")
          )
        .def("Cone",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Cone),
             R"#()#" 
          )
        .def("Cone",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Cone),
             R"#()#"  , py::arg("B")
          )
        .def("Sphere",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Sphere),
             R"#()#" 
          )
        .def("Sphere",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Sphere),
             R"#()#"  , py::arg("B")
          )
        .def("Torus",
             (bool (HLRBRep_FaceData::*)() const) static_cast<bool (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Torus),
             R"#()#" 
          )
        .def("Torus",
             (void (HLRBRep_FaceData::*)(  const bool  ) ) static_cast<void (HLRBRep_FaceData::*)(  const bool  ) >(&HLRBRep_FaceData::Torus),
             R"#()#"  , py::arg("B")
          )
        .def("Size",
             (double (HLRBRep_FaceData::*)() const) static_cast<double (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Size),
             R"#()#" 
          )
        .def("Size",
             (void (HLRBRep_FaceData::*)(  const double  ) ) static_cast<void (HLRBRep_FaceData::*)(  const double  ) >(&HLRBRep_FaceData::Size),
             R"#()#"  , py::arg("S")
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_FaceData::*)() const) static_cast<TopAbs_Orientation (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Orientation),
             R"#()#" 
          )
        .def("Orientation",
             (void (HLRBRep_FaceData::*)(  const TopAbs_Orientation  ) ) static_cast<void (HLRBRep_FaceData::*)(  const TopAbs_Orientation  ) >(&HLRBRep_FaceData::Orientation),
             R"#()#"  , py::arg("O")
          )
        .def("Tolerance",
             (float (HLRBRep_FaceData::*)() const) static_cast<float (HLRBRep_FaceData::*)() const>(&HLRBRep_FaceData::Tolerance),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Wires",
             (handle<HLRAlgo_WiresBlock> & (HLRBRep_FaceData::*)() ) static_cast<handle<HLRAlgo_WiresBlock> & (HLRBRep_FaceData::*)() >(&HLRBRep_FaceData::Wires),
             R"#()#"
             
         )
       .def("Geometry",
             (HLRBRep_Surface & (HLRBRep_FaceData::*)() ) static_cast<HLRBRep_Surface & (HLRBRep_FaceData::*)() >(&HLRBRep_FaceData::Geometry),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Wires",
             (handle<HLRAlgo_WiresBlock> & (HLRBRep_FaceData::*)() ) static_cast<handle<HLRAlgo_WiresBlock> & (HLRBRep_FaceData::*)() >(&HLRBRep_FaceData::Wires),
             R"#()#"
             
         )
       .def("Geometry",
             (HLRBRep_Surface & (HLRBRep_FaceData::*)() ) static_cast<HLRBRep_Surface & (HLRBRep_FaceData::*)() >(&HLRBRep_FaceData::Geometry),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRBRep_FaceIterator from ./opencascade/HLRBRep_FaceIterator.hxx
    klass = m.attr("HLRBRep_FaceIterator");


    // nested enums

    static_cast<py::class_<HLRBRep_FaceIterator , shared_ptr<HLRBRep_FaceIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("InitEdge",
             (void (HLRBRep_FaceIterator::*)( HLRBRep_FaceData &  ) ) static_cast<void (HLRBRep_FaceIterator::*)( HLRBRep_FaceData &  ) >(&HLRBRep_FaceIterator::InitEdge),
             R"#(Begin an exploration of the edges of the face <fd>)#"  , py::arg("fd")
          )
        .def("MoreEdge",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::MoreEdge),
             R"#()#" 
          )
        .def("NextEdge",
             (void (HLRBRep_FaceIterator::*)() ) static_cast<void (HLRBRep_FaceIterator::*)() >(&HLRBRep_FaceIterator::NextEdge),
             R"#()#" 
          )
        .def("BeginningOfWire",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::BeginningOfWire),
             R"#(Returns True if the current edge is the first of a wire.)#" 
          )
        .def("EndOfWire",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::EndOfWire),
             R"#(Returns True if the current edge is the last of a wire.)#" 
          )
        .def("SkipWire",
             (void (HLRBRep_FaceIterator::*)() ) static_cast<void (HLRBRep_FaceIterator::*)() >(&HLRBRep_FaceIterator::SkipWire),
             R"#(Skip the current wire in the exploration.)#" 
          )
        .def("Wire",
             (handle<HLRAlgo_EdgesBlock> (HLRBRep_FaceIterator::*)() const) static_cast<handle<HLRAlgo_EdgesBlock> (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Wire),
             R"#(Returns the edges of the current wire.)#" 
          )
        .def("Edge",
             (int (HLRBRep_FaceIterator::*)() const) static_cast<int (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Edge),
             R"#()#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_FaceIterator::*)() const) static_cast<TopAbs_Orientation (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Orientation),
             R"#()#" 
          )
        .def("OutLine",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::OutLine),
             R"#()#" 
          )
        .def("Internal",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Internal),
             R"#()#" 
          )
        .def("Double",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Double),
             R"#()#" 
          )
        .def("IsoLine",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::IsoLine),
             R"#()#" 
          )
        .def("MoreEdge",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::MoreEdge),
             R"#()#" 
          )
        .def("BeginningOfWire",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::BeginningOfWire),
             R"#(Returns True if the current edge is the first of a wire.)#" 
          )
        .def("EndOfWire",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::EndOfWire),
             R"#(Returns True if the current edge is the last of a wire.)#" 
          )
        .def("SkipWire",
             (void (HLRBRep_FaceIterator::*)() ) static_cast<void (HLRBRep_FaceIterator::*)() >(&HLRBRep_FaceIterator::SkipWire),
             R"#(Skip the current wire in the exploration.)#" 
          )
        .def("Wire",
             (handle<HLRAlgo_EdgesBlock> (HLRBRep_FaceIterator::*)() const) static_cast<handle<HLRAlgo_EdgesBlock> (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Wire),
             R"#(Returns the edges of the current wire.)#" 
          )
        .def("Edge",
             (int (HLRBRep_FaceIterator::*)() const) static_cast<int (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Edge),
             R"#()#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_FaceIterator::*)() const) static_cast<TopAbs_Orientation (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Orientation),
             R"#()#" 
          )
        .def("OutLine",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::OutLine),
             R"#()#" 
          )
        .def("Internal",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Internal),
             R"#()#" 
          )
        .def("Double",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::Double),
             R"#()#" 
          )
        .def("IsoLine",
             (bool (HLRBRep_FaceIterator::*)() const) static_cast<bool (HLRBRep_FaceIterator::*)() const>(&HLRBRep_FaceIterator::IsoLine),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_HLRToShape from ./opencascade/HLRBRep_HLRToShape.hxx
    klass = m.attr("HLRBRep_HLRToShape");


    // nested enums

    static_cast<py::class_<HLRBRep_HLRToShape , shared_ptr<HLRBRep_HLRToShape>  >>(klass)
    // constructors
        .def(py::init<  const handle<HLRBRep_Algo> & >()  , py::arg("A") )
    // custom constructors
    // methods
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::VCompound),
             R"#(Return visible sharp edges (of C0-continuity).)#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::VCompound),
             R"#(Return visible sharp edges (of C0-continuity) of specified shape.)#"  , py::arg("S")
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::Rg1LineVCompound),
             R"#(Return visible smooth edges (G1-continuity between two surfaces).)#" 
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::Rg1LineVCompound),
             R"#(Return visible smooth edges (G1-continuity between two surfaces) of specified shape.)#"  , py::arg("S")
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::RgNLineVCompound),
             R"#(Return visible sewn edges (of CN-continuity on one surface).)#" 
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::RgNLineVCompound),
             R"#(Return visible sewn edges (of CN-continuity on one surface) of specified shape.)#"  , py::arg("S")
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineVCompound),
             R"#(Return visible outline edges ("silhouette").)#" 
          )
        .def("OutLineVCompound3d",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineVCompound3d),
             R"#(Return visible outline edges ("silhouette").)#" 
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::OutLineVCompound),
             R"#(Return visible outline edges ("silhouette") of specified shape.)#"  , py::arg("S")
          )
        .def("IsoLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::IsoLineVCompound),
             R"#(Return visible isoparameters.)#" 
          )
        .def("IsoLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::IsoLineVCompound),
             R"#(Return visible isoparameters of specified shape.)#"  , py::arg("S")
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::HCompound),
             R"#(Return hidden sharp edges (of C0-continuity).)#" 
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::HCompound),
             R"#(Return hidden sharp edges (of C0-continuity) of specified shape.)#"  , py::arg("S")
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::Rg1LineHCompound),
             R"#(Return hidden smooth edges (G1-continuity between two surfaces).)#" 
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::Rg1LineHCompound),
             R"#(Return hidden smooth edges (G1-continuity between two surfaces) of specified shape.)#"  , py::arg("S")
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::RgNLineHCompound),
             R"#(Return hidden sewn edges (of CN-continuity on one surface).)#" 
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::RgNLineHCompound),
             R"#(Return hidden sewn edges (of CN-continuity on one surface) of specified shape.)#"  , py::arg("S")
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineHCompound),
             R"#(Return hidden outline edges ("silhouette").)#" 
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::OutLineHCompound),
             R"#(Return hidden outline edges ("silhouette") of specified shape.)#"  , py::arg("S")
          )
        .def("IsoLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::IsoLineHCompound),
             R"#(Return hidden isoparameters.)#" 
          )
        .def("IsoLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::IsoLineHCompound),
             R"#(Return hidden isoparameters of specified shape.)#"  , py::arg("S")
          )
        .def("CompoundOfEdges",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) >(&HLRBRep_HLRToShape::CompoundOfEdges),
             R"#(Returns compound of resulting edges of required type and visibility, taking into account the kind of space (2d or 3d))#"  , py::arg("type"),  py::arg("visible"),  py::arg("In3d")
          )
        .def("CompoundOfEdges",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape & ,   const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape & ,   const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) >(&HLRBRep_HLRToShape::CompoundOfEdges),
             R"#(For specified shape returns compound of resulting edges of required type and visibility, taking into account the kind of space (2d or 3d))#"  , py::arg("S"),  py::arg("type"),  py::arg("visible"),  py::arg("In3d")
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::VCompound),
             R"#(Return visible sharp edges (of C0-continuity).)#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::VCompound),
             R"#(Return visible sharp edges (of C0-continuity) of specified shape.)#"  , py::arg("S")
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::Rg1LineVCompound),
             R"#(Return visible smooth edges (G1-continuity between two surfaces).)#" 
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::Rg1LineVCompound),
             R"#(Return visible smooth edges (G1-continuity between two surfaces) of specified shape.)#"  , py::arg("S")
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::RgNLineVCompound),
             R"#(Return visible sewn edges (of CN-continuity on one surface).)#" 
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::RgNLineVCompound),
             R"#(Return visible sewn edges (of CN-continuity on one surface) of specified shape.)#"  , py::arg("S")
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineVCompound),
             R"#(Return visible outline edges ("silhouette").)#" 
          )
        .def("OutLineVCompound3d",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineVCompound3d),
             R"#(Return visible outline edges ("silhouette").)#" 
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::OutLineVCompound),
             R"#(Return visible outline edges ("silhouette") of specified shape.)#"  , py::arg("S")
          )
        .def("IsoLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::IsoLineVCompound),
             R"#(Return visible isoparameters.)#" 
          )
        .def("IsoLineVCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::IsoLineVCompound),
             R"#(Return visible isoparameters of specified shape.)#"  , py::arg("S")
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::HCompound),
             R"#(Return hidden sharp edges (of C0-continuity).)#" 
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::HCompound),
             R"#(Return hidden sharp edges (of C0-continuity) of specified shape.)#"  , py::arg("S")
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::Rg1LineHCompound),
             R"#(Return hidden smooth edges (G1-continuity between two surfaces).)#" 
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::Rg1LineHCompound),
             R"#(Return hidden smooth edges (G1-continuity between two surfaces) of specified shape.)#"  , py::arg("S")
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::RgNLineHCompound),
             R"#(Return hidden sewn edges (of CN-continuity on one surface).)#" 
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::RgNLineHCompound),
             R"#(Return hidden sewn edges (of CN-continuity on one surface) of specified shape.)#"  , py::arg("S")
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::OutLineHCompound),
             R"#(Return hidden outline edges ("silhouette").)#" 
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::OutLineHCompound),
             R"#(Return hidden outline edges ("silhouette") of specified shape.)#"  , py::arg("S")
          )
        .def("IsoLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)() >(&HLRBRep_HLRToShape::IsoLineHCompound),
             R"#(Return hidden isoparameters.)#" 
          )
        .def("IsoLineHCompound",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_HLRToShape::IsoLineHCompound),
             R"#(Return hidden isoparameters of specified shape.)#"  , py::arg("S")
          )
        .def("CompoundOfEdges",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) >(&HLRBRep_HLRToShape::CompoundOfEdges),
             R"#(Returns compound of resulting edges of required type and visibility, taking into account the kind of space (2d or 3d))#"  , py::arg("type"),  py::arg("visible"),  py::arg("In3d")
          )
        .def("CompoundOfEdges",
             (TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape & ,   const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) ) static_cast<TopoDS_Shape (HLRBRep_HLRToShape::*)(  const TopoDS_Shape & ,   const HLRBRep_TypeOfResultingEdge ,   const bool ,   const bool  ) >(&HLRBRep_HLRToShape::CompoundOfEdges),
             R"#(For specified shape returns compound of resulting edges of required type and visibility, taking into account the kind of space (2d or 3d))#"  , py::arg("S"),  py::arg("type"),  py::arg("visible"),  py::arg("In3d")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_Hider from ./opencascade/HLRBRep_Hider.hxx
    klass = m.attr("HLRBRep_Hider");


    // nested enums

    static_cast<py::class_<HLRBRep_Hider , shared_ptr<HLRBRep_Hider>  >>(klass)
    // constructors
        .def(py::init<  const handle<HLRBRep_Data> & >()  , py::arg("DS") )
    // custom constructors
    // methods
        .def("OwnHiding",
             (void (HLRBRep_Hider::*)(  const int  ) ) static_cast<void (HLRBRep_Hider::*)(  const int  ) >(&HLRBRep_Hider::OwnHiding),
             R"#(own hiding the side face number <FI>.)#"  , py::arg("FI")
          )
        .def("Hide",
             (void (HLRBRep_Hider::*)(  const int ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> &  ) ) static_cast<void (HLRBRep_Hider::*)(  const int ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> &  ) >(&HLRBRep_Hider::Hide),
             R"#(Removes from the edges, the parts hidden by the hiding face number <FI>.)#"  , py::arg("FI"),  py::arg("MST")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_IntConicCurveOfCInter from ./opencascade/HLRBRep_IntConicCurveOfCInter.hxx
    klass = m.attr("HLRBRep_IntConicCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_IntConicCurveOfCInter , shared_ptr<HLRBRep_IntConicCurveOfCInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_InterCSurf from ./opencascade/HLRBRep_InterCSurf.hxx
    klass = m.attr("HLRBRep_InterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_InterCSurf , shared_ptr<HLRBRep_InterCSurf>  , IntCurveSurface_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,  HLRBRep_Surface *  ) ) static_cast<void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,  HLRBRep_Surface *  ) >(&HLRBRep_InterCSurf::Perform),
             R"#(Compute the Intersection between the curve and the surface)#"  , py::arg("theCurve"),  py::arg("theSurface")
          )
        .def("Perform",
             (void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface *  ) ) static_cast<void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface *  ) >(&HLRBRep_InterCSurf::Perform),
             R"#(Compute the Intersection between the curve and the surface. The Curve is already sampled and its polygon : <thePolygon> is given.)#"  , py::arg("theCurve"),  py::arg("thePolygon"),  py::arg("theSurface")
          )
        .def("Perform",
             (void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_InterCSurf::Perform),
             R"#(Compute the Intersection between the curve and the surface. The Curve is already sampled and its polygon : <thePolygon> is given. The Surface is also sampled and <thePolyhedron> is given.)#"  , py::arg("theCurve"),  py::arg("thePolygon"),  py::arg("theSurface"),  py::arg("thePolyhedron")
          )
        .def("Perform",
             (void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) ) static_cast<void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolygonOfInterCSurf & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) >(&HLRBRep_InterCSurf::Perform),
             R"#(Compute the Intersection between the curve and the surface. The Curve is already sampled and its polygon : <thePolygon> is given. The Surface is also sampled and <thePolyhedron> is given.)#"  , py::arg("theCurve"),  py::arg("thePolygon"),  py::arg("theSurface"),  py::arg("thePolyhedron"),  py::arg("theBndBSB")
          )
        .def("Perform",
             (void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_InterCSurf::*)(  const gp_Lin & ,  HLRBRep_Surface * ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_InterCSurf::Perform),
             R"#(Compute the Intersection between the curve and the surface. The Surface is already sampled and its polyhedron : <thePolyhedron> is given.)#"  , py::arg("theCurve"),  py::arg("theSurface"),  py::arg("thePolyhedron")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_InternalAlgo from ./opencascade/HLRBRep_InternalAlgo.hxx
    klass = m.attr("HLRBRep_InternalAlgo");


    // nested enums

    static_cast<py::class_<HLRBRep_InternalAlgo ,opencascade::handle<HLRBRep_InternalAlgo>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<HLRBRep_InternalAlgo> & >()  , py::arg("A") )
    // custom constructors
    // methods
        .def("Projector",
             (void (HLRBRep_InternalAlgo::*)(  const HLRAlgo_Projector &  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const HLRAlgo_Projector &  ) >(&HLRBRep_InternalAlgo::Projector),
             R"#(set the projector.)#"  , py::arg("P")
          )
        .def("Update",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::Update),
             R"#(update the DataStructure.)#" 
          )
        .def("Load",
             (void (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> & ,   const handle<Standard_Transient> & ,   const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> & ,   const handle<Standard_Transient> & ,   const int  ) >(&HLRBRep_InternalAlgo::Load),
             R"#(add the shape <S>.)#"  , py::arg("S"),  py::arg("SData"),  py::arg("nbIso")=static_cast< const int>(0)
          )
        .def("Load",
             (void (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> & ,   const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> & ,   const int  ) >(&HLRBRep_InternalAlgo::Load),
             R"#(add the shape <S>.)#"  , py::arg("S"),  py::arg("nbIso")=static_cast< const int>(0)
          )
        .def("Index",
             (int (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> &  ) const) static_cast<int (HLRBRep_InternalAlgo::*)(  const handle<HLRTopoBRep_OutLiner> &  ) const>(&HLRBRep_InternalAlgo::Index),
             R"#(return the index of the Shape <S> and return 0 if the Shape <S> is not found.)#"  , py::arg("S")
          )
        .def("Remove",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::Remove),
             R"#(remove the Shape of Index <I>.)#"  , py::arg("I")
          )
        .def("ShapeData",
             (void (HLRBRep_InternalAlgo::*)(  const int ,   const handle<Standard_Transient> &  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int ,   const handle<Standard_Transient> &  ) >(&HLRBRep_InternalAlgo::ShapeData),
             R"#(Change the Shape Data of the Shape of index <I>.)#"  , py::arg("I"),  py::arg("SData")
          )
        .def("NbShapes",
             (int (HLRBRep_InternalAlgo::*)() const) static_cast<int (HLRBRep_InternalAlgo::*)() const>(&HLRBRep_InternalAlgo::NbShapes),
             R"#()#" 
          )
        .def("ShapeBounds",
             (HLRBRep_ShapeBounds & (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<HLRBRep_ShapeBounds & (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::ShapeBounds),
             R"#()#"  , py::arg("I")
          )
        .def("InitEdgeStatus",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::InitEdgeStatus),
             R"#(init the status of the selected edges depending of the back faces of a closed shell.)#" 
          )
        .def("Select",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::Select),
             R"#(select all the DataStructure.)#" 
          )
        .def("Select",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::Select),
             R"#(select only the Shape of index <I>.)#"  , py::arg("I")
          )
        .def("SelectEdge",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::SelectEdge),
             R"#(select only the edges of the Shape <S>.)#"  , py::arg("I")
          )
        .def("SelectFace",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::SelectFace),
             R"#(select only the faces of the Shape <S>.)#"  , py::arg("I")
          )
        .def("ShowAll",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::ShowAll),
             R"#(set to visible all the edges.)#" 
          )
        .def("ShowAll",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::ShowAll),
             R"#(set to visible all the edges of the Shape <S>.)#"  , py::arg("I")
          )
        .def("HideAll",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::HideAll),
             R"#(set to hide all the edges.)#" 
          )
        .def("HideAll",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::HideAll),
             R"#(set to hide all the edges of the Shape <S>.)#"  , py::arg("I")
          )
        .def("PartialHide",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::PartialHide),
             R"#(own hiding of all the shapes of the DataStructure without hiding by each other.)#" 
          )
        .def("Hide",
             (void (HLRBRep_InternalAlgo::*)() ) static_cast<void (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::Hide),
             R"#(hide all the DataStructure.)#" 
          )
        .def("Hide",
             (void (HLRBRep_InternalAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int  ) >(&HLRBRep_InternalAlgo::Hide),
             R"#(hide the Shape <S> by itself.)#"  , py::arg("I")
          )
        .def("Hide",
             (void (HLRBRep_InternalAlgo::*)(  const int ,   const int  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const int ,   const int  ) >(&HLRBRep_InternalAlgo::Hide),
             R"#(hide the Shape <S1> by the shape <S2>.)#"  , py::arg("I"),  py::arg("J")
          )
        .def("Debug",
             (void (HLRBRep_InternalAlgo::*)(  const bool  ) ) static_cast<void (HLRBRep_InternalAlgo::*)(  const bool  ) >(&HLRBRep_InternalAlgo::Debug),
             R"#()#"  , py::arg("deb")
          )
        .def("Debug",
             (bool (HLRBRep_InternalAlgo::*)() const) static_cast<bool (HLRBRep_InternalAlgo::*)() const>(&HLRBRep_InternalAlgo::Debug),
             R"#()#" 
          )
        .def("DataStructure",
             (handle<HLRBRep_Data> (HLRBRep_InternalAlgo::*)() const) static_cast<handle<HLRBRep_Data> (HLRBRep_InternalAlgo::*)() const>(&HLRBRep_InternalAlgo::DataStructure),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRBRep_InternalAlgo::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRBRep_InternalAlgo::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Projector",
             (HLRAlgo_Projector & (HLRBRep_InternalAlgo::*)() ) static_cast<HLRAlgo_Projector & (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::Projector),
             R"#(set the projector.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("SeqOfShapeBounds",
             (NCollection_Sequence<HLRBRep_ShapeBounds> & (HLRBRep_InternalAlgo::*)() ) static_cast<NCollection_Sequence<HLRBRep_ShapeBounds> & (HLRBRep_InternalAlgo::*)() >(&HLRBRep_InternalAlgo::SeqOfShapeBounds),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRBRep_InternalAlgo::*)() const) static_cast< const handle<Standard_Type> & (HLRBRep_InternalAlgo::*)() const>(&HLRBRep_InternalAlgo::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRBRep_Intersector from ./opencascade/HLRBRep_Intersector.hxx
    klass = m.attr("HLRBRep_Intersector");


    // nested enums

    static_cast<py::class_<HLRBRep_Intersector , shared_ptr<HLRBRep_Intersector>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (HLRBRep_Intersector::*)( HLRBRep_EdgeData * ,   const double ,   const double  ) ) static_cast<void (HLRBRep_Intersector::*)( HLRBRep_EdgeData * ,   const double ,   const double  ) >(&HLRBRep_Intersector::Perform),
             R"#(Performs the auto intersection of an edge. The edge domain is cut at start with da1*(b-a) and at end with db1*(b-a).)#"  , py::arg("theEdge1"),  py::arg("theDa1"),  py::arg("theDb1")
          )
        .def("Perform",
             (void (HLRBRep_Intersector::*)(  const int ,  HLRBRep_EdgeData * ,   const double ,   const double ,   const int ,  HLRBRep_EdgeData * ,   const double ,   const double ,   const bool  ) ) static_cast<void (HLRBRep_Intersector::*)(  const int ,  HLRBRep_EdgeData * ,   const double ,   const double ,   const int ,  HLRBRep_EdgeData * ,   const double ,   const double ,   const bool  ) >(&HLRBRep_Intersector::Perform),
             R"#(Performs the intersection between the two edges. The edges domains are cut at start with da*(b-a) and at end with db*(b-a).)#"  , py::arg("theNA"),  py::arg("theEdge1"),  py::arg("theDa1"),  py::arg("theDb1"),  py::arg("theNB"),  py::arg("theEdge2"),  py::arg("theDa2"),  py::arg("theDb2"),  py::arg("theNoBound")
          )
        .def("SimulateOnePoint",
             (void (HLRBRep_Intersector::*)( HLRBRep_EdgeData * ,   const double ,  HLRBRep_EdgeData * ,   const double  ) ) static_cast<void (HLRBRep_Intersector::*)( HLRBRep_EdgeData * ,   const double ,  HLRBRep_EdgeData * ,   const double  ) >(&HLRBRep_Intersector::SimulateOnePoint),
             R"#(Create a single IntersectionPoint (U on theEdge1) (V on theEdge2) The point is middle on both curves.)#"  , py::arg("theEdge1"),  py::arg("theU"),  py::arg("theEdge2"),  py::arg("theV")
          )
        .def("Load",
             (void (HLRBRep_Intersector::*)( HLRBRep_Surface *  ) ) static_cast<void (HLRBRep_Intersector::*)( HLRBRep_Surface *  ) >(&HLRBRep_Intersector::Load),
             R"#()#"  , py::arg("theSurface")
          )
        .def("Perform",
             (void (HLRBRep_Intersector::*)(  const gp_Lin & ,   const double  ) ) static_cast<void (HLRBRep_Intersector::*)(  const gp_Lin & ,   const double  ) >(&HLRBRep_Intersector::Perform),
             R"#()#"  , py::arg("theL"),  py::arg("theP")
          )
        .def("IsDone",
             (bool (HLRBRep_Intersector::*)() const) static_cast<bool (HLRBRep_Intersector::*)() const>(&HLRBRep_Intersector::IsDone),
             R"#()#" 
          )
        .def("NbPoints",
             (int (HLRBRep_Intersector::*)() const) static_cast<int (HLRBRep_Intersector::*)() const>(&HLRBRep_Intersector::NbPoints),
             R"#()#" 
          )
        .def("Point",
             ( const IntRes2d_IntersectionPoint & (HLRBRep_Intersector::*)(  const int  ) const) static_cast< const IntRes2d_IntersectionPoint & (HLRBRep_Intersector::*)(  const int  ) const>(&HLRBRep_Intersector::Point),
             R"#()#"  , py::arg("N")
          )
        .def("CSPoint",
             ( const IntCurveSurface_IntersectionPoint & (HLRBRep_Intersector::*)(  const int  ) const) static_cast< const IntCurveSurface_IntersectionPoint & (HLRBRep_Intersector::*)(  const int  ) const>(&HLRBRep_Intersector::CSPoint),
             R"#()#"  , py::arg("N")
          )
        .def("NbSegments",
             (int (HLRBRep_Intersector::*)() const) static_cast<int (HLRBRep_Intersector::*)() const>(&HLRBRep_Intersector::NbSegments),
             R"#()#" 
          )
        .def("Segment",
             ( const IntRes2d_IntersectionSegment & (HLRBRep_Intersector::*)(  const int  ) const) static_cast< const IntRes2d_IntersectionSegment & (HLRBRep_Intersector::*)(  const int  ) const>(&HLRBRep_Intersector::Segment),
             R"#()#"  , py::arg("N")
          )
        .def("CSSegment",
             ( const IntCurveSurface_IntersectionSegment & (HLRBRep_Intersector::*)(  const int  ) const) static_cast< const IntCurveSurface_IntersectionSegment & (HLRBRep_Intersector::*)(  const int  ) const>(&HLRBRep_Intersector::CSSegment),
             R"#()#"  , py::arg("N")
          )
        .def("Destroy",
             (void (HLRBRep_Intersector::*)() ) static_cast<void (HLRBRep_Intersector::*)() >(&HLRBRep_Intersector::Destroy),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_LineTool from ./opencascade/HLRBRep_LineTool.hxx
    klass = m.attr("HLRBRep_LineTool");

    // default constructor
    register_default_constructor<HLRBRep_LineTool , shared_ptr<HLRBRep_LineTool>>(m,"HLRBRep_LineTool");

    // nested enums

    static_cast<py::class_<HLRBRep_LineTool , shared_ptr<HLRBRep_LineTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const gp_Lin &  ) ) static_cast<double (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::FirstParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const gp_Lin &  ) ) static_cast<double (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::LastParameter),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const gp_Lin &  ) ) static_cast<GeomAbs_Shape (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Continuity),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const gp_Lin & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const gp_Lin & ,   const GeomAbs_Shape  ) >(&HLRBRep_LineTool::NbIntervals),
                    R"#(If necessary, breaks the line in intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("C"),  py::arg("S")
          )
        .def_static("Intervals_s",
                    (void (*)(  const gp_Lin & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const gp_Lin & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_LineTool::Intervals),
                    R"#(Sets the current working interval.)#"  , py::arg("C"),  py::arg("T"),  py::arg("Sh")
          )
        .def_static("IntervalFirst_s",
                    (double (*)(  const gp_Lin &  ) ) static_cast<double (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IntervalFirst),
                    R"#(Returns the first parameter of the current interval.)#"  , py::arg("C")
          )
        .def_static("IntervalLast_s",
                    (double (*)(  const gp_Lin &  ) ) static_cast<double (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IntervalLast),
                    R"#(Returns the last parameter of the current interval.)#"  , py::arg("C")
          )
        .def_static("IntervalContinuity_s",
                    (GeomAbs_Shape (*)(  const gp_Lin &  ) ) static_cast<GeomAbs_Shape (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IntervalContinuity),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsClosed_s",
                    (bool (*)(  const gp_Lin &  ) ) static_cast<bool (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IsClosed),
                    R"#()#"  , py::arg("C")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const gp_Lin &  ) ) static_cast<bool (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IsPeriodic),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Period_s",
                    (double (*)(  const gp_Lin &  ) ) static_cast<double (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Period),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const gp_Lin & ,   const double  ) ) static_cast<gp_Pnt (*)(  const gp_Lin & ,   const double  ) >(&HLRBRep_LineTool::Value),
                    R"#(Computes the point of parameter U on the line.)#"  , py::arg("C"),  py::arg("U")
          )
        .def_static("D0_s",
                    (void (*)(  const gp_Lin & ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const gp_Lin & ,   const double ,  gp_Pnt &  ) >(&HLRBRep_LineTool::D0),
                    R"#(Computes the point of parameter U on the line.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) ) static_cast<void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) >(&HLRBRep_LineTool::D1),
                    R"#(Computes the point of parameter U on the line with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V")
          )
        .def_static("D2_s",
                    (void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_LineTool::D2),
                    R"#(Returns the point P of parameter U, the first and second derivatives V1 and V2. Raised if the continuity of the current interval is not C2.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2")
          )
        .def_static("D3_s",
                    (void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const gp_Lin & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_LineTool::D3),
                    R"#(Returns the point P of parameter U, the first, the second and the third derivative. Raised if the continuity of the current interval is not C3.)#"  , py::arg("C"),  py::arg("U"),  py::arg("P"),  py::arg("V1"),  py::arg("V2"),  py::arg("V3")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const gp_Lin & ,   const double ,   const int  ) ) static_cast<gp_Vec (*)(  const gp_Lin & ,   const double ,   const int  ) >(&HLRBRep_LineTool::DN),
                    R"#(The returned vector gives the value of the derivative for the order of derivation N. Raised if the continuity of the current interval is not CN. Raised if N < 1.)#"  , py::arg("C"),  py::arg("U"),  py::arg("N")
          )
        .def_static("Resolution_s",
                    (double (*)(  const gp_Lin & ,   const double  ) ) static_cast<double (*)(  const gp_Lin & ,   const double  ) >(&HLRBRep_LineTool::Resolution),
                    R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("C"),  py::arg("R3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const gp_Lin &  ) ) static_cast<GeomAbs_CurveType (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::GetType),
                    R"#(Returns the type of the line in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("C")
          )
        .def_static("Line_s",
                    (gp_Lin (*)(  const gp_Lin &  ) ) static_cast<gp_Lin (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Line),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Circle_s",
                    (gp_Circ (*)(  const gp_Lin &  ) ) static_cast<gp_Circ (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Circle),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Ellipse_s",
                    (gp_Elips (*)(  const gp_Lin &  ) ) static_cast<gp_Elips (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Ellipse),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr (*)(  const gp_Lin &  ) ) static_cast<gp_Hypr (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Hyperbola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Parabola_s",
                    (gp_Parab (*)(  const gp_Lin &  ) ) static_cast<gp_Parab (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Parabola),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierCurve> (*)(  const gp_Lin &  ) ) static_cast<handle<Geom_BezierCurve> (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Bezier),
                    R"#()#"  , py::arg("C")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineCurve> (*)(  const gp_Lin &  ) ) static_cast<handle<Geom_BSplineCurve> (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::BSpline),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Degree_s",
                    (int (*)(  const gp_Lin &  ) ) static_cast<int (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::Degree),
                    R"#()#"  , py::arg("C")
          )
        .def_static("NbPoles_s",
                    (int (*)(  const gp_Lin &  ) ) static_cast<int (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::NbPoles),
                    R"#()#"  , py::arg("C")
          )
        .def_static("Poles_s",
                    (void (*)(  const gp_Lin & ,  NCollection_Array1<gp_Pnt> &  ) ) static_cast<void (*)(  const gp_Lin & ,  NCollection_Array1<gp_Pnt> &  ) >(&HLRBRep_LineTool::Poles),
                    R"#()#"  , py::arg("C"),  py::arg("TP")
          )
        .def_static("IsRational_s",
                    (bool (*)(  const gp_Lin &  ) ) static_cast<bool (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::IsRational),
                    R"#()#"  , py::arg("C")
          )
        .def_static("PolesAndWeights_s",
                    (void (*)(  const gp_Lin & ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<double> &  ) ) static_cast<void (*)(  const gp_Lin & ,  NCollection_Array1<gp_Pnt> & ,  NCollection_Array1<double> &  ) >(&HLRBRep_LineTool::PolesAndWeights),
                    R"#()#"  , py::arg("C"),  py::arg("TP"),  py::arg("TW")
          )
        .def_static("NbKnots_s",
                    (int (*)(  const gp_Lin &  ) ) static_cast<int (*)(  const gp_Lin &  ) >(&HLRBRep_LineTool::NbKnots),
                    R"#()#"  , py::arg("C")
          )
        .def_static("KnotsAndMultiplicities_s",
                    (void (*)(  const gp_Lin & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> &  ) ) static_cast<void (*)(  const gp_Lin & ,  NCollection_Array1<double> & ,  NCollection_Array1<int> &  ) >(&HLRBRep_LineTool::KnotsAndMultiplicities),
                    R"#()#"  , py::arg("C"),  py::arg("TK"),  py::arg("TM")
          )
        .def_static("NbSamples_s",
                    (int (*)(  const gp_Lin & ,   const double ,   const double  ) ) static_cast<int (*)(  const gp_Lin & ,   const double ,   const double  ) >(&HLRBRep_LineTool::NbSamples),
                    R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1")
          )
        .def_static("SamplePars_s",
                    (handle<NCollection_HArray1<double>> (*)(  const gp_Lin & ,   const double ,   const double ,   const double ,   const int  ) ) static_cast<handle<NCollection_HArray1<double>> (*)(  const gp_Lin & ,   const double ,   const double ,   const double ,   const int  ) >(&HLRBRep_LineTool::SamplePars),
                    R"#(Returns sample parameters for the line within [U0, U1] range.)#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1"),  py::arg("Defl"),  py::arg("NbMin")
          )
    // static methods using call by reference i.s.o. return
        .def_static("SamplePars_s",
            []( const gp_Lin & C, const double U0, const double U1, const double Defl, const int NbMin,NCollection_HArray1<double>& Pars ){
                handle<NCollection_HArray1<double>>  Pars_ptr; Pars_ptr = &Pars;

                HLRBRep_LineTool::SamplePars(C,U0,U1,Defl,NbMin,Pars_ptr);
                if ( Pars_ptr.get() != &Pars ) copy_if_assignable(Pars, *Pars_ptr);

 },
            R"#()#"  , py::arg("C"),  py::arg("U0"),  py::arg("U1"),  py::arg("Defl"),  py::arg("NbMin"),  py::arg("Pars")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter from ./opencascade/HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter.hxx
    klass = m.attr("HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter , shared_ptr<HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter>  , math_FunctionWithDerivative >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Value",
             (bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double &  ) ) static_cast<bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double &  ) >(&HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::Value),
             R"#(Computes the value of the signed distance between the implicit curve and the point at parameter Param on the parametrised curve.)#"  , py::arg("Param"),  py::arg("F")
          )
        .def("Derivative",
             (bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double &  ) ) static_cast<bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double &  ) >(&HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::Derivative),
             R"#(Computes the derivative of the previous function at parameter Param.)#"  , py::arg("Param"),  py::arg("D")
          )
        .def("Values",
             (bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::*)(  const double ,  double & ,  double &  ) >(&HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter::Values),
             R"#(Computes the value and the derivative of the function.)#"  , py::arg("Param"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_PolyAlgo from ./opencascade/HLRBRep_PolyAlgo.hxx
    klass = m.attr("HLRBRep_PolyAlgo");


    // nested enums

    static_cast<py::class_<HLRBRep_PolyAlgo ,opencascade::handle<HLRBRep_PolyAlgo>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("S") )
        .def(py::init<  const handle<HLRBRep_PolyAlgo> & >()  , py::arg("A") )
    // custom constructors
    // methods
        .def("NbShapes",
             (int (HLRBRep_PolyAlgo::*)() const) static_cast<int (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::NbShapes),
             R"#()#" 
          )
        .def("Shape",
             (TopoDS_Shape & (HLRBRep_PolyAlgo::*)(  const int  ) ) static_cast<TopoDS_Shape & (HLRBRep_PolyAlgo::*)(  const int  ) >(&HLRBRep_PolyAlgo::Shape),
             R"#()#"  , py::arg("I")
          )
        .def("Remove",
             (void (HLRBRep_PolyAlgo::*)(  const int  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const int  ) >(&HLRBRep_PolyAlgo::Remove),
             R"#(remove the Shape of Index <I>.)#"  , py::arg("I")
          )
        .def("Index",
             (int (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) const) static_cast<int (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) const>(&HLRBRep_PolyAlgo::Index),
             R"#(return the index of the Shape <S> and return 0 if the Shape <S> is not found.)#"  , py::arg("S")
          )
        .def("Load",
             (void (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyAlgo::Load),
             R"#(Loads the shape S into this framework. Warning S must have already been triangulated.)#"  , py::arg("theShape")
          )
        .def("Projector",
             (void (HLRBRep_PolyAlgo::*)(  const HLRAlgo_Projector &  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const HLRAlgo_Projector &  ) >(&HLRBRep_PolyAlgo::Projector),
             R"#()#"  , py::arg("theProj")
          )
        .def("TolAngular",
             (double (HLRBRep_PolyAlgo::*)() const) static_cast<double (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::TolAngular),
             R"#()#" 
          )
        .def("TolAngular",
             (void (HLRBRep_PolyAlgo::*)(  const double  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const double  ) >(&HLRBRep_PolyAlgo::TolAngular),
             R"#()#"  , py::arg("theTol")
          )
        .def("TolCoef",
             (double (HLRBRep_PolyAlgo::*)() const) static_cast<double (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::TolCoef),
             R"#()#" 
          )
        .def("TolCoef",
             (void (HLRBRep_PolyAlgo::*)(  const double  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const double  ) >(&HLRBRep_PolyAlgo::TolCoef),
             R"#()#"  , py::arg("theTol")
          )
        .def("Update",
             (void (HLRBRep_PolyAlgo::*)() ) static_cast<void (HLRBRep_PolyAlgo::*)() >(&HLRBRep_PolyAlgo::Update),
             R"#(Launches calculation of outlines of the shape visualized by this framework. Used after setting the point of view and defining the shape or shapes to be visualized.)#" 
          )
        .def("InitHide",
             (void (HLRBRep_PolyAlgo::*)() ) static_cast<void (HLRBRep_PolyAlgo::*)() >(&HLRBRep_PolyAlgo::InitHide),
             R"#()#" 
          )
        .def("MoreHide",
             (bool (HLRBRep_PolyAlgo::*)() const) static_cast<bool (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::MoreHide),
             R"#()#" 
          )
        .def("NextHide",
             (void (HLRBRep_PolyAlgo::*)() ) static_cast<void (HLRBRep_PolyAlgo::*)() >(&HLRBRep_PolyAlgo::NextHide),
             R"#()#" 
          )
        .def("Hide",
             (HLRAlgo_BiPoint::PointsT & (HLRBRep_PolyAlgo::*)( HLRAlgo_EdgeStatus & ,  TopoDS_Shape & ,  bool & ,  bool & ,  bool & ,  bool &  ) ) static_cast<HLRAlgo_BiPoint::PointsT & (HLRBRep_PolyAlgo::*)( HLRAlgo_EdgeStatus & ,  TopoDS_Shape & ,  bool & ,  bool & ,  bool & ,  bool &  ) >(&HLRBRep_PolyAlgo::Hide),
             R"#()#"  , py::arg("status"),  py::arg("S"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl")
          )
        .def("InitShow",
             (void (HLRBRep_PolyAlgo::*)() ) static_cast<void (HLRBRep_PolyAlgo::*)() >(&HLRBRep_PolyAlgo::InitShow),
             R"#()#" 
          )
        .def("MoreShow",
             (bool (HLRBRep_PolyAlgo::*)() const) static_cast<bool (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::MoreShow),
             R"#()#" 
          )
        .def("NextShow",
             (void (HLRBRep_PolyAlgo::*)() ) static_cast<void (HLRBRep_PolyAlgo::*)() >(&HLRBRep_PolyAlgo::NextShow),
             R"#()#" 
          )
        .def("Show",
             (HLRAlgo_BiPoint::PointsT & (HLRBRep_PolyAlgo::*)( TopoDS_Shape & ,  bool & ,  bool & ,  bool & ,  bool &  ) ) static_cast<HLRAlgo_BiPoint::PointsT & (HLRBRep_PolyAlgo::*)( TopoDS_Shape & ,  bool & ,  bool & ,  bool & ,  bool &  ) >(&HLRBRep_PolyAlgo::Show),
             R"#()#"  , py::arg("S"),  py::arg("reg1"),  py::arg("regn"),  py::arg("outl"),  py::arg("intl")
          )
        .def("OutLinedShape",
             (TopoDS_Shape (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) const) static_cast<TopoDS_Shape (HLRBRep_PolyAlgo::*)(  const TopoDS_Shape &  ) const>(&HLRBRep_PolyAlgo::OutLinedShape),
             R"#(Make a shape with the internal outlines in each face.)#"  , py::arg("S")
          )
        .def("Debug",
             (bool (HLRBRep_PolyAlgo::*)() const) static_cast<bool (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::Debug),
             R"#()#" 
          )
        .def("Debug",
             (void (HLRBRep_PolyAlgo::*)(  const bool  ) ) static_cast<void (HLRBRep_PolyAlgo::*)(  const bool  ) >(&HLRBRep_PolyAlgo::Debug),
             R"#()#"  , py::arg("theDebug")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRBRep_PolyAlgo::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRBRep_PolyAlgo::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Algo",
             ( const handle<HLRAlgo_PolyAlgo> & (HLRBRep_PolyAlgo::*)() const) static_cast< const handle<HLRAlgo_PolyAlgo> & (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::Algo),
             R"#()#"
             
         )
       .def("Projector",
             ( const HLRAlgo_Projector & (HLRBRep_PolyAlgo::*)() const) static_cast< const HLRAlgo_Projector & (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::Projector),
             R"#(Sets the parameters of the view for this framework. These parameters are defined by an HLRAlgo_Projector object, which is returned by the Projector function on a Prs3d_Projector object.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRBRep_PolyAlgo::*)() const) static_cast< const handle<Standard_Type> & (HLRBRep_PolyAlgo::*)() const>(&HLRBRep_PolyAlgo::DynamicType),
             R"#()#"
             
         )
;

    // Class HLRBRep_PolyHLRToShape from ./opencascade/HLRBRep_PolyHLRToShape.hxx
    klass = m.attr("HLRBRep_PolyHLRToShape");


    // nested enums

    static_cast<py::class_<HLRBRep_PolyHLRToShape , shared_ptr<HLRBRep_PolyHLRToShape>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Update",
             (void (HLRBRep_PolyHLRToShape::*)(  const handle<HLRBRep_PolyAlgo> &  ) ) static_cast<void (HLRBRep_PolyHLRToShape::*)(  const handle<HLRBRep_PolyAlgo> &  ) >(&HLRBRep_PolyHLRToShape::Update),
             R"#()#"  , py::arg("A")
          )
        .def("Show",
             (void (HLRBRep_PolyHLRToShape::*)() ) static_cast<void (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Show),
             R"#()#" 
          )
        .def("Hide",
             (void (HLRBRep_PolyHLRToShape::*)() ) static_cast<void (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Hide),
             R"#()#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::VCompound),
             R"#()#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::VCompound),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Rg1LineVCompound),
             R"#(Sets the extraction filter for visible smooth edges.)#" 
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::Rg1LineVCompound),
             R"#()#"  , py::arg("S")
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::RgNLineVCompound),
             R"#(Sets the extraction filter for visible sewn edges.)#" 
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::RgNLineVCompound),
             R"#()#"  , py::arg("S")
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::OutLineVCompound),
             R"#()#" 
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::OutLineVCompound),
             R"#(Sets the extraction filter for visible outlines.)#"  , py::arg("S")
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::HCompound),
             R"#()#" 
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::HCompound),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Rg1LineHCompound),
             R"#()#" 
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::Rg1LineHCompound),
             R"#(Sets the extraction filter for hidden smooth edges.)#"  , py::arg("S")
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::RgNLineHCompound),
             R"#()#" 
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::RgNLineHCompound),
             R"#(Sets the extraction filter for hidden sewn edges.)#"  , py::arg("S")
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::OutLineHCompound),
             R"#()#" 
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::OutLineHCompound),
             R"#(Sets the extraction filter for hidden outlines. Hidden outlines occur, for instance, in tori. In this case, the inner outlines of the torus seen on its side are hidden.)#"  , py::arg("S")
          )
        .def("Show",
             (void (HLRBRep_PolyHLRToShape::*)() ) static_cast<void (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Show),
             R"#()#" 
          )
        .def("Hide",
             (void (HLRBRep_PolyHLRToShape::*)() ) static_cast<void (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Hide),
             R"#()#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::VCompound),
             R"#()#" 
          )
        .def("VCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::VCompound),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Rg1LineVCompound),
             R"#(Sets the extraction filter for visible smooth edges.)#" 
          )
        .def("Rg1LineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::Rg1LineVCompound),
             R"#()#"  , py::arg("S")
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::RgNLineVCompound),
             R"#(Sets the extraction filter for visible sewn edges.)#" 
          )
        .def("RgNLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::RgNLineVCompound),
             R"#()#"  , py::arg("S")
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::OutLineVCompound),
             R"#()#" 
          )
        .def("OutLineVCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::OutLineVCompound),
             R"#(Sets the extraction filter for visible outlines.)#"  , py::arg("S")
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::HCompound),
             R"#()#" 
          )
        .def("HCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::HCompound),
             R"#()#"  , py::arg("S")
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::Rg1LineHCompound),
             R"#()#" 
          )
        .def("Rg1LineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::Rg1LineHCompound),
             R"#(Sets the extraction filter for hidden smooth edges.)#"  , py::arg("S")
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::RgNLineHCompound),
             R"#()#" 
          )
        .def("RgNLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::RgNLineHCompound),
             R"#(Sets the extraction filter for hidden sewn edges.)#"  , py::arg("S")
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)() >(&HLRBRep_PolyHLRToShape::OutLineHCompound),
             R"#()#" 
          )
        .def("OutLineHCompound",
             (TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) ) static_cast<TopoDS_Shape (HLRBRep_PolyHLRToShape::*)(  const TopoDS_Shape &  ) >(&HLRBRep_PolyHLRToShape::OutLineHCompound),
             R"#(Sets the extraction filter for hidden outlines. Hidden outlines occur, for instance, in tori. In this case, the inner outlines of the torus seen on its side are hidden.)#"  , py::arg("S")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_SLPropsATool from ./opencascade/HLRBRep_SLPropsATool.hxx
    klass = m.attr("HLRBRep_SLPropsATool");

    // default constructor
    register_default_constructor<HLRBRep_SLPropsATool , shared_ptr<HLRBRep_SLPropsATool>>(m,"HLRBRep_SLPropsATool");

    // nested enums

    static_cast<py::class_<HLRBRep_SLPropsATool , shared_ptr<HLRBRep_SLPropsATool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Value_s",
                    (void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt &  ) >(&HLRBRep_SLPropsATool::Value),
                    R"#(Computes the point <P> of parameter <U> and <V> on the Surface <A>.)#"  , py::arg("A"),  py::arg("U"),  py::arg("V"),  py::arg("P")
          )
        .def_static("D1_s",
                    (void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_SLPropsATool::D1),
                    R"#(Computes the point <P> and first derivative <D1*> of parameter <U> and <V> on the Surface <A>.)#"  , py::arg("A"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V")
          )
        .def_static("D2_s",
                    (void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_SLPropsATool::D2),
                    R"#(Computes the point <P>, the first derivative <D1*> and second derivative <D2*> of parameter <U> and <V> on the Surface <A>.)#"  , py::arg("A"),  py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("DUV")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,   const int ,   const int  ) ) static_cast<gp_Vec (*)(  const HLRBRep_SurfacePtr ,   const double ,   const double ,   const int ,   const int  ) >(&HLRBRep_SLPropsATool::DN),
                    R"#()#"  , py::arg("A"),  py::arg("U"),  py::arg("V"),  py::arg("Nu"),  py::arg("Nv")
          )
        .def_static("Continuity_s",
                    (int (*)(  const HLRBRep_SurfacePtr  ) ) static_cast<int (*)(  const HLRBRep_SurfacePtr  ) >(&HLRBRep_SLPropsATool::Continuity),
                    R"#(returns the order of continuity of the Surface <A>. returns 1 : first derivative only is computable returns 2 : first and second derivative only are computable.)#"  , py::arg("A")
          )
    // static methods using call by reference i.s.o. return
        .def_static("Bounds_s",
            []( const HLRBRep_SurfacePtr A ){
                double  U1;
                double  V1;
                double  U2;
                double  V2;

                HLRBRep_SLPropsATool::Bounds(A,U1,V1,U2,V2);
                
return std::make_tuple(U1,V1,U2,V2); },
            R"#(returns the bounds of the Surface.)#"  , py::arg("A")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_ShapeBounds from ./opencascade/HLRBRep_ShapeBounds.hxx
    klass = m.attr("HLRBRep_ShapeBounds");


    // nested enums

    static_cast<py::class_<HLRBRep_ShapeBounds , shared_ptr<HLRBRep_ShapeBounds>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<HLRTopoBRep_OutLiner> &, const int, const int, const int, const int, const int, const int, const int >()  , py::arg("S"),  py::arg("nbIso"),  py::arg("V1"),  py::arg("V2"),  py::arg("E1"),  py::arg("E2"),  py::arg("F1"),  py::arg("F2") )
        .def(py::init<  const handle<HLRTopoBRep_OutLiner> &, const handle<Standard_Transient> &, const int, const int, const int, const int, const int, const int, const int >()  , py::arg("S"),  py::arg("SData"),  py::arg("nbIso"),  py::arg("V1"),  py::arg("V2"),  py::arg("E1"),  py::arg("E2"),  py::arg("F1"),  py::arg("F2") )
    // custom constructors
    // methods
        .def("Translate",
             (void (HLRBRep_ShapeBounds::*)(  const int ,   const int ,   const int  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const int ,   const int ,   const int  ) >(&HLRBRep_ShapeBounds::Translate),
             R"#()#"  , py::arg("NV"),  py::arg("NE"),  py::arg("NF")
          )
        .def("Shape",
             (void (HLRBRep_ShapeBounds::*)(  const handle<HLRTopoBRep_OutLiner> &  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const handle<HLRTopoBRep_OutLiner> &  ) >(&HLRBRep_ShapeBounds::Shape),
             R"#()#"  , py::arg("S")
          )
        .def("ShapeData",
             (void (HLRBRep_ShapeBounds::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const handle<Standard_Transient> &  ) >(&HLRBRep_ShapeBounds::ShapeData),
             R"#()#"  , py::arg("SD")
          )
        .def("NbOfIso",
             (void (HLRBRep_ShapeBounds::*)(  const int  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const int  ) >(&HLRBRep_ShapeBounds::NbOfIso),
             R"#()#"  , py::arg("nbIso")
          )
        .def("NbOfIso",
             (int (HLRBRep_ShapeBounds::*)() const) static_cast<int (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::NbOfIso),
             R"#()#" 
          )
        .def("UpdateMinMax",
             (void (HLRBRep_ShapeBounds::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const HLRAlgo_EdgesBlock::MinMaxIndices &  ) >(&HLRBRep_ShapeBounds::UpdateMinMax),
             R"#()#"  , py::arg("theTotMinMax")
          )
        .def("Shape",
             (void (HLRBRep_ShapeBounds::*)(  const handle<HLRTopoBRep_OutLiner> &  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const handle<HLRTopoBRep_OutLiner> &  ) >(&HLRBRep_ShapeBounds::Shape),
             R"#()#"  , py::arg("S")
          )
        .def("ShapeData",
             (void (HLRBRep_ShapeBounds::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const handle<Standard_Transient> &  ) >(&HLRBRep_ShapeBounds::ShapeData),
             R"#()#"  , py::arg("SD")
          )
        .def("NbOfIso",
             (void (HLRBRep_ShapeBounds::*)(  const int  ) ) static_cast<void (HLRBRep_ShapeBounds::*)(  const int  ) >(&HLRBRep_ShapeBounds::NbOfIso),
             R"#()#"  , py::arg("nbIso")
          )
        .def("NbOfIso",
             (int (HLRBRep_ShapeBounds::*)() const) static_cast<int (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::NbOfIso),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Sizes",
             []( HLRBRep_ShapeBounds &self   ){
                 int  NV;
                int  NE;
                int  NF;

                 self.Sizes(NV,NE,NF);
                 return std::make_tuple(NV,NE,NF); },
             R"#()#" 
          )
        .def("Bounds",
             []( HLRBRep_ShapeBounds &self   ){
                 int  V1;
                int  V2;
                int  E1;
                int  E2;
                int  F1;
                int  F2;

                 self.Bounds(V1,V2,E1,E2,F1,F2);
                 return std::make_tuple(V1,V2,E1,E2,F1,F2); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const handle<HLRTopoBRep_OutLiner> & (HLRBRep_ShapeBounds::*)() const) static_cast< const handle<HLRTopoBRep_OutLiner> & (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::Shape),
             R"#()#"
             
         )
       .def("ShapeData",
             ( const handle<Standard_Transient> & (HLRBRep_ShapeBounds::*)() const) static_cast< const handle<Standard_Transient> & (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::ShapeData),
             R"#()#"
             
         )
       .def("MinMax",
             (HLRAlgo_EdgesBlock::MinMaxIndices & (HLRBRep_ShapeBounds::*)() ) static_cast<HLRAlgo_EdgesBlock::MinMaxIndices & (HLRBRep_ShapeBounds::*)() >(&HLRBRep_ShapeBounds::MinMax),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Shape",
             ( const handle<HLRTopoBRep_OutLiner> & (HLRBRep_ShapeBounds::*)() const) static_cast< const handle<HLRTopoBRep_OutLiner> & (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::Shape),
             R"#()#"
             
         )
       .def("ShapeData",
             ( const handle<Standard_Transient> & (HLRBRep_ShapeBounds::*)() const) static_cast< const handle<Standard_Transient> & (HLRBRep_ShapeBounds::*)() const>(&HLRBRep_ShapeBounds::ShapeData),
             R"#()#"
             
         )
;

    // Class HLRBRep_ShapeToHLR from ./opencascade/HLRBRep_ShapeToHLR.hxx
    klass = m.attr("HLRBRep_ShapeToHLR");

    // default constructor
    register_default_constructor<HLRBRep_ShapeToHLR , shared_ptr<HLRBRep_ShapeToHLR>>(m,"HLRBRep_ShapeToHLR");

    // nested enums

    static_cast<py::class_<HLRBRep_ShapeToHLR , shared_ptr<HLRBRep_ShapeToHLR>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Load_s",
                    (handle<HLRBRep_Data> (*)(  const handle<HLRTopoBRep_OutLiner> & ,   const HLRAlgo_Projector & ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> & ,   const int  ) ) static_cast<handle<HLRBRep_Data> (*)(  const handle<HLRTopoBRep_OutLiner> & ,   const HLRAlgo_Projector & ,  NCollection_DataMap<TopoDS_Shape, BRepTopAdaptor_Tool, TopTools_ShapeMapHasher> & ,   const int  ) >(&HLRBRep_ShapeToHLR::Load),
                    R"#(Creates a DataStructure containing the OutLiner <S> depending on the projector <P> and nbIso.)#"  , py::arg("S"),  py::arg("P"),  py::arg("MST"),  py::arg("nbIso")=static_cast< const int>(0)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_Surface from ./opencascade/HLRBRep_Surface.hxx
    klass = m.attr("HLRBRep_Surface");


    // nested enums

    static_cast<py::class_<HLRBRep_Surface , shared_ptr<HLRBRep_Surface>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Projector",
             (void (HLRBRep_Surface::*)(  const HLRAlgo_Projector *  ) ) static_cast<void (HLRBRep_Surface::*)(  const HLRAlgo_Projector *  ) >(&HLRBRep_Surface::Projector),
             R"#()#"  , py::arg("Proj")
          )
        .def("Surface",
             (void (HLRBRep_Surface::*)(  const TopoDS_Face &  ) ) static_cast<void (HLRBRep_Surface::*)(  const TopoDS_Face &  ) >(&HLRBRep_Surface::Surface),
             R"#(Sets the 3D Surface to be projected.)#"  , py::arg("F")
          )
        .def("IsSide",
             (bool (HLRBRep_Surface::*)(  const double ,   const double  ) const) static_cast<bool (HLRBRep_Surface::*)(  const double ,   const double  ) const>(&HLRBRep_Surface::IsSide),
             R"#(returns true if it is a side face)#"  , py::arg("tolf"),  py::arg("toler")
          )
        .def("IsAbove",
             (bool (HLRBRep_Surface::*)(  const bool ,   const HLRBRep_Curve * ,   const double  ) const) static_cast<bool (HLRBRep_Surface::*)(  const bool ,   const HLRBRep_Curve * ,   const double  ) const>(&HLRBRep_Surface::IsAbove),
             R"#()#"  , py::arg("back"),  py::arg("A"),  py::arg("tolC")
          )
        .def("FirstUParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::LastVParameter),
             R"#()#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (HLRBRep_Surface::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (HLRBRep_Surface::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VContinuity),
             R"#()#" 
          )
        .def("NbUIntervals",
             (int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Surface::NbUIntervals),
             R"#(If necessary, breaks the surface in U intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("NbVIntervals",
             (int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Surface::NbVIntervals),
             R"#(If necessary, breaks the surface in V intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("IsUClosed",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VPeriod),
             R"#()#" 
          )
        .def("Value",
             (gp_Pnt (HLRBRep_Surface::*)(  const double ,   const double  ) const) static_cast<gp_Pnt (HLRBRep_Surface::*)(  const double ,   const double  ) const>(&HLRBRep_Surface::Value),
             R"#(Computes the point of parameters U,V on the surface.)#"  , py::arg("U"),  py::arg("V")
          )
        .def("D0",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt &  ) const>(&HLRBRep_Surface::D0),
             R"#(Computes the point of parameters U,V on the surface.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P")
          )
        .def("D1",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D1),
             R"#(Computes the point and the first derivatives on the surface. Raised if the continuity of the current intervals is not C1.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V")
          )
        .def("D2",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D2),
             R"#(Computes the point, the first and second derivatives on the surface. Raised if the continuity of the current intervals is not C2.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV")
          )
        .def("D3",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D3),
             R"#(Computes the point, the first, second and third derivatives on the surface. Raised if the continuity of the current intervals is not C3.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV"),  py::arg("D3U"),  py::arg("D3V"),  py::arg("D3UUV"),  py::arg("D3UVV")
          )
        .def("DN",
             (gp_Vec (HLRBRep_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const) static_cast<gp_Vec (HLRBRep_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const>(&HLRBRep_Surface::DN),
             R"#(Computes the derivative of order Nu in the direction U and Nv in the direction V at the point P(U, V). Raised if the current U interval is not not CNu and the current V interval is not CNv. Raised if Nu + Nv < 1 or Nu < 0 or Nv < 0.)#"  , py::arg("U"),  py::arg("V"),  py::arg("Nu"),  py::arg("Nv")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (HLRBRep_Surface::*)() const) static_cast<GeomAbs_SurfaceType (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::GetType),
             R"#(Returns the type of the surface : Plane, Cylinder, Cone, Sphere, Torus, BezierSurface, BSplineSurface, SurfaceOfRevolution, SurfaceOfExtrusion, OtherSurface)#" 
          )
        .def("Plane",
             (gp_Pln (HLRBRep_Surface::*)() const) static_cast<gp_Pln (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Plane),
             R"#()#" 
          )
        .def("Cylinder",
             (gp_Cylinder (HLRBRep_Surface::*)() const) static_cast<gp_Cylinder (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (HLRBRep_Surface::*)() const) static_cast<gp_Cone (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Cone),
             R"#()#" 
          )
        .def("Sphere",
             (gp_Sphere (HLRBRep_Surface::*)() const) static_cast<gp_Sphere (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (HLRBRep_Surface::*)() const) static_cast<gp_Torus (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Torus),
             R"#()#" 
          )
        .def("UDegree",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UDegree),
             R"#()#" 
          )
        .def("NbUPoles",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbUPoles),
             R"#()#" 
          )
        .def("VDegree",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VDegree),
             R"#()#" 
          )
        .def("NbVPoles",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbVPoles),
             R"#()#" 
          )
        .def("NbUKnots",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbUKnots),
             R"#()#" 
          )
        .def("NbVKnots",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbVKnots),
             R"#()#" 
          )
        .def("Axis",
             (gp_Ax1 (HLRBRep_Surface::*)() const) static_cast<gp_Ax1 (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Axis),
             R"#()#" 
          )
        .def("FirstUParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::LastVParameter),
             R"#()#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (HLRBRep_Surface::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (HLRBRep_Surface::*)() const) static_cast<GeomAbs_Shape (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VContinuity),
             R"#()#" 
          )
        .def("NbUIntervals",
             (int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Surface::NbUIntervals),
             R"#(If necessary, breaks the surface in U intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("NbVIntervals",
             (int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (HLRBRep_Surface::*)(  const GeomAbs_Shape  ) const>(&HLRBRep_Surface::NbVIntervals),
             R"#(If necessary, breaks the surface in V intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("S")
          )
        .def("IsUClosed",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (HLRBRep_Surface::*)() const) static_cast<bool (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (HLRBRep_Surface::*)() const) static_cast<double (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VPeriod),
             R"#()#" 
          )
        .def("D0",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt &  ) const>(&HLRBRep_Surface::D0),
             R"#(Computes the point of parameters U,V on the surface.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P")
          )
        .def("D1",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D1),
             R"#(Computes the point and the first derivatives on the surface. Raised if the continuity of the current intervals is not C1.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V")
          )
        .def("D2",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D2),
             R"#(Computes the point, the first and second derivatives on the surface. Raised if the continuity of the current intervals is not C2.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV")
          )
        .def("D3",
             (void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (HLRBRep_Surface::*)(  const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const>(&HLRBRep_Surface::D3),
             R"#(Computes the point, the first, second and third derivatives on the surface. Raised if the continuity of the current intervals is not C3.)#"  , py::arg("U"),  py::arg("V"),  py::arg("P"),  py::arg("D1U"),  py::arg("D1V"),  py::arg("D2U"),  py::arg("D2V"),  py::arg("D2UV"),  py::arg("D3U"),  py::arg("D3V"),  py::arg("D3UUV"),  py::arg("D3UVV")
          )
        .def("DN",
             (gp_Vec (HLRBRep_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const) static_cast<gp_Vec (HLRBRep_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const>(&HLRBRep_Surface::DN),
             R"#(Computes the derivative of order Nu in the direction U and Nv in the direction V at the point P(U, V). Raised if the current U interval is not not CNu and the current V interval is not CNv. Raised if Nu + Nv < 1 or Nu < 0 or Nv < 0.)#"  , py::arg("U"),  py::arg("V"),  py::arg("Nu"),  py::arg("Nv")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (HLRBRep_Surface::*)() const) static_cast<GeomAbs_SurfaceType (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::GetType),
             R"#(Returns the type of the surface : Plane, Cylinder, Cone, Sphere, Torus, BezierSurface, BSplineSurface, SurfaceOfRevolution, SurfaceOfExtrusion, OtherSurface)#" 
          )
        .def("Cylinder",
             (gp_Cylinder (HLRBRep_Surface::*)() const) static_cast<gp_Cylinder (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (HLRBRep_Surface::*)() const) static_cast<gp_Cone (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Cone),
             R"#()#" 
          )
        .def("Sphere",
             (gp_Sphere (HLRBRep_Surface::*)() const) static_cast<gp_Sphere (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (HLRBRep_Surface::*)() const) static_cast<gp_Torus (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Torus),
             R"#()#" 
          )
        .def("UDegree",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::UDegree),
             R"#()#" 
          )
        .def("NbUPoles",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbUPoles),
             R"#()#" 
          )
        .def("VDegree",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::VDegree),
             R"#()#" 
          )
        .def("NbVPoles",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbVPoles),
             R"#()#" 
          )
        .def("NbUKnots",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbUKnots),
             R"#()#" 
          )
        .def("NbVKnots",
             (int (HLRBRep_Surface::*)() const) static_cast<int (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::NbVKnots),
             R"#()#" 
          )
        .def("Axis",
             (gp_Ax1 (HLRBRep_Surface::*)() const) static_cast<gp_Ax1 (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Axis),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Surface",
             (BRepAdaptor_Surface & (HLRBRep_Surface::*)() ) static_cast<BRepAdaptor_Surface & (HLRBRep_Surface::*)() >(&HLRBRep_Surface::Surface),
             R"#(Returns the 3D Surface.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Surface",
             ( const BRepAdaptor_Surface & (HLRBRep_Surface::*)() const) static_cast< const BRepAdaptor_Surface & (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Surface),
             R"#(Returns the 3D Surface (const version).)#"
             
         )
       .def("Surface",
             (BRepAdaptor_Surface & (HLRBRep_Surface::*)() ) static_cast<BRepAdaptor_Surface & (HLRBRep_Surface::*)() >(&HLRBRep_Surface::Surface),
             R"#(Returns the 3D Surface.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Surface",
             ( const BRepAdaptor_Surface & (HLRBRep_Surface::*)() const) static_cast< const BRepAdaptor_Surface & (HLRBRep_Surface::*)() const>(&HLRBRep_Surface::Surface),
             R"#(Returns the 3D Surface (const version).)#"
             
         )
;

    // Class HLRBRep_SurfaceTool from ./opencascade/HLRBRep_SurfaceTool.hxx
    klass = m.attr("HLRBRep_SurfaceTool");

    // default constructor
    register_default_constructor<HLRBRep_SurfaceTool , shared_ptr<HLRBRep_SurfaceTool>>(m,"HLRBRep_SurfaceTool");

    // nested enums

    static_cast<py::class_<HLRBRep_SurfaceTool , shared_ptr<HLRBRep_SurfaceTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstUParameter_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::FirstUParameter),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("FirstVParameter_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::FirstVParameter),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("LastUParameter_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::LastUParameter),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("LastVParameter_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::LastVParameter),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("NbUIntervals_s",
                    (int (*)(  const HLRBRep_Surface * ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const HLRBRep_Surface * ,   const GeomAbs_Shape  ) >(&HLRBRep_SurfaceTool::NbUIntervals),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theSh")
          )
        .def_static("NbVIntervals_s",
                    (int (*)(  const HLRBRep_Surface * ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const HLRBRep_Surface * ,   const GeomAbs_Shape  ) >(&HLRBRep_SurfaceTool::NbVIntervals),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theSh")
          )
        .def_static("UIntervals_s",
                    (void (*)(  const HLRBRep_Surface * ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_SurfaceTool::UIntervals),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theT"),  py::arg("theSh")
          )
        .def_static("VIntervals_s",
                    (void (*)(  const HLRBRep_Surface * ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&HLRBRep_SurfaceTool::VIntervals),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theT"),  py::arg("theSh")
          )
        .def_static("UTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const double  ) >(&HLRBRep_SurfaceTool::UTrim),
                    R"#(If <theFirst> >= <theLast>)#"  , py::arg("theSurf"),  py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTol")
          )
        .def_static("VTrim_s",
                    (handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const double  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const double  ) >(&HLRBRep_SurfaceTool::VTrim),
                    R"#(If <theFirst> >= <theLast>)#"  , py::arg("theSurf"),  py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTol")
          )
        .def_static("IsUClosed_s",
                    (bool (*)(  const HLRBRep_Surface *  ) ) static_cast<bool (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::IsUClosed),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("IsVClosed_s",
                    (bool (*)(  const HLRBRep_Surface *  ) ) static_cast<bool (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::IsVClosed),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("IsUPeriodic_s",
                    (bool (*)(  const HLRBRep_Surface *  ) ) static_cast<bool (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::IsUPeriodic),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("UPeriod_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::UPeriod),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("IsVPeriodic_s",
                    (bool (*)(  const HLRBRep_Surface *  ) ) static_cast<bool (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::IsVPeriodic),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("VPeriod_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::VPeriod),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) ) static_cast<gp_Pnt (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) >(&HLRBRep_SurfaceTool::Value),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV")
          )
        .def_static("D0_s",
                    (void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt &  ) >(&HLRBRep_SurfaceTool::D0),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV"),  py::arg("theP")
          )
        .def_static("D1_s",
                    (void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_SurfaceTool::D1),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV"),  py::arg("theP"),  py::arg("theD1U"),  py::arg("theD1V")
          )
        .def_static("D2_s",
                    (void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_SurfaceTool::D2),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV"),  py::arg("theP"),  py::arg("theD1U"),  py::arg("theD1V"),  py::arg("theD2U"),  py::arg("theD2V"),  py::arg("theD2UV")
          )
        .def_static("D3_s",
                    (void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const HLRBRep_Surface * ,   const double ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&HLRBRep_SurfaceTool::D3),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV"),  py::arg("theP"),  py::arg("theD1U"),  py::arg("theD1V"),  py::arg("theD2U"),  py::arg("theD2V"),  py::arg("theD2UV"),  py::arg("theD3U"),  py::arg("theD3V"),  py::arg("theD3UUV"),  py::arg("theD3UVV")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const int ,   const int  ) ) static_cast<gp_Vec (*)(  const HLRBRep_Surface * ,   const double ,   const double ,   const int ,   const int  ) >(&HLRBRep_SurfaceTool::DN),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU"),  py::arg("theV"),  py::arg("theNu"),  py::arg("theNv")
          )
        .def_static("UResolution_s",
                    (double (*)(  const HLRBRep_Surface * ,   const double  ) ) static_cast<double (*)(  const HLRBRep_Surface * ,   const double  ) >(&HLRBRep_SurfaceTool::UResolution),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theR3d")
          )
        .def_static("VResolution_s",
                    (double (*)(  const HLRBRep_Surface * ,   const double  ) ) static_cast<double (*)(  const HLRBRep_Surface * ,   const double  ) >(&HLRBRep_SurfaceTool::VResolution),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theR3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_SurfaceType (*)(  const HLRBRep_Surface *  ) ) static_cast<GeomAbs_SurfaceType (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::GetType),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Plane_s",
                    (gp_Pln (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Pln (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Plane),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Cylinder_s",
                    (gp_Cylinder (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Cylinder (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Cylinder),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Cone_s",
                    (gp_Cone (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Cone (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Cone),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Torus_s",
                    (gp_Torus (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Torus (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Torus),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Sphere_s",
                    (gp_Sphere (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Sphere (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Sphere),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierSurface> (*)(  const HLRBRep_Surface *  ) ) static_cast<handle<Geom_BezierSurface> (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Bezier),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineSurface> (*)(  const HLRBRep_Surface *  ) ) static_cast<handle<Geom_BSplineSurface> (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::BSpline),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("AxeOfRevolution_s",
                    (gp_Ax1 (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Ax1 (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::AxeOfRevolution),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("Direction_s",
                    (gp_Dir (*)(  const HLRBRep_Surface *  ) ) static_cast<gp_Dir (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::Direction),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("BasisCurve_s",
                    (handle<Adaptor3d_Curve> (*)(  const HLRBRep_Surface *  ) ) static_cast<handle<Adaptor3d_Curve> (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::BasisCurve),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("BasisSurface_s",
                    (handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface *  ) ) static_cast<handle<Adaptor3d_Surface> (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::BasisSurface),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("OffsetValue_s",
                    (double (*)(  const HLRBRep_Surface *  ) ) static_cast<double (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::OffsetValue),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const HLRBRep_Surface *  ) ) static_cast<int (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const HLRBRep_Surface *  ) ) static_cast<int (*)(  const HLRBRep_Surface *  ) >(&HLRBRep_SurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("theSurf")
          )
        .def_static("NbSamplesU_s",
                    (int (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) ) static_cast<int (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) >(&HLRBRep_SurfaceTool::NbSamplesU),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theU1"),  py::arg("theU2")
          )
        .def_static("NbSamplesV_s",
                    (int (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) ) static_cast<int (*)(  const HLRBRep_Surface * ,   const double ,   const double  ) >(&HLRBRep_SurfaceTool::NbSamplesV),
                    R"#()#"  , py::arg("theSurf"),  py::arg("theV1"),  py::arg("theV2")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter from ./opencascade/HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter.hxx
    klass = m.attr("HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter , shared_ptr<HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("NbVariables",
             (int (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<int (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::NbVariables),
             R"#(returns 2.)#" 
          )
        .def("NbEquations",
             (int (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<int (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::NbEquations),
             R"#(returns 2.)#" 
          )
        .def("Value",
             (bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Vector &  ) >(&HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::Value),
             R"#(computes the values <F> of the Functions for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Matrix &  ) >(&HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::Derivatives),
             R"#(returns the values <D> of the derivatives for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("D")
          )
        .def("Values",
             (bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter::Values),
             R"#(returns the values <F> of the functions and the derivatives <D> for the variable <X>. returns True if the computation was done successfully, False otherwise.)#"  , py::arg("X"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheExactInterCSurf from ./opencascade/HLRBRep_TheExactInterCSurf.hxx
    klass = m.attr("HLRBRep_TheExactInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_TheExactInterCSurf , shared_ptr<HLRBRep_TheExactInterCSurf>  >>(klass)
    // constructors
        .def(py::init<  const HLRBRep_TheCSFunctionOfInterCSurf &, const double >()  , py::arg("F"),  py::arg("TolTangency") )
        .def(py::init<  const double, const double, const double, const HLRBRep_TheCSFunctionOfInterCSurf &, const double, const double >()  , py::arg("U"),  py::arg("V"),  py::arg("W"),  py::arg("F"),  py::arg("TolTangency"),  py::arg("MarginCoef")=static_cast< const double>(0.0) )
    // custom constructors
    // methods
        .def("Perform",
             (void (HLRBRep_TheExactInterCSurf::*)(  const double ,   const double ,   const double ,  math_FunctionSetRoot & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (HLRBRep_TheExactInterCSurf::*)(  const double ,   const double ,   const double ,  math_FunctionSetRoot & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&HLRBRep_TheExactInterCSurf::Perform),
             R"#(compute the solution it's possible to write to optimize: IntImp_IntCS inter(S1,C1,Toltangency) math_FunctionSetRoot rsnld(Inter.function()) while ...{ u=... v=... w=... inter.Perform(u,v,w,rsnld) } or IntImp_IntCS inter(Toltangency) inter.SetSurface(S); math_FunctionSetRoot rsnld(Inter.function()) while ...{ C=... inter.SetCurve(C); u=... v=... w=... inter.Perform(u,v,w,rsnld) })#"  , py::arg("U"),  py::arg("V"),  py::arg("W"),  py::arg("Rsnld"),  py::arg("u0"),  py::arg("v0"),  py::arg("u1"),  py::arg("v1"),  py::arg("w0"),  py::arg("w1")
          )
        .def("IsDone",
             (bool (HLRBRep_TheExactInterCSurf::*)() const) static_cast<bool (HLRBRep_TheExactInterCSurf::*)() const>(&HLRBRep_TheExactInterCSurf::IsDone),
             R"#(Returns TRUE if the creation completed without failure.)#" 
          )
        .def("IsEmpty",
             (bool (HLRBRep_TheExactInterCSurf::*)() const) static_cast<bool (HLRBRep_TheExactInterCSurf::*)() const>(&HLRBRep_TheExactInterCSurf::IsEmpty),
             R"#()#" 
          )
        .def("ParameterOnCurve",
             (double (HLRBRep_TheExactInterCSurf::*)() const) static_cast<double (HLRBRep_TheExactInterCSurf::*)() const>(&HLRBRep_TheExactInterCSurf::ParameterOnCurve),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("ParameterOnSurface",
             []( HLRBRep_TheExactInterCSurf &self   ){
                 double  U;
                double  V;

                 self.ParameterOnSurface(U,V);
                 return std::make_tuple(U,V); },
             R"#()#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Point",
             ( const gp_Pnt & (HLRBRep_TheExactInterCSurf::*)() const) static_cast< const gp_Pnt & (HLRBRep_TheExactInterCSurf::*)() const>(&HLRBRep_TheExactInterCSurf::Point),
             R"#(returns the intersection point The exception NotDone is raised if IsDone is false. The exception DomainError is raised if IsEmpty is true.)#"
             
         )
       .def("Function",
             (HLRBRep_TheCSFunctionOfInterCSurf & (HLRBRep_TheExactInterCSurf::*)() ) static_cast<HLRBRep_TheCSFunctionOfInterCSurf & (HLRBRep_TheExactInterCSurf::*)() >(&HLRBRep_TheExactInterCSurf::Function),
             R"#(return the math function which is used to compute the intersection)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class HLRBRep_TheIntConicCurveOfCInter from ./opencascade/HLRBRep_TheIntConicCurveOfCInter.hxx
    klass = m.attr("HLRBRep_TheIntConicCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_TheIntConicCurveOfCInter , shared_ptr<HLRBRep_TheIntConicCurveOfCInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheIntPCurvePCurveOfCInter from ./opencascade/HLRBRep_TheIntPCurvePCurveOfCInter.hxx
    klass = m.attr("HLRBRep_TheIntPCurvePCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_TheIntPCurvePCurveOfCInter , shared_ptr<HLRBRep_TheIntPCurvePCurveOfCInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetMinNbSamples",
             (void (HLRBRep_TheIntPCurvePCurveOfCInter::*)(  const int  ) ) static_cast<void (HLRBRep_TheIntPCurvePCurveOfCInter::*)(  const int  ) >(&HLRBRep_TheIntPCurvePCurveOfCInter::SetMinNbSamples),
             R"#(Set / get minimum number of points in polygon for intersection.)#"  , py::arg("theMinNbSamples")
          )
        .def("GetMinNbSamples",
             (int (HLRBRep_TheIntPCurvePCurveOfCInter::*)() const) static_cast<int (HLRBRep_TheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_TheIntPCurvePCurveOfCInter::GetMinNbSamples),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheInterferenceOfInterCSurf from ./opencascade/HLRBRep_TheInterferenceOfInterCSurf.hxx
    klass = m.attr("HLRBRep_TheInterferenceOfInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_TheInterferenceOfInterCSurf , shared_ptr<HLRBRep_TheInterferenceOfInterCSurf>  , Intf_Interference >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const HLRBRep_ThePolygonOfInterCSurf &, const HLRBRep_ThePolyhedronOfInterCSurf & >()  , py::arg("thePolyg"),  py::arg("thePolyh") )
        .def(py::init<  const HLRBRep_ThePolygonOfInterCSurf &, const HLRBRep_ThePolyhedronOfInterCSurf &,Bnd_BoundSortBox & >()  , py::arg("thePolyg"),  py::arg("thePolyh"),  py::arg("theBoundSB") )
        .def(py::init<  const NCollection_Array1<gp_Lin> &, const HLRBRep_ThePolyhedronOfInterCSurf & >()  , py::arg("theLins"),  py::arg("thePolyh") )
        .def(py::init<  const NCollection_Array1<gp_Lin> &, const HLRBRep_ThePolyhedronOfInterCSurf &,Bnd_BoundSortBox & >()  , py::arg("theLins"),  py::arg("thePolyh"),  py::arg("theBoundSB") )
        .def(py::init<  const gp_Lin &, const HLRBRep_ThePolyhedronOfInterCSurf & >()  , py::arg("theLin"),  py::arg("thePolyh") )
        .def(py::init<  const gp_Lin &, const HLRBRep_ThePolyhedronOfInterCSurf &,Bnd_BoundSortBox & >()  , py::arg("theLin"),  py::arg("thePolyh"),  py::arg("theBoundSB") )
    // custom constructors
    // methods
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Polygon and the Polyhedron.)#"  , py::arg("thePolyg"),  py::arg("thePolyh")
          )
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Straight Line and the Polyhedron.)#"  , py::arg("theLin"),  py::arg("thePolyh")
          )
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const NCollection_Array1<gp_Lin> & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const NCollection_Array1<gp_Lin> & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Straight Lines and the Polyhedron.)#"  , py::arg("theLins"),  py::arg("thePolyh")
          )
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Polygon and the Polyhedron.)#"  , py::arg("thePolyg"),  py::arg("thePolyh"),  py::arg("theBoundSB")
          )
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const gp_Lin & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Straight Line and the Polyhedron.)#"  , py::arg("theLin"),  py::arg("thePolyh"),  py::arg("theBoundSB")
          )
        .def("Perform",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const NCollection_Array1<gp_Lin> & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const NCollection_Array1<gp_Lin> & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Perform),
             R"#(Computes an interference between the Straight Lines and the Polyhedron.)#"  , py::arg("theLins"),  py::arg("thePolyh"),  py::arg("theBoundSB")
          )
        .def("Interference",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf & ,  Bnd_BoundSortBox &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Interference),
             R"#(Compares the boundings between the segment of <thePolyg> and the facets of <thePolyh>.)#"  , py::arg("thePolyg"),  py::arg("thePolyh"),  py::arg("theBoundSB")
          )
        .def("Interference",
             (void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (HLRBRep_TheInterferenceOfInterCSurf::*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_TheInterferenceOfInterCSurf::Interference),
             R"#(Compares the boundings between the segment of <thePolyg> and the facets of <thePolyh>.)#"  , py::arg("thePolyg"),  py::arg("thePolyh")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter from ./opencascade/HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter.hxx
    klass = m.attr("HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter , shared_ptr<HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter>  , IntRes2d_Intersection >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter from ./opencascade/HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx
    klass = m.attr("HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter");


    // nested enums

    static_cast<py::class_<HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter , shared_ptr<HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter>  , Intf_Polygon2d >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("DeflectionOverEstimation",
             (double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::DeflectionOverEstimation),
             R"#()#" 
          )
        .def("SetDeflectionOverEstimation",
             (void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const double  ) ) static_cast<void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const double  ) >(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::SetDeflectionOverEstimation),
             R"#()#"  , py::arg("x")
          )
        .def("Closed",
             (void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const bool  ) >(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::Closed),
             R"#()#"  , py::arg("clos")
          )
        .def("Closed",
             (bool (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<bool (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::Closed),
             R"#(Returns True if the polyline is closed.)#" 
          )
        .def("NbSegments",
             (int (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<int (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::NbSegments),
             R"#(Give the number of Segments in the polyline.)#" 
          )
        .def("Segment",
             (void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const) static_cast<void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const int ,  gp_Pnt2d & ,  gp_Pnt2d &  ) const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::Segment),
             R"#(Returns the points of the segment <Index> in the Polygon.)#"  , py::arg("theIndex"),  py::arg("theBegin"),  py::arg("theEnd")
          )
        .def("InfParameter",
             (double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::InfParameter),
             R"#(Returns the parameter (On the curve) of the first point of the Polygon)#" 
          )
        .def("SupParameter",
             (double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::SupParameter),
             R"#(Returns the parameter (On the curve) of the last point of the Polygon)#" 
          )
        .def("AutoIntersectionIsPossible",
             (bool (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<bool (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::AutoIntersectionIsPossible),
             R"#()#" 
          )
        .def("ApproxParamOnCurve",
             (double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const int ,   const double  ) const) static_cast<double (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const int ,   const double  ) const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::ApproxParamOnCurve),
             R"#(Give an approximation of the parameter on the curve according to the discretization of the Curve.)#"  , py::arg("Index"),  py::arg("ParamOnLine")
          )
        .def("CalculRegion",
             (int (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) const) static_cast<int (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::CalculRegion),
             R"#()#"  , py::arg("x"),  py::arg("y"),  py::arg("x1"),  py::arg("x2"),  py::arg("y1"),  py::arg("y2")
          )
        .def("Dump",
             (void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const) static_cast<void (HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::*)() const>(&HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter::Dump),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_ThePolygonOfInterCSurf from ./opencascade/HLRBRep_ThePolygonOfInterCSurf.hxx
    klass = m.attr("HLRBRep_ThePolygonOfInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_ThePolygonOfInterCSurf , shared_ptr<HLRBRep_ThePolygonOfInterCSurf>  >>(klass)
    // constructors
        .def(py::init<  const gp_Lin &, const NCollection_Array1<double> & >()  , py::arg("Curve"),  py::arg("Upars") )
        .def(py::init<  const gp_Lin &, const double, const double, const int >()  , py::arg("Curve"),  py::arg("U1"),  py::arg("U2"),  py::arg("NbPnt") )
        .def(py::init<  const gp_Lin &, const int >()  , py::arg("Curve"),  py::arg("NbPnt") )
    // custom constructors
    // methods
        .def("DeflectionOverEstimation",
             (double (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<double (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::DeflectionOverEstimation),
             R"#()#" 
          )
        .def("SetDeflectionOverEstimation",
             (void (HLRBRep_ThePolygonOfInterCSurf::*)(  const double  ) ) static_cast<void (HLRBRep_ThePolygonOfInterCSurf::*)(  const double  ) >(&HLRBRep_ThePolygonOfInterCSurf::SetDeflectionOverEstimation),
             R"#()#"  , py::arg("x")
          )
        .def("Closed",
             (void (HLRBRep_ThePolygonOfInterCSurf::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolygonOfInterCSurf::*)(  const bool  ) >(&HLRBRep_ThePolygonOfInterCSurf::Closed),
             R"#()#"  , py::arg("flag")
          )
        .def("Closed",
             (bool (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<bool (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::Closed),
             R"#()#" 
          )
        .def("NbSegments",
             (int (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<int (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::NbSegments),
             R"#(Give the number of Segments in the polyline.)#" 
          )
        .def("BeginOfSeg",
             ( const gp_Pnt & (HLRBRep_ThePolygonOfInterCSurf::*)(  const int  ) const) static_cast< const gp_Pnt & (HLRBRep_ThePolygonOfInterCSurf::*)(  const int  ) const>(&HLRBRep_ThePolygonOfInterCSurf::BeginOfSeg),
             R"#(Give the point of range Index in the Polygon.)#"  , py::arg("theIndex")
          )
        .def("EndOfSeg",
             ( const gp_Pnt & (HLRBRep_ThePolygonOfInterCSurf::*)(  const int  ) const) static_cast< const gp_Pnt & (HLRBRep_ThePolygonOfInterCSurf::*)(  const int  ) const>(&HLRBRep_ThePolygonOfInterCSurf::EndOfSeg),
             R"#(Give the point of range Index in the Polygon.)#"  , py::arg("theIndex")
          )
        .def("InfParameter",
             (double (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<double (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::InfParameter),
             R"#(Returns the parameter (On the curve) of the first point of the Polygon)#" 
          )
        .def("SupParameter",
             (double (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<double (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::SupParameter),
             R"#(Returns the parameter (On the curve) of the last point of the Polygon)#" 
          )
        .def("ApproxParamOnCurve",
             (double (HLRBRep_ThePolygonOfInterCSurf::*)(  const int ,   const double  ) const) static_cast<double (HLRBRep_ThePolygonOfInterCSurf::*)(  const int ,   const double  ) const>(&HLRBRep_ThePolygonOfInterCSurf::ApproxParamOnCurve),
             R"#(Give an approximation of the parameter on the curve according to the discretization of the Curve.)#"  , py::arg("Index"),  py::arg("ParamOnLine")
          )
        .def("Dump",
             (void (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast<void (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::Dump),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Bounding",
             ( const Bnd_Box & (HLRBRep_ThePolygonOfInterCSurf::*)() const) static_cast< const Bnd_Box & (HLRBRep_ThePolygonOfInterCSurf::*)() const>(&HLRBRep_ThePolygonOfInterCSurf::Bounding),
             R"#(Give the bounding box of the polygon.)#"
             
         )
;

    // Class HLRBRep_ThePolygonToolOfInterCSurf from ./opencascade/HLRBRep_ThePolygonToolOfInterCSurf.hxx
    klass = m.attr("HLRBRep_ThePolygonToolOfInterCSurf");

    // default constructor
    register_default_constructor<HLRBRep_ThePolygonToolOfInterCSurf , shared_ptr<HLRBRep_ThePolygonToolOfInterCSurf>>(m,"HLRBRep_ThePolygonToolOfInterCSurf");

    // nested enums

    static_cast<py::class_<HLRBRep_ThePolygonToolOfInterCSurf , shared_ptr<HLRBRep_ThePolygonToolOfInterCSurf>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Bounding_s",
                    ( const Bnd_Box & (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) ) static_cast< const Bnd_Box & (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::Bounding),
                    R"#(Give the bounding box of the polygon.)#"  , py::arg("thePolygon")
          )
        .def_static("DeflectionOverEstimation_s",
                    (double (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) ) static_cast<double (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::DeflectionOverEstimation),
                    R"#()#"  , py::arg("thePolygon")
          )
        .def_static("Closed_s",
                    (bool (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) ) static_cast<bool (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::Closed),
                    R"#()#"  , py::arg("thePolygon")
          )
        .def_static("NbSegments_s",
                    (int (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) ) static_cast<int (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::NbSegments),
                    R"#()#"  , py::arg("thePolygon")
          )
        .def_static("BeginOfSeg_s",
                    ( const gp_Pnt & (*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const int  ) ) static_cast< const gp_Pnt & (*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const int  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::BeginOfSeg),
                    R"#(Give the point of range Index in the Polygon.)#"  , py::arg("thePolygon"),  py::arg("Index")
          )
        .def_static("EndOfSeg_s",
                    ( const gp_Pnt & (*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const int  ) ) static_cast< const gp_Pnt & (*)(  const HLRBRep_ThePolygonOfInterCSurf & ,   const int  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::EndOfSeg),
                    R"#(Give the point of range Index in the Polygon.)#"  , py::arg("thePolygon"),  py::arg("Index")
          )
        .def_static("Dump_s",
                    (void (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) ) static_cast<void (*)(  const HLRBRep_ThePolygonOfInterCSurf &  ) >(&HLRBRep_ThePolygonToolOfInterCSurf::Dump),
                    R"#()#"  , py::arg("thePolygon")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_ThePolyhedronOfInterCSurf from ./opencascade/HLRBRep_ThePolyhedronOfInterCSurf.hxx
    klass = m.attr("HLRBRep_ThePolyhedronOfInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_ThePolyhedronOfInterCSurf , shared_ptr<HLRBRep_ThePolyhedronOfInterCSurf>  >>(klass)
    // constructors
        .def(py::init< HLRBRep_Surface *, const NCollection_Array1<double> &, const NCollection_Array1<double> & >()  , py::arg("Surface"),  py::arg("Upars"),  py::arg("Vpars") )
        .def(py::init< HLRBRep_Surface *, const int, const int, const double, const double, const double, const double >()  , py::arg("Surface"),  py::arg("nbdU"),  py::arg("nbdV"),  py::arg("U1"),  py::arg("V1"),  py::arg("U2"),  py::arg("V2") )
    // custom constructors
    // methods
        .def("Destroy",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)() ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)() >(&HLRBRep_ThePolyhedronOfInterCSurf::Destroy),
             R"#()#" 
          )
        .def("DeflectionOverEstimation",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const double  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const double  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::DeflectionOverEstimation),
             R"#()#"  , py::arg("flec")
          )
        .def("UMinSingularity",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::UMinSingularity),
             R"#()#"  , py::arg("Sing")
          )
        .def("UMaxSingularity",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::UMaxSingularity),
             R"#()#"  , py::arg("Sing")
          )
        .def("VMinSingularity",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::VMinSingularity),
             R"#()#"  , py::arg("Sing")
          )
        .def("VMaxSingularity",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const bool  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::VMaxSingularity),
             R"#()#"  , py::arg("Sing")
          )
        .def("NbTriangles",
             (int (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<int (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::NbTriangles),
             R"#(Give the number of triangles in this double array of)#" 
          )
        .def("TriConnex",
             (int (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const int ,   const int ,  int & ,  int &  ) const) static_cast<int (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const int ,   const int ,  int & ,  int &  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::TriConnex),
             R"#(Give the address Tricon of the triangle connexe to the triangle of address Triang by the edge Pivot Pedge and the third point of this connexe triangle. When we are on a free edge TriCon==0 but the function return the value of the triangle in the other side of Pivot on the free edge. Used to turn around a vertex.)#"  , py::arg("Triang"),  py::arg("Pivot"),  py::arg("Pedge"),  py::arg("TriCon"),  py::arg("OtherP")
          )
        .def("NbPoints",
             (int (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<int (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::NbPoints),
             R"#(Give the number of point in the double array of triangles ((nbdu+1)*(nbdv+1)).)#" 
          )
        .def("Point",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const gp_Pnt & ,   const int ,   const int ,   const double ,   const double  ) ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const gp_Pnt & ,   const int ,   const int ,   const double ,   const double  ) >(&HLRBRep_ThePolyhedronOfInterCSurf::Point),
             R"#(Set the value of a field of the double array of points.)#"  , py::arg("thePnt"),  py::arg("lig"),  py::arg("col"),  py::arg("U"),  py::arg("V")
          )
        .def("Point",
             ( const gp_Pnt & (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,  double & ,  double &  ) const) static_cast< const gp_Pnt & (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,  double & ,  double &  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::Point),
             R"#(Give the point of index i in the MaTriangle.)#"  , py::arg("Index"),  py::arg("U"),  py::arg("V")
          )
        .def("Point",
             ( const gp_Pnt & (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int  ) const) static_cast< const gp_Pnt & (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::Point),
             R"#(Give the point of index i in the MaTriangle.)#"  , py::arg("Index")
          )
        .def("Point",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,  gp_Pnt &  ) const) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,  gp_Pnt &  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::Point),
             R"#(Give the point of index i in the MaTriangle.)#"  , py::arg("Index"),  py::arg("P")
          )
        .def("FillBounding",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)() ) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)() >(&HLRBRep_ThePolyhedronOfInterCSurf::FillBounding),
             R"#(Compute the array of boxes. The box <n> corresponding to the triangle <n>.)#" 
          )
        .def("DeflectionOverEstimation",
             (double (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<double (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::DeflectionOverEstimation),
             R"#()#" 
          )
        .def("HasUMinSingularity",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::HasUMinSingularity),
             R"#()#" 
          )
        .def("HasUMaxSingularity",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::HasUMaxSingularity),
             R"#()#" 
          )
        .def("HasVMinSingularity",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::HasVMinSingularity),
             R"#()#" 
          )
        .def("HasVMaxSingularity",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::HasVMaxSingularity),
             R"#()#" 
          )
        .def("Contain",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const gp_Pnt &  ) const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const gp_Pnt &  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::Contain),
             R"#(Give the plane equation of the triangle of address Triang.)#"  , py::arg("Triang"),  py::arg("ThePnt")
          )
        .def("IsOnBound",
             (bool (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const int  ) const) static_cast<bool (HLRBRep_ThePolyhedronOfInterCSurf::*)(  const int ,   const int  ) const>(&HLRBRep_ThePolyhedronOfInterCSurf::IsOnBound),
             R"#(This method returns true if the edge based on points with indices Index1 and Index2 represents a boundary edge. It is necessary to take into account the boundary deflection for this edge.)#"  , py::arg("Index1"),  py::arg("Index2")
          )
        .def("GetBorderDeflection",
             (double (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<double (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::GetBorderDeflection),
             R"#(This method returns a border deflection.)#" 
          )
        .def("Dump",
             (void (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast<void (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::Dump),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Size",
             []( HLRBRep_ThePolyhedronOfInterCSurf &self   ){
                 int  nbdu;
                int  nbdv;

                 self.Size(nbdu,nbdv);
                 return std::make_tuple(nbdu,nbdv); },
             R"#(get the size of the discretization.)#" 
          )
        .def("Triangle",
             []( HLRBRep_ThePolyhedronOfInterCSurf &self ,  const int Index ){
                 int  P1;
                int  P2;
                int  P3;

                 self.Triangle(Index,P1,P2,P3);
                 return std::make_tuple(P1,P2,P3); },
             R"#(Give the 3 points of the triangle of address Index in the double array of triangles.)#"  , py::arg("Index")
          )
        .def("PlaneEquation",
             []( HLRBRep_ThePolyhedronOfInterCSurf &self ,  const int Triang,gp_XYZ & NormalVector ){
                 double  PolarDistance;

                 self.PlaneEquation(Triang,NormalVector,PolarDistance);
                 return std::make_tuple(PolarDistance); },
             R"#(Give the plane equation of the triangle of address Triang.)#"  , py::arg("Triang"),  py::arg("NormalVector")
          )
        .def("Parameters",
             []( HLRBRep_ThePolyhedronOfInterCSurf &self ,  const int Index ){
                 double  U;
                double  V;

                 self.Parameters(Index,U,V);
                 return std::make_tuple(U,V); },
             R"#()#"  , py::arg("Index")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Bounding",
             ( const Bnd_Box & (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast< const Bnd_Box & (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::Bounding),
             R"#(Give the bounding box of the MaTriangle.)#"
             
         )
       .def("ComponentsBounding",
             ( const handle<NCollection_HArray1<Bnd_Box>> & (HLRBRep_ThePolyhedronOfInterCSurf::*)() const) static_cast< const handle<NCollection_HArray1<Bnd_Box>> & (HLRBRep_ThePolyhedronOfInterCSurf::*)() const>(&HLRBRep_ThePolyhedronOfInterCSurf::ComponentsBounding),
             R"#(Give the array of boxes. The box <n> corresponding to the triangle <n>.)#"
             
         )
;

    // Class HLRBRep_ThePolyhedronToolOfInterCSurf from ./opencascade/HLRBRep_ThePolyhedronToolOfInterCSurf.hxx
    klass = m.attr("HLRBRep_ThePolyhedronToolOfInterCSurf");

    // default constructor
    register_default_constructor<HLRBRep_ThePolyhedronToolOfInterCSurf , shared_ptr<HLRBRep_ThePolyhedronToolOfInterCSurf>>(m,"HLRBRep_ThePolyhedronToolOfInterCSurf");

    // nested enums

    static_cast<py::class_<HLRBRep_ThePolyhedronToolOfInterCSurf , shared_ptr<HLRBRep_ThePolyhedronToolOfInterCSurf>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Bounding_s",
                    ( const Bnd_Box & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast< const Bnd_Box & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::Bounding),
                    R"#(Give the bounding box of the PolyhedronTool.)#"  , py::arg("thePolyh")
          )
        .def_static("ComponentsBounding_s",
                    ( const handle<NCollection_HArray1<Bnd_Box>> & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast< const handle<NCollection_HArray1<Bnd_Box>> & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::ComponentsBounding),
                    R"#(Give the array of boxes. The box <n> corresponding to the triangle <n>.)#"  , py::arg("thePolyh")
          )
        .def_static("DeflectionOverEstimation_s",
                    (double (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<double (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::DeflectionOverEstimation),
                    R"#(Give the tolerance of the polygon.)#"  , py::arg("thePolyh")
          )
        .def_static("NbTriangles_s",
                    (int (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<int (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::NbTriangles),
                    R"#(Give the number of triangles in this polyhedral surface.)#"  , py::arg("thePolyh")
          )
        .def_static("Point_s",
                    ( const gp_Pnt & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int  ) ) static_cast< const gp_Pnt & (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::Point),
                    R"#(Give the point of index i in the polyhedral surface.)#"  , py::arg("thePolyh"),  py::arg("Index")
          )
        .def_static("TriConnex_s",
                    (int (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int ,   const int ,   const int ,  int & ,  int &  ) ) static_cast<int (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int ,   const int ,   const int ,  int & ,  int &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::TriConnex),
                    R"#(Give the address Tricon of the triangle connexe to the triangle of address Triang by the edge Pivot Pedge and the third point of this connexe triangle. When we are on a free edge TriCon==0 but the function return the value of the triangle in the other side of Pivot on the free edge. Used to turn around a vertex.)#"  , py::arg("thePolyh"),  py::arg("Triang"),  py::arg("Pivot"),  py::arg("Pedge"),  py::arg("TriCon"),  py::arg("OtherP")
          )
        .def_static("IsOnBound_s",
                    (bool (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int ,   const int  ) ) static_cast<bool (*)(  const HLRBRep_ThePolyhedronOfInterCSurf & ,   const int ,   const int  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::IsOnBound),
                    R"#(This method returns true if the edge based on points with indices Index1 and Index2 represents a boundary edge. It is necessary to take into account the boundary deflection for this edge.)#"  , py::arg("thePolyh"),  py::arg("Index1"),  py::arg("Index2")
          )
        .def_static("GetBorderDeflection_s",
                    (double (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<double (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::GetBorderDeflection),
                    R"#(This method returns a border deflection of the polyhedron.)#"  , py::arg("thePolyh")
          )
        .def_static("Dump_s",
                    (void (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) ) static_cast<void (*)(  const HLRBRep_ThePolyhedronOfInterCSurf &  ) >(&HLRBRep_ThePolyhedronToolOfInterCSurf::Dump),
                    R"#()#"  , py::arg("thePolyh")
          )
    // static methods using call by reference i.s.o. return
        .def_static("Triangle_s",
            []( const HLRBRep_ThePolyhedronOfInterCSurf & thePolyh, const int Index ){
                int  P1;
                int  P2;
                int  P3;

                HLRBRep_ThePolyhedronToolOfInterCSurf::Triangle(thePolyh,Index,P1,P2,P3);
                
return std::make_tuple(P1,P2,P3); },
            R"#(Give the indices of the 3 points of the triangle of address Index in the PolyhedronTool.)#"  , py::arg("thePolyh"),  py::arg("Index")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheProjPCurOfCInter from ./opencascade/HLRBRep_TheProjPCurOfCInter.hxx
    klass = m.attr("HLRBRep_TheProjPCurOfCInter");

    // default constructor
    register_default_constructor<HLRBRep_TheProjPCurOfCInter , shared_ptr<HLRBRep_TheProjPCurOfCInter>>(m,"HLRBRep_TheProjPCurOfCInter");

    // nested enums

    static_cast<py::class_<HLRBRep_TheProjPCurOfCInter , shared_ptr<HLRBRep_TheProjPCurOfCInter>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheQuadCurvExactInterCSurf from ./opencascade/HLRBRep_TheQuadCurvExactInterCSurf.hxx
    klass = m.attr("HLRBRep_TheQuadCurvExactInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_TheQuadCurvExactInterCSurf , shared_ptr<HLRBRep_TheQuadCurvExactInterCSurf>  >>(klass)
    // constructors
        .def(py::init< HLRBRep_Surface *, const gp_Lin & >()  , py::arg("S"),  py::arg("C") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (HLRBRep_TheQuadCurvExactInterCSurf::*)() const) static_cast<bool (HLRBRep_TheQuadCurvExactInterCSurf::*)() const>(&HLRBRep_TheQuadCurvExactInterCSurf::IsDone),
             R"#()#" 
          )
        .def("NbRoots",
             (int (HLRBRep_TheQuadCurvExactInterCSurf::*)() const) static_cast<int (HLRBRep_TheQuadCurvExactInterCSurf::*)() const>(&HLRBRep_TheQuadCurvExactInterCSurf::NbRoots),
             R"#()#" 
          )
        .def("Root",
             (double (HLRBRep_TheQuadCurvExactInterCSurf::*)(  const int  ) const) static_cast<double (HLRBRep_TheQuadCurvExactInterCSurf::*)(  const int  ) const>(&HLRBRep_TheQuadCurvExactInterCSurf::Root),
             R"#()#"  , py::arg("Index")
          )
        .def("NbIntervals",
             (int (HLRBRep_TheQuadCurvExactInterCSurf::*)() const) static_cast<int (HLRBRep_TheQuadCurvExactInterCSurf::*)() const>(&HLRBRep_TheQuadCurvExactInterCSurf::NbIntervals),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Intervals",
             []( HLRBRep_TheQuadCurvExactInterCSurf &self ,  const int Index ){
                 double  U1;
                double  U2;

                 self.Intervals(Index,U1,U2);
                 return std::make_tuple(U1,U2); },
             R"#(U1 and U2 are the parameters of a segment on the curve.)#"  , py::arg("Index")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf from ./opencascade/HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf.hxx
    klass = m.attr("HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf");


    // nested enums

    static_cast<py::class_<HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf , shared_ptr<HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf>  , math_FunctionWithDerivative >>(klass)
    // constructors
        .def(py::init<  const IntSurf_Quadric &, const gp_Lin & >()  , py::arg("Q"),  py::arg("C") )
    // custom constructors
    // methods
        .def("Value",
             (bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double &  ) ) static_cast<bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double &  ) >(&HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::Value),
             R"#(Computes the value of the signed distance between the implicit surface and the point at parameter Param on the parametrised curve. Value always returns True.)#"  , py::arg("Param"),  py::arg("F")
          )
        .def("Derivative",
             (bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double &  ) ) static_cast<bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double &  ) >(&HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::Derivative),
             R"#(Computes the derivative of the previous function at parameter Param. Derivative always returns True.)#"  , py::arg("Param"),  py::arg("D")
          )
        .def("Values",
             (bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double & ,  double &  ) ) static_cast<bool (HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::*)(  const double ,  double & ,  double &  ) >(&HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf::Values),
             R"#(Computes the value and the derivative of the function. returns True.)#"  , py::arg("Param"),  py::arg("F"),  py::arg("D")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class HLRBRep_VertexList from ./opencascade/HLRBRep_VertexList.hxx
    klass = m.attr("HLRBRep_VertexList");


    // nested enums

    static_cast<py::class_<HLRBRep_VertexList , shared_ptr<HLRBRep_VertexList>  >>(klass)
    // constructors
        .def(py::init<  const HLRBRep_EdgeInterferenceTool &, const typename NCollection_List<HLRAlgo_Interference>::Iterator & >()  , py::arg("T"),  py::arg("I") )
    // custom constructors
    // methods
        .def("IsPeriodic",
             (bool (HLRBRep_VertexList::*)() const) static_cast<bool (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::IsPeriodic),
             R"#(Returns True when the curve is periodic.)#" 
          )
        .def("More",
             (bool (HLRBRep_VertexList::*)() const) static_cast<bool (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::More),
             R"#(Returns True when there are more vertices.)#" 
          )
        .def("Next",
             (void (HLRBRep_VertexList::*)() ) static_cast<void (HLRBRep_VertexList::*)() >(&HLRBRep_VertexList::Next),
             R"#(Proceeds to the next vertex.)#" 
          )
        .def("IsBoundary",
             (bool (HLRBRep_VertexList::*)() const) static_cast<bool (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::IsBoundary),
             R"#(Returns True if the current vertex is on the boundary of the edge.)#" 
          )
        .def("IsInterference",
             (bool (HLRBRep_VertexList::*)() const) static_cast<bool (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::IsInterference),
             R"#(Returns True if the current vertex is an interference.)#" 
          )
        .def("Orientation",
             (TopAbs_Orientation (HLRBRep_VertexList::*)() const) static_cast<TopAbs_Orientation (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::Orientation),
             R"#(Returns the orientation of the current vertex if it is on the boundary of the edge.)#" 
          )
        .def("Transition",
             (TopAbs_Orientation (HLRBRep_VertexList::*)() const) static_cast<TopAbs_Orientation (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::Transition),
             R"#(Returns the transition of the current vertex if it is an interference.)#" 
          )
        .def("BoundaryTransition",
             (TopAbs_Orientation (HLRBRep_VertexList::*)() const) static_cast<TopAbs_Orientation (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::BoundaryTransition),
             R"#(Returns the transition of the current vertex relative to the boundary if it is an interference.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Current",
             ( const HLRAlgo_Intersection & (HLRBRep_VertexList::*)() const) static_cast< const HLRAlgo_Intersection & (HLRBRep_VertexList::*)() const>(&HLRBRep_VertexList::Current),
             R"#(Returns the current vertex)#"
             
         )
;

    // Class HLRBRep_Algo from ./opencascade/HLRBRep_Algo.hxx
    klass = m.attr("HLRBRep_Algo");


    // nested enums

    static_cast<py::class_<HLRBRep_Algo ,opencascade::handle<HLRBRep_Algo>  , HLRBRep_InternalAlgo >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<HLRBRep_Algo> & >()  , py::arg("A") )
    // custom constructors
    // methods
        .def("Add",
             (void (HLRBRep_Algo::*)(  const TopoDS_Shape & ,   const handle<Standard_Transient> & ,   const int  ) ) static_cast<void (HLRBRep_Algo::*)(  const TopoDS_Shape & ,   const handle<Standard_Transient> & ,   const int  ) >(&HLRBRep_Algo::Add),
             R"#(add the Shape <S>.)#"  , py::arg("S"),  py::arg("SData"),  py::arg("nbIso")=static_cast< const int>(0)
          )
        .def("Add",
             (void (HLRBRep_Algo::*)(  const TopoDS_Shape & ,   const int  ) ) static_cast<void (HLRBRep_Algo::*)(  const TopoDS_Shape & ,   const int  ) >(&HLRBRep_Algo::Add),
             R"#(Adds the shape S to this framework, and specifies the number of isoparameters nbiso desired in visualizing S. You may add as many shapes as you wish. Use the function Add once for each shape.)#"  , py::arg("S"),  py::arg("nbIso")=static_cast< const int>(0)
          )
        .def("Index",
             (int (HLRBRep_Algo::*)(  const TopoDS_Shape &  ) ) static_cast<int (HLRBRep_Algo::*)(  const TopoDS_Shape &  ) >(&HLRBRep_Algo::Index),
             R"#(return the index of the Shape <S> and return 0 if the Shape <S> is not found.)#"  , py::arg("S")
          )
        .def("OutLinedShapeNullify",
             (void (HLRBRep_Algo::*)() ) static_cast<void (HLRBRep_Algo::*)() >(&HLRBRep_Algo::OutLinedShapeNullify),
             R"#(nullify all the results of OutLiner from HLRTopoBRep.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&HLRBRep_Algo::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&HLRBRep_Algo::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (HLRBRep_Algo::*)() const) static_cast< const handle<Standard_Type> & (HLRBRep_Algo::*)() const>(&HLRBRep_Algo::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/HLRBRep.hxx
// ./opencascade/HLRBRep_Algo.hxx
// ./opencascade/HLRBRep_AreaLimit.hxx
// ./opencascade/HLRBRep_BCurveTool.hxx
// ./opencascade/HLRBRep_BSurfaceTool.hxx
// ./opencascade/HLRBRep_BiPnt2D.hxx
// ./opencascade/HLRBRep_BiPoint.hxx
// ./opencascade/HLRBRep_CInter.hxx
// ./opencascade/HLRBRep_CLProps.hxx
// ./opencascade/HLRBRep_CLPropsATool.hxx
// ./opencascade/HLRBRep_Curve.hxx
// ./opencascade/HLRBRep_CurveTool.hxx
// ./opencascade/HLRBRep_Data.hxx
// ./opencascade/HLRBRep_EdgeBuilder.hxx
// ./opencascade/HLRBRep_EdgeData.hxx
// ./opencascade/HLRBRep_EdgeFaceTool.hxx
// ./opencascade/HLRBRep_EdgeIList.hxx
// ./opencascade/HLRBRep_EdgeInterferenceTool.hxx
// ./opencascade/HLRBRep_ExactIntersectionPointOfTheIntPCurvePCurveOfCInter.hxx
// ./opencascade/HLRBRep_FaceData.hxx
// ./opencascade/HLRBRep_FaceIterator.hxx
// ./opencascade/HLRBRep_HLRToShape.hxx
// ./opencascade/HLRBRep_Hider.hxx
// ./opencascade/HLRBRep_IntConicCurveOfCInter.hxx
// ./opencascade/HLRBRep_InterCSurf.hxx
// ./opencascade/HLRBRep_InternalAlgo.hxx
// ./opencascade/HLRBRep_Intersector.hxx
// ./opencascade/HLRBRep_LineTool.hxx
// ./opencascade/HLRBRep_MyImpParToolOfTheIntersectorOfTheIntConicCurveOfCInter.hxx
// ./opencascade/HLRBRep_PCLocFOfTheLocateExtPCOfTheProjPCurOfCInter.hxx
// ./opencascade/HLRBRep_PolyAlgo.hxx
// ./opencascade/HLRBRep_PolyHLRToShape.hxx
// ./opencascade/HLRBRep_SLProps.hxx
// ./opencascade/HLRBRep_SLPropsATool.hxx
// ./opencascade/HLRBRep_ShapeBounds.hxx
// ./opencascade/HLRBRep_ShapeToHLR.hxx
// ./opencascade/HLRBRep_Surface.hxx
// ./opencascade/HLRBRep_SurfaceTool.hxx
// ./opencascade/HLRBRep_TheCSFunctionOfInterCSurf.hxx
// ./opencascade/HLRBRep_TheCurveLocatorOfTheProjPCurOfCInter.hxx
// ./opencascade/HLRBRep_TheDistBetweenPCurvesOfTheIntPCurvePCurveOfCInter.hxx
// ./opencascade/HLRBRep_TheExactInterCSurf.hxx
// ./opencascade/HLRBRep_TheIntConicCurveOfCInter.hxx
// ./opencascade/HLRBRep_TheIntPCurvePCurveOfCInter.hxx
// ./opencascade/HLRBRep_TheInterferenceOfInterCSurf.hxx
// ./opencascade/HLRBRep_TheIntersectorOfTheIntConicCurveOfCInter.hxx
// ./opencascade/HLRBRep_TheLocateExtPCOfTheProjPCurOfCInter.hxx
// ./opencascade/HLRBRep_ThePolygon2dOfTheIntPCurvePCurveOfCInter.hxx
// ./opencascade/HLRBRep_ThePolygonOfInterCSurf.hxx
// ./opencascade/HLRBRep_ThePolygonToolOfInterCSurf.hxx
// ./opencascade/HLRBRep_ThePolyhedronOfInterCSurf.hxx
// ./opencascade/HLRBRep_ThePolyhedronToolOfInterCSurf.hxx
// ./opencascade/HLRBRep_TheProjPCurOfCInter.hxx
// ./opencascade/HLRBRep_TheQuadCurvExactInterCSurf.hxx
// ./opencascade/HLRBRep_TheQuadCurvFuncOfTheQuadCurvExactInterCSurf.hxx
// ./opencascade/HLRBRep_TypeDef.hxx
// ./opencascade/HLRBRep_TypeOfResultingEdge.hxx
// ./opencascade/HLRBRep_VertexList.hxx

// Additional functions


// operators

// register typdefs
    register_template_GeomLProp_CLPropsBase<gp_Pnt2d, gp_Vec2d, gp_Dir2d, const HLRBRep_Curve *, LProp_CurveUtils::ToolAccess<HLRBRep_CLPropsATool>>(m,"HLRBRep_CLProps");
    register_template_Extrema_GFuncExtPC<HLRBRep_CurvePtr, HLRBRep_CurveTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"HLRBRep_PCLocFOfTheLocateExtPCOfTheProjPCurOfCInter");
    register_template_GeomLProp_SLPropsBase<HLRBRep_SurfacePtr, LProp_SurfaceUtils::ToolAccess<HLRBRep_SLPropsATool>>(m,"HLRBRep_SLProps");
    register_template_Extrema_GCurveLocator<HLRBRep_CurvePtr, HLRBRep_CurveTool, Extrema_POnCurv2d, gp_Pnt2d>(m,"HLRBRep_TheCurveLocatorOfTheProjPCurOfCInter");
    register_template_Extrema_GenLocateExtPC<HLRBRep_CurvePtr, HLRBRep_CurveTool, Extrema_POnCurv2d, gp_Pnt2d, HLRBRep_PCLocFOfTheLocateExtPCOfTheProjPCurOfCInter>(m,"HLRBRep_TheLocateExtPCOfTheProjPCurOfCInter");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
