
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_Protocol.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_SubfigureDef.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_AssocGroupType.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalRefFile.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalRefFileIndex.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalRefFileName.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalRefLibName.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalRefName.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_ExternalReferenceFile.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_Group.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_GroupWithoutBackP.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_Hierarchy.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_Name.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_OrderedGroup.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_OrderedGroupWithoutBackP.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_SingleParent.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_SingularSubfigure.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESBasic_SubfigureDef.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>

// module includes
#include <IGESBasic.hxx>
#include <IGESBasic_AssocGroupType.hxx>
#include <IGESBasic_ExternalReferenceFile.hxx>
#include <IGESBasic_ExternalRefFile.hxx>
#include <IGESBasic_ExternalRefFileIndex.hxx>
#include <IGESBasic_ExternalRefFileName.hxx>
#include <IGESBasic_ExternalRefLibName.hxx>
#include <IGESBasic_ExternalRefName.hxx>
#include <IGESBasic_GeneralModule.hxx>
#include <IGESBasic_Group.hxx>
#include <IGESBasic_GroupWithoutBackP.hxx>
#include <IGESBasic_HArray1OfHArray1OfIGESEntity.hxx>
#include <IGESBasic_HArray1OfHArray1OfInteger.hxx>
#include <IGESBasic_HArray1OfHArray1OfReal.hxx>
#include <IGESBasic_HArray1OfHArray1OfXY.hxx>
#include <IGESBasic_HArray1OfHArray1OfXYZ.hxx>
#include <IGESBasic_Hierarchy.hxx>
#include <IGESBasic_Name.hxx>
#include <IGESBasic_OrderedGroup.hxx>
#include <IGESBasic_OrderedGroupWithoutBackP.hxx>
#include <IGESBasic_Protocol.hxx>
#include <IGESBasic_ReadWriteModule.hxx>
#include <IGESBasic_SingleParent.hxx>
#include <IGESBasic_SingularSubfigure.hxx>
#include <IGESBasic_SpecificModule.hxx>
#include <IGESBasic_SubfigureDef.hxx>
#include <IGESBasic_ToolAssocGroupType.hxx>
#include <IGESBasic_ToolExternalReferenceFile.hxx>
#include <IGESBasic_ToolExternalRefFile.hxx>
#include <IGESBasic_ToolExternalRefFileIndex.hxx>
#include <IGESBasic_ToolExternalRefFileName.hxx>
#include <IGESBasic_ToolExternalRefLibName.hxx>
#include <IGESBasic_ToolExternalRefName.hxx>
#include <IGESBasic_ToolGroup.hxx>
#include <IGESBasic_ToolGroupWithoutBackP.hxx>
#include <IGESBasic_ToolHierarchy.hxx>
#include <IGESBasic_ToolName.hxx>
#include <IGESBasic_ToolOrderedGroup.hxx>
#include <IGESBasic_ToolOrderedGroupWithoutBackP.hxx>
#include <IGESBasic_ToolSingleParent.hxx>
#include <IGESBasic_ToolSingularSubfigure.hxx>
#include <IGESBasic_ToolSubfigureDef.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_IGESBasic(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("IGESBasic"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class IGESBasic from ./opencascade/IGESBasic.hxx
    klass = m.attr("IGESBasic");

    // default constructor
    register_default_constructor<IGESBasic , shared_ptr<IGESBasic>>(m,"IGESBasic");

    // nested enums

    static_cast<py::class_<IGESBasic , shared_ptr<IGESBasic>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Init_s",
                    (void (*)() ) static_cast<void (*)() >(&IGESBasic::Init),
                    R"#(Prepares dynqmic data (Protocol, Modules) for this package)#" 
          )
        .def_static("Protocol_s",
                    (handle<IGESBasic_Protocol> (*)() ) static_cast<handle<IGESBasic_Protocol> (*)() >(&IGESBasic::Protocol),
                    R"#(Returns the Protocol for this Package)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_AssocGroupType from ./opencascade/IGESBasic_AssocGroupType.hxx
    klass = m.attr("IGESBasic_AssocGroupType");


    // nested enums

    static_cast<py::class_<IGESBasic_AssocGroupType ,opencascade::handle<IGESBasic_AssocGroupType>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_AssocGroupType::*)(  const int ,   const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_AssocGroupType::*)(  const int ,   const int ,   const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_AssocGroupType::Init),
             R"#(This method is used to set the fields of the class AssocGroupType - nbDataFields : number of parameter data fields = 2 - aType : type of attached associativity - aName : identifier of associativity of type AType)#"  , py::arg("nbDataFields"),  py::arg("aType"),  py::arg("aName")
          )
        .def("NbData",
             (int (IGESBasic_AssocGroupType::*)() const) static_cast<int (IGESBasic_AssocGroupType::*)() const>(&IGESBasic_AssocGroupType::NbData),
             R"#(returns the number of parameter data fields, always = 2)#" 
          )
        .def("AssocType",
             (int (IGESBasic_AssocGroupType::*)() const) static_cast<int (IGESBasic_AssocGroupType::*)() const>(&IGESBasic_AssocGroupType::AssocType),
             R"#(returns the type of attached associativity)#" 
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IGESBasic_AssocGroupType::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_AssocGroupType::*)() const>(&IGESBasic_AssocGroupType::Name),
             R"#(returns identifier of instance of specified associativity)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_AssocGroupType::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_AssocGroupType::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_AssocGroupType::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_AssocGroupType::*)() const>(&IGESBasic_AssocGroupType::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalRefFile from ./opencascade/IGESBasic_ExternalRefFile.hxx
    klass = m.attr("IGESBasic_ExternalRefFile");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalRefFile ,opencascade::handle<IGESBasic_ExternalRefFile>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalRefFile::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_ExternalRefFile::*)(  const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_ExternalRefFile::Init),
             R"#(This method is used to set the field of the class ExternalRefFile - aFileIdent : External Reference File Identifier)#"  , py::arg("aFileIdent")
          )
        .def("FileId",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFile::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFile::*)() const>(&IGESBasic_ExternalRefFile::FileId),
             R"#(returns External Reference File Identifier)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalRefFile::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalRefFile::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalRefFile::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalRefFile::*)() const>(&IGESBasic_ExternalRefFile::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalRefFileIndex from ./opencascade/IGESBasic_ExternalRefFileIndex.hxx
    klass = m.attr("IGESBasic_ExternalRefFileIndex");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalRefFileIndex ,opencascade::handle<IGESBasic_ExternalRefFileIndex>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalRefFileIndex::*)(  const handle<NCollection_HArray1<handle<TCollection_HAsciiString>>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESBasic_ExternalRefFileIndex::*)(  const handle<NCollection_HArray1<handle<TCollection_HAsciiString>>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESBasic_ExternalRefFileIndex::Init),
             R"#(This method is used to set the fields of the class ExternalRefFileIndex - aNameArray : External Reference Entity symbolic names - allEntities : External Reference Entities raises exception if array lengths are not equal if size of aNameArray is not equal to size of allEntities)#"  , py::arg("aNameArray"),  py::arg("allEntities")
          )
        .def("NbEntries",
             (int (IGESBasic_ExternalRefFileIndex::*)() const) static_cast<int (IGESBasic_ExternalRefFileIndex::*)() const>(&IGESBasic_ExternalRefFileIndex::NbEntries),
             R"#(returns number of index entries)#" 
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileIndex::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileIndex::*)(  const int  ) const>(&IGESBasic_ExternalRefFileIndex::Name),
             R"#(returns the External Reference Entity symbolic name raises exception if Index <= 0 or Index > NbEntries())#"  , py::arg("Index")
          )
        .def("Entity",
             (handle<IGESData_IGESEntity> (IGESBasic_ExternalRefFileIndex::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESBasic_ExternalRefFileIndex::*)(  const int  ) const>(&IGESBasic_ExternalRefFileIndex::Entity),
             R"#(returns the internal entity raises exception if Index <= 0 or Index > NbEntries())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalRefFileIndex::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalRefFileIndex::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalRefFileIndex::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalRefFileIndex::*)() const>(&IGESBasic_ExternalRefFileIndex::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalRefFileName from ./opencascade/IGESBasic_ExternalRefFileName.hxx
    klass = m.attr("IGESBasic_ExternalRefFileName");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalRefFileName ,opencascade::handle<IGESBasic_ExternalRefFileName>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalRefFileName::*)(  const handle<TCollection_HAsciiString> & ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_ExternalRefFileName::*)(  const handle<TCollection_HAsciiString> & ,   const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_ExternalRefFileName::Init),
             R"#(This method is used to set the fields of the class ExternalRefFileName - aFileIdent : External Reference File Identifier - anExtName : External Reference Entity Symbolic Name)#"  , py::arg("aFileIdent"),  py::arg("anExtName")
          )
        .def("SetForEntity",
             (void (IGESBasic_ExternalRefFileName::*)(  const bool  ) ) static_cast<void (IGESBasic_ExternalRefFileName::*)(  const bool  ) >(&IGESBasic_ExternalRefFileName::SetForEntity),
             R"#(Changes FormNumber to be 2 if <mode> is True (For Entity) or 0 if <mode> is False (For Definition))#"  , py::arg("mode")
          )
        .def("FileId",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileName::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileName::*)() const>(&IGESBasic_ExternalRefFileName::FileId),
             R"#(returns External Reference File Identifier)#" 
          )
        .def("ReferenceName",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileName::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefFileName::*)() const>(&IGESBasic_ExternalRefFileName::ReferenceName),
             R"#(returns External Reference Entity Symbolic Name)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalRefFileName::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalRefFileName::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalRefFileName::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalRefFileName::*)() const>(&IGESBasic_ExternalRefFileName::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalRefLibName from ./opencascade/IGESBasic_ExternalRefLibName.hxx
    klass = m.attr("IGESBasic_ExternalRefLibName");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalRefLibName ,opencascade::handle<IGESBasic_ExternalRefLibName>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalRefLibName::*)(  const handle<TCollection_HAsciiString> & ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_ExternalRefLibName::*)(  const handle<TCollection_HAsciiString> & ,   const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_ExternalRefLibName::Init),
             R"#(This method is used to set the fields of the class ExternalRefLibName - aLibName : Name of library in which ExtName resides - anExtName : External Reference Entity Symbolic Name)#"  , py::arg("aLibName"),  py::arg("anExtName")
          )
        .def("LibraryName",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefLibName::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefLibName::*)() const>(&IGESBasic_ExternalRefLibName::LibraryName),
             R"#(returns name of library in which External Reference Entity Symbolic Name resides)#" 
          )
        .def("ReferenceName",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefLibName::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefLibName::*)() const>(&IGESBasic_ExternalRefLibName::ReferenceName),
             R"#(returns External Reference Entity Symbolic Name)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalRefLibName::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalRefLibName::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalRefLibName::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalRefLibName::*)() const>(&IGESBasic_ExternalRefLibName::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalRefName from ./opencascade/IGESBasic_ExternalRefName.hxx
    klass = m.attr("IGESBasic_ExternalRefName");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalRefName ,opencascade::handle<IGESBasic_ExternalRefName>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalRefName::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_ExternalRefName::*)(  const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_ExternalRefName::Init),
             R"#(This method is used to set the fields of the class ExternalRefName - anExtName : External Reference Entity Symbolic Name)#"  , py::arg("anExtName")
          )
        .def("ReferenceName",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalRefName::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalRefName::*)() const>(&IGESBasic_ExternalRefName::ReferenceName),
             R"#(returns External Reference Entity Symbolic Name)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalRefName::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalRefName::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalRefName::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalRefName::*)() const>(&IGESBasic_ExternalRefName::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ExternalReferenceFile from ./opencascade/IGESBasic_ExternalReferenceFile.hxx
    klass = m.attr("IGESBasic_ExternalReferenceFile");


    // nested enums

    static_cast<py::class_<IGESBasic_ExternalReferenceFile ,opencascade::handle<IGESBasic_ExternalReferenceFile>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_ExternalReferenceFile::*)(  const handle<NCollection_HArray1<handle<TCollection_HAsciiString>>> &  ) ) static_cast<void (IGESBasic_ExternalReferenceFile::*)(  const handle<NCollection_HArray1<handle<TCollection_HAsciiString>>> &  ) >(&IGESBasic_ExternalReferenceFile::Init),
             R"#(This method is used to set the fields of the class ExternalReferenceFile - aNameArray : External Reference File Names)#"  , py::arg("aNameArray")
          )
        .def("NbListEntries",
             (int (IGESBasic_ExternalReferenceFile::*)() const) static_cast<int (IGESBasic_ExternalReferenceFile::*)() const>(&IGESBasic_ExternalReferenceFile::NbListEntries),
             R"#(returns number of External Reference File Names)#" 
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IGESBasic_ExternalReferenceFile::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_ExternalReferenceFile::*)(  const int  ) const>(&IGESBasic_ExternalReferenceFile::Name),
             R"#(returns External Reference File Name raises exception if Index <= 0 or Index > NbListEntries())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ExternalReferenceFile::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ExternalReferenceFile::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ExternalReferenceFile::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ExternalReferenceFile::*)() const>(&IGESBasic_ExternalReferenceFile::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_GeneralModule from ./opencascade/IGESBasic_GeneralModule.hxx
    klass = m.attr("IGESBasic_GeneralModule");


    // nested enums

    static_cast<py::class_<IGESBasic_GeneralModule ,opencascade::handle<IGESBasic_GeneralModule>  , IGESData_GeneralModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("OwnSharedCase",
             (void (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_GeneralModule::OwnSharedCase),
             R"#(Lists the Entities shared by a given IGESEntity <ent>, from its specific parameters : specific for each type)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const>(&IGESBasic_GeneralModule::DirChecker),
             R"#(Returns a DirChecker, specific for each type of Entity (identified by its Case Number) : this DirChecker defines constraints which must be respected by the DirectoryPart)#"  , py::arg("CN"),  py::arg("ent")
          )
        .def("NewVoid",
             (bool (IGESBasic_GeneralModule::*)(  const int ,  handle<Standard_Transient> &  ) const) static_cast<bool (IGESBasic_GeneralModule::*)(  const int ,  handle<Standard_Transient> &  ) const>(&IGESBasic_GeneralModule::NewVoid),
             R"#(Specific creation of a new void entity)#"  , py::arg("CN"),  py::arg("entto")
          )
        .def("OwnCopyCase",
             (void (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,  Interface_CopyTool &  ) const>(&IGESBasic_GeneralModule::OwnCopyCase),
             R"#(Copies parameters which are specific of each Type of Entity)#"  , py::arg("CN"),  py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("CategoryNumber",
             (int (IGESBasic_GeneralModule::*)(  const int ,   const handle<Standard_Transient> & ,   const Interface_ShareTool &  ) const) static_cast<int (IGESBasic_GeneralModule::*)(  const int ,   const handle<Standard_Transient> & ,   const Interface_ShareTool &  ) const>(&IGESBasic_GeneralModule::CategoryNumber),
             R"#(Returns a category number which characterizes an entity Structure for Groups, Figures & Co Description for External Refs Auxiliary for other)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("shares")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheckCase",
             []( IGESBasic_GeneralModule &self ,  const int CN, const handle<IGESData_IGESEntity> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheckCase(CN,ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check for each type of Entity)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_GeneralModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_GeneralModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_GeneralModule::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_GeneralModule::*)() const>(&IGESBasic_GeneralModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_Group from ./opencascade/IGESBasic_Group.hxx
    klass = m.attr("IGESBasic_Group");


    // nested enums

    static_cast<py::class_<IGESBasic_Group ,opencascade::handle<IGESBasic_Group>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int >()  , py::arg("nb") )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_Group::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESBasic_Group::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESBasic_Group::Init),
             R"#(This method is used to set the fields of the class Group - allEntities : Used to store pointers to members of the Group.)#"  , py::arg("allEntities")
          )
        .def("SetOrdered",
             (void (IGESBasic_Group::*)(  const bool  ) ) static_cast<void (IGESBasic_Group::*)(  const bool  ) >(&IGESBasic_Group::SetOrdered),
             R"#(Sets a Group to be, or not to be Ordered (according mode))#"  , py::arg("mode")
          )
        .def("SetWithoutBackP",
             (void (IGESBasic_Group::*)(  const bool  ) ) static_cast<void (IGESBasic_Group::*)(  const bool  ) >(&IGESBasic_Group::SetWithoutBackP),
             R"#(Sets a Group to be, or not to be WithoutBackP)#"  , py::arg("mode")
          )
        .def("IsOrdered",
             (bool (IGESBasic_Group::*)() const) static_cast<bool (IGESBasic_Group::*)() const>(&IGESBasic_Group::IsOrdered),
             R"#(Returns True if <me> is Ordered)#" 
          )
        .def("IsWithoutBackP",
             (bool (IGESBasic_Group::*)() const) static_cast<bool (IGESBasic_Group::*)() const>(&IGESBasic_Group::IsWithoutBackP),
             R"#(Returns True if <me> is WithoutBackP)#" 
          )
        .def("SetUser",
             (void (IGESBasic_Group::*)(  const int ,   const int  ) ) static_cast<void (IGESBasic_Group::*)(  const int ,   const int  ) >(&IGESBasic_Group::SetUser),
             R"#(Enforce a new value for the type and form)#"  , py::arg("type"),  py::arg("form")
          )
        .def("SetNb",
             (void (IGESBasic_Group::*)(  const int  ) ) static_cast<void (IGESBasic_Group::*)(  const int  ) >(&IGESBasic_Group::SetNb),
             R"#(Changes the count of item If greater, new items are null If lower, old items are lost)#"  , py::arg("nb")
          )
        .def("NbEntities",
             (int (IGESBasic_Group::*)() const) static_cast<int (IGESBasic_Group::*)() const>(&IGESBasic_Group::NbEntities),
             R"#(returns the number of IGESEntities in the Group)#" 
          )
        .def("Entity",
             (handle<IGESData_IGESEntity> (IGESBasic_Group::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESBasic_Group::*)(  const int  ) const>(&IGESBasic_Group::Entity),
             R"#(returns the specific entity from the Group)#"  , py::arg("Index")
          )
        .def("Value",
             (handle<Standard_Transient> (IGESBasic_Group::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IGESBasic_Group::*)(  const int  ) const>(&IGESBasic_Group::Value),
             R"#(returns the specific entity from the Group)#"  , py::arg("Index")
          )
        .def("SetValue",
             (void (IGESBasic_Group::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) ) static_cast<void (IGESBasic_Group::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) >(&IGESBasic_Group::SetValue),
             R"#(Sets a new value for item <Index>)#"  , py::arg("Index"),  py::arg("ent")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_Group::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_Group::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_Group::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_Group::*)() const>(&IGESBasic_Group::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_HArray1OfHArray1OfIGESEntity from ./opencascade/IGESBasic_HArray1OfHArray1OfIGESEntity.hxx
    klass = m.attr("IGESBasic_HArray1OfHArray1OfIGESEntity");


    // nested enums

    static_cast<py::class_<IGESBasic_HArray1OfHArray1OfIGESEntity ,opencascade::handle<IGESBasic_HArray1OfHArray1OfIGESEntity>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("low"),  py::arg("up") )
    // custom constructors
    // methods
        .def("Lower",
             (int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const>(&IGESBasic_HArray1OfHArray1OfIGESEntity::Lower),
             R"#()#" 
          )
        .def("Upper",
             (int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const>(&IGESBasic_HArray1OfHArray1OfIGESEntity::Upper),
             R"#()#" 
          )
        .def("Length",
             (int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const>(&IGESBasic_HArray1OfHArray1OfIGESEntity::Length),
             R"#()#" 
          )
        .def("SetValue",
             (void (IGESBasic_HArray1OfHArray1OfIGESEntity::*)(  const int ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESBasic_HArray1OfHArray1OfIGESEntity::*)(  const int ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESBasic_HArray1OfHArray1OfIGESEntity::SetValue),
             R"#()#"  , py::arg("num"),  py::arg("val")
          )
        .def("Value",
             (handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> (IGESBasic_HArray1OfHArray1OfIGESEntity::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> (IGESBasic_HArray1OfHArray1OfIGESEntity::*)(  const int  ) const>(&IGESBasic_HArray1OfHArray1OfIGESEntity::Value),
             R"#()#"  , py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_HArray1OfHArray1OfIGESEntity::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_HArray1OfHArray1OfIGESEntity::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfIGESEntity::*)() const>(&IGESBasic_HArray1OfHArray1OfIGESEntity::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_HArray1OfHArray1OfInteger from ./opencascade/IGESBasic_HArray1OfHArray1OfInteger.hxx
    klass = m.attr("IGESBasic_HArray1OfHArray1OfInteger");


    // nested enums

    static_cast<py::class_<IGESBasic_HArray1OfHArray1OfInteger ,opencascade::handle<IGESBasic_HArray1OfHArray1OfInteger>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("low"),  py::arg("up") )
    // custom constructors
    // methods
        .def("Lower",
             (int (IGESBasic_HArray1OfHArray1OfInteger::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfInteger::*)() const>(&IGESBasic_HArray1OfHArray1OfInteger::Lower),
             R"#()#" 
          )
        .def("Upper",
             (int (IGESBasic_HArray1OfHArray1OfInteger::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfInteger::*)() const>(&IGESBasic_HArray1OfHArray1OfInteger::Upper),
             R"#()#" 
          )
        .def("Length",
             (int (IGESBasic_HArray1OfHArray1OfInteger::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfInteger::*)() const>(&IGESBasic_HArray1OfHArray1OfInteger::Length),
             R"#()#" 
          )
        .def("SetValue",
             (void (IGESBasic_HArray1OfHArray1OfInteger::*)(  const int ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (IGESBasic_HArray1OfHArray1OfInteger::*)(  const int ,   const handle<NCollection_HArray1<int>> &  ) >(&IGESBasic_HArray1OfHArray1OfInteger::SetValue),
             R"#()#"  , py::arg("num"),  py::arg("val")
          )
        .def("Value",
             (handle<NCollection_HArray1<int>> (IGESBasic_HArray1OfHArray1OfInteger::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<int>> (IGESBasic_HArray1OfHArray1OfInteger::*)(  const int  ) const>(&IGESBasic_HArray1OfHArray1OfInteger::Value),
             R"#()#"  , py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_HArray1OfHArray1OfInteger::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_HArray1OfHArray1OfInteger::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfInteger::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfInteger::*)() const>(&IGESBasic_HArray1OfHArray1OfInteger::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_HArray1OfHArray1OfReal from ./opencascade/IGESBasic_HArray1OfHArray1OfReal.hxx
    klass = m.attr("IGESBasic_HArray1OfHArray1OfReal");


    // nested enums

    static_cast<py::class_<IGESBasic_HArray1OfHArray1OfReal ,opencascade::handle<IGESBasic_HArray1OfHArray1OfReal>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("low"),  py::arg("up") )
    // custom constructors
    // methods
        .def("Lower",
             (int (IGESBasic_HArray1OfHArray1OfReal::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfReal::*)() const>(&IGESBasic_HArray1OfHArray1OfReal::Lower),
             R"#()#" 
          )
        .def("Upper",
             (int (IGESBasic_HArray1OfHArray1OfReal::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfReal::*)() const>(&IGESBasic_HArray1OfHArray1OfReal::Upper),
             R"#()#" 
          )
        .def("Length",
             (int (IGESBasic_HArray1OfHArray1OfReal::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfReal::*)() const>(&IGESBasic_HArray1OfHArray1OfReal::Length),
             R"#()#" 
          )
        .def("SetValue",
             (void (IGESBasic_HArray1OfHArray1OfReal::*)(  const int ,   const handle<NCollection_HArray1<double>> &  ) ) static_cast<void (IGESBasic_HArray1OfHArray1OfReal::*)(  const int ,   const handle<NCollection_HArray1<double>> &  ) >(&IGESBasic_HArray1OfHArray1OfReal::SetValue),
             R"#()#"  , py::arg("num"),  py::arg("val")
          )
        .def("Value",
             (handle<NCollection_HArray1<double>> (IGESBasic_HArray1OfHArray1OfReal::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<double>> (IGESBasic_HArray1OfHArray1OfReal::*)(  const int  ) const>(&IGESBasic_HArray1OfHArray1OfReal::Value),
             R"#()#"  , py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_HArray1OfHArray1OfReal::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_HArray1OfHArray1OfReal::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfReal::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfReal::*)() const>(&IGESBasic_HArray1OfHArray1OfReal::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_HArray1OfHArray1OfXY from ./opencascade/IGESBasic_HArray1OfHArray1OfXY.hxx
    klass = m.attr("IGESBasic_HArray1OfHArray1OfXY");


    // nested enums

    static_cast<py::class_<IGESBasic_HArray1OfHArray1OfXY ,opencascade::handle<IGESBasic_HArray1OfHArray1OfXY>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("low"),  py::arg("up") )
    // custom constructors
    // methods
        .def("Lower",
             (int (IGESBasic_HArray1OfHArray1OfXY::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXY::*)() const>(&IGESBasic_HArray1OfHArray1OfXY::Lower),
             R"#()#" 
          )
        .def("Upper",
             (int (IGESBasic_HArray1OfHArray1OfXY::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXY::*)() const>(&IGESBasic_HArray1OfHArray1OfXY::Upper),
             R"#()#" 
          )
        .def("Length",
             (int (IGESBasic_HArray1OfHArray1OfXY::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXY::*)() const>(&IGESBasic_HArray1OfHArray1OfXY::Length),
             R"#()#" 
          )
        .def("SetValue",
             (void (IGESBasic_HArray1OfHArray1OfXY::*)(  const int ,   const handle<NCollection_HArray1<gp_XY>> &  ) ) static_cast<void (IGESBasic_HArray1OfHArray1OfXY::*)(  const int ,   const handle<NCollection_HArray1<gp_XY>> &  ) >(&IGESBasic_HArray1OfHArray1OfXY::SetValue),
             R"#()#"  , py::arg("num"),  py::arg("val")
          )
        .def("Value",
             (handle<NCollection_HArray1<gp_XY>> (IGESBasic_HArray1OfHArray1OfXY::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<gp_XY>> (IGESBasic_HArray1OfHArray1OfXY::*)(  const int  ) const>(&IGESBasic_HArray1OfHArray1OfXY::Value),
             R"#()#"  , py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_HArray1OfHArray1OfXY::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_HArray1OfHArray1OfXY::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfXY::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfXY::*)() const>(&IGESBasic_HArray1OfHArray1OfXY::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_HArray1OfHArray1OfXYZ from ./opencascade/IGESBasic_HArray1OfHArray1OfXYZ.hxx
    klass = m.attr("IGESBasic_HArray1OfHArray1OfXYZ");


    // nested enums

    static_cast<py::class_<IGESBasic_HArray1OfHArray1OfXYZ ,opencascade::handle<IGESBasic_HArray1OfHArray1OfXYZ>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("low"),  py::arg("up") )
    // custom constructors
    // methods
        .def("Lower",
             (int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const>(&IGESBasic_HArray1OfHArray1OfXYZ::Lower),
             R"#()#" 
          )
        .def("Upper",
             (int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const>(&IGESBasic_HArray1OfHArray1OfXYZ::Upper),
             R"#()#" 
          )
        .def("Length",
             (int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const) static_cast<int (IGESBasic_HArray1OfHArray1OfXYZ::*)() const>(&IGESBasic_HArray1OfHArray1OfXYZ::Length),
             R"#()#" 
          )
        .def("SetValue",
             (void (IGESBasic_HArray1OfHArray1OfXYZ::*)(  const int ,   const handle<NCollection_HArray1<gp_XYZ>> &  ) ) static_cast<void (IGESBasic_HArray1OfHArray1OfXYZ::*)(  const int ,   const handle<NCollection_HArray1<gp_XYZ>> &  ) >(&IGESBasic_HArray1OfHArray1OfXYZ::SetValue),
             R"#()#"  , py::arg("num"),  py::arg("val")
          )
        .def("Value",
             (handle<NCollection_HArray1<gp_XYZ>> (IGESBasic_HArray1OfHArray1OfXYZ::*)(  const int  ) const) static_cast<handle<NCollection_HArray1<gp_XYZ>> (IGESBasic_HArray1OfHArray1OfXYZ::*)(  const int  ) const>(&IGESBasic_HArray1OfHArray1OfXYZ::Value),
             R"#()#"  , py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_HArray1OfHArray1OfXYZ::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_HArray1OfHArray1OfXYZ::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfXYZ::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_HArray1OfHArray1OfXYZ::*)() const>(&IGESBasic_HArray1OfHArray1OfXYZ::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_Hierarchy from ./opencascade/IGESBasic_Hierarchy.hxx
    klass = m.attr("IGESBasic_Hierarchy");


    // nested enums

    static_cast<py::class_<IGESBasic_Hierarchy ,opencascade::handle<IGESBasic_Hierarchy>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_Hierarchy::*)(  const int ,   const int ,   const int ,   const int ,   const int ,   const int ,   const int  ) ) static_cast<void (IGESBasic_Hierarchy::*)(  const int ,   const int ,   const int ,   const int ,   const int ,   const int ,   const int  ) >(&IGESBasic_Hierarchy::Init),
             R"#(This method is used to set the fields of the class Hierarchy - nbPropVal : Number of Property values = 6 - aLineFont : indicates the line font - aView : indicates the view - aEntityLevel : indicates the entity level - aBlankStatus : indicates the blank status - aLineWt : indicates the line weight - aColorNum : indicates the color num aLineFont, aView, aEntityLevel, aBlankStatus, aLineWt and aColorNum can take 0 or 1. 0 : The directory entry attribute will apply to entities physically subordinate to this entity. 1 : The directory entry attribute of this entity will not apply to physically subordinate entities.)#"  , py::arg("nbPropVal"),  py::arg("aLineFont"),  py::arg("aView"),  py::arg("anEntityLevel"),  py::arg("aBlankStatus"),  py::arg("aLineWt"),  py::arg("aColorNum")
          )
        .def("NbPropertyValues",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NbPropertyValues),
             R"#(returns the number of property values, which should be 6)#" 
          )
        .def("NewLineFont",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewLineFont),
             R"#(returns the line font)#" 
          )
        .def("NewView",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewView),
             R"#(returns the view)#" 
          )
        .def("NewEntityLevel",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewEntityLevel),
             R"#(returns the entity level)#" 
          )
        .def("NewBlankStatus",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewBlankStatus),
             R"#(returns the blank status)#" 
          )
        .def("NewLineWeight",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewLineWeight),
             R"#(returns the line weight)#" 
          )
        .def("NewColorNum",
             (int (IGESBasic_Hierarchy::*)() const) static_cast<int (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::NewColorNum),
             R"#(returns the color number)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_Hierarchy::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_Hierarchy::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_Hierarchy::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_Hierarchy::*)() const>(&IGESBasic_Hierarchy::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_Name from ./opencascade/IGESBasic_Name.hxx
    klass = m.attr("IGESBasic_Name");


    // nested enums

    static_cast<py::class_<IGESBasic_Name ,opencascade::handle<IGESBasic_Name>  , IGESData_NameEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_Name::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IGESBasic_Name::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&IGESBasic_Name::Init),
             R"#(This method is used to set the fields of the class Name - nbPropVal : Number of property values, always = 1 - aName : Stores the Name)#"  , py::arg("nbPropVal"),  py::arg("aName")
          )
        .def("NbPropertyValues",
             (int (IGESBasic_Name::*)() const) static_cast<int (IGESBasic_Name::*)() const>(&IGESBasic_Name::NbPropertyValues),
             R"#(returns the number of property values, which should be 1)#" 
          )
        .def("Value",
             (handle<TCollection_HAsciiString> (IGESBasic_Name::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_Name::*)() const>(&IGESBasic_Name::Value),
             R"#(returns the user defined Name)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_Name::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_Name::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_Name::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_Name::*)() const>(&IGESBasic_Name::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_Protocol from ./opencascade/IGESBasic_Protocol.hxx
    klass = m.attr("IGESBasic_Protocol");


    // nested enums

    static_cast<py::class_<IGESBasic_Protocol ,opencascade::handle<IGESBasic_Protocol>  , IGESData_Protocol >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("NbResources",
             (int (IGESBasic_Protocol::*)() const) static_cast<int (IGESBasic_Protocol::*)() const>(&IGESBasic_Protocol::NbResources),
             R"#(Gives the count of Resource Protocol. Here, one (Protocol from IGESData))#" 
          )
        .def("Resource",
             (handle<Interface_Protocol> (IGESBasic_Protocol::*)(  const int  ) const) static_cast<handle<Interface_Protocol> (IGESBasic_Protocol::*)(  const int  ) const>(&IGESBasic_Protocol::Resource),
             R"#(Returns a Resource, given a rank.)#"  , py::arg("num")
          )
        .def("TypeNumber",
             (int (IGESBasic_Protocol::*)(  const handle<Standard_Type> &  ) const) static_cast<int (IGESBasic_Protocol::*)(  const handle<Standard_Type> &  ) const>(&IGESBasic_Protocol::TypeNumber),
             R"#(Returns a Case Number, specific of each recognized Type This Case Number is then used in Libraries : the various Modules attached to this class of Protocol must use them in accordance (for a given value of TypeNumber, they must consider the same Type as the Protocol defines))#"  , py::arg("atype")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_Protocol::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_Protocol::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_Protocol::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_Protocol::*)() const>(&IGESBasic_Protocol::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ReadWriteModule from ./opencascade/IGESBasic_ReadWriteModule.hxx
    klass = m.attr("IGESBasic_ReadWriteModule");


    // nested enums

    static_cast<py::class_<IGESBasic_ReadWriteModule ,opencascade::handle<IGESBasic_ReadWriteModule>  , IGESData_ReadWriteModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("CaseIGES",
             (int (IGESBasic_ReadWriteModule::*)(  const int ,   const int  ) const) static_cast<int (IGESBasic_ReadWriteModule::*)(  const int ,   const int  ) const>(&IGESBasic_ReadWriteModule::CaseIGES),
             R"#(Defines Case Numbers for Entities of IGESBasic)#"  , py::arg("typenum"),  py::arg("formnum")
          )
        .def("ReadOwnParams",
             (void (IGESBasic_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ReadWriteModule::ReadOwnParams),
             R"#(Reads own parameters from file for an Entity of IGESBasic)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ReadWriteModule::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("IW")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_ReadWriteModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_ReadWriteModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_ReadWriteModule::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_ReadWriteModule::*)() const>(&IGESBasic_ReadWriteModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_SingleParent from ./opencascade/IGESBasic_SingleParent.hxx
    klass = m.attr("IGESBasic_SingleParent");


    // nested enums

    static_cast<py::class_<IGESBasic_SingleParent ,opencascade::handle<IGESBasic_SingleParent>  , IGESData_SingleParentEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_SingleParent::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESBasic_SingleParent::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESBasic_SingleParent::Init),
             R"#(This method is used to set the fields of the class SingleParent - nbParentEntities : Indicates number of Parents, always = 1 - aParentEntity : Used to hold the Parent Entity - allChildren : Used to hold the children)#"  , py::arg("nbParentEntities"),  py::arg("aParentEntity"),  py::arg("allChildren")
          )
        .def("NbParentEntities",
             (int (IGESBasic_SingleParent::*)() const) static_cast<int (IGESBasic_SingleParent::*)() const>(&IGESBasic_SingleParent::NbParentEntities),
             R"#(returns the number of Parent Entities, which should be 1)#" 
          )
        .def("SingleParent",
             (handle<IGESData_IGESEntity> (IGESBasic_SingleParent::*)() const) static_cast<handle<IGESData_IGESEntity> (IGESBasic_SingleParent::*)() const>(&IGESBasic_SingleParent::SingleParent),
             R"#(Returns the Parent Entity (inherited method))#" 
          )
        .def("NbChildren",
             (int (IGESBasic_SingleParent::*)() const) static_cast<int (IGESBasic_SingleParent::*)() const>(&IGESBasic_SingleParent::NbChildren),
             R"#(returns the number of children of the Parent)#" 
          )
        .def("Child",
             (handle<IGESData_IGESEntity> (IGESBasic_SingleParent::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESBasic_SingleParent::*)(  const int  ) const>(&IGESBasic_SingleParent::Child),
             R"#(returns the specific child as indicated by Index raises exception if Index <= 0 or Index > NbChildren())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_SingleParent::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_SingleParent::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_SingleParent::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_SingleParent::*)() const>(&IGESBasic_SingleParent::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_SingularSubfigure from ./opencascade/IGESBasic_SingularSubfigure.hxx
    klass = m.attr("IGESBasic_SingularSubfigure");


    // nested enums

    static_cast<py::class_<IGESBasic_SingularSubfigure ,opencascade::handle<IGESBasic_SingularSubfigure>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_SingularSubfigure::*)(  const handle<IGESBasic_SubfigureDef> & ,   const gp_XYZ & ,   const bool ,   const double  ) ) static_cast<void (IGESBasic_SingularSubfigure::*)(  const handle<IGESBasic_SubfigureDef> & ,   const gp_XYZ & ,   const bool ,   const double  ) >(&IGESBasic_SingularSubfigure::Init),
             R"#(This method is used to set the fields of the class SingularSubfigure - aSubfigureDef : the Subfigure Definition entity - aTranslation : used to store the X,Y,Z coord - hasScale : Indicates the presence of scale factor - aScale : Used to store the scale factor)#"  , py::arg("aSubfigureDef"),  py::arg("aTranslation"),  py::arg("hasScale"),  py::arg("aScale")
          )
        .def("Subfigure",
             (handle<IGESBasic_SubfigureDef> (IGESBasic_SingularSubfigure::*)() const) static_cast<handle<IGESBasic_SubfigureDef> (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::Subfigure),
             R"#(returns the subfigure definition entity)#" 
          )
        .def("Translation",
             (gp_XYZ (IGESBasic_SingularSubfigure::*)() const) static_cast<gp_XYZ (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::Translation),
             R"#(returns the X, Y, Z coordinates)#" 
          )
        .def("ScaleFactor",
             (double (IGESBasic_SingularSubfigure::*)() const) static_cast<double (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::ScaleFactor),
             R"#(returns the scale factor if hasScaleFactor is False, returns 1.0 (default))#" 
          )
        .def("HasScaleFactor",
             (bool (IGESBasic_SingularSubfigure::*)() const) static_cast<bool (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::HasScaleFactor),
             R"#(returns a boolean indicating whether scale factor is present or not)#" 
          )
        .def("TransformedTranslation",
             (gp_XYZ (IGESBasic_SingularSubfigure::*)() const) static_cast<gp_XYZ (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::TransformedTranslation),
             R"#(returns the Translation after transformation)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_SingularSubfigure::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_SingularSubfigure::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_SingularSubfigure::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_SingularSubfigure::*)() const>(&IGESBasic_SingularSubfigure::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_SpecificModule from ./opencascade/IGESBasic_SpecificModule.hxx
    klass = m.attr("IGESBasic_SpecificModule");


    // nested enums

    static_cast<py::class_<IGESBasic_SpecificModule ,opencascade::handle<IGESBasic_SpecificModule>  , IGESData_SpecificModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("OwnDump",
             (void (IGESBasic_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_SpecificModule::OwnDump),
             R"#(Specific Dump (own parameters) for IGESBasic)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const) static_cast<bool (IGESBasic_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const>(&IGESBasic_SpecificModule::OwnCorrect),
             R"#(Performs non-ambiguous Corrections on Entities which support them (AssocGroupType,Hierarchy,Name,SingleParent))#"  , py::arg("CN"),  py::arg("ent")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_SpecificModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_SpecificModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_SpecificModule::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_SpecificModule::*)() const>(&IGESBasic_SpecificModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_SubfigureDef from ./opencascade/IGESBasic_SubfigureDef.hxx
    klass = m.attr("IGESBasic_SubfigureDef");


    // nested enums

    static_cast<py::class_<IGESBasic_SubfigureDef ,opencascade::handle<IGESBasic_SubfigureDef>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESBasic_SubfigureDef::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESBasic_SubfigureDef::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESBasic_SubfigureDef::Init),
             R"#(This method is used to set the fields of the class SubfigureDef - aDepth : It indicates the amount of nesting - aName : the subfigure name - allAssocEntities : the associated entities)#"  , py::arg("aDepth"),  py::arg("aName"),  py::arg("allAssocEntities")
          )
        .def("Depth",
             (int (IGESBasic_SubfigureDef::*)() const) static_cast<int (IGESBasic_SubfigureDef::*)() const>(&IGESBasic_SubfigureDef::Depth),
             R"#(returns depth of the Subfigure if theDepth = 0 - No reference to any subfigure instance.)#" 
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IGESBasic_SubfigureDef::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESBasic_SubfigureDef::*)() const>(&IGESBasic_SubfigureDef::Name),
             R"#(returns the name of Subfigure)#" 
          )
        .def("NbEntities",
             (int (IGESBasic_SubfigureDef::*)() const) static_cast<int (IGESBasic_SubfigureDef::*)() const>(&IGESBasic_SubfigureDef::NbEntities),
             R"#(returns number of entities. Is greater than or equal to zero.)#" 
          )
        .def("AssociatedEntity",
             (handle<IGESData_IGESEntity> (IGESBasic_SubfigureDef::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESBasic_SubfigureDef::*)(  const int  ) const>(&IGESBasic_SubfigureDef::AssociatedEntity),
             R"#(returns the specific entity as indicated by Index raises exception if Index <= 0 or Index > NbEntities())#"  , py::arg("Index")
          )
        .def("Value",
             (handle<Standard_Transient> (IGESBasic_SubfigureDef::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IGESBasic_SubfigureDef::*)(  const int  ) const>(&IGESBasic_SubfigureDef::Value),
             R"#(returns the specific entity as indicated by Index raises exception if Index <= 0 or Index > NbEntities())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_SubfigureDef::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_SubfigureDef::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_SubfigureDef::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_SubfigureDef::*)() const>(&IGESBasic_SubfigureDef::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_ToolAssocGroupType from ./opencascade/IGESBasic_ToolAssocGroupType.hxx
    klass = m.attr("IGESBasic_ToolAssocGroupType");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolAssocGroupType , shared_ptr<IGESBasic_ToolAssocGroupType>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolAssocGroupType::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolAssocGroupType::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolAssocGroupType::OwnShared),
             R"#(Lists the Entities shared by a AssocGroupType <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> &  ) const) static_cast<bool (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> &  ) const>(&IGESBasic_ToolAssocGroupType::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a AssocGroupType (NbData forced to 2))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> &  ) const>(&IGESBasic_ToolAssocGroupType::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const handle<IGESBasic_AssocGroupType> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const handle<IGESBasic_AssocGroupType> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolAssocGroupType::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolAssocGroupType::*)(  const handle<IGESBasic_AssocGroupType> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolAssocGroupType::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolAssocGroupType &self ,  const handle<IGESBasic_AssocGroupType> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalRefFile from ./opencascade/IGESBasic_ToolExternalRefFile.hxx
    klass = m.attr("IGESBasic_ToolExternalRefFile");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalRefFile , shared_ptr<IGESBasic_ToolExternalRefFile>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalRefFile::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalRefFile::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalRefFile::OwnShared),
             R"#(Lists the Entities shared by a ExternalRefFile <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> &  ) const>(&IGESBasic_ToolExternalRefFile::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const handle<IGESBasic_ExternalRefFile> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const handle<IGESBasic_ExternalRefFile> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalRefFile::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalRefFile::*)(  const handle<IGESBasic_ExternalRefFile> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalRefFile::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalRefFile &self ,  const handle<IGESBasic_ExternalRefFile> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalRefFileIndex from ./opencascade/IGESBasic_ToolExternalRefFileIndex.hxx
    klass = m.attr("IGESBasic_ToolExternalRefFileIndex");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalRefFileIndex , shared_ptr<IGESBasic_ToolExternalRefFileIndex>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalRefFileIndex::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalRefFileIndex::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalRefFileIndex::OwnShared),
             R"#(Lists the Entities shared by a ExternalRefFileIndex <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> &  ) const>(&IGESBasic_ToolExternalRefFileIndex::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const handle<IGESBasic_ExternalRefFileIndex> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const handle<IGESBasic_ExternalRefFileIndex> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalRefFileIndex::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalRefFileIndex::*)(  const handle<IGESBasic_ExternalRefFileIndex> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalRefFileIndex::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalRefFileIndex &self ,  const handle<IGESBasic_ExternalRefFileIndex> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalRefFileName from ./opencascade/IGESBasic_ToolExternalRefFileName.hxx
    klass = m.attr("IGESBasic_ToolExternalRefFileName");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalRefFileName , shared_ptr<IGESBasic_ToolExternalRefFileName>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalRefFileName::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalRefFileName::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalRefFileName::OwnShared),
             R"#(Lists the Entities shared by a ExternalRefFileName <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> &  ) const>(&IGESBasic_ToolExternalRefFileName::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const handle<IGESBasic_ExternalRefFileName> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const handle<IGESBasic_ExternalRefFileName> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalRefFileName::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalRefFileName::*)(  const handle<IGESBasic_ExternalRefFileName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalRefFileName::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalRefFileName &self ,  const handle<IGESBasic_ExternalRefFileName> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalRefLibName from ./opencascade/IGESBasic_ToolExternalRefLibName.hxx
    klass = m.attr("IGESBasic_ToolExternalRefLibName");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalRefLibName , shared_ptr<IGESBasic_ToolExternalRefLibName>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalRefLibName::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalRefLibName::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalRefLibName::OwnShared),
             R"#(Lists the Entities shared by a ExternalRefLibName <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> &  ) const>(&IGESBasic_ToolExternalRefLibName::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const handle<IGESBasic_ExternalRefLibName> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const handle<IGESBasic_ExternalRefLibName> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalRefLibName::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalRefLibName::*)(  const handle<IGESBasic_ExternalRefLibName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalRefLibName::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalRefLibName &self ,  const handle<IGESBasic_ExternalRefLibName> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalRefName from ./opencascade/IGESBasic_ToolExternalRefName.hxx
    klass = m.attr("IGESBasic_ToolExternalRefName");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalRefName , shared_ptr<IGESBasic_ToolExternalRefName>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalRefName::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalRefName::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalRefName::OwnShared),
             R"#(Lists the Entities shared by a ExternalRefName <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> &  ) const>(&IGESBasic_ToolExternalRefName::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const handle<IGESBasic_ExternalRefName> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const handle<IGESBasic_ExternalRefName> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalRefName::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalRefName::*)(  const handle<IGESBasic_ExternalRefName> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalRefName::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalRefName &self ,  const handle<IGESBasic_ExternalRefName> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolExternalReferenceFile from ./opencascade/IGESBasic_ToolExternalReferenceFile.hxx
    klass = m.attr("IGESBasic_ToolExternalReferenceFile");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolExternalReferenceFile , shared_ptr<IGESBasic_ToolExternalReferenceFile>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolExternalReferenceFile::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolExternalReferenceFile::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolExternalReferenceFile::OwnShared),
             R"#(Lists the Entities shared by a ExternalReferenceFile <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> &  ) const>(&IGESBasic_ToolExternalReferenceFile::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const handle<IGESBasic_ExternalReferenceFile> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const handle<IGESBasic_ExternalReferenceFile> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolExternalReferenceFile::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolExternalReferenceFile::*)(  const handle<IGESBasic_ExternalReferenceFile> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolExternalReferenceFile::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolExternalReferenceFile &self ,  const handle<IGESBasic_ExternalReferenceFile> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolGroup from ./opencascade/IGESBasic_ToolGroup.hxx
    klass = m.attr("IGESBasic_ToolGroup");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolGroup , shared_ptr<IGESBasic_ToolGroup>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolGroup::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolGroup::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolGroup::OwnShared),
             R"#(Lists the Entities shared by a Group <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> &  ) const) static_cast<bool (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> &  ) const>(&IGESBasic_ToolGroup::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a Group (Null Elements are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> &  ) const>(&IGESBasic_ToolGroup::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const handle<IGESBasic_Group> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const handle<IGESBasic_Group> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolGroup::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolGroup::*)(  const handle<IGESBasic_Group> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolGroup::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolGroup &self ,  const handle<IGESBasic_Group> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolGroupWithoutBackP from ./opencascade/IGESBasic_ToolGroupWithoutBackP.hxx
    klass = m.attr("IGESBasic_ToolGroupWithoutBackP");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolGroupWithoutBackP , shared_ptr<IGESBasic_ToolGroupWithoutBackP>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolGroupWithoutBackP::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolGroupWithoutBackP::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolGroupWithoutBackP::OwnShared),
             R"#(Lists the Entities shared by a GroupWithoutBackP <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> &  ) const) static_cast<bool (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> &  ) const>(&IGESBasic_ToolGroupWithoutBackP::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a GroupWithoutBackP (Null Elements are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> &  ) const>(&IGESBasic_ToolGroupWithoutBackP::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const handle<IGESBasic_GroupWithoutBackP> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const handle<IGESBasic_GroupWithoutBackP> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolGroupWithoutBackP::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolGroupWithoutBackP::*)(  const handle<IGESBasic_GroupWithoutBackP> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolGroupWithoutBackP::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolGroupWithoutBackP &self ,  const handle<IGESBasic_GroupWithoutBackP> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolHierarchy from ./opencascade/IGESBasic_ToolHierarchy.hxx
    klass = m.attr("IGESBasic_ToolHierarchy");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolHierarchy , shared_ptr<IGESBasic_ToolHierarchy>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolHierarchy::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolHierarchy::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolHierarchy::OwnShared),
             R"#(Lists the Entities shared by a Hierarchy <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> &  ) const) static_cast<bool (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> &  ) const>(&IGESBasic_ToolHierarchy::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a Hierarchy (NbPropertyValues forced to 6))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> &  ) const>(&IGESBasic_ToolHierarchy::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const handle<IGESBasic_Hierarchy> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const handle<IGESBasic_Hierarchy> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolHierarchy::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolHierarchy::*)(  const handle<IGESBasic_Hierarchy> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolHierarchy::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolHierarchy &self ,  const handle<IGESBasic_Hierarchy> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolName from ./opencascade/IGESBasic_ToolName.hxx
    klass = m.attr("IGESBasic_ToolName");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolName , shared_ptr<IGESBasic_ToolName>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolName::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolName::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolName::OwnShared),
             R"#(Lists the Entities shared by a Name <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> &  ) const) static_cast<bool (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> &  ) const>(&IGESBasic_ToolName::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a Name (NbPropertyValues forced to 1))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> &  ) const>(&IGESBasic_ToolName::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const handle<IGESBasic_Name> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const handle<IGESBasic_Name> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolName::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolName::*)(  const handle<IGESBasic_Name> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolName::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolName &self ,  const handle<IGESBasic_Name> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolOrderedGroup from ./opencascade/IGESBasic_ToolOrderedGroup.hxx
    klass = m.attr("IGESBasic_ToolOrderedGroup");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolOrderedGroup , shared_ptr<IGESBasic_ToolOrderedGroup>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolOrderedGroup::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolOrderedGroup::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolOrderedGroup::OwnShared),
             R"#(Lists the Entities shared by a OrderedGroup <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> &  ) const) static_cast<bool (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> &  ) const>(&IGESBasic_ToolOrderedGroup::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on an OrderedGroup (Null Elements are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> &  ) const>(&IGESBasic_ToolOrderedGroup::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const handle<IGESBasic_OrderedGroup> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const handle<IGESBasic_OrderedGroup> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolOrderedGroup::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolOrderedGroup::*)(  const handle<IGESBasic_OrderedGroup> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolOrderedGroup::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolOrderedGroup &self ,  const handle<IGESBasic_OrderedGroup> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolOrderedGroupWithoutBackP from ./opencascade/IGESBasic_ToolOrderedGroupWithoutBackP.hxx
    klass = m.attr("IGESBasic_ToolOrderedGroupWithoutBackP");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolOrderedGroupWithoutBackP , shared_ptr<IGESBasic_ToolOrderedGroupWithoutBackP>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::OwnShared),
             R"#(Lists the Entities shared by a OrderedGroupWithoutBackP <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> &  ) const) static_cast<bool (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on an OrderedGroupWithoutBackP (Null Elements are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const handle<IGESBasic_OrderedGroupWithoutBackP> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolOrderedGroupWithoutBackP::*)(  const handle<IGESBasic_OrderedGroupWithoutBackP> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolOrderedGroupWithoutBackP::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolOrderedGroupWithoutBackP &self ,  const handle<IGESBasic_OrderedGroupWithoutBackP> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolSingleParent from ./opencascade/IGESBasic_ToolSingleParent.hxx
    klass = m.attr("IGESBasic_ToolSingleParent");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolSingleParent , shared_ptr<IGESBasic_ToolSingleParent>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolSingleParent::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolSingleParent::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolSingleParent::OwnShared),
             R"#(Lists the Entities shared by a SingleParent <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> &  ) const) static_cast<bool (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> &  ) const>(&IGESBasic_ToolSingleParent::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a SingleParent (NbParents forced to 1))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> &  ) const>(&IGESBasic_ToolSingleParent::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const handle<IGESBasic_SingleParent> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const handle<IGESBasic_SingleParent> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolSingleParent::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolSingleParent::*)(  const handle<IGESBasic_SingleParent> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolSingleParent::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolSingleParent &self ,  const handle<IGESBasic_SingleParent> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolSingularSubfigure from ./opencascade/IGESBasic_ToolSingularSubfigure.hxx
    klass = m.attr("IGESBasic_ToolSingularSubfigure");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolSingularSubfigure , shared_ptr<IGESBasic_ToolSingularSubfigure>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolSingularSubfigure::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolSingularSubfigure::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolSingularSubfigure::OwnShared),
             R"#(Lists the Entities shared by a SingularSubfigure <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> &  ) const>(&IGESBasic_ToolSingularSubfigure::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const handle<IGESBasic_SingularSubfigure> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const handle<IGESBasic_SingularSubfigure> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolSingularSubfigure::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolSingularSubfigure::*)(  const handle<IGESBasic_SingularSubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolSingularSubfigure::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolSingularSubfigure &self ,  const handle<IGESBasic_SingularSubfigure> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_ToolSubfigureDef from ./opencascade/IGESBasic_ToolSubfigureDef.hxx
    klass = m.attr("IGESBasic_ToolSubfigureDef");


    // nested enums

    static_cast<py::class_<IGESBasic_ToolSubfigureDef , shared_ptr<IGESBasic_ToolSubfigureDef>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESBasic_ToolSubfigureDef::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,  IGESData_IGESWriter &  ) const>(&IGESBasic_ToolSubfigureDef::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,  Interface_EntityIterator &  ) const>(&IGESBasic_ToolSubfigureDef::OwnShared),
             R"#(Lists the Entities shared by a SubfigureDef <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> &  ) const) static_cast<IGESData_DirChecker (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> &  ) const>(&IGESBasic_ToolSubfigureDef::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const handle<IGESBasic_SubfigureDef> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const handle<IGESBasic_SubfigureDef> & ,  Interface_CopyTool &  ) const>(&IGESBasic_ToolSubfigureDef::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESBasic_ToolSubfigureDef::*)(  const handle<IGESBasic_SubfigureDef> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESBasic_ToolSubfigureDef::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESBasic_ToolSubfigureDef &self ,  const handle<IGESBasic_SubfigureDef> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESBasic_GroupWithoutBackP from ./opencascade/IGESBasic_GroupWithoutBackP.hxx
    klass = m.attr("IGESBasic_GroupWithoutBackP");


    // nested enums

    static_cast<py::class_<IGESBasic_GroupWithoutBackP ,opencascade::handle<IGESBasic_GroupWithoutBackP>  , IGESBasic_Group >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_GroupWithoutBackP::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_GroupWithoutBackP::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_GroupWithoutBackP::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_GroupWithoutBackP::*)() const>(&IGESBasic_GroupWithoutBackP::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_OrderedGroup from ./opencascade/IGESBasic_OrderedGroup.hxx
    klass = m.attr("IGESBasic_OrderedGroup");


    // nested enums

    static_cast<py::class_<IGESBasic_OrderedGroup ,opencascade::handle<IGESBasic_OrderedGroup>  , IGESBasic_Group >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_OrderedGroup::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_OrderedGroup::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_OrderedGroup::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_OrderedGroup::*)() const>(&IGESBasic_OrderedGroup::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESBasic_OrderedGroupWithoutBackP from ./opencascade/IGESBasic_OrderedGroupWithoutBackP.hxx
    klass = m.attr("IGESBasic_OrderedGroupWithoutBackP");


    // nested enums

    static_cast<py::class_<IGESBasic_OrderedGroupWithoutBackP ,opencascade::handle<IGESBasic_OrderedGroupWithoutBackP>  , IGESBasic_Group >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESBasic_OrderedGroupWithoutBackP::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESBasic_OrderedGroupWithoutBackP::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESBasic_OrderedGroupWithoutBackP::*)() const) static_cast< const handle<Standard_Type> & (IGESBasic_OrderedGroupWithoutBackP::*)() const>(&IGESBasic_OrderedGroupWithoutBackP::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/IGESBasic.hxx
// ./opencascade/IGESBasic_AssocGroupType.hxx
// ./opencascade/IGESBasic_ExternalRefFile.hxx
// ./opencascade/IGESBasic_ExternalRefFileIndex.hxx
// ./opencascade/IGESBasic_ExternalRefFileName.hxx
// ./opencascade/IGESBasic_ExternalRefLibName.hxx
// ./opencascade/IGESBasic_ExternalRefName.hxx
// ./opencascade/IGESBasic_ExternalReferenceFile.hxx
// ./opencascade/IGESBasic_GeneralModule.hxx
// ./opencascade/IGESBasic_Group.hxx
// ./opencascade/IGESBasic_GroupWithoutBackP.hxx
// ./opencascade/IGESBasic_HArray1OfHArray1OfIGESEntity.hxx
// ./opencascade/IGESBasic_HArray1OfHArray1OfInteger.hxx
// ./opencascade/IGESBasic_HArray1OfHArray1OfReal.hxx
// ./opencascade/IGESBasic_HArray1OfHArray1OfXY.hxx
// ./opencascade/IGESBasic_HArray1OfHArray1OfXYZ.hxx
// ./opencascade/IGESBasic_Hierarchy.hxx
// ./opencascade/IGESBasic_Name.hxx
// ./opencascade/IGESBasic_OrderedGroup.hxx
// ./opencascade/IGESBasic_OrderedGroupWithoutBackP.hxx
// ./opencascade/IGESBasic_Protocol.hxx
// ./opencascade/IGESBasic_ReadWriteModule.hxx
// ./opencascade/IGESBasic_SingleParent.hxx
// ./opencascade/IGESBasic_SingularSubfigure.hxx
// ./opencascade/IGESBasic_SpecificModule.hxx
// ./opencascade/IGESBasic_SubfigureDef.hxx
// ./opencascade/IGESBasic_ToolAssocGroupType.hxx
// ./opencascade/IGESBasic_ToolExternalRefFile.hxx
// ./opencascade/IGESBasic_ToolExternalRefFileIndex.hxx
// ./opencascade/IGESBasic_ToolExternalRefFileName.hxx
// ./opencascade/IGESBasic_ToolExternalRefLibName.hxx
// ./opencascade/IGESBasic_ToolExternalRefName.hxx
// ./opencascade/IGESBasic_ToolExternalReferenceFile.hxx
// ./opencascade/IGESBasic_ToolGroup.hxx
// ./opencascade/IGESBasic_ToolGroupWithoutBackP.hxx
// ./opencascade/IGESBasic_ToolHierarchy.hxx
// ./opencascade/IGESBasic_ToolName.hxx
// ./opencascade/IGESBasic_ToolOrderedGroup.hxx
// ./opencascade/IGESBasic_ToolOrderedGroupWithoutBackP.hxx
// ./opencascade/IGESBasic_ToolSingleParent.hxx
// ./opencascade/IGESBasic_ToolSingularSubfigure.hxx
// ./opencascade/IGESBasic_ToolSubfigureDef.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
