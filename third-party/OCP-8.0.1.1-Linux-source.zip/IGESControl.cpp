
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

#include <XSAlgo_ShapeProcessor.hxx>

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Transfer_FinderProcess.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Interface_InterfaceModel.hxx>
#include <Transfer_ActorOfTransientProcess.hxx>
#include <TopoDS_Shape.hxx>
#include <Transfer_FinderProcess.hxx>
#include <XSControl_WorkSession.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <ShapeExtend_WireData.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESModel.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESToBRep_IGESBoundary.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Transfer_FinderProcess.hxx>
#include <IGESData_IGESModel.hxx>
#include <IGESData_IGESEntity.hxx>

// module includes
#include <IGESControl_ActorWrite.hxx>
#include <IGESControl_AlgoContainer.hxx>
#include <IGESControl_Controller.hxx>
#include <IGESControl_IGESBoundary.hxx>
#include <IGESControl_Reader.hxx>
#include <IGESControl_ToolContainer.hxx>
#include <IGESControl_Writer.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_IGESControl(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("IGESControl"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class IGESControl_ActorWrite from ./opencascade/IGESControl_ActorWrite.hxx
    klass = m.attr("IGESControl_ActorWrite");


    // nested enums

    static_cast<py::class_<IGESControl_ActorWrite ,opencascade::handle<IGESControl_ActorWrite>  , Transfer_ActorOfFinderProcess >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Recognize",
             (bool (IGESControl_ActorWrite::*)(  const handle<Transfer_Finder> &  ) ) static_cast<bool (IGESControl_ActorWrite::*)(  const handle<Transfer_Finder> &  ) >(&IGESControl_ActorWrite::Recognize),
             R"#(Recognizes a ShapeMapper)#"  , py::arg("start")
          )
        .def("Transfer",
             (handle<Transfer_Binder> (IGESControl_ActorWrite::*)(  const handle<Transfer_Finder> & ,   const handle<Transfer_FinderProcess> & ,   const Message_ProgressRange &  ) ) static_cast<handle<Transfer_Binder> (IGESControl_ActorWrite::*)(  const handle<Transfer_Finder> & ,   const handle<Transfer_FinderProcess> & ,   const Message_ProgressRange &  ) >(&IGESControl_ActorWrite::Transfer),
             R"#(Transfers Shape to IGES Entities)#"  , py::arg("start"),  py::arg("FP"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESControl_ActorWrite::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESControl_ActorWrite::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESControl_ActorWrite::*)() const) static_cast< const handle<Standard_Type> & (IGESControl_ActorWrite::*)() const>(&IGESControl_ActorWrite::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESControl_AlgoContainer from ./opencascade/IGESControl_AlgoContainer.hxx
    klass = m.attr("IGESControl_AlgoContainer");


    // nested enums

    static_cast<py::class_<IGESControl_AlgoContainer ,opencascade::handle<IGESControl_AlgoContainer>  , IGESToBRep_AlgoContainer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESControl_AlgoContainer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESControl_AlgoContainer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESControl_AlgoContainer::*)() const) static_cast< const handle<Standard_Type> & (IGESControl_AlgoContainer::*)() const>(&IGESControl_AlgoContainer::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESControl_Controller from ./opencascade/IGESControl_Controller.hxx
    klass = m.attr("IGESControl_Controller");


    // nested enums

    static_cast<py::class_<IGESControl_Controller ,opencascade::handle<IGESControl_Controller>  , XSControl_Controller >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("modefnes")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("NewModel",
             (handle<Interface_InterfaceModel> (IGESControl_Controller::*)() const) static_cast<handle<Interface_InterfaceModel> (IGESControl_Controller::*)() const>(&IGESControl_Controller::NewModel),
             R"#(Creates a new empty Model ready to receive data of the Norm. It is taken from IGES Template Model)#" 
          )
        .def("ActorRead",
             (handle<Transfer_ActorOfTransientProcess> (IGESControl_Controller::*)(  const handle<Interface_InterfaceModel> &  ) const) static_cast<handle<Transfer_ActorOfTransientProcess> (IGESControl_Controller::*)(  const handle<Interface_InterfaceModel> &  ) const>(&IGESControl_Controller::ActorRead),
             R"#(Returns the Actor for Read attached to the pair (norm,appli) It is an Actor from IGESToBRep, adapted from an IGESModel : Unit, tolerances)#"  , py::arg("model")
          )
        .def("TransferWriteShape",
             (IFSelect_ReturnStatus (IGESControl_Controller::*)(  const TopoDS_Shape & ,   const handle<Transfer_FinderProcess> & ,   const handle<Interface_InterfaceModel> & ,   const int ,   const Message_ProgressRange &  ) const) static_cast<IFSelect_ReturnStatus (IGESControl_Controller::*)(  const TopoDS_Shape & ,   const handle<Transfer_FinderProcess> & ,   const handle<Interface_InterfaceModel> & ,   const int ,   const Message_ProgressRange &  ) const>(&IGESControl_Controller::TransferWriteShape),
             R"#(Takes one Shape and transfers it to the InterfaceModel (already created by NewModel for instance) <modetrans> is to be interpreted by each kind of XstepAdaptor Returns a status : 0 OK 1 No result 2 Fail -1 bad modeshape -2 bad model (requires an IGESModel) modeshape : 0 group of face (version < 5.1) 1 BREP-version 5.1 of IGES)#"  , py::arg("shape"),  py::arg("FP"),  py::arg("model"),  py::arg("modetrans")=static_cast< const int>(0),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
        .def("Customise",
             []( IGESControl_Controller &self , XSControl_WorkSession& WS ){
                 handle<XSControl_WorkSession>  WS_ptr; WS_ptr = &WS;

                 self.Customise(WS_ptr);
                 return std::make_tuple(WS_ptr); },
             R"#()#"  , py::arg("WS")
          )
    // static methods
        .def_static("Init_s",
                    (bool (*)() ) static_cast<bool (*)() >(&IGESControl_Controller::Init),
                    R"#(Standard Initialisation. It creates a Controller for IGES and records it to various names, available to select it later Returns True when done, False if could not be done Also, it creates and records an Adaptor for FNES)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESControl_Controller::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESControl_Controller::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESControl_Controller::*)() const) static_cast< const handle<Standard_Type> & (IGESControl_Controller::*)() const>(&IGESControl_Controller::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESControl_IGESBoundary from ./opencascade/IGESControl_IGESBoundary.hxx
    klass = m.attr("IGESControl_IGESBoundary");


    // nested enums

    static_cast<py::class_<IGESControl_IGESBoundary ,opencascade::handle<IGESControl_IGESBoundary>  , IGESToBRep_IGESBoundary >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const IGESToBRep_CurveAndSurface & >()  , py::arg("CS") )
    // custom constructors
    // methods
        .def("Check",
             (void (IGESControl_IGESBoundary::*)(  const bool ,   const bool ,   const bool ,   const bool  ) ) static_cast<void (IGESControl_IGESBoundary::*)(  const bool ,   const bool ,   const bool ,   const bool  ) >(&IGESControl_IGESBoundary::Check),
             R"#(Checks result of translation of IGES boundary entities (types 141, 142 or 508). Checks consistency of 2D and 3D representations and keeps only one if they are inconsistent. Checks the closure of resulting wire and if it is not closed, checks 2D and 3D representation and updates the resulting wire to contain only closed representation.)#"  , py::arg("result"),  py::arg("checkclosure"),  py::arg("okCurve3d"),  py::arg("okCurve2d")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESControl_IGESBoundary::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESControl_IGESBoundary::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESControl_IGESBoundary::*)() const) static_cast< const handle<Standard_Type> & (IGESControl_IGESBoundary::*)() const>(&IGESControl_IGESBoundary::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESControl_Reader from ./opencascade/IGESControl_Reader.hxx
    klass = m.attr("IGESControl_Reader");


    // nested enums

    static_cast<py::class_<IGESControl_Reader , shared_ptr<IGESControl_Reader>  , XSControl_Reader >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<XSControl_WorkSession> &, const bool >()  , py::arg("WS"),  py::arg("scratch")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("SetReadVisible",
             (void (IGESControl_Reader::*)(  const bool  ) ) static_cast<void (IGESControl_Reader::*)(  const bool  ) >(&IGESControl_Reader::SetReadVisible),
             R"#(Set the transion of ALL Roots (if theReadOnlyVisible is False) or of Visible Roots (if theReadOnlyVisible is True))#"  , py::arg("ReadRoot")
          )
        .def("GetReadVisible",
             (bool (IGESControl_Reader::*)() const) static_cast<bool (IGESControl_Reader::*)() const>(&IGESControl_Reader::GetReadVisible),
             R"#()#" 
          )
        .def("IGESModel",
             (handle<IGESData_IGESModel> (IGESControl_Reader::*)() const) static_cast<handle<IGESData_IGESModel> (IGESControl_Reader::*)() const>(&IGESControl_Reader::IGESModel),
             R"#(Returns the model as a IGESModel. It can then be consulted (header, product))#" 
          )
        .def("NbRootsForTransfer",
             (int (IGESControl_Reader::*)() ) static_cast<int (IGESControl_Reader::*)() >(&IGESControl_Reader::NbRootsForTransfer),
             R"#(Determines the list of root entities from Model which are candidate for a transfer to a Shape (type of entities is PRODUCT) <theReadOnlyVisible> is taken into account to define roots)#" 
          )
        .def("PrintTransferInfo",
             (void (IGESControl_Reader::*)(  const IFSelect_PrintFail ,   const IFSelect_PrintCount  ) const) static_cast<void (IGESControl_Reader::*)(  const IFSelect_PrintFail ,   const IFSelect_PrintCount  ) const>(&IGESControl_Reader::PrintTransferInfo),
             R"#(Prints Statistics and check list for Transfer)#"  , py::arg("failwarn"),  py::arg("mode")
          )
        .def("SetReadVisible",
             (void (IGESControl_Reader::*)(  const bool  ) ) static_cast<void (IGESControl_Reader::*)(  const bool  ) >(&IGESControl_Reader::SetReadVisible),
             R"#(Set the transion of ALL Roots (if theReadOnlyVisible is False) or of Visible Roots (if theReadOnlyVisible is True))#"  , py::arg("ReadRoot")
          )
        .def("GetReadVisible",
             (bool (IGESControl_Reader::*)() const) static_cast<bool (IGESControl_Reader::*)() const>(&IGESControl_Reader::GetReadVisible),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESControl_ToolContainer from ./opencascade/IGESControl_ToolContainer.hxx
    klass = m.attr("IGESControl_ToolContainer");


    // nested enums

    static_cast<py::class_<IGESControl_ToolContainer ,opencascade::handle<IGESControl_ToolContainer>  , IGESToBRep_ToolContainer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IGESBoundary",
             (handle<IGESToBRep_IGESBoundary> (IGESControl_ToolContainer::*)() const) static_cast<handle<IGESToBRep_IGESBoundary> (IGESControl_ToolContainer::*)() const>(&IGESControl_ToolContainer::IGESBoundary),
             R"#(Returns IGESControl_IGESBoundary)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESControl_ToolContainer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESControl_ToolContainer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESControl_ToolContainer::*)() const) static_cast< const handle<Standard_Type> & (IGESControl_ToolContainer::*)() const>(&IGESControl_ToolContainer::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESControl_Writer from ./opencascade/IGESControl_Writer.hxx
    klass = m.attr("IGESControl_Writer");


    // nested enums

    static_cast<py::class_<IGESControl_Writer , shared_ptr<IGESControl_Writer>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const char * const , const int >()  , py::arg("theUnit"),  py::arg("theModecr")=static_cast< const int>(0) )
        .def(py::init<  const handle<IGESData_IGESModel> &, const int >()  , py::arg("theModel"),  py::arg("theModecr")=static_cast< const int>(0) )
    // custom constructors
    // methods
        .def("SetTransferProcess",
             (void (IGESControl_Writer::*)(  const handle<Transfer_FinderProcess> &  ) ) static_cast<void (IGESControl_Writer::*)(  const handle<Transfer_FinderProcess> &  ) >(&IGESControl_Writer::SetTransferProcess),
             R"#(Returns/Sets the TransferProcess : it contains final results and if some, check messages)#"  , py::arg("TP")
          )
        .def("AddShape",
             (bool (IGESControl_Writer::*)(  const TopoDS_Shape & ,   const Message_ProgressRange &  ) ) static_cast<bool (IGESControl_Writer::*)(  const TopoDS_Shape & ,   const Message_ProgressRange &  ) >(&IGESControl_Writer::AddShape),
             R"#(Translates a Shape to IGES Entities and adds them to the model Returns True if done, False if Shape not suitable for IGES or null)#"  , py::arg("sh"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("AddGeom",
             (bool (IGESControl_Writer::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IGESControl_Writer::*)(  const handle<Standard_Transient> &  ) >(&IGESControl_Writer::AddGeom),
             R"#(Translates a Geometry (Surface or Curve) to IGES Entities and adds them to the model Returns True if done, False if geom is neither a Surface or a Curve suitable for IGES or is null)#"  , py::arg("geom")
          )
        .def("AddEntity",
             (bool (IGESControl_Writer::*)(  const handle<IGESData_IGESEntity> &  ) ) static_cast<bool (IGESControl_Writer::*)(  const handle<IGESData_IGESEntity> &  ) >(&IGESControl_Writer::AddEntity),
             R"#(Adds an IGES entity (and the ones it references) to the model)#"  , py::arg("ent")
          )
        .def("ComputeModel",
             (void (IGESControl_Writer::*)() ) static_cast<void (IGESControl_Writer::*)() >(&IGESControl_Writer::ComputeModel),
             R"#(Computes the entities found in the model, which is ready to be written. This contrasts with the default computation of headers only.)#" 
          )
        .def("Write",
             (bool (IGESControl_Writer::*)( Standard_OStream & ,   const bool  ) ) static_cast<bool (IGESControl_Writer::*)( Standard_OStream & ,   const bool  ) >(&IGESControl_Writer::Write),
             R"#(Computes then writes the model to an OStream Returns True when done, false in case of error)#"  , py::arg("S"),  py::arg("fnes")=static_cast< const bool>(false)
          )
        .def("Write",
             (bool (IGESControl_Writer::*)(  const char * const  ,   const bool  ) ) static_cast<bool (IGESControl_Writer::*)(  const char * const  ,   const bool  ) >(&IGESControl_Writer::Write),
             R"#(Prepares and writes an IGES model either to an OStream, S or to a file name,CString. Returns True if the operation was performed correctly and False if an error occurred (for instance, if the processor could not create the file).)#"  , py::arg("file"),  py::arg("fnes")=static_cast< const bool>(false)
          )
        .def("SetShapeFixParameters",
             (void (IGESControl_Writer::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (IGESControl_Writer::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&IGESControl_Writer::SetShapeFixParameters),
             R"#(Sets parameters for shape processing.)#"  , py::arg("theParameters")
          )
        .def("SetShapeFixParameters",
             (void (IGESControl_Writer::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (IGESControl_Writer::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&IGESControl_Writer::SetShapeFixParameters),
             R"#(Sets parameters for shape processing. Parameters from theParameters are copied to the internal map. Parameters from theAdditionalParameters are copied to the internal map if they are not present in theParameters.)#"  , py::arg("theParameters"),  py::arg("theAdditionalParameters")=static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap &>(XSAlgo_ShapeProcessor::ParameterMap{ })
          )
        .def("SetShapeProcessFlags",
             (void (IGESControl_Writer::*)(  const typename ShapeProcess::OperationsFlags &  ) ) static_cast<void (IGESControl_Writer::*)(  const typename ShapeProcess::OperationsFlags &  ) >(&IGESControl_Writer::SetShapeProcessFlags),
             R"#(Sets flags defining operations to be performed on shapes.)#"  , py::arg("theFlags")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Model",
             ( const handle<IGESData_IGESModel> & (IGESControl_Writer::*)() const) static_cast< const handle<IGESData_IGESModel> & (IGESControl_Writer::*)() const>(&IGESControl_Writer::Model),
             R"#(Returns the IGES model to be written in output.)#"
             
         )
       .def("TransferProcess",
             ( const handle<Transfer_FinderProcess> & (IGESControl_Writer::*)() const) static_cast< const handle<Transfer_FinderProcess> & (IGESControl_Writer::*)() const>(&IGESControl_Writer::TransferProcess),
             R"#()#"
             
         )
       .def("GetShapeFixParameters",
             ( const typename XSAlgo_ShapeProcessor::ParameterMap & (IGESControl_Writer::*)() const) static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap & (IGESControl_Writer::*)() const>(&IGESControl_Writer::GetShapeFixParameters),
             R"#(Returns parameters for shape processing that was set by SetParameters() method.)#"
             
         )
       .def("GetShapeProcessFlags",
             ( const typename ShapeProcess::OperationsFlags & (IGESControl_Writer::*)() const) static_cast< const typename ShapeProcess::OperationsFlags & (IGESControl_Writer::*)() const>(&IGESControl_Writer::GetShapeProcessFlags),
             R"#(Returns flags defining operations to be performed on shapes.)#"
             
         )
;

// functions

// ./opencascade/IGESControl_ActorWrite.hxx
// ./opencascade/IGESControl_AlgoContainer.hxx
// ./opencascade/IGESControl_Controller.hxx
// ./opencascade/IGESControl_IGESBoundary.hxx
// ./opencascade/IGESControl_Reader.hxx
// ./opencascade/IGESControl_ToolContainer.hxx
// ./opencascade/IGESControl_Writer.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
