
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_Protocol.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <IGESGraph_TextDisplayTemplate.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_XYZ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_XYZ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_NetworkSubfigureDef.hxx>
#include <TCollection_HAsciiString.hxx>
#include <IGESGraph_TextDisplayTemplate.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <IGESGraph_TextDisplayTemplate.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Vec.hxx>
#include <gp_Pnt.hxx>
#include <gp_Pnt2d.hxx>
#include <IGESData_TransfEntity.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESGeom_TransformationMatrix.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESData_IGESEntity.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_CircArraySubfigure.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_ConnectPoint.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_Drawing.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_DrawingWithRotation.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_LabelDisplay.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_NetworkSubfigure.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_NetworkSubfigureDef.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_PerspectiveView.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_Planar.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_RectArraySubfigure.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_SegmentedViewsVisible.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_View.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_ViewsVisible.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESDraw_ViewsVisibleWithAttr.hxx>
#include <IGESData_IGESReaderData.hxx>
#include <IGESData_ParamReader.hxx>
#include <IGESData_IGESWriter.hxx>
#include <Interface_EntityIterator.hxx>
#include <IGESData_DirChecker.hxx>
#include <Interface_ShareTool.hxx>
#include <Interface_Check.hxx>
#include <Interface_CopyTool.hxx>
#include <IGESData_IGESDumper.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IGESGeom_Plane.hxx>
#include <IGESData_TransfEntity.hxx>
#include <gp_XYZ.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <IGESDraw.hxx>
#include <IGESDraw_CircArraySubfigure.hxx>
#include <IGESDraw_ConnectPoint.hxx>
#include <IGESDraw_Drawing.hxx>
#include <IGESDraw_DrawingWithRotation.hxx>
#include <IGESDraw_GeneralModule.hxx>
#include <IGESDraw_LabelDisplay.hxx>
#include <IGESDraw_NetworkSubfigure.hxx>
#include <IGESDraw_NetworkSubfigureDef.hxx>
#include <IGESDraw_PerspectiveView.hxx>
#include <IGESDraw_Planar.hxx>
#include <IGESDraw_Protocol.hxx>
#include <IGESDraw_ReadWriteModule.hxx>
#include <IGESDraw_RectArraySubfigure.hxx>
#include <IGESDraw_SegmentedViewsVisible.hxx>
#include <IGESDraw_SpecificModule.hxx>
#include <IGESDraw_ToolCircArraySubfigure.hxx>
#include <IGESDraw_ToolConnectPoint.hxx>
#include <IGESDraw_ToolDrawing.hxx>
#include <IGESDraw_ToolDrawingWithRotation.hxx>
#include <IGESDraw_ToolLabelDisplay.hxx>
#include <IGESDraw_ToolNetworkSubfigure.hxx>
#include <IGESDraw_ToolNetworkSubfigureDef.hxx>
#include <IGESDraw_ToolPerspectiveView.hxx>
#include <IGESDraw_ToolPlanar.hxx>
#include <IGESDraw_ToolRectArraySubfigure.hxx>
#include <IGESDraw_ToolSegmentedViewsVisible.hxx>
#include <IGESDraw_ToolView.hxx>
#include <IGESDraw_ToolViewsVisible.hxx>
#include <IGESDraw_ToolViewsVisibleWithAttr.hxx>
#include <IGESDraw_View.hxx>
#include <IGESDraw_ViewsVisible.hxx>
#include <IGESDraw_ViewsVisibleWithAttr.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_IGESDraw(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("IGESDraw"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class IGESDraw from ./opencascade/IGESDraw.hxx
    klass = m.attr("IGESDraw");

    // default constructor
    register_default_constructor<IGESDraw , shared_ptr<IGESDraw>>(m,"IGESDraw");

    // nested enums

    static_cast<py::class_<IGESDraw , shared_ptr<IGESDraw>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Init_s",
                    (void (*)() ) static_cast<void (*)() >(&IGESDraw::Init),
                    R"#(Prepares dynamic data (Protocol, Modules) for this package)#" 
          )
        .def_static("Protocol_s",
                    (handle<IGESDraw_Protocol> (*)() ) static_cast<handle<IGESDraw_Protocol> (*)() >(&IGESDraw::Protocol),
                    R"#(Returns the Protocol for this Package)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_CircArraySubfigure from ./opencascade/IGESDraw_CircArraySubfigure.hxx
    klass = m.attr("IGESDraw_CircArraySubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_CircArraySubfigure ,opencascade::handle<IGESDraw_CircArraySubfigure>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_CircArraySubfigure::*)(  const handle<IGESData_IGESEntity> & ,   const int ,   const gp_XYZ & ,   const double ,   const double ,   const double ,   const int ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (IGESDraw_CircArraySubfigure::*)(  const handle<IGESData_IGESEntity> & ,   const int ,   const gp_XYZ & ,   const double ,   const double ,   const double ,   const int ,   const handle<NCollection_HArray1<int>> &  ) >(&IGESDraw_CircArraySubfigure::Init),
             R"#(This method is used to set the fields of the class CircArraySubfigure - aBase : Base entity - aNumLocs : Total number of possible instance locations - aCenter : Coordinates of Center of imaginary circle - aRadius : Radius of imaginary circle - aStAngle : Start angle in radians - aDelAngle : Delta angle in radians - aFlag : DO-DON'T flag to control which portion to display - allNumPos : All position to be or not to be processed)#"  , py::arg("aBase"),  py::arg("aNumLocs"),  py::arg("aCenter"),  py::arg("aRadius"),  py::arg("aStAngle"),  py::arg("aDelAngle"),  py::arg("aFlag"),  py::arg("allNumPos")
          )
        .def("BaseEntity",
             (handle<IGESData_IGESEntity> (IGESDraw_CircArraySubfigure::*)() const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::BaseEntity),
             R"#(returns the base entity, copies of which are produced)#" 
          )
        .def("NbLocations",
             (int (IGESDraw_CircArraySubfigure::*)() const) static_cast<int (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::NbLocations),
             R"#(returns total number of possible instance locations)#" 
          )
        .def("CenterPoint",
             (gp_Pnt (IGESDraw_CircArraySubfigure::*)() const) static_cast<gp_Pnt (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::CenterPoint),
             R"#(returns the center of the imaginary circle)#" 
          )
        .def("TransformedCenterPoint",
             (gp_Pnt (IGESDraw_CircArraySubfigure::*)() const) static_cast<gp_Pnt (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::TransformedCenterPoint),
             R"#(returns the Transformed center of the imaginary circle)#" 
          )
        .def("CircleRadius",
             (double (IGESDraw_CircArraySubfigure::*)() const) static_cast<double (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::CircleRadius),
             R"#(returns the radius of the imaginary circle)#" 
          )
        .def("StartAngle",
             (double (IGESDraw_CircArraySubfigure::*)() const) static_cast<double (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::StartAngle),
             R"#(returns the start angle in radians)#" 
          )
        .def("DeltaAngle",
             (double (IGESDraw_CircArraySubfigure::*)() const) static_cast<double (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::DeltaAngle),
             R"#(returns the delta angle in radians)#" 
          )
        .def("ListCount",
             (int (IGESDraw_CircArraySubfigure::*)() const) static_cast<int (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::ListCount),
             R"#(returns 0 if all elements to be displayed)#" 
          )
        .def("DisplayFlag",
             (bool (IGESDraw_CircArraySubfigure::*)() const) static_cast<bool (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::DisplayFlag),
             R"#(returns True if (ListCount = 0) all elements are to be displayed)#" 
          )
        .def("DoDontFlag",
             (bool (IGESDraw_CircArraySubfigure::*)() const) static_cast<bool (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::DoDontFlag),
             R"#(returns 0 if half or fewer of the elements of the array are defined returns 1 if half or more of the elements are defined)#" 
          )
        .def("PositionNum",
             (bool (IGESDraw_CircArraySubfigure::*)(  const int  ) const) static_cast<bool (IGESDraw_CircArraySubfigure::*)(  const int  ) const>(&IGESDraw_CircArraySubfigure::PositionNum),
             R"#(returns whether Index is to be processed (DO) or not to be processed(DON'T) if (ListCount = 0) return theDoDontFlag raises exception if Index <= 0 or Index > ListCount().)#"  , py::arg("Index")
          )
        .def("ListPosition",
             (int (IGESDraw_CircArraySubfigure::*)(  const int  ) const) static_cast<int (IGESDraw_CircArraySubfigure::*)(  const int  ) const>(&IGESDraw_CircArraySubfigure::ListPosition),
             R"#(returns the Index'th value position raises exception if Index <= 0 or Index > ListCount().)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_CircArraySubfigure::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_CircArraySubfigure::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_CircArraySubfigure::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_CircArraySubfigure::*)() const>(&IGESDraw_CircArraySubfigure::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_ConnectPoint from ./opencascade/IGESDraw_ConnectPoint.hxx
    klass = m.attr("IGESDraw_ConnectPoint");


    // nested enums

    static_cast<py::class_<IGESDraw_ConnectPoint ,opencascade::handle<IGESDraw_ConnectPoint>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_ConnectPoint::*)(  const gp_XYZ & ,   const handle<IGESData_IGESEntity> & ,   const int ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const int ,   const int ,   const int ,   const handle<IGESData_IGESEntity> &  ) ) static_cast<void (IGESDraw_ConnectPoint::*)(  const gp_XYZ & ,   const handle<IGESData_IGESEntity> & ,   const int ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const int ,   const int ,   const int ,   const handle<IGESData_IGESEntity> &  ) >(&IGESDraw_ConnectPoint::Init),
             R"#(This method is used to set the fields of the class ConnectPoint - aPoint : A Coordinate point - aDisplaySymbol : Display symbol Geometry - aTypeFlag : Type of the connection - aFunctionFlag : Function flag for the connection - aFunctionIdentifier : Connection Point Function Identifier - anIdentifierTemplate : Connection Point Function Template - aFunctionName : Connection Point Function Name - aFunctionTemplate : Connection Point Function Template - aPointIdentifier : Unique Connect Point Identifier - aFunctionCode : Connect Point Function Code - aSwapFlag : Connect Point Swap Flag - anOwnerSubfigure : Pointer to the "Owner" Entity)#"  , py::arg("aPoint"),  py::arg("aDisplaySymbol"),  py::arg("aTypeFlag"),  py::arg("aFunctionFlag"),  py::arg("aFunctionIdentifier"),  py::arg("anIdentifierTemplate"),  py::arg("aFunctionName"),  py::arg("aFunctionTemplate"),  py::arg("aPointIdentifier"),  py::arg("aFunctionCode"),  py::arg("aSwapFlag"),  py::arg("anOwnerSubfigure")
          )
        .def("Point",
             (gp_Pnt (IGESDraw_ConnectPoint::*)() const) static_cast<gp_Pnt (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::Point),
             R"#(returns the coordinate of the connection point)#" 
          )
        .def("TransformedPoint",
             (gp_Pnt (IGESDraw_ConnectPoint::*)() const) static_cast<gp_Pnt (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::TransformedPoint),
             R"#(returns the Transformed coordinate of the connection point)#" 
          )
        .def("HasDisplaySymbol",
             (bool (IGESDraw_ConnectPoint::*)() const) static_cast<bool (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::HasDisplaySymbol),
             R"#(returns True if Display symbol is specified else returns False)#" 
          )
        .def("DisplaySymbol",
             (handle<IGESData_IGESEntity> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::DisplaySymbol),
             R"#(if display symbol specified returns display symbol geometric entity else returns NULL Handle)#" 
          )
        .def("TypeFlag",
             (int (IGESDraw_ConnectPoint::*)() const) static_cast<int (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::TypeFlag),
             R"#(return value specifies a particular type of connection : Type Flag = 0 : Not Specified(default) 1 : Nonspecific logical point of connection 2 : Nonspecific physical point of connection 101 : Logical component pin 102 : Logical part connector 103 : Logical offpage connector 104 : Logical global signal connector 201 : Physical PWA surface mount pin 202 : Physical PWA blind pin 203 : Physical PWA thru-pin 5001-9999 : Implementor defined.)#" 
          )
        .def("FunctionFlag",
             (int (IGESDraw_ConnectPoint::*)() const) static_cast<int (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::FunctionFlag),
             R"#(returns Function Code that specifies a particular function for the ECO576 connection : e.g., Function Flag = 0 : Unspecified(default) = 1 : Electrical Signal = 2 : Fluid flow Signal)#" 
          )
        .def("FunctionIdentifier",
             (handle<TCollection_HAsciiString> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::FunctionIdentifier),
             R"#(return HAsciiString identifying Pin Number or Nozzle Label etc.)#" 
          )
        .def("HasIdentifierTemplate",
             (bool (IGESDraw_ConnectPoint::*)() const) static_cast<bool (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::HasIdentifierTemplate),
             R"#(returns True if Text Display Template is specified for Identifier else returns False)#" 
          )
        .def("IdentifierTemplate",
             (handle<IGESGraph_TextDisplayTemplate> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<IGESGraph_TextDisplayTemplate> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::IdentifierTemplate),
             R"#(if Text Display Template for the Function Identifier is defined, returns TestDisplayTemplate else returns NULL Handle)#" 
          )
        .def("FunctionName",
             (handle<TCollection_HAsciiString> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::FunctionName),
             R"#(returns Connection Point Function Name)#" 
          )
        .def("HasFunctionTemplate",
             (bool (IGESDraw_ConnectPoint::*)() const) static_cast<bool (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::HasFunctionTemplate),
             R"#(returns True if Text Display Template is specified for Function Name else returns False)#" 
          )
        .def("FunctionTemplate",
             (handle<IGESGraph_TextDisplayTemplate> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<IGESGraph_TextDisplayTemplate> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::FunctionTemplate),
             R"#(if Text Display Template for the Function Name is defined, returns TestDisplayTemplate else returns NULL Handle)#" 
          )
        .def("PointIdentifier",
             (int (IGESDraw_ConnectPoint::*)() const) static_cast<int (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::PointIdentifier),
             R"#(returns the Unique Connect Point Identifier)#" 
          )
        .def("FunctionCode",
             (int (IGESDraw_ConnectPoint::*)() const) static_cast<int (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::FunctionCode),
             R"#(returns the Connect Point Function Code)#" 
          )
        .def("SwapFlag",
             (bool (IGESDraw_ConnectPoint::*)() const) static_cast<bool (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::SwapFlag),
             R"#(return value = 0 : Connect point may be swapped(default) = 1 : Connect point may not be swapped)#" 
          )
        .def("HasOwnerSubfigure",
             (bool (IGESDraw_ConnectPoint::*)() const) static_cast<bool (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::HasOwnerSubfigure),
             R"#(returns True if Network Subfigure Instance/Definition Entity is specified else returns False)#" 
          )
        .def("OwnerSubfigure",
             (handle<IGESData_IGESEntity> (IGESDraw_ConnectPoint::*)() const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::OwnerSubfigure),
             R"#(returns "owner" Network Subfigure Instance Entity, or Network Subfigure Definition Entity, or NULL Handle.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_ConnectPoint::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_ConnectPoint::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_ConnectPoint::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_ConnectPoint::*)() const>(&IGESDraw_ConnectPoint::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_Drawing from ./opencascade/IGESDraw_Drawing.hxx
    klass = m.attr("IGESDraw_Drawing");


    // nested enums

    static_cast<py::class_<IGESDraw_Drawing ,opencascade::handle<IGESDraw_Drawing>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_Drawing::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XY>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_Drawing::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XY>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_Drawing::Init),
             R"#(This method is used to set the fields of the class Drawing - allViews : Pointers to DEs of View entities - allViewOrigins : Origin coordinates of transformed Views - allAnnotations : Pointers to DEs of Annotation entities raises exception if Lengths of allViews and allViewOrigins are not same.)#"  , py::arg("allViews"),  py::arg("allViewOrigins"),  py::arg("allAnnotations")
          )
        .def("NbViews",
             (int (IGESDraw_Drawing::*)() const) static_cast<int (IGESDraw_Drawing::*)() const>(&IGESDraw_Drawing::NbViews),
             R"#(returns the number of view pointers in <me>)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_Drawing::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_Drawing::*)(  const int  ) const>(&IGESDraw_Drawing::ViewItem),
             R"#(returns the ViewKindEntity indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbViews().)#"  , py::arg("ViewIndex")
          )
        .def("ViewOrigin",
             (gp_Pnt2d (IGESDraw_Drawing::*)(  const int  ) const) static_cast<gp_Pnt2d (IGESDraw_Drawing::*)(  const int  ) const>(&IGESDraw_Drawing::ViewOrigin),
             R"#(returns the Drawing space coordinates of the origin of the Transformed view indicated by TViewIndex raises an exception if TViewIndex <= 0 or TViewIndex > NbViews().)#"  , py::arg("TViewIndex")
          )
        .def("NbAnnotations",
             (int (IGESDraw_Drawing::*)() const) static_cast<int (IGESDraw_Drawing::*)() const>(&IGESDraw_Drawing::NbAnnotations),
             R"#(returns the number of Annotation entities in <me>)#" 
          )
        .def("Annotation",
             (handle<IGESData_IGESEntity> (IGESDraw_Drawing::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_Drawing::*)(  const int  ) const>(&IGESDraw_Drawing::Annotation),
             R"#(returns the Annotation entity in this Drawing, indicated by the AnnotationIndex raises an exception if AnnotationIndex <= 0 or AnnotationIndex > NbAnnotations().)#"  , py::arg("AnnotationIndex")
          )
        .def("ViewToDrawing",
             (gp_XY (IGESDraw_Drawing::*)(  const int ,   const gp_XYZ &  ) const) static_cast<gp_XY (IGESDraw_Drawing::*)(  const int ,   const gp_XYZ &  ) const>(&IGESDraw_Drawing::ViewToDrawing),
             R"#()#"  , py::arg("NumView"),  py::arg("ViewCoords")
          )
        .def("DrawingUnit",
             (bool (IGESDraw_Drawing::*)( double &  ) const) static_cast<bool (IGESDraw_Drawing::*)( double &  ) const>(&IGESDraw_Drawing::DrawingUnit),
             R"#(Returns the Drawing Unit Value if it is specified (by a specific property entity) If not specified, returns False, and val as zero : unit to consider is then the model unit in GlobalSection)#"  , py::arg("value")
          )
        .def("DrawingSize",
             (bool (IGESDraw_Drawing::*)( double & ,  double &  ) const) static_cast<bool (IGESDraw_Drawing::*)( double & ,  double &  ) const>(&IGESDraw_Drawing::DrawingSize),
             R"#(Returns the Drawing Size if it is specified (by a specific property entity) If not specified, returns False, and X,Y as zero : unit to consider is then the model unit in GlobalSection)#"  , py::arg("X"),  py::arg("Y")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_Drawing::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_Drawing::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_Drawing::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_Drawing::*)() const>(&IGESDraw_Drawing::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_DrawingWithRotation from ./opencascade/IGESDraw_DrawingWithRotation.hxx
    klass = m.attr("IGESDraw_DrawingWithRotation");


    // nested enums

    static_cast<py::class_<IGESDraw_DrawingWithRotation ,opencascade::handle<IGESDraw_DrawingWithRotation>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_DrawingWithRotation::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XY>> & ,   const handle<NCollection_HArray1<double>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_DrawingWithRotation::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XY>> & ,   const handle<NCollection_HArray1<double>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_DrawingWithRotation::Init),
             R"#(This method is used to set the fields of the class DrawingWithRotation - allViews : Pointers to View entities - allViewOrigins : Origin coords of transformed views - allOrientationAngles : Orientation angles of transformed views - allAnnotations : Pointers to Annotation entities raises exception if Lengths of allViews, allViewOrigins and allOrientationAngles are not same.)#"  , py::arg("allViews"),  py::arg("allViewOrigins"),  py::arg("allOrientationAngles"),  py::arg("allAnnotations")
          )
        .def("NbViews",
             (int (IGESDraw_DrawingWithRotation::*)() const) static_cast<int (IGESDraw_DrawingWithRotation::*)() const>(&IGESDraw_DrawingWithRotation::NbViews),
             R"#(returns the number of view pointers in <me>)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_DrawingWithRotation::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_DrawingWithRotation::*)(  const int  ) const>(&IGESDraw_DrawingWithRotation::ViewItem),
             R"#(returns the View entity indicated by Index raises an exception if Index <= 0 or Index > NbViews().)#"  , py::arg("Index")
          )
        .def("ViewOrigin",
             (gp_Pnt2d (IGESDraw_DrawingWithRotation::*)(  const int  ) const) static_cast<gp_Pnt2d (IGESDraw_DrawingWithRotation::*)(  const int  ) const>(&IGESDraw_DrawingWithRotation::ViewOrigin),
             R"#(returns the Drawing space coordinates of the origin of the Transformed view indicated by Index raises an exception if Index <= 0 or Index > NbViews().)#"  , py::arg("Index")
          )
        .def("OrientationAngle",
             (double (IGESDraw_DrawingWithRotation::*)(  const int  ) const) static_cast<double (IGESDraw_DrawingWithRotation::*)(  const int  ) const>(&IGESDraw_DrawingWithRotation::OrientationAngle),
             R"#(returns the Orientation angle for the Transformed view indicated by Index raises an exception if Index <= 0 or Index > NbViews().)#"  , py::arg("Index")
          )
        .def("NbAnnotations",
             (int (IGESDraw_DrawingWithRotation::*)() const) static_cast<int (IGESDraw_DrawingWithRotation::*)() const>(&IGESDraw_DrawingWithRotation::NbAnnotations),
             R"#(returns the number of Annotation entities in <me>)#" 
          )
        .def("Annotation",
             (handle<IGESData_IGESEntity> (IGESDraw_DrawingWithRotation::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_DrawingWithRotation::*)(  const int  ) const>(&IGESDraw_DrawingWithRotation::Annotation),
             R"#(returns the Annotation entity in this Drawing, indicated by Index raises an exception if Index <= 0 or Index > NbAnnotations().)#"  , py::arg("Index")
          )
        .def("ViewToDrawing",
             (gp_XY (IGESDraw_DrawingWithRotation::*)(  const int ,   const gp_XYZ &  ) const) static_cast<gp_XY (IGESDraw_DrawingWithRotation::*)(  const int ,   const gp_XYZ &  ) const>(&IGESDraw_DrawingWithRotation::ViewToDrawing),
             R"#()#"  , py::arg("NumView"),  py::arg("ViewCoords")
          )
        .def("DrawingUnit",
             (bool (IGESDraw_DrawingWithRotation::*)( double &  ) const) static_cast<bool (IGESDraw_DrawingWithRotation::*)( double &  ) const>(&IGESDraw_DrawingWithRotation::DrawingUnit),
             R"#(Returns the Drawing Unit Value if it is specified (by a specific property entity) If not specified, returns False, and val as zero : unit to consider is then the model unit in GlobalSection)#"  , py::arg("value")
          )
        .def("DrawingSize",
             (bool (IGESDraw_DrawingWithRotation::*)( double & ,  double &  ) const) static_cast<bool (IGESDraw_DrawingWithRotation::*)( double & ,  double &  ) const>(&IGESDraw_DrawingWithRotation::DrawingSize),
             R"#(Returns the Drawing Size if it is specified (by a specific property entity) If not specified, returns False, and X,Y as zero : unit to consider is then the model unit in GlobalSection)#"  , py::arg("X"),  py::arg("Y")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_DrawingWithRotation::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_DrawingWithRotation::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_DrawingWithRotation::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_DrawingWithRotation::*)() const>(&IGESDraw_DrawingWithRotation::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_GeneralModule from ./opencascade/IGESDraw_GeneralModule.hxx
    klass = m.attr("IGESDraw_GeneralModule");


    // nested enums

    static_cast<py::class_<IGESDraw_GeneralModule ,opencascade::handle<IGESDraw_GeneralModule>  , IGESData_GeneralModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("OwnSharedCase",
             (void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_GeneralModule::OwnSharedCase),
             R"#(Lists the Entities shared by a given IGESEntity <ent>, from its specific parameters : specific for each type)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("iter")
          )
        .def("OwnImpliedCase",
             (void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_GeneralModule::OwnImpliedCase),
             R"#(Specific list of Entities implied by an IGESEntity <ent> (in addition to Associativities). Redefined for ViewsVisible ...)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const>(&IGESDraw_GeneralModule::DirChecker),
             R"#(Returns a DirChecker, specific for each type of Entity (identified by its Case Number) : this DirChecker defines constraints which must be respected by the DirectoryPart)#"  , py::arg("CN"),  py::arg("ent")
          )
        .def("NewVoid",
             (bool (IGESDraw_GeneralModule::*)(  const int ,  handle<Standard_Transient> &  ) const) static_cast<bool (IGESDraw_GeneralModule::*)(  const int ,  handle<Standard_Transient> &  ) const>(&IGESDraw_GeneralModule::NewVoid),
             R"#(Specific creation of a new void entity)#"  , py::arg("CN"),  py::arg("entto")
          )
        .def("OwnCopyCase",
             (void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,  Interface_CopyTool &  ) const>(&IGESDraw_GeneralModule::OwnCopyCase),
             R"#(Copies parameters which are specific of each Type of Entity)#"  , py::arg("CN"),  py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnRenewCase",
             (void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,   const Interface_CopyTool &  ) const) static_cast<void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESEntity> & ,   const Interface_CopyTool &  ) const>(&IGESDraw_GeneralModule::OwnRenewCase),
             R"#(Renews parameters which are specific of each Type of Entity : redefined for ViewsVisible ... (takes only the implied ref.s which have also been copied))#"  , py::arg("CN"),  py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDeleteCase",
             (void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const) static_cast<void (IGESDraw_GeneralModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const>(&IGESDraw_GeneralModule::OwnDeleteCase),
             R"#(Clears parameters with can cause looping structures : redefined for ViewsVisible ... (clears the implied ref.s))#"  , py::arg("CN"),  py::arg("ent")
          )
        .def("CategoryNumber",
             (int (IGESDraw_GeneralModule::*)(  const int ,   const handle<Standard_Transient> & ,   const Interface_ShareTool &  ) const) static_cast<int (IGESDraw_GeneralModule::*)(  const int ,   const handle<Standard_Transient> & ,   const Interface_ShareTool &  ) const>(&IGESDraw_GeneralModule::CategoryNumber),
             R"#(Returns a category number which characterizes an entity Planar : Auxiliary Subfigures and ConnectPoint : Structure others : Drawing)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("shares")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheckCase",
             []( IGESDraw_GeneralModule &self ,  const int CN, const handle<IGESData_IGESEntity> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheckCase(CN,ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check for each type of Entity)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_GeneralModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_GeneralModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_GeneralModule::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_GeneralModule::*)() const>(&IGESDraw_GeneralModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_LabelDisplay from ./opencascade/IGESDraw_LabelDisplay.hxx
    klass = m.attr("IGESDraw_LabelDisplay");


    // nested enums

    static_cast<py::class_<IGESDraw_LabelDisplay ,opencascade::handle<IGESDraw_LabelDisplay>  , IGESData_LabelDisplayEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_LabelDisplay::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XYZ>> & ,   const handle<NCollection_HArray1<handle<IGESDimen_LeaderArrow>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_LabelDisplay::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<gp_XYZ>> & ,   const handle<NCollection_HArray1<handle<IGESDimen_LeaderArrow>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_LabelDisplay::Init),
             R"#(This method is used to set the fields of the class LabelDisplay - allViews : Pointers to View Entities - allTextLocations : Coordinates of text locations in the views - allLeaderEntities : Pointers to Leader Entities in the views - allLabelLevels : Entity label level numbers in the views - allDisplayedEntities : Pointers to the entities being displayed raises exception if Lengths of allViews, allTextLocations, allLeaderEntities, allLabelLevels and allDisplayedEntities are not same.)#"  , py::arg("allViews"),  py::arg("allTextLocations"),  py::arg("allLeaderEntities"),  py::arg("allLabelLevels"),  py::arg("allDisplayedEntities")
          )
        .def("NbLabels",
             (int (IGESDraw_LabelDisplay::*)() const) static_cast<int (IGESDraw_LabelDisplay::*)() const>(&IGESDraw_LabelDisplay::NbLabels),
             R"#(returns the number of label placements in <me>)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::ViewItem),
             R"#(returns the View entity indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbLabels().)#"  , py::arg("ViewIndex")
          )
        .def("TextLocation",
             (gp_Pnt (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<gp_Pnt (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::TextLocation),
             R"#(returns the 3d-Point coordinates of the text location, in the view indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbLabels().)#"  , py::arg("ViewIndex")
          )
        .def("LeaderEntity",
             (handle<IGESDimen_LeaderArrow> (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<handle<IGESDimen_LeaderArrow> (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::LeaderEntity),
             R"#(returns the Leader entity in the view indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbLabels().)#"  , py::arg("ViewIndex")
          )
        .def("LabelLevel",
             (int (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<int (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::LabelLevel),
             R"#(returns the Entity label level number in the view indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbLabels().)#"  , py::arg("ViewIndex")
          )
        .def("DisplayedEntity",
             (handle<IGESData_IGESEntity> (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::DisplayedEntity),
             R"#(returns the entity indicated by EntityIndex raises an exception if EntityIndex <= 0 or EntityIndex > NbLabels().)#"  , py::arg("EntityIndex")
          )
        .def("TransformedTextLocation",
             (gp_Pnt (IGESDraw_LabelDisplay::*)(  const int  ) const) static_cast<gp_Pnt (IGESDraw_LabelDisplay::*)(  const int  ) const>(&IGESDraw_LabelDisplay::TransformedTextLocation),
             R"#(returns the transformed 3d-Point coordinates of the text location, in the view indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbLabels().)#"  , py::arg("ViewIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_LabelDisplay::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_LabelDisplay::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_LabelDisplay::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_LabelDisplay::*)() const>(&IGESDraw_LabelDisplay::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_NetworkSubfigure from ./opencascade/IGESDraw_NetworkSubfigure.hxx
    klass = m.attr("IGESDraw_NetworkSubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_NetworkSubfigure ,opencascade::handle<IGESDraw_NetworkSubfigure>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_NetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const gp_XYZ & ,   const gp_XYZ & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<NCollection_HArray1<handle<IGESDraw_ConnectPoint>>> &  ) ) static_cast<void (IGESDraw_NetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const gp_XYZ & ,   const gp_XYZ & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<NCollection_HArray1<handle<IGESDraw_ConnectPoint>>> &  ) >(&IGESDraw_NetworkSubfigure::Init),
             R"#(This method is used to set the fields of the class NetworkSubfigure - aDefinition : Network Subfigure Definition Entity - aTranslation : Translation data relative to the model space or the definition space - aScaleFactor : Scale factors in the definition space - aTypeFlag : Type flag - aDesignator : Primary reference designator - aTemplate : Primary reference designator Text display Template Entity - allConnectPoints : Associated Connect Point Entities)#"  , py::arg("aDefinition"),  py::arg("aTranslation"),  py::arg("aScaleFactor"),  py::arg("aTypeFlag"),  py::arg("aDesignator"),  py::arg("aTemplate"),  py::arg("allConnectPoints")
          )
        .def("SubfigureDefinition",
             (handle<IGESDraw_NetworkSubfigureDef> (IGESDraw_NetworkSubfigure::*)() const) static_cast<handle<IGESDraw_NetworkSubfigureDef> (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::SubfigureDefinition),
             R"#(returns Network Subfigure Definition Entity specified by this entity)#" 
          )
        .def("Translation",
             (gp_XYZ (IGESDraw_NetworkSubfigure::*)() const) static_cast<gp_XYZ (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::Translation),
             R"#(returns Translation Data relative to either model space or to the definition space of a referring entity)#" 
          )
        .def("TransformedTranslation",
             (gp_XYZ (IGESDraw_NetworkSubfigure::*)() const) static_cast<gp_XYZ (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::TransformedTranslation),
             R"#(returns the Transformed Translation Data relative to either model space or to the definition space of a referring entity)#" 
          )
        .def("ScaleFactors",
             (gp_XYZ (IGESDraw_NetworkSubfigure::*)() const) static_cast<gp_XYZ (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::ScaleFactors),
             R"#(returns Scale factor in definition space(x, y, z axes))#" 
          )
        .def("TypeFlag",
             (int (IGESDraw_NetworkSubfigure::*)() const) static_cast<int (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::TypeFlag),
             R"#(returns Type Flag which implements the distinction between Logical design and Physical design data,and is required if both are present. Type Flag = 0 : Not specified (default) = 1 : Logical = 2 : Physical)#" 
          )
        .def("ReferenceDesignator",
             (handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigure::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::ReferenceDesignator),
             R"#(returns the primary reference designator)#" 
          )
        .def("HasDesignatorTemplate",
             (bool (IGESDraw_NetworkSubfigure::*)() const) static_cast<bool (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::HasDesignatorTemplate),
             R"#(returns True if Text Display Template Entity is specified, else False)#" 
          )
        .def("DesignatorTemplate",
             (handle<IGESGraph_TextDisplayTemplate> (IGESDraw_NetworkSubfigure::*)() const) static_cast<handle<IGESGraph_TextDisplayTemplate> (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::DesignatorTemplate),
             R"#(returns primary reference designator Text Display Template Entity, or null. If null, no Text Display Template Entity specified)#" 
          )
        .def("NbConnectPoints",
             (int (IGESDraw_NetworkSubfigure::*)() const) static_cast<int (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::NbConnectPoints),
             R"#(returns the number of associated Connect Point Entities)#" 
          )
        .def("ConnectPoint",
             (handle<IGESDraw_ConnectPoint> (IGESDraw_NetworkSubfigure::*)(  const int  ) const) static_cast<handle<IGESDraw_ConnectPoint> (IGESDraw_NetworkSubfigure::*)(  const int  ) const>(&IGESDraw_NetworkSubfigure::ConnectPoint),
             R"#(returns the Index'th associated Connect point Entity raises exception if Index <= 0 or Index > NbConnectPoints())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_NetworkSubfigure::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_NetworkSubfigure::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_NetworkSubfigure::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_NetworkSubfigure::*)() const>(&IGESDraw_NetworkSubfigure::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_NetworkSubfigureDef from ./opencascade/IGESDraw_NetworkSubfigureDef.hxx
    klass = m.attr("IGESDraw_NetworkSubfigureDef");


    // nested enums

    static_cast<py::class_<IGESDraw_NetworkSubfigureDef ,opencascade::handle<IGESDraw_NetworkSubfigureDef>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_NetworkSubfigureDef::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<NCollection_HArray1<handle<IGESDraw_ConnectPoint>>> &  ) ) static_cast<void (IGESDraw_NetworkSubfigureDef::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const handle<IGESGraph_TextDisplayTemplate> & ,   const handle<NCollection_HArray1<handle<IGESDraw_ConnectPoint>>> &  ) >(&IGESDraw_NetworkSubfigureDef::Init),
             R"#(This method is used to set fields of the class NetworkSubfigureDef - aDepth : Depth of Subfigure (indicating the amount of nesting) - aName : Subfigure Name - allEntities : Associated subfigures Entities exclusive of primary reference designator and Control Points. - aTypeFlag : Type flag determines which Entity belongs in which design (Logical design or Physical design) - aDesignator : Designator HAsciiString and its Template - allPointEntities : Associated Connect Point Entities)#"  , py::arg("aDepth"),  py::arg("aName"),  py::arg("allEntities"),  py::arg("aTypeFlag"),  py::arg("aDesignator"),  py::arg("aTemplate"),  py::arg("allPointEntities")
          )
        .def("Depth",
             (int (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<int (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::Depth),
             R"#(returns Depth of Subfigure(indication the amount of nesting) Note : The Depth is inclusive of both Network Subfigure Definition Entity and the Ordinary Subfigure Definition Entity. Thus, the two may be nested.)#" 
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::Name),
             R"#(returns the Subfigure Name)#" 
          )
        .def("NbEntities",
             (int (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<int (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::NbEntities),
             R"#(returns Number of Associated(child) entries in subfigure exclusive of primary reference designator and Control Points)#" 
          )
        .def("Entity",
             (handle<IGESData_IGESEntity> (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const>(&IGESDraw_NetworkSubfigureDef::Entity),
             R"#(returns the Index'th IGESEntity in subfigure exclusive of primary reference designator and Control Points raises exception if Index <=0 or Index > NbEntities())#"  , py::arg("Index")
          )
        .def("TypeFlag",
             (int (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<int (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::TypeFlag),
             R"#(return value = 0 : Not Specified = 1 : Logical design = 2 : Physical design)#" 
          )
        .def("Designator",
             (handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<handle<TCollection_HAsciiString> (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::Designator),
             R"#(returns Primary Reference Designator)#" 
          )
        .def("HasDesignatorTemplate",
             (bool (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<bool (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::HasDesignatorTemplate),
             R"#(returns True if Text Display Template is specified for primary designator else returns False)#" 
          )
        .def("DesignatorTemplate",
             (handle<IGESGraph_TextDisplayTemplate> (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<handle<IGESGraph_TextDisplayTemplate> (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::DesignatorTemplate),
             R"#(if Text Display Template specified then return TextDisplayTemplate else return NULL Handle)#" 
          )
        .def("NbPointEntities",
             (int (IGESDraw_NetworkSubfigureDef::*)() const) static_cast<int (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::NbPointEntities),
             R"#(returns the Number Of Associated(child) Connect Point Entities)#" 
          )
        .def("HasPointEntity",
             (bool (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const) static_cast<bool (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const>(&IGESDraw_NetworkSubfigureDef::HasPointEntity),
             R"#(returns True is Index'th Associated Connect Point Entity is present else returns False raises exception if Index is out of bound)#"  , py::arg("Index")
          )
        .def("PointEntity",
             (handle<IGESDraw_ConnectPoint> (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const) static_cast<handle<IGESDraw_ConnectPoint> (IGESDraw_NetworkSubfigureDef::*)(  const int  ) const>(&IGESDraw_NetworkSubfigureDef::PointEntity),
             R"#(returns the Index'th Associated Connect Point Entity raises exception if Index <= 0 or Index > NbPointEntities())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_NetworkSubfigureDef::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_NetworkSubfigureDef::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_NetworkSubfigureDef::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_NetworkSubfigureDef::*)() const>(&IGESDraw_NetworkSubfigureDef::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_PerspectiveView from ./opencascade/IGESDraw_PerspectiveView.hxx
    klass = m.attr("IGESDraw_PerspectiveView");


    // nested enums

    static_cast<py::class_<IGESDraw_PerspectiveView ,opencascade::handle<IGESDraw_PerspectiveView>  , IGESData_ViewKindEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_PerspectiveView::*)(  const int ,   const double ,   const gp_XYZ & ,   const gp_XYZ & ,   const gp_XYZ & ,   const gp_XYZ & ,   const double ,   const gp_XY & ,   const gp_XY & ,   const int ,   const double ,   const double  ) ) static_cast<void (IGESDraw_PerspectiveView::*)(  const int ,   const double ,   const gp_XYZ & ,   const gp_XYZ & ,   const gp_XYZ & ,   const gp_XYZ & ,   const double ,   const gp_XY & ,   const gp_XY & ,   const int ,   const double ,   const double  ) >(&IGESDraw_PerspectiveView::Init),
             R"#(This method is used to set the fields of the class PerspectiveView - aViewNumber : The desired view - aScaleFactor : Scale factor - aViewNormalVector : View plane normal vector (model space) - aViewReferencePoint : View reference point (model space) - aCenterOfProjection : Center Of Projection (model space) - aViewUpVector : View up vector (model space) - aViewPlaneDistance : View plane distance (model space) - aTopLeft : Top-left point of clipping window - aBottomRight : Bottom-right point of clipping window - aDepthClip : Depth clipping indicator - aBackPlaneDistance : Distance of back clipping plane - aFrontPlaneDistance : Distance of front clipping plane)#"  , py::arg("aViewNumber"),  py::arg("aScaleFactor"),  py::arg("aViewNormalVector"),  py::arg("aViewReferencePoint"),  py::arg("aCenterOfProjection"),  py::arg("aViewUpVector"),  py::arg("aViewPlaneDistance"),  py::arg("aTopLeft"),  py::arg("aBottomRight"),  py::arg("aDepthClip"),  py::arg("aBackPlaneDistance"),  py::arg("aFrontPlaneDistance")
          )
        .def("IsSingle",
             (bool (IGESDraw_PerspectiveView::*)() const) static_cast<bool (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::IsSingle),
             R"#(Returns True (for a single view))#" 
          )
        .def("NbViews",
             (int (IGESDraw_PerspectiveView::*)() const) static_cast<int (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::NbViews),
             R"#(Returns 1 (single view))#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_PerspectiveView::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_PerspectiveView::*)(  const int  ) const>(&IGESDraw_PerspectiveView::ViewItem),
             R"#(For a single view, returns <me> whatever <num>)#"  , py::arg("num")
          )
        .def("ViewNumber",
             (int (IGESDraw_PerspectiveView::*)() const) static_cast<int (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewNumber),
             R"#(returns the view number associated with <me>)#" 
          )
        .def("ScaleFactor",
             (double (IGESDraw_PerspectiveView::*)() const) static_cast<double (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ScaleFactor),
             R"#(returns the scale factor associated with <me>)#" 
          )
        .def("ViewNormalVector",
             (gp_Vec (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Vec (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewNormalVector),
             R"#(returns the View plane normal vector (model space))#" 
          )
        .def("ViewReferencePoint",
             (gp_Pnt (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Pnt (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewReferencePoint),
             R"#(returns the View reference point (model space))#" 
          )
        .def("CenterOfProjection",
             (gp_Pnt (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Pnt (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::CenterOfProjection),
             R"#(returns the Center Of Projection (model space))#" 
          )
        .def("ViewUpVector",
             (gp_Vec (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Vec (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewUpVector),
             R"#(returns the View up vector (model space))#" 
          )
        .def("ViewPlaneDistance",
             (double (IGESDraw_PerspectiveView::*)() const) static_cast<double (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewPlaneDistance),
             R"#(returns the View plane distance (model space))#" 
          )
        .def("TopLeft",
             (gp_Pnt2d (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Pnt2d (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::TopLeft),
             R"#(returns the top left point of the clipping window)#" 
          )
        .def("BottomRight",
             (gp_Pnt2d (IGESDraw_PerspectiveView::*)() const) static_cast<gp_Pnt2d (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::BottomRight),
             R"#(returns the bottom right point of the clipping window)#" 
          )
        .def("DepthClip",
             (int (IGESDraw_PerspectiveView::*)() const) static_cast<int (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::DepthClip),
             R"#(returns the Depth clipping indicator 0 = No depth clipping 1 = Back clipping plane ON 2 = Front clipping plane ON 3 = Back and front clipping planes ON)#" 
          )
        .def("BackPlaneDistance",
             (double (IGESDraw_PerspectiveView::*)() const) static_cast<double (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::BackPlaneDistance),
             R"#(returns the View coordinate denoting the location of the back clipping plane)#" 
          )
        .def("FrontPlaneDistance",
             (double (IGESDraw_PerspectiveView::*)() const) static_cast<double (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::FrontPlaneDistance),
             R"#(returns the View coordinate denoting the location of the front clipping plane)#" 
          )
        .def("ViewMatrix",
             (handle<IGESData_TransfEntity> (IGESDraw_PerspectiveView::*)() const) static_cast<handle<IGESData_TransfEntity> (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::ViewMatrix),
             R"#(returns the Transformation Matrix)#" 
          )
        .def("ModelToView",
             (gp_XYZ (IGESDraw_PerspectiveView::*)(  const gp_XYZ &  ) const) static_cast<gp_XYZ (IGESDraw_PerspectiveView::*)(  const gp_XYZ &  ) const>(&IGESDraw_PerspectiveView::ModelToView),
             R"#(returns XYX from the Model space to the View space by applying the View Matrix)#"  , py::arg("coords")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_PerspectiveView::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_PerspectiveView::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_PerspectiveView::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_PerspectiveView::*)() const>(&IGESDraw_PerspectiveView::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_Planar from ./opencascade/IGESDraw_Planar.hxx
    klass = m.attr("IGESDraw_Planar");


    // nested enums

    static_cast<py::class_<IGESDraw_Planar ,opencascade::handle<IGESDraw_Planar>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_Planar::*)(  const int ,   const handle<IGESGeom_TransformationMatrix> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_Planar::*)(  const int ,   const handle<IGESGeom_TransformationMatrix> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_Planar::Init),
             R"#(This method is used to set the fields of the class Planar - nbMats : Number of Transformation matrices - aTransformationMatrix : Pointer to the Transformation matrix - allEntities : Pointers to the entities specified)#"  , py::arg("nbMats"),  py::arg("aTransformationMatrix"),  py::arg("allEntities")
          )
        .def("NbMatrices",
             (int (IGESDraw_Planar::*)() const) static_cast<int (IGESDraw_Planar::*)() const>(&IGESDraw_Planar::NbMatrices),
             R"#(returns the number of Transformation matrices in <me>)#" 
          )
        .def("NbEntities",
             (int (IGESDraw_Planar::*)() const) static_cast<int (IGESDraw_Planar::*)() const>(&IGESDraw_Planar::NbEntities),
             R"#(returns the number of Entities in the plane pointed to by this associativity)#" 
          )
        .def("IsIdentityMatrix",
             (bool (IGESDraw_Planar::*)() const) static_cast<bool (IGESDraw_Planar::*)() const>(&IGESDraw_Planar::IsIdentityMatrix),
             R"#(returns True if TransformationMatrix is Identity Matrix, i.e:- No Matrix defined.)#" 
          )
        .def("TransformMatrix",
             (handle<IGESGeom_TransformationMatrix> (IGESDraw_Planar::*)() const) static_cast<handle<IGESGeom_TransformationMatrix> (IGESDraw_Planar::*)() const>(&IGESDraw_Planar::TransformMatrix),
             R"#(returns the Transformation matrix moving data from the XY plane into space or zero)#" 
          )
        .def("Entity",
             (handle<IGESData_IGESEntity> (IGESDraw_Planar::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_Planar::*)(  const int  ) const>(&IGESDraw_Planar::Entity),
             R"#(returns the Entity on the specified plane, indicated by EntityIndex raises an exception if EntityIndex <= 0 or EntityIndex > NbEntities())#"  , py::arg("EntityIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_Planar::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_Planar::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_Planar::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_Planar::*)() const>(&IGESDraw_Planar::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_Protocol from ./opencascade/IGESDraw_Protocol.hxx
    klass = m.attr("IGESDraw_Protocol");


    // nested enums

    static_cast<py::class_<IGESDraw_Protocol ,opencascade::handle<IGESDraw_Protocol>  , IGESData_Protocol >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("NbResources",
             (int (IGESDraw_Protocol::*)() const) static_cast<int (IGESDraw_Protocol::*)() const>(&IGESDraw_Protocol::NbResources),
             R"#(Gives the count of Resource Protocol. Here, one (Protocol from IGESDimen))#" 
          )
        .def("Resource",
             (handle<Interface_Protocol> (IGESDraw_Protocol::*)(  const int  ) const) static_cast<handle<Interface_Protocol> (IGESDraw_Protocol::*)(  const int  ) const>(&IGESDraw_Protocol::Resource),
             R"#(Returns a Resource, given a rank.)#"  , py::arg("num")
          )
        .def("TypeNumber",
             (int (IGESDraw_Protocol::*)(  const handle<Standard_Type> &  ) const) static_cast<int (IGESDraw_Protocol::*)(  const handle<Standard_Type> &  ) const>(&IGESDraw_Protocol::TypeNumber),
             R"#(Returns a Case Number, specific of each recognized Type This Case Number is then used in Libraries : the various Modules attached to this class of Protocol must use them in accordance (for a given value of TypeNumber, they must consider the same Type as the Protocol defines))#"  , py::arg("atype")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_Protocol::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_Protocol::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_Protocol::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_Protocol::*)() const>(&IGESDraw_Protocol::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_ReadWriteModule from ./opencascade/IGESDraw_ReadWriteModule.hxx
    klass = m.attr("IGESDraw_ReadWriteModule");


    // nested enums

    static_cast<py::class_<IGESDraw_ReadWriteModule ,opencascade::handle<IGESDraw_ReadWriteModule>  , IGESData_ReadWriteModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("CaseIGES",
             (int (IGESDraw_ReadWriteModule::*)(  const int ,   const int  ) const) static_cast<int (IGESDraw_ReadWriteModule::*)(  const int ,   const int  ) const>(&IGESDraw_ReadWriteModule::CaseIGES),
             R"#(Defines Case Numbers for Entities of IGESDraw)#"  , py::arg("typenum"),  py::arg("formnum")
          )
        .def("ReadOwnParams",
             (void (IGESDraw_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ReadWriteModule::ReadOwnParams),
             R"#(Reads own parameters from file for an Entity of IGESDraw)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ReadWriteModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ReadWriteModule::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("IW")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_ReadWriteModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_ReadWriteModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_ReadWriteModule::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_ReadWriteModule::*)() const>(&IGESDraw_ReadWriteModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_RectArraySubfigure from ./opencascade/IGESDraw_RectArraySubfigure.hxx
    klass = m.attr("IGESDraw_RectArraySubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_RectArraySubfigure ,opencascade::handle<IGESDraw_RectArraySubfigure>  , IGESData_IGESEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_RectArraySubfigure::*)(  const handle<IGESData_IGESEntity> & ,   const double ,   const gp_XYZ & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const int ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (IGESDraw_RectArraySubfigure::*)(  const handle<IGESData_IGESEntity> & ,   const double ,   const gp_XYZ & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const int ,   const handle<NCollection_HArray1<int>> &  ) >(&IGESDraw_RectArraySubfigure::Init),
             R"#(This method is used to set the fields of the class RectArraySubfigure - aBase : a base entity which is replicated - aScale : Scale Factor - aCorner : lower left hand corner for the entire array - nbCols : Number of columns of the array - nbRows : Number of rows of the array - hDisp : Column separations - vtDisp : Row separation - rotationAngle : Rotation angle specified in radians - allDont : DO-DON'T flag to control which portion to display - allNumPos : List of positions to be or not to be displayed)#"  , py::arg("aBase"),  py::arg("aScale"),  py::arg("aCorner"),  py::arg("nbCols"),  py::arg("nbRows"),  py::arg("hDisp"),  py::arg("vtDisp"),  py::arg("rotationAngle"),  py::arg("doDont"),  py::arg("allNumPos")
          )
        .def("BaseEntity",
             (handle<IGESData_IGESEntity> (IGESDraw_RectArraySubfigure::*)() const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::BaseEntity),
             R"#(returns the base entity, copies of which are produced)#" 
          )
        .def("ScaleFactor",
             (double (IGESDraw_RectArraySubfigure::*)() const) static_cast<double (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::ScaleFactor),
             R"#(returns the scale factor)#" 
          )
        .def("LowerLeftCorner",
             (gp_Pnt (IGESDraw_RectArraySubfigure::*)() const) static_cast<gp_Pnt (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::LowerLeftCorner),
             R"#(returns coordinates of lower left hand corner for the entire array)#" 
          )
        .def("TransformedLowerLeftCorner",
             (gp_Pnt (IGESDraw_RectArraySubfigure::*)() const) static_cast<gp_Pnt (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::TransformedLowerLeftCorner),
             R"#(returns Transformed coordinates of lower left corner for the array)#" 
          )
        .def("NbColumns",
             (int (IGESDraw_RectArraySubfigure::*)() const) static_cast<int (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::NbColumns),
             R"#(returns number of columns in the array)#" 
          )
        .def("NbRows",
             (int (IGESDraw_RectArraySubfigure::*)() const) static_cast<int (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::NbRows),
             R"#(returns number of rows in the array)#" 
          )
        .def("ColumnSeparation",
             (double (IGESDraw_RectArraySubfigure::*)() const) static_cast<double (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::ColumnSeparation),
             R"#(returns horizontal distance between columns)#" 
          )
        .def("RowSeparation",
             (double (IGESDraw_RectArraySubfigure::*)() const) static_cast<double (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::RowSeparation),
             R"#(returns vertical distance between rows)#" 
          )
        .def("RotationAngle",
             (double (IGESDraw_RectArraySubfigure::*)() const) static_cast<double (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::RotationAngle),
             R"#(returns rotation angle in radians)#" 
          )
        .def("DisplayFlag",
             (bool (IGESDraw_RectArraySubfigure::*)() const) static_cast<bool (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::DisplayFlag),
             R"#(returns True if (ListCount = 0) i.e., all elements to be displayed)#" 
          )
        .def("ListCount",
             (int (IGESDraw_RectArraySubfigure::*)() const) static_cast<int (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::ListCount),
             R"#(returns 0 if all replicated entities to be displayed)#" 
          )
        .def("DoDontFlag",
             (bool (IGESDraw_RectArraySubfigure::*)() const) static_cast<bool (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::DoDontFlag),
             R"#(returns 0 if half or fewer of the elements of the array are defined 1 if half or more of the elements are defined)#" 
          )
        .def("PositionNum",
             (bool (IGESDraw_RectArraySubfigure::*)(  const int  ) const) static_cast<bool (IGESDraw_RectArraySubfigure::*)(  const int  ) const>(&IGESDraw_RectArraySubfigure::PositionNum),
             R"#(returns whether Index is to be processed (DO) or not to be processed(DON'T) if (ListCount = 0) return theDoDontFlag)#"  , py::arg("Index")
          )
        .def("ListPosition",
             (int (IGESDraw_RectArraySubfigure::*)(  const int  ) const) static_cast<int (IGESDraw_RectArraySubfigure::*)(  const int  ) const>(&IGESDraw_RectArraySubfigure::ListPosition),
             R"#(returns the Index'th value position raises exception if Index <= 0 or Index > ListCount())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_RectArraySubfigure::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_RectArraySubfigure::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_RectArraySubfigure::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_RectArraySubfigure::*)() const>(&IGESDraw_RectArraySubfigure::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_SegmentedViewsVisible from ./opencascade/IGESDraw_SegmentedViewsVisible.hxx
    klass = m.attr("IGESDraw_SegmentedViewsVisible");


    // nested enums

    static_cast<py::class_<IGESDraw_SegmentedViewsVisible ,opencascade::handle<IGESDraw_SegmentedViewsVisible>  , IGESData_ViewKindEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_SegmentedViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<double>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESGraph_Color>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_LineFontEntity>>> & ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (IGESDraw_SegmentedViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<double>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESGraph_Color>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_LineFontEntity>>> & ,   const handle<NCollection_HArray1<int>> &  ) >(&IGESDraw_SegmentedViewsVisible::Init),
             R"#(This method is used to set the fields of the class SegmentedViewsVisible - allViews : Pointers to View Entities - allBreakpointParameters : Parameters of breakpoints - allDisplayFlags : Display flags - allColorValues : Color Values - allColorDefinitions : Color Definitions - allLineFontValues : LineFont values - allLineFontDefinitions : LineFont Definitions - allLineWeights : Line weights raises exception if Lengths of allViews, allBreakpointParameters, allDisplayFlags, allColorValues, allColorDefinitions, allLineFontValues, allLineFontDefinitions and allLineWeights are not same.)#"  , py::arg("allViews"),  py::arg("allBreakpointParameters"),  py::arg("allDisplayFlags"),  py::arg("allColorValues"),  py::arg("allColorDefinitions"),  py::arg("allLineFontValues"),  py::arg("allLineFontDefinitions"),  py::arg("allLineWeights")
          )
        .def("IsSingle",
             (bool (IGESDraw_SegmentedViewsVisible::*)() const) static_cast<bool (IGESDraw_SegmentedViewsVisible::*)() const>(&IGESDraw_SegmentedViewsVisible::IsSingle),
             R"#(Returns False (for a complex view))#" 
          )
        .def("NbViews",
             (int (IGESDraw_SegmentedViewsVisible::*)() const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)() const>(&IGESDraw_SegmentedViewsVisible::NbViews),
             R"#(Returns the count of Views referenced by <me> (inherited))#" 
          )
        .def("NbSegmentBlocks",
             (int (IGESDraw_SegmentedViewsVisible::*)() const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)() const>(&IGESDraw_SegmentedViewsVisible::NbSegmentBlocks),
             R"#(returns the number of view/segment blocks in <me> Similar to NbViews but has a more general significance)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::ViewItem),
             R"#(returns the View entity indicated by ViewIndex raises an exception if ViewIndex <= 0 or ViewIndex > NbSegmentBlocks())#"  , py::arg("ViewIndex")
          )
        .def("BreakpointParameter",
             (double (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<double (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::BreakpointParameter),
             R"#(returns the parameter of the breakpoint indicated by BreakpointIndex raises an exception if BreakpointIndex <= 0 or BreakpointIndex > NbSegmentBlocks().)#"  , py::arg("BreakpointIndex")
          )
        .def("DisplayFlag",
             (int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::DisplayFlag),
             R"#(returns the Display flag indicated by FlagIndex raises an exception if FlagIndex <= 0 or FlagIndex > NbSegmentBlocks().)#"  , py::arg("FlagIndex")
          )
        .def("IsColorDefinition",
             (bool (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<bool (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::IsColorDefinition),
             R"#(returns True if the ColorIndex'th value of the "theColorDefinitions" field of <me> is a pointer raises an exception if ColorIndex <= 0 or ColorIndex > NbSegmentBlocks().)#"  , py::arg("ColorIndex")
          )
        .def("ColorValue",
             (int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::ColorValue),
             R"#(returns the Color value indicated by ColorIndex raises an exception if ColorIndex <= 0 or ColorIndex > NbSegmentBlocks().)#"  , py::arg("ColorIndex")
          )
        .def("ColorDefinition",
             (handle<IGESGraph_Color> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<handle<IGESGraph_Color> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::ColorDefinition),
             R"#(returns the Color definition entity indicated by ColorIndex raises an exception if ColorIndex <= 0 or ColorIndex > NbSegmentBlocks().)#"  , py::arg("ColorIndex")
          )
        .def("IsFontDefinition",
             (bool (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<bool (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::IsFontDefinition),
             R"#(returns True if the FontIndex'th value of the "theLineFontDefinitions" field of <me> is a pointer raises an exception if FontIndex <= 0 or FontIndex > NbSegmentBlocks().)#"  , py::arg("FontIndex")
          )
        .def("LineFontValue",
             (int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::LineFontValue),
             R"#(returns the LineFont value indicated by FontIndex raises an exception if FontIndex <= 0 or FontIndex > NbSegmentBlocks().)#"  , py::arg("FontIndex")
          )
        .def("LineFontDefinition",
             (handle<IGESData_LineFontEntity> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<handle<IGESData_LineFontEntity> (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::LineFontDefinition),
             R"#(returns the LineFont definition entity indicated by FontIndex raises an exception if FontIndex <= 0 or FontIndex > NbSegmentBlocks().)#"  , py::arg("FontIndex")
          )
        .def("LineWeightItem",
             (int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const) static_cast<int (IGESDraw_SegmentedViewsVisible::*)(  const int  ) const>(&IGESDraw_SegmentedViewsVisible::LineWeightItem),
             R"#(returns the LineWeight value indicated by WeightIndex raises an exception if WeightIndex <= 0 or WeightIndex > NbSegmentBlocks().)#"  , py::arg("WeightIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_SegmentedViewsVisible::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_SegmentedViewsVisible::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_SegmentedViewsVisible::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_SegmentedViewsVisible::*)() const>(&IGESDraw_SegmentedViewsVisible::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_SpecificModule from ./opencascade/IGESDraw_SpecificModule.hxx
    klass = m.attr("IGESDraw_SpecificModule");


    // nested enums

    static_cast<py::class_<IGESDraw_SpecificModule ,opencascade::handle<IGESDraw_SpecificModule>  , IGESData_SpecificModule >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("OwnDump",
             (void (IGESDraw_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_SpecificModule::OwnDump),
             R"#(Specific Dump (own parameters) for IGESDraw)#"  , py::arg("CN"),  py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const) static_cast<bool (IGESDraw_SpecificModule::*)(  const int ,   const handle<IGESData_IGESEntity> &  ) const>(&IGESDraw_SpecificModule::OwnCorrect),
             R"#(Performs non-ambiguous Corrections on Entities which support them (Planar))#"  , py::arg("CN"),  py::arg("ent")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_SpecificModule::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_SpecificModule::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_SpecificModule::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_SpecificModule::*)() const>(&IGESDraw_SpecificModule::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_ToolCircArraySubfigure from ./opencascade/IGESDraw_ToolCircArraySubfigure.hxx
    klass = m.attr("IGESDraw_ToolCircArraySubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolCircArraySubfigure , shared_ptr<IGESDraw_ToolCircArraySubfigure>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolCircArraySubfigure::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolCircArraySubfigure::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolCircArraySubfigure::OwnShared),
             R"#(Lists the Entities shared by a CircArraySubfigure <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> &  ) const>(&IGESDraw_ToolCircArraySubfigure::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const handle<IGESDraw_CircArraySubfigure> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const handle<IGESDraw_CircArraySubfigure> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolCircArraySubfigure::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolCircArraySubfigure::*)(  const handle<IGESDraw_CircArraySubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolCircArraySubfigure::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolCircArraySubfigure &self ,  const handle<IGESDraw_CircArraySubfigure> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolConnectPoint from ./opencascade/IGESDraw_ToolConnectPoint.hxx
    klass = m.attr("IGESDraw_ToolConnectPoint");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolConnectPoint , shared_ptr<IGESDraw_ToolConnectPoint>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolConnectPoint::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolConnectPoint::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolConnectPoint::OwnShared),
             R"#(Lists the Entities shared by a ConnectPoint <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> &  ) const>(&IGESDraw_ToolConnectPoint::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const handle<IGESDraw_ConnectPoint> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const handle<IGESDraw_ConnectPoint> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolConnectPoint::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolConnectPoint::*)(  const handle<IGESDraw_ConnectPoint> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolConnectPoint::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolConnectPoint &self ,  const handle<IGESDraw_ConnectPoint> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolDrawing from ./opencascade/IGESDraw_ToolDrawing.hxx
    klass = m.attr("IGESDraw_ToolDrawing");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolDrawing , shared_ptr<IGESDraw_ToolDrawing>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolDrawing::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolDrawing::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolDrawing::OwnShared),
             R"#(Lists the Entities shared by a Drawing <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> &  ) const) static_cast<bool (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> &  ) const>(&IGESDraw_ToolDrawing::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a Drawing (Null Views are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> &  ) const>(&IGESDraw_ToolDrawing::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const handle<IGESDraw_Drawing> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const handle<IGESDraw_Drawing> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolDrawing::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolDrawing::*)(  const handle<IGESDraw_Drawing> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolDrawing::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolDrawing &self ,  const handle<IGESDraw_Drawing> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolDrawingWithRotation from ./opencascade/IGESDraw_ToolDrawingWithRotation.hxx
    klass = m.attr("IGESDraw_ToolDrawingWithRotation");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolDrawingWithRotation , shared_ptr<IGESDraw_ToolDrawingWithRotation>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolDrawingWithRotation::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolDrawingWithRotation::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolDrawingWithRotation::OwnShared),
             R"#(Lists the Entities shared by a DrawingWithRotation <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> &  ) const) static_cast<bool (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> &  ) const>(&IGESDraw_ToolDrawingWithRotation::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a DrawingWithRotation (Null Views are removed from list))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> &  ) const>(&IGESDraw_ToolDrawingWithRotation::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const handle<IGESDraw_DrawingWithRotation> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const handle<IGESDraw_DrawingWithRotation> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolDrawingWithRotation::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolDrawingWithRotation::*)(  const handle<IGESDraw_DrawingWithRotation> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolDrawingWithRotation::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolDrawingWithRotation &self ,  const handle<IGESDraw_DrawingWithRotation> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolLabelDisplay from ./opencascade/IGESDraw_ToolLabelDisplay.hxx
    klass = m.attr("IGESDraw_ToolLabelDisplay");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolLabelDisplay , shared_ptr<IGESDraw_ToolLabelDisplay>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolLabelDisplay::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolLabelDisplay::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolLabelDisplay::OwnShared),
             R"#(Lists the Entities shared by a LabelDisplay <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> &  ) const>(&IGESDraw_ToolLabelDisplay::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const handle<IGESDraw_LabelDisplay> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const handle<IGESDraw_LabelDisplay> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolLabelDisplay::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolLabelDisplay::*)(  const handle<IGESDraw_LabelDisplay> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolLabelDisplay::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolLabelDisplay &self ,  const handle<IGESDraw_LabelDisplay> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolNetworkSubfigure from ./opencascade/IGESDraw_ToolNetworkSubfigure.hxx
    klass = m.attr("IGESDraw_ToolNetworkSubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolNetworkSubfigure , shared_ptr<IGESDraw_ToolNetworkSubfigure>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolNetworkSubfigure::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolNetworkSubfigure::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolNetworkSubfigure::OwnShared),
             R"#(Lists the Entities shared by a NetworkSubfigure <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> &  ) const>(&IGESDraw_ToolNetworkSubfigure::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const handle<IGESDraw_NetworkSubfigure> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const handle<IGESDraw_NetworkSubfigure> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolNetworkSubfigure::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigure::*)(  const handle<IGESDraw_NetworkSubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolNetworkSubfigure::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolNetworkSubfigure &self ,  const handle<IGESDraw_NetworkSubfigure> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolNetworkSubfigureDef from ./opencascade/IGESDraw_ToolNetworkSubfigureDef.hxx
    klass = m.attr("IGESDraw_ToolNetworkSubfigureDef");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolNetworkSubfigureDef , shared_ptr<IGESDraw_ToolNetworkSubfigureDef>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolNetworkSubfigureDef::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolNetworkSubfigureDef::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolNetworkSubfigureDef::OwnShared),
             R"#(Lists the Entities shared by a NetworkSubfigureDef <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> &  ) const>(&IGESDraw_ToolNetworkSubfigureDef::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const handle<IGESDraw_NetworkSubfigureDef> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const handle<IGESDraw_NetworkSubfigureDef> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolNetworkSubfigureDef::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolNetworkSubfigureDef::*)(  const handle<IGESDraw_NetworkSubfigureDef> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolNetworkSubfigureDef::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolNetworkSubfigureDef &self ,  const handle<IGESDraw_NetworkSubfigureDef> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolPerspectiveView from ./opencascade/IGESDraw_ToolPerspectiveView.hxx
    klass = m.attr("IGESDraw_ToolPerspectiveView");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolPerspectiveView , shared_ptr<IGESDraw_ToolPerspectiveView>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolPerspectiveView::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolPerspectiveView::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolPerspectiveView::OwnShared),
             R"#(Lists the Entities shared by a PerspectiveView <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> &  ) const>(&IGESDraw_ToolPerspectiveView::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const handle<IGESDraw_PerspectiveView> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const handle<IGESDraw_PerspectiveView> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolPerspectiveView::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolPerspectiveView::*)(  const handle<IGESDraw_PerspectiveView> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolPerspectiveView::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolPerspectiveView &self ,  const handle<IGESDraw_PerspectiveView> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolPlanar from ./opencascade/IGESDraw_ToolPlanar.hxx
    klass = m.attr("IGESDraw_ToolPlanar");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolPlanar , shared_ptr<IGESDraw_ToolPlanar>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolPlanar::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolPlanar::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolPlanar::OwnShared),
             R"#(Lists the Entities shared by a Planar <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> &  ) const) static_cast<bool (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> &  ) const>(&IGESDraw_ToolPlanar::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a Planar (NbMatrices forced to 1))#"  , py::arg("ent")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> &  ) const>(&IGESDraw_ToolPlanar::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const handle<IGESDraw_Planar> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const handle<IGESDraw_Planar> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolPlanar::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolPlanar::*)(  const handle<IGESDraw_Planar> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolPlanar::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolPlanar &self ,  const handle<IGESDraw_Planar> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolRectArraySubfigure from ./opencascade/IGESDraw_ToolRectArraySubfigure.hxx
    klass = m.attr("IGESDraw_ToolRectArraySubfigure");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolRectArraySubfigure , shared_ptr<IGESDraw_ToolRectArraySubfigure>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolRectArraySubfigure::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolRectArraySubfigure::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolRectArraySubfigure::OwnShared),
             R"#(Lists the Entities shared by a RectArraySubfigure <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> &  ) const>(&IGESDraw_ToolRectArraySubfigure::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const handle<IGESDraw_RectArraySubfigure> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const handle<IGESDraw_RectArraySubfigure> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolRectArraySubfigure::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolRectArraySubfigure::*)(  const handle<IGESDraw_RectArraySubfigure> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolRectArraySubfigure::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolRectArraySubfigure &self ,  const handle<IGESDraw_RectArraySubfigure> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolSegmentedViewsVisible from ./opencascade/IGESDraw_ToolSegmentedViewsVisible.hxx
    klass = m.attr("IGESDraw_ToolSegmentedViewsVisible");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolSegmentedViewsVisible , shared_ptr<IGESDraw_ToolSegmentedViewsVisible>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolSegmentedViewsVisible::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolSegmentedViewsVisible::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolSegmentedViewsVisible::OwnShared),
             R"#(Lists the Entities shared by a SegmentedViewsVisible <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> &  ) const>(&IGESDraw_ToolSegmentedViewsVisible::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const handle<IGESDraw_SegmentedViewsVisible> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const handle<IGESDraw_SegmentedViewsVisible> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolSegmentedViewsVisible::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolSegmentedViewsVisible::*)(  const handle<IGESDraw_SegmentedViewsVisible> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolSegmentedViewsVisible::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolSegmentedViewsVisible &self ,  const handle<IGESDraw_SegmentedViewsVisible> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolView from ./opencascade/IGESDraw_ToolView.hxx
    klass = m.attr("IGESDraw_ToolView");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolView , shared_ptr<IGESDraw_ToolView>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolView::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolView::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolView::OwnShared),
             R"#(Lists the Entities shared by a View <ent>, from its specific (own) parameters)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> &  ) const>(&IGESDraw_ToolView::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const handle<IGESDraw_View> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const handle<IGESDraw_View> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolView::OwnCopy),
             R"#(Copies Specific Parameters)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolView::*)(  const handle<IGESDraw_View> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolView::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolView &self ,  const handle<IGESDraw_View> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolViewsVisible from ./opencascade/IGESDraw_ToolViewsVisible.hxx
    klass = m.attr("IGESDraw_ToolViewsVisible");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolViewsVisible , shared_ptr<IGESDraw_ToolViewsVisible>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolViewsVisible::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolViewsVisible::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolViewsVisible::OwnShared),
             R"#(Lists the Entities shared by a ViewsVisible <ent>, from its specific (own) parameters shared not implied (the Views))#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnImplied",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolViewsVisible::OwnImplied),
             R"#(Lists the Entities shared by a ViewsVisible <ent>, from its specific (own) implied parameters : the Displayed Entities)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const>(&IGESDraw_ToolViewsVisible::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESDraw_ViewsVisible> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESDraw_ViewsVisible> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolViewsVisible::OwnCopy),
             R"#(Copies Specific Parameters shared not implied, i.e. all but the Displayed Entities)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnRenew",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESDraw_ViewsVisible> & ,   const Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const handle<IGESDraw_ViewsVisible> & ,   const Interface_CopyTool &  ) const>(&IGESDraw_ToolViewsVisible::OwnRenew),
             R"#(Copies Specific implied Parameters : the Displayed Entities which have already been copied)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnWhenDelete",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const>(&IGESDraw_ToolViewsVisible::OwnWhenDelete),
             R"#(Clears specific implied parameters, which cause looping structures; required for deletion)#"  , py::arg("ent")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolViewsVisible::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const) static_cast<bool (IGESDraw_ToolViewsVisible::*)(  const handle<IGESDraw_ViewsVisible> &  ) const>(&IGESDraw_ToolViewsVisible::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a ViewsVisible (all displayed entities must refer to <ent> in directory part, else the list is cleared))#"  , py::arg("ent")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolViewsVisible &self ,  const handle<IGESDraw_ViewsVisible> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_ToolViewsVisibleWithAttr from ./opencascade/IGESDraw_ToolViewsVisibleWithAttr.hxx
    klass = m.attr("IGESDraw_ToolViewsVisibleWithAttr");


    // nested enums

    static_cast<py::class_<IGESDraw_ToolViewsVisibleWithAttr , shared_ptr<IGESDraw_ToolViewsVisibleWithAttr>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ReadOwnParams",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESData_IGESReaderData> & ,  IGESData_ParamReader &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::ReadOwnParams),
             R"#(Reads own parameters from file. <PR> gives access to them, <IR> detains parameter types and values)#"  , py::arg("ent"),  py::arg("IR"),  py::arg("PR")
          )
        .def("WriteOwnParams",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  IGESData_IGESWriter &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  IGESData_IGESWriter &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::WriteOwnParams),
             R"#(Writes own parameters to IGESWriter)#"  , py::arg("ent"),  py::arg("IW")
          )
        .def("OwnShared",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnShared),
             R"#(Lists the Entities shared by a ViewsVisibleWithAttr <ent>, from its specific (own) parameters shared not implied, i.e. all but the Displayed Entities)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("OwnImplied",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_EntityIterator &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_EntityIterator &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnImplied),
             R"#(Lists the Entities shared by a ViewsVisible <ent>, from its specific (own) implied parameters : the Displayed Entities)#"  , py::arg("ent"),  py::arg("iter")
          )
        .def("DirChecker",
             (IGESData_DirChecker (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const) static_cast<IGESData_DirChecker (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::DirChecker),
             R"#(Returns specific DirChecker)#"  , py::arg("ent")
          )
        .def("OwnCopy",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESDraw_ViewsVisibleWithAttr> & ,  Interface_CopyTool &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnCopy),
             R"#(Copies Specific Parameters shared not implied, i.e. all but the Displayed Entities)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnRenew",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const Interface_CopyTool &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const Interface_CopyTool &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnRenew),
             R"#(Copies Specific implied Parameters : the Displayed Entities which have already been copied)#"  , py::arg("entfrom"),  py::arg("entto"),  py::arg("TC")
          )
        .def("OwnWhenDelete",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnWhenDelete),
             R"#(Clears specific implied parameters, which cause looping structures; required for deletion)#"  , py::arg("ent")
          )
        .def("OwnDump",
             (void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const) static_cast<void (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> & ,   const IGESData_IGESDumper & ,  Standard_OStream & ,   const int  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnDump),
             R"#(Dump of Specific Parameters)#"  , py::arg("ent"),  py::arg("dumper"),  py::arg("S"),  py::arg("own")
          )
        .def("OwnCorrect",
             (bool (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const) static_cast<bool (IGESDraw_ToolViewsVisibleWithAttr::*)(  const handle<IGESDraw_ViewsVisibleWithAttr> &  ) const>(&IGESDraw_ToolViewsVisibleWithAttr::OwnCorrect),
             R"#(Sets automatic unambiguous Correction on a ViewsVisibleWithAttr (all displayed entities must refer to <ent> in directory part, else the list is cleared))#"  , py::arg("ent")
          )
    // methods using call by reference i.s.o. return
        .def("OwnCheck",
             []( IGESDraw_ToolViewsVisibleWithAttr &self ,  const handle<IGESDraw_ViewsVisibleWithAttr> & ent, const Interface_ShareTool & shares,Interface_Check& ach ){
                 handle<Interface_Check>  ach_ptr; ach_ptr = &ach;

                 self.OwnCheck(ent,shares,ach_ptr);
                 return std::make_tuple(ach_ptr); },
             R"#(Performs Specific Semantic Check)#"  , py::arg("ent"),  py::arg("shares"),  py::arg("ach")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IGESDraw_View from ./opencascade/IGESDraw_View.hxx
    klass = m.attr("IGESDraw_View");


    // nested enums

    static_cast<py::class_<IGESDraw_View ,opencascade::handle<IGESDraw_View>  , IGESData_ViewKindEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_View::*)(  const int ,   const double ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> &  ) ) static_cast<void (IGESDraw_View::*)(  const int ,   const double ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> & ,   const handle<IGESGeom_Plane> &  ) >(&IGESDraw_View::Init),
             R"#(This method is used to set fields of the class View - aViewNum : View number - aScale : Scale factor - aLeftPlane : Left plane of view volume - aTopPlane : Top plane of view volume - aRightPlane : Right plane of view volume - aBottomPlane : Bottom plane of view volume - aBackPlane : Back plane of view volume - aFrontPlane : Front plane of view volume)#"  , py::arg("aViewNum"),  py::arg("aScale"),  py::arg("aLeftPlane"),  py::arg("aTopPlane"),  py::arg("aRightPlane"),  py::arg("aBottomPlane"),  py::arg("aBackPlane"),  py::arg("aFrontPlane")
          )
        .def("IsSingle",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::IsSingle),
             R"#(Returns True (for a single view))#" 
          )
        .def("NbViews",
             (int (IGESDraw_View::*)() const) static_cast<int (IGESDraw_View::*)() const>(&IGESDraw_View::NbViews),
             R"#(Returns 1 (single view))#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_View::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_View::*)(  const int  ) const>(&IGESDraw_View::ViewItem),
             R"#(For a single view, returns <me> whatever <num>)#"  , py::arg("num")
          )
        .def("ViewNumber",
             (int (IGESDraw_View::*)() const) static_cast<int (IGESDraw_View::*)() const>(&IGESDraw_View::ViewNumber),
             R"#(returns integer number identifying view orientation)#" 
          )
        .def("ScaleFactor",
             (double (IGESDraw_View::*)() const) static_cast<double (IGESDraw_View::*)() const>(&IGESDraw_View::ScaleFactor),
             R"#(returns the scale factor(Default = 1.0))#" 
          )
        .def("HasLeftPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasLeftPlane),
             R"#(returns False if left side of view volume is not present)#" 
          )
        .def("LeftPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::LeftPlane),
             R"#(returns the left side of view volume, or null handle)#" 
          )
        .def("HasTopPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasTopPlane),
             R"#(returns False if top of view volume is not present)#" 
          )
        .def("TopPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::TopPlane),
             R"#(returns the top of view volume, or null handle)#" 
          )
        .def("HasRightPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasRightPlane),
             R"#(returns False if right side of view volume is not present)#" 
          )
        .def("RightPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::RightPlane),
             R"#(returns the right side of view volume, or null handle)#" 
          )
        .def("HasBottomPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasBottomPlane),
             R"#(returns False if bottom of view volume is not present)#" 
          )
        .def("BottomPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::BottomPlane),
             R"#(returns the bottom of view volume, or null handle)#" 
          )
        .def("HasBackPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasBackPlane),
             R"#(returns False if back of view volume is not present)#" 
          )
        .def("BackPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::BackPlane),
             R"#(returns the back of view volume, or null handle)#" 
          )
        .def("HasFrontPlane",
             (bool (IGESDraw_View::*)() const) static_cast<bool (IGESDraw_View::*)() const>(&IGESDraw_View::HasFrontPlane),
             R"#(returns False if front of view volume is not present)#" 
          )
        .def("FrontPlane",
             (handle<IGESGeom_Plane> (IGESDraw_View::*)() const) static_cast<handle<IGESGeom_Plane> (IGESDraw_View::*)() const>(&IGESDraw_View::FrontPlane),
             R"#(returns the front of view volume, or null handle)#" 
          )
        .def("ViewMatrix",
             (handle<IGESData_TransfEntity> (IGESDraw_View::*)() const) static_cast<handle<IGESData_TransfEntity> (IGESDraw_View::*)() const>(&IGESDraw_View::ViewMatrix),
             R"#(returns the Transformation Matrix)#" 
          )
        .def("ModelToView",
             (gp_XYZ (IGESDraw_View::*)(  const gp_XYZ &  ) const) static_cast<gp_XYZ (IGESDraw_View::*)(  const gp_XYZ &  ) const>(&IGESDraw_View::ModelToView),
             R"#(returns XYZ from the Model space to the View space by applying the View Matrix)#"  , py::arg("coords")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_View::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_View::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_View::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_View::*)() const>(&IGESDraw_View::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_ViewsVisible from ./opencascade/IGESDraw_ViewsVisible.hxx
    klass = m.attr("IGESDraw_ViewsVisible");


    // nested enums

    static_cast<py::class_<IGESDraw_ViewsVisible ,opencascade::handle<IGESDraw_ViewsVisible>  , IGESData_ViewKindEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_ViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_ViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_ViewsVisible::Init),
             R"#(This method is used to set the fields of the class ViewsVisible - allViewEntities : All View kind entities - allDisplayEntity : All entities whose display is specified)#"  , py::arg("allViewEntities"),  py::arg("allDisplayEntity")
          )
        .def("InitImplied",
             (void (IGESDraw_ViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_ViewsVisible::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_ViewsVisible::InitImplied),
             R"#(Changes only the list of Displayed Entities (Null allowed))#"  , py::arg("allDisplayEntity")
          )
        .def("IsSingle",
             (bool (IGESDraw_ViewsVisible::*)() const) static_cast<bool (IGESDraw_ViewsVisible::*)() const>(&IGESDraw_ViewsVisible::IsSingle),
             R"#(Returns False (for a complex view))#" 
          )
        .def("NbViews",
             (int (IGESDraw_ViewsVisible::*)() const) static_cast<int (IGESDraw_ViewsVisible::*)() const>(&IGESDraw_ViewsVisible::NbViews),
             R"#(returns the Number of views visible)#" 
          )
        .def("NbDisplayedEntities",
             (int (IGESDraw_ViewsVisible::*)() const) static_cast<int (IGESDraw_ViewsVisible::*)() const>(&IGESDraw_ViewsVisible::NbDisplayedEntities),
             R"#(returns the number of entities displayed in the Views or zero if no Entities specified in these Views)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_ViewsVisible::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_ViewsVisible::*)(  const int  ) const>(&IGESDraw_ViewsVisible::ViewItem),
             R"#(returns the Index'th ViewKindEntity Entity raises exception if Index <= 0 or Index > NbViewsVisible())#"  , py::arg("Index")
          )
        .def("DisplayedEntity",
             (handle<IGESData_IGESEntity> (IGESDraw_ViewsVisible::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_ViewsVisible::*)(  const int  ) const>(&IGESDraw_ViewsVisible::DisplayedEntity),
             R"#(returns the Index'th entity whose display is being specified by this associativity instance raises exception if Index <= 0 or Index > NbEntityDisplayed())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_ViewsVisible::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_ViewsVisible::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_ViewsVisible::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_ViewsVisible::*)() const>(&IGESDraw_ViewsVisible::DynamicType),
             R"#()#"
             
         )
;

    // Class IGESDraw_ViewsVisibleWithAttr from ./opencascade/IGESDraw_ViewsVisibleWithAttr.hxx
    klass = m.attr("IGESDraw_ViewsVisibleWithAttr");


    // nested enums

    static_cast<py::class_<IGESDraw_ViewsVisibleWithAttr ,opencascade::handle<IGESDraw_ViewsVisibleWithAttr>  , IGESData_ViewKindEntity >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (IGESDraw_ViewsVisibleWithAttr::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_LineFontEntity>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESGraph_Color>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_ViewsVisibleWithAttr::*)(  const handle<NCollection_HArray1<handle<IGESData_ViewKindEntity>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_LineFontEntity>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESGraph_Color>>> & ,   const handle<NCollection_HArray1<int>> & ,   const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_ViewsVisibleWithAttr::Init),
             R"#(This method is used to set fields of the class ViewsVisibleWithAttr - allViewEntities : All View kind entities - allLineFonts : All Line Font values or zero(0) - allLineDefinitions : Line Font Definition (if Line Font value = 0) - allColorValues : All Color values - allColorDefinitions : All Color Definition Entities - allLineWeights : All Line Weight values - allDisplayEntities : Entities which are member of this associativity raises exception if Lengths of allViewEntities, allLineFonts, allColorValues,allColorDefinitions, allLineWeights are not same)#"  , py::arg("allViewEntities"),  py::arg("allLineFonts"),  py::arg("allLineDefinitions"),  py::arg("allColorValues"),  py::arg("allColorDefinitions"),  py::arg("allLineWeights"),  py::arg("allDisplayEntities")
          )
        .def("InitImplied",
             (void (IGESDraw_ViewsVisibleWithAttr::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) ) static_cast<void (IGESDraw_ViewsVisibleWithAttr::*)(  const handle<NCollection_HArray1<handle<IGESData_IGESEntity>>> &  ) >(&IGESDraw_ViewsVisibleWithAttr::InitImplied),
             R"#(Changes only the list of Displayed Entities (Null allowed))#"  , py::arg("allDisplayEntity")
          )
        .def("IsSingle",
             (bool (IGESDraw_ViewsVisibleWithAttr::*)() const) static_cast<bool (IGESDraw_ViewsVisibleWithAttr::*)() const>(&IGESDraw_ViewsVisibleWithAttr::IsSingle),
             R"#(Returns False (for a complex view))#" 
          )
        .def("NbViews",
             (int (IGESDraw_ViewsVisibleWithAttr::*)() const) static_cast<int (IGESDraw_ViewsVisibleWithAttr::*)() const>(&IGESDraw_ViewsVisibleWithAttr::NbViews),
             R"#(returns the number of Views containing the view visible, line font, color number, and line weight information)#" 
          )
        .def("NbDisplayedEntities",
             (int (IGESDraw_ViewsVisibleWithAttr::*)() const) static_cast<int (IGESDraw_ViewsVisibleWithAttr::*)() const>(&IGESDraw_ViewsVisibleWithAttr::NbDisplayedEntities),
             R"#(returns the number of entities which have this particular set of display characteristic, or zero if no Entities specified)#" 
          )
        .def("ViewItem",
             (handle<IGESData_ViewKindEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<handle<IGESData_ViewKindEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::ViewItem),
             R"#(returns the Index'th ViewKindEntity entity raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("LineFontValue",
             (int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::LineFontValue),
             R"#(returns the Index'th Line font value or zero raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("IsFontDefinition",
             (bool (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<bool (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::IsFontDefinition),
             R"#(returns True if the Index'th Line Font Definition is specified else returns False raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("FontDefinition",
             (handle<IGESData_LineFontEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<handle<IGESData_LineFontEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::FontDefinition),
             R"#(returns the Index'th Line Font Definition Entity or NULL(0) raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("ColorValue",
             (int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::ColorValue),
             R"#(returns the Index'th Color number value raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("IsColorDefinition",
             (bool (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<bool (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::IsColorDefinition),
             R"#(returns True if Index'th Color Definition is specified else returns False raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("ColorDefinition",
             (handle<IGESGraph_Color> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<handle<IGESGraph_Color> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::ColorDefinition),
             R"#(returns the Index'th Color Definition Entity raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("LineWeightItem",
             (int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<int (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::LineWeightItem),
             R"#(returns the Index'th Color Line Weight raises exception if Index <= 0 or Index > NbViews())#"  , py::arg("Index")
          )
        .def("DisplayedEntity",
             (handle<IGESData_IGESEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const) static_cast<handle<IGESData_IGESEntity> (IGESDraw_ViewsVisibleWithAttr::*)(  const int  ) const>(&IGESDraw_ViewsVisibleWithAttr::DisplayedEntity),
             R"#(returns Index'th Display entity with this particular characteristics raises exception if Index <= 0 or Index > NbEntities())#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IGESDraw_ViewsVisibleWithAttr::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IGESDraw_ViewsVisibleWithAttr::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IGESDraw_ViewsVisibleWithAttr::*)() const) static_cast< const handle<Standard_Type> & (IGESDraw_ViewsVisibleWithAttr::*)() const>(&IGESDraw_ViewsVisibleWithAttr::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/IGESDraw.hxx
// ./opencascade/IGESDraw_CircArraySubfigure.hxx
// ./opencascade/IGESDraw_ConnectPoint.hxx
// ./opencascade/IGESDraw_Drawing.hxx
// ./opencascade/IGESDraw_DrawingWithRotation.hxx
// ./opencascade/IGESDraw_GeneralModule.hxx
// ./opencascade/IGESDraw_LabelDisplay.hxx
// ./opencascade/IGESDraw_NetworkSubfigure.hxx
// ./opencascade/IGESDraw_NetworkSubfigureDef.hxx
// ./opencascade/IGESDraw_PerspectiveView.hxx
// ./opencascade/IGESDraw_Planar.hxx
// ./opencascade/IGESDraw_Protocol.hxx
// ./opencascade/IGESDraw_ReadWriteModule.hxx
// ./opencascade/IGESDraw_RectArraySubfigure.hxx
// ./opencascade/IGESDraw_SegmentedViewsVisible.hxx
// ./opencascade/IGESDraw_SpecificModule.hxx
// ./opencascade/IGESDraw_ToolCircArraySubfigure.hxx
// ./opencascade/IGESDraw_ToolConnectPoint.hxx
// ./opencascade/IGESDraw_ToolDrawing.hxx
// ./opencascade/IGESDraw_ToolDrawingWithRotation.hxx
// ./opencascade/IGESDraw_ToolLabelDisplay.hxx
// ./opencascade/IGESDraw_ToolNetworkSubfigure.hxx
// ./opencascade/IGESDraw_ToolNetworkSubfigureDef.hxx
// ./opencascade/IGESDraw_ToolPerspectiveView.hxx
// ./opencascade/IGESDraw_ToolPlanar.hxx
// ./opencascade/IGESDraw_ToolRectArraySubfigure.hxx
// ./opencascade/IGESDraw_ToolSegmentedViewsVisible.hxx
// ./opencascade/IGESDraw_ToolView.hxx
// ./opencascade/IGESDraw_ToolViewsVisible.hxx
// ./opencascade/IGESDraw_ToolViewsVisibleWithAttr.hxx
// ./opencascade/IGESDraw_View.hxx
// ./opencascade/IGESDraw_ViewsVisible.hxx
// ./opencascade/IGESDraw_ViewsVisibleWithAttr.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
